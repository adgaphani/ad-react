const fs = require('fs');
const { ipcRenderer } = require('electron');
const path = require('path');

const itragetpath = './TermsAndCondtionData.txt';

ipcRenderer.on('sendbackhtml', (event, arg) => {
  // console.log('preload: received sendbackhtml');
  const filepath = path.join(__dirname, itragetpath);
  // console.log(filepath,arg);
  if (arg === 'ReadTerms') {
    const iFileData = fs.readFileSync(filepath, {
      encoding: 'utf8',
      flag: 'r',
    });
    // console.log(iFileData);
    ipcRenderer.send('termsdetails', iFileData);
  } else {
    const idata = document.getElementsByTagName('main');
    if (idata[0].innerHTML.length > 0) {
      const iTempterms = idata[0].innerHTML.replace(
        /<a/g,
        "<a onclick='return false;' class='isDisabled'"
      );
      const iTempterms1 = iTempterms.replace(/TERMS &amp; CONDITIONS/g, '');
      const iTempterms2 = iTempterms1.replace(/Table of Contents/g, '');
      const iTempterms3 = iTempterms2.replace(
        /div class="index-wrapper"/g,
        "div class='index-wrapper' hidden"
      );
      const iModifiedTermsAndCondition = iTempterms3.replace(
        /TERMS AND CONDITIONS/g,
        ''
      );
      /* var iModifiedTermsAndCondition = iTempterms4.replace(
        /"><strong>Last Updated:/g,
        "hidden '><strong>Last Updated:"
      );
      var iModifiedTermsAndCondition = iTempterms4.replace(
        /">Last Updated:/g,
        "hidden '>Last Updated:"
      ); */
      fs.writeFileSync(filepath, iModifiedTermsAndCondition);
      ipcRenderer.send('termsdetails', iModifiedTermsAndCondition);
    }
  }
});
