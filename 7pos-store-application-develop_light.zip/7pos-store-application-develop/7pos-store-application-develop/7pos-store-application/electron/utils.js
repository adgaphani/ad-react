const dns = require('dns');
const ip = require('ip');
const {
  OposCoinDispenser,
  SerialCoinDispenser,
} = require('./CoinDispenser/CoinDispenser');
const { IpDvr, SerialDvr } = require('./DVR/DVR');

const resolveHostOrConstructIP = async (hostName, lastOctet) =>
  new Promise(resolve => {
    dns.resolve4(hostName, (err, addresses) => {
      if (err) {
        console.log(`${hostName} resolve error`, err);

        const addr = ip.address('public', 'ipv4');
        console.log('host ip', addr);

        const parts = addr.split('.');
        parts[parts.length - 1] = lastOctet;
        return resolve(parts.join('.'));
      }

      console.log(`${hostName} IP's`, addresses);
      return resolve(addresses[0]);
    });
  });

const createCoinDispenser = async config =>
  config.enabled
    ? config.is_2bcd
      ? new SerialCoinDispenser(config)
      : new OposCoinDispenser(config)
    : null;

const createDvr = async config => {
  if (config.enabled) {
    if (config.type === 'serial') {
      return new SerialDvr(config);
    }

    if (config.host) {
      config.host = await resolveHostOrConstructIP(config.host, '181');
    }
    return new IpDvr(config);
  }

  return null;
};

module.exports = {
  createCoinDispenser,
  createDvr,
};
