const electron = require('electron');
const { ipcMain } = require('electron');
const os = require('os');
const path = require('path');

const { app, BrowserWindow } = electron;
const { createCoinDispenser, createDvr } = require('./utils');

if (process.env.NODE_ENV === 'dev') require('electron-reload');

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = 'true';
const isDev = process.env.NODE_ENV === 'dev';
const isMac = isDev && os.platform() === 'darwin';
// const isProd = process.env.NODE_ENV === 'prod';

let POSWindow;
let CFDWindow;
let childWindow;
let coinDispenser;
let dvr;

function createWindow() {
  const primaryDisplay = electron.screen.getPrimaryDisplay();
  POSWindow = new BrowserWindow({
    x: primaryDisplay.bounds.x,
    y: primaryDisplay.bounds.y,
    frame: false,
    closable: false,
    webPreferences: {
      nodeIntegration: true,
      // devTools: isDev,
    },
    width: 1024, // 7POS default width and height
    height: 768,
    title: '7POSApp',
  });
  if (isDev && isMac) {
    POSWindow.webContents.openDevTools();
  }
  POSWindow.maximize();
  POSWindow.setMenuBarVisibility(false);
  POSWindow.setAlwaysOnTop(!isDev);
  POSWindow.setKiosk(!isDev);
  POSWindow.loadURL(
    isDev ? 'http://localhost:3000' : `file://${__dirname}/../index.html`
  );

  POSWindow.on('closed', () => {
    POSWindow = null;
  });
}

function createSecondWindow() {
  const displays = electron.screen.getAllDisplays();
  const externalDisplay = displays.find(
    display => display.bounds.x !== 0 || display.bounds.y !== 0
  );
  if (externalDisplay) {
    console.log('CFD launched in External Screen');
    CFDWindow = new BrowserWindow({
      x: externalDisplay.bounds.x + 50,
      y: externalDisplay.bounds.y + 50,
      frame: false,
      closable: false,
      webPreferences: {
        nodeIntegration: true,
        webSecurity: !isDev,
        // devTools: isDev,
      },
      title: '7POSCFDApp',
    });
  } else if (isDev) {
    console.log('CFD launched in Primary Screen on Dev environment');
    CFDWindow = new BrowserWindow({
      frame: false,
      closable: false,
      webPreferences: {
        nodeIntegration: true,
        webSecurity: !isDev,
        // devTools: isDev,
      },
    });
  } else {
    console.log('CFD not launch due to not available external display');
  }

  if (CFDWindow) {
    if (isDev && isMac) {
      CFDWindow.webContents.openDevTools();
    }
    CFDWindow.maximize();
    CFDWindow.setMenuBarVisibility(false);
    CFDWindow.setAlwaysOnTop(!isDev);
    CFDWindow.setKiosk(!isDev);
    CFDWindow.loadURL(
      isDev
        ? 'http://localhost:3000?view=viewB'
        : `file://${__dirname}/../index.html?view=viewB`
    );

    childWindow = new BrowserWindow({
      parent: CFDWindow,
      center: true,
      minWidth: 800,
      minHeight: 600,
      show: false,
      frame: false,
      closable: false,
      webPreferences: {
        nodeIntegration: false,
        preload: path.join(__dirname, './childWindow.js'),
      },
    });
    // childWindow.webContents.openDevTools();
    if (childWindow) {
      childWindow.webContents.on('dom-ready', () => {
        // console.log('Before delay');
        setTimeout(() => {
          console.log('childWindow DOM-READY => send back html');
          childWindow.send('sendbackhtml');
        }, 5000);
      });
    }
    CFDWindow.on('closed', () => {
      CFDWindow = null;
    });
  }
}

// Event handler for asynchronous incoming messages
ipcMain.on('POS-message', (_, arg) => {
  // console.log(arg);
  // Event emitter for sending asynchronous messages
  if (CFDWindow) CFDWindow.webContents.send('TOCFD', arg);
});

const getUptime = () => {
  const isAppUpTime = process.uptime();
  console.log(isAppUpTime);
  const iTransactionMessage = {
    CMD: 'Uptime',
    UpTime: isAppUpTime,
  };
  console.log(iTransactionMessage);
  POSWindow.webContents.send('TOPOS', iTransactionMessage);
};

const shutdownHardware = async () => {
  if (dvr) {
    await dvr.stop();
    dvr = null;
  }

  if (coinDispenser) {
    await coinDispenser.stop();
    coinDispenser = null;
  }
};

ipcMain.on('Main-Message', (_, Command) => {
  console.log('Received CMD:', Command);
  if (Command === 'Restart') {
    app.relaunch();
    app.exit(0);
  } else if (Command === 'Shutdown') {
    app.exit(0);
  } else if (Command === 'Uptime') {
    getUptime();
  }
});

// Event handler for asynchronous incoming messages
ipcMain.on('CFD-message', (_, arg) => {
  // console.log(arg);
  if (arg === 'ReadTerms') {
    if (childWindow) childWindow.send('sendbackhtml', arg);
  } else {
    // Event emitter for sending asynchronous messages
    POSWindow && POSWindow.webContents.send('TOPOS', arg);
  }
});

ipcMain.on('termsdetails', (_, html) => {
  // console.log(html);
  if (CFDWindow) CFDWindow.webContents.send('TOCFDDATA', html);
  // childWindow.destroy();
});

ipcMain.on('init-hardware', async (event, msg) => {
  if (isDev) {
    switch (os.type()) {
      case 'Darwin':
      case 'Linux':
        event.returnValue = false;
        return;
      default:
        break;
    }
  }

  await shutdownHardware();

  console.log('hardware config', msg);

  msg.coin_dispenser.win = POSWindow;
  msg.dvr.win = POSWindow;

  dvr = await createDvr(msg.dvr);
  if (dvr) {
    await dvr.start();
  }

  coinDispenser = await createCoinDispenser(msg.coin_dispenser);
  if (coinDispenser) {
    await coinDispenser.start();
  }

  event.returnValue = true;
});

ipcMain.on('shutdown-hardware', async (event, msg) => {
  await shutdownHardware();
  event.returnValue = true;
});

ipcMain.on('DVR-send-message', (_, msg) => {
  if (dvr) {
    dvr.sendMessage(msg);
  }
});

ipcMain.on('CoinDispenser-dispense-amount', (_, msg) => {
  if (coinDispenser) {
    coinDispenser.dispenseAmount(msg);
  }
});

ipcMain.on('LoadUrl', (_, arg) => {
  console.log('Terms URL:', arg);
  childWindow.loadURL(arg);
});

app.whenReady().then(() => {
  createWindow();
  createSecondWindow();

  app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) {
      // createSecondWindow()
      createWindow();
    }
  });
});

app.on('window-all-closed', async () => {
  console.log('window-all-closed');
  await shutdownHardware();

  if (process.platform !== 'darwin') {
    app.quit();
  }
});
