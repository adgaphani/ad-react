const axios = require('axios');
const isDev = process.env.NODE_ENV === 'dev';
const isMac = isDev && require('os').platform() === 'darwin';
const { exec, spawn } = require('child_process');
const { SerialPort } = isMac ? { SerialPort: {} } : require('serialport');

const STATUS_INTERVAL = 5000;

const isProcessRunning = async processName =>
  new Promise(resolve => {
    exec('tasklist', (err, stdout) => {
      if (err) return resolve(false);
      return resolve(
        stdout.toLowerCase().indexOf(processName.toLowerCase()) > -1
      );
    });
  });

const apiLog = (win, is_error, msg, ...optionalParams) => {
  try {
    console.log('CoinDispenser', msg, ...optionalParams);

    let data = `CoinDispenser|${msg}`;
    for (let i = 0; i < optionalParams.length; i += 1) {
      data += `|${optionalParams[i]}`;
    }

    win.webContents.send('hardware-log-message', {
      is_error,
      msg: data,
    });
  } catch (e) {
    console.log('CoinDispenser', 'log', 'exception', e);
  }
};

class OposCoinDispenser {
  constructor({ host, port, win }) {
    this.host = host;
    this.port = port;
    this.win = win;

    this.status = {
      status: 'COIN_STATUS_UNKNOWN',
      status_code: -1,
    };
    this.statusInterval = null;
    this.stopped = false;
  }

  launchServer = async () =>
    new Promise(resolve => {
      try {
        const subprocess = spawn(
          'C:\\711.Peripherals\\CoinDispenser\\CoinDispenserServer.exe',
          [],
          {
            cwd: 'C:\\711.Peripherals\\CoinDispenser',
            detached: true,
            stdio: 'ignore',
          }
        );
        subprocess.unref();
        setTimeout(() => resolve(), 250);
      } catch (e) {
        apiLog(this.win, true, 'failed to launch CoinDispenserServer', e);
        resolve();
      }
    });

  setStatus = (status, forceOnFailure) => {
    const doNotify = () => {
      this.win.webContents.send('hardware-log-status', {
        module: 'CoinDispenser',
        status: this.status,
      });
    };

    if (status.status_code !== this.status.status_code) {
      this.status = status;
      doNotify();
    } else if (forceOnFailure && status.status_code !== 1) {
      doNotify();
    }
  };

  dispenseAmount = async amount => {
    if (!this.stopped) {
      try {
        const cents = Number.parseInt(amount.split('.')[1], 10);
        if (cents > 0) {
          const res = await axios.post(
            `http://${this.host}:${this.port}/api/v1/dispense`,
            {
              amount: cents,
            }
          );

          if (res.status === 200) {
            if (res.data.result_code !== 0) {
              apiLog(this.win, true, 'dispense', 'opos error', res.data.result);

              this.win.webContents.send('hardware-log-result', {
                module: 'CoinDispenser',
                result: { opos_error: true, data: res.data },
              });
            }

            this.setStatus(
              {
                status: res.data.status,
                status_code: res.data.status_code,
              },
              true
            );
          } else {
            apiLog(
              this.win,
              true,
              'dispense',
              'http error',
              res.status,
              res.data
            );
            this.win.webContents.send('hardware-log-result', {
              module: 'CoinDispenser',
              result: { http_error: true, status: res.status, data: res.data },
            });
          }
        }
      } catch (e) {
        apiLog(this.win, true, 'dispense', 'exception', e);
        this.win.webContents.send('hardware-log-result', {
          module: 'CoinDispenser',
          result: { exception: true, data: e },
        });
      }
    }
  };

  start = async () => {
    if (!this.statusInterval && !this.stopped) {
      await this.launchServer();

      try {
        const res = await axios.post(
          `http://${this.host}:${this.port}/api/v1/init`,
          {
            device_name: 'TF_RS232',
          }
        );

        if (res.status === 200) {
          this.setStatus({
            status: res.data.status,
            status_code: res.data.status_code,
          });

          if (res.data.result_code === 0) {
            const getStatus = async () => {
              try {
                const res = await axios.get(
                  `http://${this.host}:${this.port}/api/v1/status`
                );

                if (res.status === 200) {
                  this.setStatus({
                    status: res.data.status,
                    status_code: res.data.status_code,
                  });
                } else {
                  apiLog(
                    this.win,
                    true,
                    'status',
                    'http error',
                    res.status,
                    res.data
                  );
                }
              } catch (e) {
                apiLog(this.win, true, 'status', 'exception', e);
              }
            };
            this.statusInterval = setInterval(getStatus, STATUS_INTERVAL);
            return;
          }

          apiLog(this.win, true, 'start', 'opos error', res.data.result);
        } else {
          apiLog(this.win, true, 'start', 'http error', res.status, res.data);
        }
      } catch (e) {
        apiLog(this.win, true, 'start', 'exception', e);
      }

      apiLog(this.win, false, 'start', 'failed');
      await this.stop();
    }
  };

  stop = async () => {
    try {
      this.stopped = true;

      clearInterval(this.statusInterval);
      this.statusInterval = null;

      const res = await axios.get(
        `http://${this.host}:${this.port}/api/v1/shutdown`
      );

      if (res.status === 200) {
        let isRunning = isProcessRunning('CoinDispenserServer.exe');
        if (isRunning) {
          apiLog(this.win, false, 'stop', 'process still running');
          return new Promise(async resolve => {
            let retryCount = 0;
            const id = setInterval(async () => {
              if (retryCount >= 5) {
                clearInterval(id);
                return resolve();
              }

              retryCount = retryCount + 1;
              apiLog(
                this.win,
                false,
                'stop',
                'check process termination retry',
                retryCount
              );
              isRunning = await isProcessRunning('CoinDispenserServer.exe');
              if (isRunning) {
                apiLog(this.win, false, 'stop', 'process still running');
              } else {
                clearInterval(id);
                apiLog(this.win, false, 'stop', 'process terminated');
                return resolve();
              }
            }, 2000);
          });
        } else {
          resolve();
        }
      }

      apiLog(this.win, true, 'stop', 'failed to release', res.status, res.data);
    } catch (e) {
      apiLog(this.win, true, 'stop', 'exception', e);
    }
  };
}

class SerialCoinDispenser {
  constructor({ port, win }) {
    this.port = port;
    this.win = win;
  }

  dispenseAmount = async amount => {
    if (this.serialPort) {
      try {
        let cents = Number.parseInt(amount.split('.')[1], 10);
        if (cents > 0) {
          cents = `0x${cents.toString().padStart(2, '0')}`;
          // eslint-disable-next-line no-bitwise
          const checksum = `0x${(~parseInt(cents, 16) & 0xff).toString(16)}`;
          console.log(cents, checksum);

          await this.sendCommand(cents);
          await this.sendCommand(checksum);
        }
      } catch (e) {
        apiLog(this.win, true, '2BCD', e);
      }
    }
  };

  sendCommand = async data =>
    new Promise((resolve, reject) => {
      if (!this.serialPort) {
        return reject('serial port is closed');
      }

      this.serialPort.write(Buffer.from([parseInt(data, 16)], 'utf-8'), err => {
        if (err) {
          return reject(err);
        }

        setTimeout(() => {
          resolve();
        }, 100);
      });
    });

  start = async () => {
    if (!this.serialPort) {
      this.serialPort = new SerialPort({
        path: this.port,
        baudRate: 1200,
        parity: 'none',
        stopBits: 1,
        dataBits: 8,
        autoOpen: false,
      });

      this.serialPort.on('error', err => {
        if (err) {
          apiLog(this.win, true, '2BCD', err);
          this.stop();
        }
      });

      this.serialPort.open(err => {
        if (err) {
          apiLog(this.win, true, '2BCD', err);
          this.serialPort = null;
        }
      });
    }
  };

  stop = async () => {
    if (this.serialPort) {
      this.serialPort.close(err => {
        if (err) {
          apiLog(this.win, true, '2BCD', err);
        }
        this.serialPort = null;
      });
    }
  };
}

module.exports = {
  OposCoinDispenser,
  SerialCoinDispenser,
};
