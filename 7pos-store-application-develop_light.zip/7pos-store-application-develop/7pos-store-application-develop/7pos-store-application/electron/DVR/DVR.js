const axios = require('axios');
const net = require('net');
const isDev = process.env.NODE_ENV === 'dev';
const isMac = isDev && require('os').platform() === 'darwin';
const { SerialPort } = isMac ? { SerialPort: {} } : require('serialport');
const apiLog = (win, is_error, msg, ...optionalParams) => {
  try {
    console.log('DVR', msg, ...optionalParams);

    let data = `DVR|${msg}`;
    for (let i = 0; i < optionalParams.length; i += 1) {
      data += `|${optionalParams[i]}`;
    }

    win.webContents.send('hardware-log-message', {
      is_error,
      msg: data,
    });
  } catch (e) {
    console.log('DVR', 'log', 'exception', e);
  }
};

class IpDvr {
  constructor({ host, is_clickit, port, type, use_https, win, term_id }) {
    this.host = host;
    this.is_clickit = is_clickit;
    this.port = port;
    this.term_id = term_id;
    this.type = type;
    this.use_https = use_https;
    this.win = win;

    this.messageQueue = [];
    this.messageQueueInterval;
  }

  intervalCallback = async () => {
    if (this.messageQueue.length > 0) {
      const msg = this.messageQueue.shift();

      const data = this.is_clickit
        ? this.type === 'http'
          ? msg
          : `mlen=${msg.length + 2}\r\n${msg}\r\n`
        : `${msg}\r\n`;

      try {
        if (this.type === 'http') {
          const response = await axios({
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Date: new Date().toUTCString(),
            },
            data,
            url: `${this.use_https ? 'https' : 'http'}://${this.host}:${
              this.port
            }/api/711pos2/${this.term_id}`,
          });

          if (response.status < 200 || response.status >= 300) {
            apiLog(
              this.win,
              true,
              this.type,
              'IpDvr post error',
              `${response.status}:${response.statusText}`
            );
          }
        } else {
          const client = net.createConnection(this.port, this.host);

          client.on('close', () => {
            console.log('IpDvr socket close');
          });

          client.on('connect', () => {
            console.log('IpDvr write:', msg);
            client.write(data);
            client.destroy();
          });

          client.on('end', () => {
            console.log('IpDvr socket end');
          });

          client.on('error', err => {
            if (err) {
              apiLog(this.win, true, this.type, 'IpDvr error', err);
            }
          });
        }
      } catch (e) {
        apiLog(this.win, true, this.type, 'IpDvr exception', e);
      }
    }
  };

  sendMessage = msg => {
    if (this.messageQueueInterval) {
      this.messageQueue.push(msg);
    }
  };

  start = async () => {
    if (!this.messageQueueInterval) {
      this.messageQueueInterval = setInterval(this.intervalCallback, 100);
    }
  };

  stop = async () => {
    if (this.messageQueueInterval) {
      clearInterval(this.messageQueueInterval);
      this.messageQueueInterval = null;
    }
  };
}

class SerialDvr {
  constructor({ is_clickit, port, win }) {
    this.is_clickit = is_clickit;
    this.port = port;
    this.win = win;

    this.messageQueue = [];
    this.messageQueueInterval;
  }

  closeHandler = () => {
    if (this.serialPort) {
      clearInterval(this.messageQueueInterval);
      this.messageQueueInterval = null;
      this.serialPort = null;
    }
  };

  intervalCallback = () => {
    if (this.serialPort) {
      if (this.messageQueue.length > 0) {
        const msg = this.messageQueue.shift();
        console.log('SerialDvr write:', msg);
        this.serialPort.write(
          this.is_clickit
            ? `mlen=${msg.length + 2}\r\n${msg}\r\n`
            : `${msg}\r\n`,
          'ascii',
          err => {
            if (err) {
              apiLog(this.win, true, 'SerialDvr write error', err);
            }
          }
        );
      }
    }
  };

  sendMessage = msg => {
    if (this.serialPort) {
      console.log('SerialDvr msg:', msg);
      this.messageQueue.push(msg);
    }
  };

  start = async () => {
    if (!this.serialPort) {
      this.serialPort = new SerialPort({
        path: this.port,
        baudRate: 9600,
        parity: 'none',
        stopBits: 1,
        dataBits: 8,
        autoOpen: false,
      });

      this.serialPort.on('error', err => {
        if (!this.isClosing && err) {
          apiLog(this.win, true, 'SerialDvr error', err);
          this.stop();
        }
      });

      this.serialPort.open(err => {
        if (err) {
          apiLog(this.win, true, 'SerialDvr open error', err);
          return this.closeHandler();
        }

        this.messageQueueInterval = setInterval(this.intervalCallback, 100);
      });
    }
  };

  stop = async () => {
    if (this.serialPort) {
      this.serialPort.close(err => {
        if (err) {
          apiLog(this.win, true, 'SerialDvr close error', err);
        }

        this.closeHandler();
      });
    }
  };
}

module.exports = {
  IpDvr,
  SerialDvr,
};
