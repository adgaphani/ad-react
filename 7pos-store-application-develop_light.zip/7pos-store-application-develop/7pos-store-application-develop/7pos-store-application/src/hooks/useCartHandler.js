import { useEffect, useCallback, useState } from 'react';
import { useSelector } from 'react-redux';
import store from '../store';

export const useCartHandler = () => {
  const [totalQuantity, setTotalQuanity] = useState(0);
  const [isQuanityChanged, setIsQuantityChanged] = useState(false);
  const { items: cartItems } = useSelector(state => ({
    items: state.cart.items,
  }));

  const currentQuanity = useCallback(
    items => {
      const reducer = (acc, i) => acc + i.quantity;
      if (items) {
        return items.reduce(reducer, 0);
      }
      return cartItems.reduce(reducer, 0);
    },
    [cartItems]
  );

  const realTimeQuanity = useCallback(() => {
    const items = store.getState()?.cart?.cartItems;
    return currentQuanity(items);
  }, []);

  useEffect(() => {
    const updatedQuantity = currentQuanity();
    if (updatedQuantity !== totalQuantity) {
      setTotalQuanity(updatedQuantity);
      setIsQuantityChanged(true);
    }
  }, [cartItems]);
  return {
    isQuanityChanged,
    realTimeQuanity,
    totalQuantity,
  };
};
