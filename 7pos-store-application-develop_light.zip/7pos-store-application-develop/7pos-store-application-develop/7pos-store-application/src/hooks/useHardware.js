import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { createDVR, getDVR, DVRTypes } from '../hardware/dvr';
import * as coinDispenser from '../hardware/coin_dispenser';
import { fetchDataServiceDeviceInfo } from '../api/app/fetchDeviceInfo';

const electron = window.require('electron');

export const useHardware = () => {
  const { dayNumber, shiftNumber, isDataSyncInProgress } = useSelector(
    state => ({
      dayNumber: state.main.dayNumber,
      shiftNumber: state.main.shiftNumber,
      isDataSyncInProgress: state.auth.isDataSyncInProgress,
    })
  );

  useEffect(() => {
    getDVR()?.setDayShift(dayNumber, shiftNumber);
  }, [dayNumber, shiftNumber]);

  useEffect(() => {
    let active = true;
    let retryTimeout;

    const startHardwareDevices = () => {
      const startAsync = async () => {
        if (active) {
          if (isDataSyncInProgress) {
            return;
          }

          let deviceInfo = await fetchDataServiceDeviceInfo({
            correlationID: 'init-hardware',
          });
          deviceInfo = JSON.parse(deviceInfo?.data?.data || '{}');
          Logger.info('INIT HARDWARE : DEVICE INFO', deviceInfo);

          const coinDispenserType = (deviceInfo?.coinDispenserType || '')
            .trim()
            .toLowerCase();
          const dvrType = (deviceInfo?.dvrType || 'click-it serial')
            .trim()
            .toLowerCase();

          const is_clickit = dvrType.includes('click-it');
          const is_tcp = !dvrType.includes('serial') && !is_clickit;
          const is_http = dvrType === 'click-it ip';
          const is_2bcd = coinDispenserType === 'gerbo';

          const cfg = {
            coin_dispenser: {
              enabled: !!coinDispenserType,
              is_2bcd,
              host: 'localhost',
              port: is_2bcd ? 'COM7' : 9601,
              term_id: parseInt(deviceInfo?.id || 0, 10),
            },
            dvr: {
              enabled: !!dvrType,
              type: is_http ? 'http' : is_tcp ? 'tcp' : 'serial',
              is_clickit,
              use_https: false, // is_http
              host: 'DVR01',
              port: is_tcp ? 5001 : is_http ? 6334 : 'COM1', // 6335 https
              term_id: parseInt(deviceInfo?.id || 0, 10),
            },
          };
          Logger.info('INIT HARDWARE : CONFIG', cfg);

          if (electron.ipcRenderer.sendSync('init-hardware', cfg)) {
            const dvr = await createDVR(
              deviceInfo,
              cfg.dvr.enabled
                ? is_clickit
                  ? DVRTypes.DVR_ClickIt
                  : DVRTypes.DVR_3xLogic
                : DVRTypes.DVR_None
            );
            dvr?.setDayShift(dayNumber, shiftNumber);

            coinDispenser.setEnabled(cfg.coin_dispenser.enabled);
          } else {
            Logger.error('INIT HARDWARE FAILED: INCOMPATIBLE OS');
          }
        }
      };

      startAsync().catch(e => {
        Logger.error(
          'ERROR INIT HARDWARE: CATCHING EXCEPTION-ENABLING RETRY',
          e
        );
        retryTimeout = setTimeout(() => {
          Logger.info('INIT HARDWARE: RETRYING AFTER FAILURE');
          startHardwareDevices();
        }, 5000);
      });
    };
    startHardwareDevices();

    return () => {
      active = false;
      clearTimeout(retryTimeout);
    };
  }, [isDataSyncInProgress]);

  const shutdownHardware = reason => {
    Logger.info(`SHUTDOWN HARDWARE: ${reason}`);
    getDVR()?.shutdown();
    coinDispenser.setEnabled(false);
    electron.ipcRenderer.sendSync('shutdown-hardware');
  };

  return [shutdownHardware];
};
