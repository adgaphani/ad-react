import { useState } from 'react';

export const useInitializer = () => {
  const [scanSound] = useState(
    new Audio(`${process.env.PUBLIC_URL}/assets/sounds/scan_sound.mp3`)
  );
  const [errorSound] = useState(
    new Audio(`${process.env.PUBLIC_URL}/assets/sounds/POS_Error.wav`)
  );
  const [keyPressSound] = useState(
    new Audio(`${process.env.PUBLIC_URL}/assets/sounds/POS_KeyPress.wav`)
  );
  const [successSound] = useState(
    new Audio(`${process.env.PUBLIC_URL}/assets/sounds/POS_Success.wav`)
  );
  const [authConfirmNotifySound] = useState(
    new Audio(
      `${process.env.PUBLIC_URL}/assets/sounds/POS_Fuelauth_boostedVolume.wav`
    )
  );

  return {
    scanSound,
    errorSound,
    keyPressSound,
    successSound,
    authConfirmNotifySound,
  };
};
