/* eslint-disable */
import { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fuelActions } from '../slices/fuel.slice';
import { cartActions } from '../slices/cart.slice';
import { FuelUtils, discountFuelPrice } from '../Utils';
import { useFuel } from './useFuel';
import { mainActions } from '../slices/main.slice';
import { SendMessageToCFD } from '../Communication';

export const useFuelPrices = () => {
  const dispatch = useDispatch();
  const {
    fuelPrices,
    newFuelPrices,
    isPendingMPSApproval,
    loyalty,
    selectedGrade,
    calculatedDiscounts,
    hostDiscounts,
    isCashCreditStore,
  } = useSelector(({ fuel, cart, main }) => ({
    fuelPrices: fuel.fuelPrices,
    newFuelPrices: fuel.newFuelPrices,
    isPendingMPSApproval: fuel.isPendingMPSApproval,
    loyalty: cart.fuelLoyalty,
    hostDiscounts: cart.hostDiscounts,
    selectedGrade: cart.selectedGrade,
    calculatedDiscounts: cart.calculatedFuelDiscounts,
    isCashCreditStore: main.isCashCreditStore,
  }));
  const {
    maxGalonLimit,
    totalDiscount,
    // totalHostDiscount,
    loyaltyTotalDiscount,
    totalOptionalLoyaltyDiscount,
  } = calculatedDiscounts || {};
  const { fuelPrepaidAmount } = useFuel();

  const setCashCredit = prices => {
    if (!prices) return;
    const isCashCreditStr =
      prices.map(item => item.price !== item.cashPrice).some(value => value) ||
      false;
    dispatch(mainActions.setIsCashCreditStore(isCashCreditStr));
    Logger.info(`[Fuel] isCashCredtStore ---> ${isCashCreditStr}`);
  };

  const setFuelPrices = pricesPayload => {
    const seiProdIdToProdNumberMapper = price => ({
      productNumber: isNaN(Number(price.seiProductId))
        ? 0
        : Number(price.seiProductId),
      ...price,
    });
    pricesPayload.prices = pricesPayload.prices.map(
      seiProdIdToProdNumberMapper
    );
    Logger.info(`[Fuel] setFuelPrices ---> ${JSON.stringify(pricesPayload)}`);
    dispatch(fuelActions.setFuelPrices(pricesPayload));
    const { prices } = pricesPayload || {};
    setCashCredit(prices); // Handling Cash Credit
  };

  const getGrades = () => fuelPrices.map(price => price?.storeProductName);
  const getCashPrices = () => fuelPrices.map(price => price?.cashPrice);
  const getCardPrices = () => fuelPrices.map(price => price?.price);
  const getGradeIds = () => fuelPrices.map(price => price?.seiProductId);
  const getNewGradeById = id =>
    newFuelPrices.find(({ seiProductId }) => seiProductId === id);

  // Enforcing the same order as current grades.
  const getNewPrices = () =>
    getGradeIds().map(id => getNewGradeById(id)?.price);

  // To Handle NON Member HOST Discounts
  useEffect(() => {
    if (!fuelPrepaidAmount || !hostDiscounts || !fuelPrices || loyalty) {
      return;
    }
    console.log(
      'Fuel Prices________ Calculating the host discounts',
      fuelPrices
    );
    // TO Calculate Cash and Credit Fuel Prices
    const calculatePrice = (grade, priceType) => {
      const totalHostDiscountPerGrade = hostDiscounts?.discountInfo?.reduce(
        (acc, d) =>
          d.productCode === grade.storeProduct ||
          d.productCode.toUpperCase() === 'ALL'
            ? acc + d.discountAmount
            : acc,
        0
      );
      const totalDiscount = totalHostDiscountPerGrade || 0;
      const gradePrice = grade[priceType] ? grade[priceType] * 1000 : 0;
      const tDiscount = Math.floor(totalDiscount * 100);
      const fPrice = discountFuelPrice(tDiscount, gradePrice);

      return {
        abbr: grade.abbr,
        name: grade.productName,
        grade_id: grade.storeProduct,
        price: Math.floor(grade[priceType] * 1000),
        final_price: fPrice,
        discount_price: grade.discount_price
          ? grade.discount_price - totalDiscount
          : 0,
        selected: selectedGrade?.product === grade?.storeProduct,
        totalDiscount: tDiscount,
        loyaltyDiscount: 0,
        hostDiscount: tDiscount,
        calculatedGallons: FuelUtils.calculatedGallons(
          undefined,
          fPrice,
          fuelPrepaidAmount
        ),
      };
    };

    const cPrices = fuelPrices.map(grade => calculatePrice(grade, 'price'));
    dispatch(cartActions.setFuelCalculatedPrices(cPrices));

    if (!isCashCreditStore) {
      return;
    }
    // For Cash Credit store , Calculating Fuel Prices
    if (isCashCreditStore) {
      const calculatedPricesForCash = fuelPrices.map(grade =>
        calculatePrice(grade, 'cashPrice')
      );
      dispatch(
        cartActions.setFuelCalculatedCashPrices(calculatedPricesForCash)
      );
    }
  }, [hostDiscounts, loyalty, fuelPrices, fuelPrepaidAmount]);

  const calculatedFuelPrices = useMemo(() => {
    // To handle multiple discounts per grade
    let cPrices;
    if (loyalty) {
      cPrices = loyalty?.fuel_data?.grades.map(grade => {
        const hostDiscountReducer = (acc, d) =>
          d.productCode === grade.grade_id ? acc + d.discountAmount : acc;
        const totalHostDiscountPerGrade =
          hostDiscounts?.discountInfo?.reduce(hostDiscountReducer, 0) || 0;
        const tHostDiscount = totalHostDiscountPerGrade * 100;
        let updatedDiscounts = [];
        let fPrice;
        if (!!grade?.discount_breakdown?.length) {
          let price = grade.price - totalOptionalLoyaltyDiscount;
          grade.discount_breakdown.forEach((obj, index) => {
            fPrice = discountFuelPrice(obj.discount, price);
            if (fPrice > 10) {
              price = fPrice;
            } else {
              updatedDiscounts.push({ ...grade?.discount_breakdown[index] });
            }
          });
        } else {
          const totalDiscount = grade.discount + totalOptionalLoyaltyDiscount;

          fPrice = discountFuelPrice(totalDiscount, grade.price);
        }
        fPrice = tHostDiscount
          ? discountFuelPrice(tHostDiscount, fPrice)
          : fPrice; //#1900 Adding Host discount to total discounts
        const isSelectedGrade = selectedGrade?.product === grade?.grade_id;
        if (isSelectedGrade) {
          const calculatedPrepaid = FuelUtils.calculatedPrePaidAmount(
            maxGalonLimit,
            fPrice,
            fuelPrepaidAmount
          );
          dispatch(cartActions.setCalculatedPrepaidAmount(calculatedPrepaid));
          dispatch(cartActions.setUpdatedDiscounts(updatedDiscounts));
          SendMessageToCFD({ CMD: 'updatedDiscounts', data: updatedDiscounts }); // Cart in CFD will be updated with manadatory discounts
        }
        return {
          abbr: grade.abbr,
          name: grade.name,
          grade_id: grade.grade_id,
          cash_price: grade.cash_price,
          price: grade.price,
          final_price: fPrice, // After Discounts
          discount_price: grade.discount_price - totalDiscount,
          loyalty_street_price: grade.loyalty_street_price,
          original_street_price: grade.original_street_price,
          finalMaxGallonLimit: maxGalonLimit,
          maxGalonLimit,
          selected: isSelectedGrade,
          totalDiscount,
          loyaltyDiscount: loyaltyTotalDiscount,
          hostDiscount: tHostDiscount,
          calculatedGallons: FuelUtils.calculatedGallons(
            maxGalonLimit,
            fPrice,
            fuelPrepaidAmount
          ),
        };
      });
    }
    dispatch(cartActions.setFuelCalculatedPrices(cPrices));
    return cPrices;
  }, [
    totalDiscount,
    maxGalonLimit,
    selectedGrade,
    hostDiscounts,
    totalOptionalLoyaltyDiscount,
    fuelPrepaidAmount,
    loyaltyTotalDiscount,
  ]);

  return {
    fuelPrices,
    newFuelPrices,
    isPendingMPSApproval,
    setFuelPrices,
    getGrades,
    getCashPrices,
    getCardPrices,
    getNewPrices,
    calculatedFuelPrices,
  };
};
