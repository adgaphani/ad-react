import { useContext } from 'react';

import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';

export const useCashDrawer = () => {
  const [ws] = useContext(WebSocketContext);
  const open = () => {
    ws.socket?.send('/app/cashdrawer/openCashDrawer');
  };
  return {
    openCashDrawer: open,
  };
};
