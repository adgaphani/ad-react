import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { useEffect, useRef, useMemo, useCallback } from 'react';
import moment from 'moment';
import { getPriceDetails } from '../Utils/cartUtils';
import { cartActions } from '../slices/cart.slice';
import { isLottoOrLotteryWin } from '../Utils/lotteryUtils';
import { ITEM_TYPE, LOAD_FLG_INVALID } from '../constants';
import { FuelUtils } from '../Utils';
import { TransactionTypes } from '../TransactionTypes';
import { getBalanceDue } from '../Utils/paymentUtils';
import store from '../store';

export const useCart = () => {
  const dispatch = useDispatch();
  const { deviceInfo } = useSelector(state => ({
    deviceInfo: state.main.deviceInfo,
  }));

  const {
    items,
    nonFuelItems,
    cartItems,
    currentTransactionId,
    isFuelTransactionInProgress,
    isTransactionInProgress,
    taxInfo,
    isTransactionVoid,
    isTransactionRefund,
    paymentTransactionId,
    isLottoOrLotteryTransaction,
    isCardLoadTransaction,
    isCreditItemInCart,
    paymentDetails,
    isCarwashInProgress,
    nonTaxItems,
  } = useSelector(state => {
    const {
      items = [],
      cartItems,
      taxInfo,
      transactionId,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId,
      paymentDetails,
    } = state.cart;
    return {
      items,
      nonFuelItems: items.filter(i => !i.isFuel && !i.isCarwash) || [],
      nonTaxItems: items.filter(i => !i.isCarwash && i.isFuel),
      isCardLoadTransaction:
        items.filter(
          i =>
            i.itemTypeID === ITEM_TYPE.CARD_LOAD &&
            i?.CardLoadFlag !== LOAD_FLG_INVALID
        ).length > 0,
      cartItems,
      isFuelTransactionInProgress: items.filter(i => i.isFuel).length > 0,
      isTransactionInProgress: items.length > 0,
      isLottoOrLotteryTransaction: items.filter(isLottoOrLotteryWin).length > 0,
      currentTransactionId: transactionId,
      taxInfo,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId,
      isCreditItemInCart:
        items?.filter(i => i.negativeSalesFlag && !isLottoOrLotteryWin(i))
          .length > 0,
      paymentDetails,
      isCarwashInProgress: items.filter(i => i.isCarwash).length > 0,
      paymentHistory: state.cart.paymentHistory,
      paymentMediaList: state.cart.paymentMediaList,
      allPayments: state.cart.allPayments,
      enteredCash: state.cart.enteredCash,
    };
  }, shallowEqual);

  const cartAttributesRef = useRef({});
  useEffect(() => {
    const cartMetrics = getPriceDetails(
      cartItems,
      taxInfo,
      isTransactionVoid || isTransactionVoid
    );
    const total = Number(cartMetrics.finalTotalPrice);
    cartAttributesRef.current = {
      cartItems,
      taxInfo,
      isTransactionVoid,
      isTransactionRefund,
      totalPrice: total,
    };
    // Logger.info(`cartAttributesRef : ${cartAttributesRef}`); // making too many logs in logz
  }, [cartItems, taxInfo, isTransactionVoid, isTransactionRefund]);
  const getCartMetrics = () => {
    const {
      paymentHistory,
      allPayments,
      paymentMediaList,
      enteredCash,
      cartItems,
    } = store?.getState()?.cart;
    const {
      taxInfo: txInfo,
      isTransactionVoid: isTVoid,
      isTransactionRefund: isTRefund,
    } = cartAttributesRef.current;
    const cartMetrics = getPriceDetails(
      cartItems,
      txInfo,
      isTRefund || isTVoid
    );
    const total = Number(cartMetrics.finalTotalPrice);
    // total * 100 is adding extra decimals at the end. Number('19.19') * 100 = 1919.00000000002
    // FIX: (Number('19.19') * 100).toFixed() = 1919
    const { balanceDue } = getBalanceDue({
      paymentHistory,
      finalTotalPrice: cartMetrics.finalTotalPrice,
      allPayments,
      paymentMediaList,
      enteredCash,
    });
    cartMetrics.transactionTotal = isNaN(total)
      ? '0.0'
      : (total * 100).toFixed();
    cartMetrics.balanceDue = balanceDue;
    return cartMetrics;
  };

  const addItemToCart = useCallback(cartItem => {
    const { isFuel = false } = cartItem;
    Logger.debug(`${isFuel ? '[Fuel] ' : ''}Adding Item To Cart:`);
    dispatch(cartActions.addToCart(cartItem));
  }, []);

  const fullTransactionRef = useRef({ trasactionId: '', terminalId: '' });
  useEffect(() => {
    fullTransactionRef.current.terminalId = deviceInfo?.id;
    fullTransactionRef.current.trasactionId = currentTransactionId;
  }, [deviceInfo?.id, currentTransactionId]);

  const getFullTransactionId = () =>
    `01${fullTransactionRef.current.terminalId}${fullTransactionRef.current.trasactionId}`;

  const setHardTotalSummary = summary => {
    dispatch(cartActions.setHardTotalSummary(summary));
  };

  const voidPrepayItemFromCart = () => {
    const prepayItem = items.find(i => i.isFuel && Number(i.retailPrice) > 0);
    if (!prepayItem) {
      return;
    }
    Logger.info(`[Fuel] Voiding the fuel item: ${JSON.stringify(prepayItem)}`);
    dispatch(
      cartActions.removeFromCart({
        itemId: prepayItem.itemId,
        itemSeq: prepayItem.itemSeq,
        sttn: prepayItem?.sttn || 0,
      })
    );
  };

  const getCalculatedFinalPrices = useMemo(() => {
    const {
      finalsubTotalPrice,
      finalTotalPrice,
      totalPromotionPrice,
    } = getPriceDetails(
      cartItems,
      taxInfo,
      isTransactionVoid || isTransactionRefund
    );
    return {
      finalTotalPrice,
      finalsubTotalPrice,
      totalPromotionPrice,
    };
  }, [cartItems, taxInfo, isTransactionVoid, isTransactionRefund]);
  const addVoidFuelCartItem = ({
    pumpNumber,
    sequenceNumber,
    fuelAmount,
    originalTransactionId,
    originalPaymentTenderId,
    mediaNumber,
    originalTransactionSequenceId,
  }) => {
    const cartItem = FuelUtils.getVoidPrepayCartItem({
      selectedPumpNumber: pumpNumber,
      sequenceNumber,
      fuelAmount,
    });
    cartItem.metaInfo = {
      originalTransactionSequenceId,
      originalTransactionId,
      originalPaymentTenderId,
      fuelDispenserId: pumpNumber?.toString(),
      fuelAmount: -Number.parseFloat(fuelAmount) / 100,
      prepayAmount: Number.parseFloat(fuelAmount) / 100,
      transactionType: TransactionTypes.preAuthCancel,
      mediaNumber,
    };
    addItemToCart(cartItem);
  };

  const setNewTransactionStartTime = () => {
    const transactionStartTime = `${moment
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
    dispatch(cartActions.setTransactionStartTime(transactionStartTime));
  };

  const isOnlyFuelInTheCart = useMemo(
    () => items.length && !items.filter(i => !i.isFuel)?.length,
    [items]
  );

  return {
    items,
    nonFuelItems,
    nonTaxItems,
    currentTransactionId,
    addItemToCart,
    voidPrepayItemFromCart,
    isFuelTransactionInProgress,
    isCarwashInProgress,
    isTransactionInProgress,
    getCartMetrics,
    paymentTransactionId,
    getFullTransactionId,
    setHardTotalSummary,
    isLottoOrLotteryTransaction,
    isCardLoadTransaction,
    isCreditItemInCart,
    addVoidFuelCartItem,
    paymentDetails,
    taxInfo,
    setNewTransactionStartTime,
    isTransactionVoid,
    isTransactionRefund,
    isOnlyFuelInTheCart,
    ...getCalculatedFinalPrices,
  };
};
