import { useContext, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';
import { peripheralActions } from '../slices/peripheral.slice';
import { cartActions } from '../slices/cart.slice';
import store from '../store';
import { useWSocket } from './useWSocket';
import { useSafe } from './useSafe';
import { safeDrop } from '../constants';
import { safeRequest } from '../Utils/safeUtils';
import { useSoundToast } from './useSoundToast';

export const useSafeInit = () => {
  const [ws] = useContext(WebSocketContext);
  const dispatch = useDispatch();
  const appQueue = useRef([]);
  const toast = useSoundToast();
  const { isConnected } = useWSocket();
  const { releaseSafeLock } = useSafe();
  const { userId } = useSelector(state => ({
    userId: state.auth?.user?.userId,
  }));

  const showToast = msg => {
    if (msg?.length > 0)
      toast?.({
        description: msg,
        status: 'error',
        duration: 3000,
        position: 'top',
      });
  };

  const onSafeEventReceived = event => {
    try {
      const response = JSON.parse(JSON.stringify(event));
      const body = JSON.parse(response.body);
      const messageType = body?.messageHeader?.messageType;
      global?.logger?.info(
        `[7POS UI] - onSafeEventReceived:${JSON.stringify(body)}`
      );
      if (
        messageType === 'safeActionEndOfDay' ||
        messageType === 'safeActionEndOfShift'
      ) {
        if (body?.messageBody?.message?.errorMessge) {
          showToast({
            description: body?.messageBody?.message?.errorMessge,
          });
        }
        releaseSafeLock();
        dispatch(peripheralActions.setMOMLockStatus(null));
        dispatch(peripheralActions.setSafeLockStatus(null));
        dispatch(cartActions.setIsEndOfDayorShift(false));
      } else if (messageType === 'safeActionSentConfiguration') {
        dispatch(peripheralActions.setSafeReady(true));
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - onSafeEventReceived ${JSON.stringify(error)}`
      );
    }
  };

  const subscribeSafeEvents = () => {
    if (!isConnected) {
      return;
    }
    const safeQueue = ws.socket?.subscribe(
      safeDrop.channels.appQueue,
      onSafeEventReceived
    );
    global?.logger?.info(`[7POS UI] - Subscribe Safe appQueue`);
    appQueue.current.push(safeQueue);
  };

  const clearSafeSubs = () => {
    global?.logger?.info(`[7POS UI] - Unsubscribe Safe appQueue`);
    appQueue?.current?.forEach(s => s.unsubscribe());
  };

  const initializeSafe = () => {
    if (!isConnected) {
      return;
    }
    const { dayNumber, shiftNumber, deviceInfo } = store.getState().main;
    const request = safeRequest({
      deviceInfo,
      userId,
      day: dayNumber,
      shift: shiftNumber,
    });
    global?.logger?.info(
      `[7POS UI] - SAFE INIT REQUEST SENT for day: ${dayNumber} shift : ${shiftNumber}`
    );
    setTimeout(() => {
      console.log('Initializing safe after 30000 MS');
      ws?.socket?.send(safeDrop.channels.init, {}, request);
    }, safeDrop.initializeAfter);
  };
  return {
    initializeSafe,
    subscribeSafeEvents,
    clearSafeSubs,
  };
};
