/*
 * prepayDetails
 * refundDetails
 */
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useRef } from 'react';
import { fuelActions } from '../slices/fuel.slice';
import { useFuel } from './useFuel';

export const useFuelCache = () => {
  const { selectedPump } = useFuel();
  const timerRef = useRef();
  const dispatch = useDispatch();
  const { prepayCache, refundCache, futurePreauthCancelCache } = useSelector(
    ({
      fuel: {
        prepayPumpDetails: prepayCache,
        refundPumpDetails: refundCache,
        futurePreauthCancelDetails: futurePreauthCancelCache,
      },
    }) => ({
      prepayCache,
      refundCache,
      futurePreauthCancelCache,
    })
  );

  const setRefundCache = refundDetails => {
    const {
      pumpNumber,
      sequenceNumber,
      fuelAmount,
      refundCartItem,
    } = refundDetails;
    Logger.info(`[Fuel] setRefundCache ---> ${JSON.stringify(refundDetails)}`);
    dispatch(
      fuelActions.setRefundPumpDetails({
        pumpNumber: pumpNumber || selectedPump,
        sequenceNumber,
        fuelAmount,
        refundCartItem,
      })
    );
  };

  const resetRefundCache = () => {
    Logger.info('[Fuel] resetRefundCache --->');
    dispatch(fuelActions.setRefundPumpDetails(undefined));
  };

  const setPrepayCache = prepayDetails => {
    const {
      pumpNumber,
      sequenceNumber,
      fuelAmount,
      transactionId,
      paymentTransactionId,
    } = prepayDetails;
    Logger.debug(`[Fuel] setPrepayCache ---> ${JSON.stringify(prepayDetails)}`);
    dispatch(
      fuelActions.setPrepayPumpDetails({
        pumpNumber: pumpNumber || selectedPump,
        sequenceNumber,
        fuelAmount,
        transactionId,
        paymentTransactionId,
        mediaNumber: 1, // Default to cash.
      })
    );
  };

  const setFuelPrepayPaymentMedia = ({
    mediaNumber = 1,
    paymentTenderId = '',
  }) => {
    Logger.info(
      `[Fuel] Setting Fuel Media Details: ---> media: ${mediaNumber}, tenderId: ${paymentTenderId}`
    );
    dispatch(
      fuelActions.setFuelPrepayPaymentMedia({ mediaNumber, paymentTenderId })
    );
  };

  const setFuturePreauthCancelCache = data => {
    Logger.info(`[Fuel] Setting Future Preauth Cancel`);
    dispatch(fuelActions.setFuturePreauthCancelDetails(data));
  };

  const clearFuturePreauthCancelCache = () => {
    dispatch(fuelActions.setFuturePreauthCancelDetails());
  };

  const resetPrepayCache = () => {
    Logger.debug('[Fuel] resetPrepayCache --->');
    dispatch(fuelActions.setPrepayPumpDetails(undefined));
  };

  const resetFuelSelections = () => {
    // Logger.info('[Fuel] resetFuelSelections --->');
    dispatch(fuelActions.resetAllSelections(undefined));
  };

  // Clearing the timer in case if we redirect to a diferent page with in the duration.
  useEffect(
    () => () => {
      clearTimeout(timerRef.current);
    },
    []
  );

  const scheduleResetFuelSelections = (timeout = 3000) => {
    // Logger.info(`[Fuel] scheduleResetFuelSelections: [${timeout} ms] --->`);
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(resetFuelSelections, timeout);
  };

  const setFuelParams = ({ fuelParameters }) => {
    // Logger.debug(`[Fuel] setFuelParams ---> ${JSON.stringify(fuelParameters)}`);
    Logger.info(`[Fuel] setFuelParams ---> `);

    dispatch(fuelActions.setFuelParams(fuelParameters));
  };
  const resetFuelPumps = () => {
    dispatch(fuelActions.resetFuelPumps(undefined));
  };

  const updateMultiPumpStatus = pumpStates => {
    dispatch(fuelActions.updateMultiPumpStatus(pumpStates));
  };

  const setFuelPumps = pumpsPayload => {
    dispatch(fuelActions.setFuelPumps(pumpsPayload));
  };

  const setCarwashConfig = config => {
    const carwash = {
      ...config,
      packages: config?.packages?.filter(p => !!p.status),
    };
    dispatch(fuelActions.setCarwashConfig(carwash));
  };

  return {
    refundCache,
    setRefundCache,
    resetRefundCache,
    prepayCache,
    setPrepayCache,
    setFuelPrepayPaymentMedia,
    resetPrepayCache,
    resetFuelSelections,
    scheduleResetFuelSelections,
    setFuturePreauthCancelCache,
    futurePreauthCancelCache,
    clearFuturePreauthCancelCache,
    setFuelParams,
    setFuelPumps,
    resetFuelPumps,
    updateMultiPumpStatus,
    setCarwashConfig,
  };
};
