import { useContext } from 'react';
import { useSelector } from 'react-redux';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';

export const useSyncService = () => {
  const [ws] = useContext(WebSocketContext);
  const { storeId, deviceId } = useSelector(state => ({
    storeId: state.main.storeDetails?.storeId,
    deviceId: state.main.deviceInfo?.id,
  }));
  const sendTransHoldReq = isRelease => {
    const request = JSON.stringify({
      sender: '7pos-app',
      target: '7pos-store-coordinator',
      serviceName: 'TRANS_MEMORY',
      message: isRelease ? 'MEMORY_CLEARED' : 'ADDED_TO_MEMORY',
      messageDetail: {
        storeId,
        deviceType: '7POS',
        deviceId,
        message: isRelease ? 'MEMORY_CLEARED' : 'ADDED_TO_MEMORY',
      },
      timeStamp: Date.now(), // #6880 corrected timestamp
    });
    ws.socket?.send('/app/sync-service-msg', {}, request);
  };
  return {
    sendTransHoldReq,
  };
};
