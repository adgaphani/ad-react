import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { useSoundToast } from '../useSoundToast';
import store from '../../store';
import { cartActions } from '../../slices/cart.slice';
import { dailpadActions } from '../../slices/dailpad.slice';
import { cfdActions } from '../../slices/cfd.slice';

import {
  fetchEligibleArbitrate,
  fetchCancelReward,
  fetchRedeemArbitrate,
} from '../../api/promoWrapper';
import { usePromoWrapperRequest } from './usePromoWrapperRequest';
import { useCart } from '../useCart';
import { usePromoUtils } from './usePromoUtils';
import { waitForGivenTime } from '../../Utils/appUtils';
import { SendMessageToCFD } from '../../Communication';
import { ACCOUNT_LOCKED } from '../../constants';

export const usePromoWrapper = () => {
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };
  const { getPromoWrapperRequest } = usePromoWrapperRequest();
  const {
    processArbitrateResponse,
    processPromoWrapperResponse,
    processEligibleResponse,
    HandleRedemptionResponse,
    SendNewRelicNotificationIfNeeded,
    processFuelArbitrateResponse,
  } = usePromoUtils();
  const { finalTotalPrice } = useCart();
  const history = useHistory();
  const {
    member,
    isTransactionVoid,
    isTransactionRefund,
    deviceInfo,
    paymentTransactionId,
    cartItems,
    MemberRewardID,
    items,
    rejectedReward,
    tempArbitRes,
    processPaymentAsMCLoyalty,
  } = useSelector(state => ({
    balanceActive: state.balance.isActive,
    member: state.cart.member,
    transactionId: state.cart.transactionId,
    storeDetails: state.main.storeDetails,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    deviceInfo: state.main.deviceInfo,
    paymentTransactionId: state.cart.paymentTransactionId,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    cartItems: state.cart.cartItems,
    MemberRewardID: state.cfd.MemberRewardID,
    items: state.cart.items,
    rejectedReward: state.cart.rejectedReward,
    tempArbitRes: state.cart.tempArbitRes,
    processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
  }));

  // Cancel Rewards
  const cancelSWPInTransaction = async () => {
    try {
      if (MemberRewardID) {
        const result = await fetchCancelReward(
          MemberRewardID,
          member,
          paymentTransactionId
        );
        const cancelRewardResponse = result?.data?.response;
        if (cancelRewardResponse) {
          dispatch(
            cartActions.UpdateMemberPoints(cancelRewardResponse.rewards_points)
          );
        } else if (result?.data?.cancelReward?.error) {
          global?.logger?.error(
            `[7POS UI] - cancelSWPInTransaction Error ${JSON.stringify(
              result.data.cancelReward.error
            )}`
          );
        }
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - cancelSWPInTransaction Error ${JSON.stringify(error)}`
      );
    }
  };
  const processMemberPromoRes = async () => {
    dispatch(cartActions.setRejectedReward(false));
    await processArbitrateResponse(tempArbitRes, finalTotalPrice, cartItems);
    dispatch(cartActions.setTempArbitRes());
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cartActions.setFinalizeClick(false));
    dispatch(dailpadActions.resetKeypadValue());
    if (
      tempArbitRes?.display_message &&
      tempArbitRes?.errors?.findIndex(err => err?.type === 'upcNotFound') !== -1
    ) {
      DisplayToastMsg(tempArbitRes?.display_message);
    }
    history.push('/payment');
  };

  useEffect(() => {
    // #7993 creating multiple cart trial revist the calling processmember
    const { rejectedReward } = store.getState().cart;
    if (tempArbitRes && rejectedReward) {
      dispatch(cartActions.setRejectedReward(false));
      processMemberPromoRes();
    }
  }, [rejectedReward]);

  const getEligibleArbitCall = async ({
    items,
    isReturnVoid,
    ReceiptTotalAmount,
  }) => {
    // Promo Call on finalize&pay
    let result = null;
    try {
      const requestPayload = getPromoWrapperRequest(items, isReturnVoid);
      Logger?.info(`[7POS UI] :  Sending Eligible Request`);
      result = await fetchEligibleArbitrate(
        requestPayload,
        paymentTransactionId
      );
      if (result !== undefined && result !== 'error') {
        return result;
      }
      throw new Error('Error');
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - EligibleArbitrate Error : ${JSON.stringify(error)}`
      );
      throw new Error(error);
    } finally {
      SendNewRelicNotificationIfNeeded(result, ReceiptTotalAmount);
    }
  };

  const applyRedeemResponse = (redeemResponse, memberRewardId) => {
    dispatch(cartActions.UpdateMemberPoints(redeemResponse?.rewards_points));
    const { cartItems: cItems, basketPromo } = store.getState().cart;
    const { isItemRedemptionIntiated, isSWPIntiated } = store.getState().cfd;
    HandleRedemptionResponse(
      cItems,
      basketPromo,
      isSWPIntiated,
      isItemRedemptionIntiated,
      memberRewardId,
      processPaymentAsMCLoyalty
    );
  };

  // 7-Eleven Redeem
  const redeemDiscounts = async () => {
    const isReturnVoid = isTransactionRefund || isTransactionVoid;
    let redeemResult;
    try {
      const redeemReq = getPromoWrapperRequest(items, isReturnVoid);
      redeemResult = await fetchRedeemArbitrate(
        redeemReq,
        paymentTransactionId
      );
      const iMemberRewardID =
        redeemResult?.data?.redeemReward?.response?.member_rewards[0]?.id;
      if (iMemberRewardID)
        dispatch(cfdActions.setMemberRewardID(iMemberRewardID));
      const {
        arbitResponse,
        redeemResponse,
        cancelRewardResponse,
        redeemError,
      } = processPromoWrapperResponse(redeemResult);
      if (
        !arbitResponse &&
        !redeemResponse &&
        !cancelRewardResponse &&
        redeemError
      ) {
        throw new Error(
          `[7POS UI]: Error fetching the Promo Wrapper redeem Call response`
        );
      }
      if (arbitResponse) {
        redeemResult = await processArbitrateResponse(
          arbitResponse,
          finalTotalPrice,
          cartItems
        );
      }
      if (redeemResponse) {
        applyRedeemResponse(redeemResponse, iMemberRewardID);
      } else if (cancelRewardResponse) {
        dispatch(
          cartActions.UpdateMemberPoints(cancelRewardResponse?.rewards_points)
        );
      } else if (redeemError) {
        throw new Error('Redeem failed');
      }
    } catch (error) {
      dispatch(cfdActions.setUserRewardAction(''));
      throw new Error('Error Processing redeem response');
    }
  };
  // Eligible Call
  const getEligiblePromos = async ({ finalTotalPrice }) => {
    let result;
    const { items, cartItems } = store.getState().cart;
    try {
      result = await getEligibleArbitCall({
        items,
        isReturnVoid: isTransactionRefund || isTransactionVoid,
        terminalID: deviceInfo?.id || 1,
        ReceiptTotalAmount: finalTotalPrice,
      });
      if (!result) {
        throw new Error('7POS : Something went wrong');
      }
      const {
        isEligibleResponse,
        arbitResponse,
        redeemResponse,
        cancelRewardResponse,
        fuelArbResponse,
      } = processPromoWrapperResponse(result);

      if (
        !arbitResponse &&
        !redeemResponse &&
        !isEligibleResponse &&
        !cancelRewardResponse &&
        !fuelArbResponse
      ) {
        throw new Error(
          `[7POS UI]: Error fetching the Promo Wrapper eligible Call response`
        );
      }
      if (isEligibleResponse) {
        if (arbitResponse) {
          dispatch(cartActions.setTempArbitRes(arbitResponse));
        }
        return processEligibleResponse({ finalTotalPrice, isEligibleResponse }); // TODO: Send Processed result
      }
      // Arbitration
      if (arbitResponse && !isEligibleResponse) {
        result = await processArbitrateResponse(
          arbitResponse,
          finalTotalPrice,
          cartItems
        );
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setFinalizePayStatus(false));
        dispatch(cartActions.setFinalizeClick(false));
        dispatch(dailpadActions.resetKeypadValue());
        if (!fuelArbResponse?.promptable_discounts?.length) {
          history.push('/payment');
        }
      }
      if (fuelArbResponse) {
        processFuelArbitrateResponse(fuelArbResponse);
      }
    } catch (error) {
      DisplayToastMsg('Promo Host is Not Availaible');
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setFinalizePayStatus(false));
      dispatch(cartActions.setFinalizeClick(false));
      dispatch(dailpadActions.resetKeypadValue());
      history.push('/payment');
    } finally {
      dispatch(cartActions.setPromoInProgress(false));
      dispatch(cartActions.setUpdateTaxFlag(true));
    }
  };
  // Speedway Redeem
  const speedyRedeemDiscount = async retryCount => {
    const isReturnVoid = isTransactionRefund || isTransactionVoid;
    let redeemResult;
    let isinCorrectPwdError;
    let doesHaveFuelDiscount;
    try {
      const redeemReq = getPromoWrapperRequest(items, isReturnVoid);
      redeemResult = await fetchRedeemArbitrate(
        redeemReq,
        paymentTransactionId
      );
      const iMemberRewardID =
        redeemResult?.data?.redeemReward?.response?.member_rewards[0]?.id;
      if (iMemberRewardID)
        dispatch(cfdActions.setMemberRewardID(iMemberRewardID));
      const {
        arbitResponse,
        redeemResponse,
        cancelRewardResponse,
        redeemError,
        fuelArbResponse,
      } = processPromoWrapperResponse(redeemResult);
      if (
        !arbitResponse &&
        !redeemResponse &&
        !cancelRewardResponse &&
        !fuelArbResponse &&
        redeemError
      ) {
        throw new Error(
          `[7POS UI]: Error fetching the Promo Wrapper redeem Call response`
        );
      }
      // SCALE-1567 cancel fuel reward
      if (fuelArbResponse && redeemResponse && !redeemError) {
        dispatch(cartActions.setCallFuelRewardCancelAPI(true));
      }
      if (redeemError?.message?.includes('invalid_passcode')) {
        isinCorrectPwdError = true;
      }
      if (arbitResponse) {
        redeemResult = await processArbitrateResponse(
          arbitResponse,
          finalTotalPrice,
          cartItems
        );
      }
      if (redeemError?.status === 423) {
        DisplayToastMsg(ACCOUNT_LOCKED);
      }
      if (fuelArbResponse && (!isinCorrectPwdError || retryCount >= 3)) {
        processFuelArbitrateResponse(fuelArbResponse);
        doesHaveFuelDiscount = fuelArbResponse?.promptable_discounts?.length;
        await waitForGivenTime(0); // Added this to handle userAction Notification screen when fuel reward is selected
      }
      if (cancelRewardResponse) {
        dispatch(
          cartActions.UpdateMemberPoints(cancelRewardResponse?.rewards_points)
        );
        throw new Error('Redeem Failed, Cancel reward response received');
      } else if (redeemResponse && Object.keys(redeemResponse)?.length !== 0) {
        applyRedeemResponse(redeemResponse, iMemberRewardID);
      } else if (
        (redeemError && !doesHaveFuelDiscount) ||
        (redeemResponse && Object.keys(redeemResponse)?.length === 0)
      ) {
        throw new Error('Redeem failed');
      } else {
        // To reset CFD Screen
        const iTransactionMessage = {
          CMD: 'RedeemResponse',
          // DiscountAmount: parseFloat(iDiscAmount).toFixed(2) / 100,
          Status: 'No_Reward',
          isSpeedyStore: true,
          processPaymentAsMCLoyalty,
        };
        SendMessageToCFD(iTransactionMessage);
      }
    } catch (error) {
      if (isinCorrectPwdError) {
        throw new Error(`invalid_passcode`);
      }
      throw new Error('Error Processing redeem response');
    }
  };

  return {
    getEligiblePromos,
    cancelSWPInTransaction,
    HandleRedemptionResponse,
    redeemDiscounts,
    speedyRedeemDiscount,
  };
};
