import { useSelector } from 'react-redux';
import moment from 'moment';

import { buildPMB } from '../../Utils/arbirtationUtils';
import { fetchPmb } from '../../api/promos/fetchPmb';
import { sendNewRelicNotifictaion } from '../../Utils/appUtils';

export const usePMB = () => {
  const {
    transInfo,
    taxBeforeEBTExempt,
    storeDetails,
    items,
    member,
    deviceInfo,
    user,
    transactionId,
    isTransactionVoid,
    isTransactionRefund,
    basketPromo,
    MemberBarcodeInfo,
    allPayments,
    CashPaymentInfo,
    cashBack,
    taxInfo,
    pmb,
    isSpeedyStore,
    paymentTransactionId,
  } = useSelector(state => ({
    transInfo: state.cart.transDetails,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    storeDetails: state.main.storeDetails,
    items: state.cart.cartItems,
    member: state.cart.member,
    deviceInfo: state.main.deviceInfo,
    user: state.auth.user,
    cashBack: state.socket.cashBack,
    transactionId: state.cart.transactionId,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    basketPromo: state.cart.basketPromo,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    allPayments: state.cart.allPayments,
    CashPaymentInfo: state.cart.CashPaymentInfo,
    taxInfo: state.cart.taxInfo,
    pmb: state.cart.pmb,
    isSpeedyStore: state.main.isSpeedyStore,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));
  const submitPMB = async ({ finalTotalPrice, isAbortTransaction } = {}) => {
    const { loyalty_id, phone_number, mobile_number } = member || {};
    if (
      !Object.keys(pmb).length ||
      (!loyalty_id && !phone_number && !mobile_number)
    ) {
      return;
    }
    const MembertransactionId = localStorage.getItem('MemberTransSeqNum');
    const todayDate = Date.now();
    let receiptTotalAmount = finalTotalPrice;
    if (!isAbortTransaction) {
      receiptTotalAmount =
        Number(transInfo['TOTAL DUE']) - Number(taxBeforeEBTExempt);
    }
    let newRelicRequest = {
      storeProfile: storeDetails,
      terminalID: deviceInfo?.id,
      tranSeq: transactionId,
      dgetranSeq: MembertransactionId,
      MemberBarcodeInfo,
      MemberID: member?.loyalty_id,
      AltID: member?.mobile_number,
      MessageType: 'SRPPostMarketBasket',
      ResponseCode: 0,
      ReceiptTotalAmount: receiptTotalAmount,
      ReceiptDateTime: `${moment.utc().format('MM/DD/YYYY HH:mm:ss A')}`,
    };
    try {
      const addPMB = buildPMB({
        storeDetails,
        cartItems: items,
        deviceInfo,
        user,
        transactionId,
        MembertransactionId,
        isTransactionVoid,
        isTransactionRefund,
        basketPromo,
        MemberBarcodeInfo,
        ReceiptTotalAmount: receiptTotalAmount,
        isAbortTransaction,
        taxInfo,
        ...(!isAbortTransaction && {
          allPayments,
          CashPaymentInfo,
          cashBack,
        }),
      });
      let newPMB = null;
      const account = {
        loyalty_id: member?.loyalty_id ? member?.loyalty_id : undefined,
        alt_id:
          member?.phone_number || member?.mobile_number
            ? member?.phone_number || member?.mobile_number
            : undefined,
      };
      // #6901 added mandatory field check for PMB
      // As per the discussion with team token should be string and amount should be int
      let token = pmb?.token || '';
      if (!pmb?.token) {
        token = `01${deviceInfo?.id}${transactionId}`;
      }
      let txn_date = pmb?.txn_date || '';
      if (!pmb?.txn_date) {
        txn_date = moment().format('YYYY-MM-DDTHH:mm:ss');
      }
      let channel = pmb?.channel || '';
      if (!pmb?.channel) {
        channel = isSpeedyStore ? '7POS_SPW' : '7POS';
      }
      // Transaction amount need update here should need not pick from promo response
      // when coupon and items are not eligible promo will not reflect due to that need calcualte here
      // let txn_total = pmb?.txn_total || '';
      // if (!pmb?.txn_total) {
      //    txn_total = parseFloat(parseFloat(receiptTotalAmount * 100).toFixed(2));
      // }
      const txn_total = parseFloat(
        parseFloat(Number(receiptTotalAmount) * 100).toFixed(2)
      );
      newPMB = {
        ...pmb,
        store_number: storeDetails?.storeId,
        txn_total,
        txn_date,
        channel,
        token,
        pmb: addPMB,
        items: [],
        account,
      };
      const result = await fetchPmb(newPMB, paymentTransactionId);
      Logger.info(`[7POS UI] - PMB request Sucess :`);
      const timeDifference = Math.abs(todayDate - Date.now());
      newRelicRequest = {
        ...newRelicRequest,
        POSRoundTripDuration: timeDifference,
        statusCode: result?.status,
      };
    } catch (e) {
      const timeDifference = Math.abs(todayDate - Date.now());
      newRelicRequest = {
        ...newRelicRequest,
        statusCode: e?.response?.status,
        ResponseCode: e?.response?.status,
        POSRoundTripDuration: timeDifference,
      };
    } finally {
      sendNewRelicNotifictaion(newRelicRequest, paymentTransactionId);
    }
  };
  return {
    submitPMB,
  };
};
