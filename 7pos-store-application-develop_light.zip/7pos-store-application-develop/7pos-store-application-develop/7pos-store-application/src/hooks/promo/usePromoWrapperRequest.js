import { useSelector } from 'react-redux';
import moment from 'moment';
import { getArbitrationRequest } from '../../Utils/arbirtationUtils';
import { isLottery } from '../../Utils/lotteryUtils';
import { getItemPriceSuffix } from '../../Utils/cartUtils';
import { useCart } from '../useCart';
import store from '../../store';
// import { FuelRewardCancelReasons } from '../../constants';

export const usePromoWrapperRequest = () => {
  const {
    member,
    transactionId,
    storeDetails,
    deviceInfo,
    MemberBarcodeInfo,
    taxInfo,
    paymentTransactionId,
    // CatlogID,
    isSpeedyStore,
    fuelGrades,
    selectedGrade,
    channel,
    prepayPumpDetails,
    priceUpdateDateTime,
    selectedSpeedyRewardType,
  } = useSelector(state => ({
    member: state.cart.member,
    transactionId: state.cart.transactionId,
    storeDetails: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    taxInfo: state.cart.taxInfo,
    paymentTransactionId: state.cart.paymentTransactionId,
    CatlogID: state.cfd.CatlogID,
    isSpeedyStore: state.main.isSpeedyStore,
    fuelGrades: state.fuel.fuelPrices,
    selectedGrade: state.cart.selectedGrade,
    channel: state.main.channel,
    prepayPumpDetails: state.fuel.prepayPumpDetails,
    priceUpdateDateTime: state.fuel.priceUpdateDateTime,
    speedyUserEnteredZipCode: state.cfd.speedyUserEnteredZipCode,
    selectedSpeedyRewardType: state.cfd.selectedSpeedyRewardType,
  }));
  const { isFuelTransactionInProgress } = useCart();
  const getEligibleAribitReqPayload = (
    items,
    isReturnVoid,
    fuelRewardCancelReason
  ) => {
    const isOnlinePromo = true;
    const terminalID = deviceInfo?.id || 1;
    const MembertransactionId = localStorage.getItem('MemberTransSeqNum');
    const onePromoArbitrationReq = getArbitrationRequest(
      member,
      transactionId,
      items,
      storeDetails,
      MembertransactionId,
      isReturnVoid,
      terminalID,
      isOnlinePromo,
      MemberBarcodeInfo
    );
    const itemsBasket = { items: [] };
    let txnAmount = 0;
    itemsBasket.items = items
      .filter(
        item =>
          (item.isMoneyOrder !== true &&
            item.isCarwash !== true &&
            !isLottery(item) &&
            !fuelRewardCancelReason &&
            (!item.isFuel ||
              (item.isFuel && item.totalRetailPrice > 0 && isSpeedyStore))) || // Filtering Fuel Refunds
          (fuelRewardCancelReason && item.isFuel) // for fuel reward cancel api we only need to send the fuel item
      )
      .map((item, index) => {
        const departmentId =
          item?.category?.id ||
          (
            item?.PSAGroupInfo?.psaCode +
            item?.PSAGroupInfo?.catCode +
            item?.PSAGroupInfo?.subcatCode
          ).toString();

        let iItemAmount = 0;
        let itemStorediscountAmt = 0;
        let itempBrierlyDiscountQty = 0;
        let itempBrierlyDiscount = 0;
        if (item.arbitration) {
          item.arbitration.map(arbitdata => {
            if (arbitdata.source === 'brierley') {
              itempBrierlyDiscount += arbitdata.itemDiscount;
              // eslint-disable-next-line no-plusplus
              itempBrierlyDiscountQty++;
            } else {
              itemStorediscountAmt += arbitdata.itemDiscount;
            }
            return arbitdata;
          });
        }
        if (item.totalOverridedPrice > 0) {
          iItemAmount =
            parseFloat(parseFloat(item.totalOverridedPrice)) -
            parseFloat(parseFloat(itemStorediscountAmt));
        } else {
          iItemAmount =
            parseFloat(parseFloat(item.totalRetailPrice)) -
            parseFloat(parseFloat(itemStorediscountAmt));
        }
        if (item.quantity === itempBrierlyDiscountQty) {
          iItemAmount = 0;
        } else if (item.totalCouponQty === 0) {
          iItemAmount /= item.quantity;
        } else {
          let coupon_discount = 0;
          if (item.storeCoupon && item.storeCoupon[0]) {
            item.storeCoupon.map(coupondata => {
              coupon_discount += Math.abs(coupondata.amount) * 100;
              return coupondata;
            });
          }
          if (
            iItemAmount - itempBrierlyDiscount - parseFloat(coupon_discount) >=
            iItemAmount / item.quantity
          ) {
            iItemAmount /= item.quantity;
          } else {
            // #9328 calculated adjusted price if any coupon reduced the item price lessthan single item value.
            iItemAmount =
              iItemAmount - itempBrierlyDiscount - parseFloat(coupon_discount);
            iItemAmount /= item.quantity;
          }
        }
        const itemsuffix = getItemPriceSuffix({
          item,
          taxData: taxInfo,
          ignoreFlag: true,
        });
        txnAmount += iItemAmount;
        let retailPrice =
          item.totalOverridedPrice > 0
            ? parseFloat(parseFloat(item.totalOverridedPrice))
            : parseFloat(parseFloat(item.totalRetailPrice));

        retailPrice /= item.quantity;

        if (fuelRewardCancelReason && item.isFuel) {
          return {
            id: index,
            department_id: '0',
            retail_price: retailPrice,
            isFuel: true,
            pump_number: prepayPumpDetails?.pumpNumber,
          };
        }

        return {
          id: index,
          slin: item.itemId?.toString(),
          upc: item.upc,
          department_id: departmentId,
          quantity: item.quantity,
          retail_price: retailPrice,
          adjusted_price: iItemAmount > 0 ? iItemAmount : 0,
          tax_type: itemsuffix === '' ? 'N' : itemsuffix,
          ...(item?.isFuel
            ? {
                isFuel: true,
                pump_number: prepayPumpDetails?.pumpNumber,
                selectedGrade: {
                  grade_id: selectedGrade?.product,
                  product_id: selectedGrade?.productNumber,
                },
                department_id: '0',
              }
            : {}),
          itemTypeId: item.itemTypeID,
        };
      });
    return {
      itemsBasket,
      txnAmount,
      onePromoArbitrationReq,
    };
  };

  const getPromoWrapperRequest = (
    items,
    isReturnVoid,
    fuelRewardCancelReason = ''
  ) => {
    const { itemsBasket, onePromoArbitrationReq } = getEligibleAribitReqPayload(
      items,
      isReturnVoid,
      fuelRewardCancelReason
    );
    const {
      CatlogID: cLogId,
      speedyUserEnteredZipCode,
    } = store?.getState()?.cfd;
    console.log(
      'generating the payload___________************',
      'REWARD ID:',
      cLogId,
      'PASSCODE:',
      speedyUserEnteredZipCode
    );
    const { external } = onePromoArbitrationReq;

    const finalPayload = {
      meta: {
        txn_date: moment().format('YYYY-MM-DDTHH:mm:ss'),
        transaction_id: paymentTransactionId,
        transaction_sequence_id: `01${deviceInfo?.id || 1}${transactionId}`,
        time_zone: storeDetails.timeZone,
        version: process.env.REACT_APP_VERSION,
      },
      memberInfo: {
        loyalty_id: member?.loyalty_id,
        rewards_points: member?.rewards_points,
        ...(cLogId && cLogId !== '' && !fuelRewardCancelReason
          ? { reward_id: cLogId }
          : {}),
        reward_type: fuelRewardCancelReason
          ? 'fuel'
          : selectedSpeedyRewardType ?? 'merchandise',
        entry_method: 'swipe',
        ...(speedyUserEnteredZipCode
          ? { passcode: speedyUserEnteredZipCode }
          : {}),
      },
      ...(fuelRewardCancelReason
        ? {}
        : {
            arbitration: {
              channel,
              external,
            },
          }),
      basket: itemsBasket.items,
      ...(isSpeedyStore && isFuelTransactionInProgress
        ? {
            fuelInfo: {
              loyalty_offline_flag: false,
              time_zone: storeDetails.timeZone,
              multiple_loyalty_capable: true,
              brand: {
                name: 'Speedway',
                sub_name: 'sub brand',
                version: process.env.REACT_APP_VERSION,
              },
              ...(fuelRewardCancelReason
                ? { status: 'Dispenser Canceled' }
                : {
                    fuel_brand: 'Speedway',
                    fuel_data: {
                      grades: fuelGrades.map(grade => ({
                        abbr: grade.storeProductName,
                        name: grade.productName,
                        price: grade.price * 1000, // Converting to cents as Loyalty team needs in Cents
                        cash_price: grade.cashPrice * 1000,
                        grade_id: grade.product,
                        product_id: grade.productNumber,
                      })),
                      last_updated: Date.now(priceUpdateDateTime),
                    },
                  }),
            },
          }
        : {}),
    };
    return finalPayload;
  };
  return { getPromoWrapperRequest };
};
