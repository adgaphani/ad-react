import { useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { cartActions } from '../../slices/cart.slice';
import { centsToDollor } from '../../Utils';
import { useFuel } from '../useFuel';
import store from '../../store';

export const useLoyalty = () => {
  const dispatch = useDispatch();
  const { mandatoryDiscounts, optionalDiscounts, fuelLoyalty } = useSelector(
    state => ({
      mandatoryDiscounts: state.cart.fuelLoyalty?.forced_discounts ?? [],
      optionalDiscounts: state.cart.fuelLoyalty?.promptable_discounts ?? [],
      fuelLoyalty: state.cart.fuelLoyalty,
      selectedGrade: state.cart.selectedGrade,
    })
  );
  const { fuelPrepaidAmount } = useFuel();
  const fuelDiscounts = useMemo(() => {
    // For refund calculation will be done in useSharedFuelRequest hook.
    if (fuelPrepaidAmount < 0) {
      const { calculatedFuelDiscounts } = store.getState().cart;
      return calculatedFuelDiscounts;
    }
    const selectedOptionalDiscounts =
      optionalDiscounts?.filter(d => d.isSelected) || [];
    const mandatoryDiscountsForSelectedGrade =
      fuelLoyalty?.forcedDiscountForSelectedGrade || [];
    const fuelDiscounts = [
      ...mandatoryDiscountsForSelectedGrade,
      ...selectedOptionalDiscounts,
    ];

    const totalDiscount =
      (fuelDiscounts.length &&
        fuelDiscounts?.reduce((acc, d) => acc + d.discount, 0)) ||
      0;
    // const lDiscounts = [...mandatoryDiscounts, ...selectedOptionalDiscounts];
    const intGalonLimit = fuelDiscounts?.[0]?.max_gallons;
    // Calculates MAX GALLON LIMIT
    const maxGalonLimit = fuelDiscounts.length
      ? fuelDiscounts?.reduce(
          (acc, d) => (acc < d.max_gallons ? acc : d.max_gallons),
          intGalonLimit
        )
      : 0;
    const totalOptionalLoyaltyDiscount =
      (selectedOptionalDiscounts?.length &&
        selectedOptionalDiscounts?.reduce((acc, d) => acc + d.discount, 0)) ||
      0;
    const uDiscs = fuelDiscounts?.map(d => ({
      ...d,
      pos_display_text: `${centsToDollor(d.discount)}/gal ${d.pos_text}`,
    }));
    const fDiscounts = {
      totalDiscount,
      discounts: uDiscs,
      maxGalonLimit,
      mandatoryDiscounts,
      optionalDiscounts: selectedOptionalDiscounts,
      loyaltyDiscounts: uDiscs,
      loyaltyTotalDiscount: totalDiscount,
      mandatoryDiscountsForSelectedGrade,
      totalOptionalLoyaltyDiscount,
    };
    dispatch(cartActions.setFuelCalculatedDiscounts(fDiscounts));
    Logger.debug(
      `[7POS UI] : Calculated fuel discounts: ${JSON.stringify(fDiscounts)}`
    );
    return fDiscounts;
  }, [fuelLoyalty, fuelPrepaidAmount]);
  return {
    fuelDiscounts,
  };
};
