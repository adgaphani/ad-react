import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { cartActions } from '../../slices/cart.slice';
import { SKIP_PROMO_TAX } from '../../constants';
import store from '../../store';
import {
  removeDuplicates,
  sendNewRelicNotifictaion,
} from '../../Utils/appUtils';
import { getMerchItemsTotalAmount } from '../../Utils/cartUtils';
import { useSoundToast } from '../useSoundToast';
import { Arbitration } from '../../Utils/arbitration';
import { ArbitrationUtils } from '../../Utils/promoUtil';
import { cfdActions } from '../../slices/cfd.slice';
import { dailpadActions } from '../../slices/dailpad.slice';
import {
  triggerBestRewardWorkFlow,
  triggerSWPWorkFlow,
} from '../../Utils/7rewardsUtils';
import { SendMessageToCFD } from '../../Communication';
import { useCart } from '../useCart';
import { fetchCancelFuelReward } from '../../api/promoWrapper';
import { usePromoWrapperRequest } from './usePromoWrapperRequest';

export const usePromoUtils = () => {
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const history = useHistory();
  const {
    cartItems,
    storeDetails,
    deviceInfo,
    transactionId,
    MemberBarcodeInfo,
    member,
    paymentTransactionId,
    selectedGrade,
    isSpeedyStore,
    isCashCreditStore,
    callFuelRewardCancelAPI,
    isTransactionVoid,
    isTransactionRefund,
    items,
  } = useSelector(state => ({
    cartItems: state.cart.cartItems,
    storeDetails: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    transactionId: state.cart.transactionId,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    member: state.cart.member,
    paymentTransactionId: state.cart.paymentTransactionId,
    selectedGrade: state.cart.selectedGrade,
    isSpeedyStore: state.main.isSpeedyStore,
    isCashCreditStore: state.main.isSpeedyStore,
    callFuelRewardCancelAPI: state.cart.callFuelRewardCancelAPI,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    items: state.cart.items,
  }));
  const { isFuelTransactionInProgress } = useCart();
  const { getPromoWrapperRequest } = usePromoWrapperRequest();

  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };
  // Process Items in Result
  const processItemsInResult = (result, preCartItems) => {
    let isRequiredItemRefersh = result?.items?.filter(
      item => item?.arbitration?.length > 0
    );
    if (isRequiredItemRefersh?.length <= 0)
      isRequiredItemRefersh = preCartItems?.filter(
        item => item?.arbitration?.length > 0
      );
    if (isRequiredItemRefersh?.length > 0) {
      dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO_TAX));
      dispatch(cartActions.updateItems(result.items));
    } else {
      dispatch(cartActions.addCartItems(result.items));
      dispatch(cartActions.setPreCartItems(result.items));
    }
  };

  // Process Arbitration in Result
  const processArbitrationInResult = (result, items) => {
    dispatch(cartActions.setArbitration(result.arbitration));
    if (result.arbitration?.basket) {
      const basketPromos = result.arbitration?.basket || [];
      if (basketPromos[0]) {
        // exclude round off charity item
        const iMerchItems = items?.filter(item => !item.isRoundUpCharityItem);
        // eslint-disable-next-line no-use-before-define
        const { totalMerchSaleAmount } = getMerchItemsTotalAmount(
          iMerchItems,
          null,
          false,
          null
        );
        if (
          totalMerchSaleAmount <
          Number(Math.abs(basketPromos[0].item_discount)) / 100
        ) {
          global?.logger?.info(
            `[7POS UI] - ignoring basket promo due to eligible items price:${totalMerchSaleAmount} lessthan basket promo:${Number(
              Math.abs(basketPromos[0].item_discount)
            ) / 100}`
          );
        } else
          dispatch(
            cartActions.setBasketPromo(removeDuplicates(basketPromos, 'id'))
          );
      }
    }
  };

  const processFinalAribtrateResponse = (arbitResponse, result) => {
    const { items, preCartItems } = store.getState().cart;
    if (arbitResponse !== 'error' || arbitResponse?.length) {
      if (result?.pmb) {
        dispatch(cartActions.setPmbDetails(result.pmb));
      }
      if (result?.items) {
        processItemsInResult(result, preCartItems);
      }
      if (result?.arbitration) {
        processArbitrationInResult(result, items);
      }
    } else {
      global?.logger?.error(`[7POS UI] - promo call failed`);
      // # 4374 added toast message for online promo call.
      DisplayToastMsg('Promo Host is Not Availaible');
    }
  };
  const processArbitrateResponse = async (
    arbitResponse,
    finalTotalPrice,
    cartitems
  ) => {
    const arbitResp = {
      data: arbitResponse,
    };
    try {
      // Validating Arbitrate Response with Rules
      const res = await new Arbitration(arbitResp).processData();
      const {
        data: {
          response: { basket, fees, items },
          pmb,
          external = [],
        },
      } = res;

      const respa = new ArbitrationUtils(cartitems, {
        basket,
        fees,
        items,
        external,
        ReceiptTotalAmount: finalTotalPrice,
      }).processPromos();
      const result = {
        items: respa,
        pmb,
        arbitration: {
          basket,
          fees,
          items,
          external,
        },
      };
      processFinalAribtrateResponse(arbitResponse, result);
      return;
    } catch (error) {
      console.log('error', error);
    }
  };
  const processPromoWrapperResponse = result => {
    let isEligibleResponse;
    let isEligibleError;
    let arbitResponse;
    let arbitError;
    let redeemResponse;
    let redeemError;
    let cancelRewardResponse;
    let cancelRewardError;
    let isEligibleEmpty;
    let fuelArbError;
    let fuelArbResponse;
    const {
      data: {
        isEligible,
        merchandiseArbitration,
        redeemReward,
        cancelReward,
        fuelArbitration,
      } = {},
    } = result;

    if (isEligible) {
      const {
        response: { best_reward, shop_with_points, best_fuel_reward },
      } = isEligible;
      isEligibleResponse =
        best_reward || shop_with_points || best_fuel_reward
          ? isEligible?.response
          : undefined;
      isEligibleError = isEligible?.error;
    }
    if (merchandiseArbitration || fuelArbitration) {
      arbitResponse = merchandiseArbitration?.response;
      arbitError = merchandiseArbitration?.error;
      fuelArbResponse = fuelArbitration?.response
        ? { ...fuelArbitration.response, promptable_discounts: undefined } // Disabling PROMPATABLE DISCOUNTS
        : undefined;
      fuelArbError = fuelArbitration?.error;
      isEligibleEmpty = !result?.data?.isEligible;
    }
    if (redeemReward) {
      redeemResponse = redeemReward?.response;
      // redeemError =
      //   redeemReward?.error ??
      //   (!redeemReward?.response && 'Empty Redeem Error');
      redeemError = redeemReward?.error;
    }
    if (cancelReward) {
      cancelRewardResponse = cancelReward?.response;
      cancelRewardError = cancelReward?.error;
    }
    if (
      isEligibleError ||
      redeemError ||
      arbitError ||
      cancelRewardError ||
      fuelArbError
    ) {
      Logger.info(
        `[7POS UI] Promo Wrapper Response : - One of response is Empty : ${JSON.stringify(
          result
        )}`
      );
    }
    if (
      !isEligible &&
      !!arbitResponse?.display_message &&
      arbitResponse?.errors.findIndex(err => err.type === 'upcNotFound') !== -1
    ) {
      DisplayToastMsg(arbitResponse?.display_message);
    }
    return {
      isEligibleResponse,
      arbitResponse,
      redeemResponse,
      cancelRewardResponse,
      isEligibleEmpty,
      fuelArbResponse,
      redeemError,
    };
  };
  const processEligibleResponse = async ({
    finalTotalPrice,
    isEligibleResponse,
  }) => {
    dispatch(cartActions.setFinalizePayStatus(true));
    dispatch(dailpadActions.resetKeypadValue());
    try {
      const notificationPage = isSpeedyStore
        ? '/home/SpeedyCFDNotification'
        : '/home/CFDNotification';
      const authcode =
        isEligibleResponse?.zip_code || isEligibleResponse?.postal_code;
      const TotalPrice = Number(parseFloat(finalTotalPrice).toFixed(2));
      if (
        (authcode && isEligibleResponse?.best_reward) ||
        (isSpeedyStore &&
          (isEligibleResponse.best_fuel_reward ||
            isEligibleResponse?.best_reward))
      ) {
        dispatch(cfdActions.IntiatedItemRedemption(true));
        dispatch(cfdActions.setAltIDUserReset(false));
        dispatch(cfdActions.setAltIDUserTrigger(false));
        const ret = triggerBestRewardWorkFlow(
          isEligibleResponse?.best_reward,
          authcode,
          cartItems,
          TotalPrice,
          isEligibleResponse?.best_fuel_reward
        );
        if (ret === 'success') {
          const data = {
            offer: 'best_reward',
          };

          history.push({
            pathname: notificationPage,
            state: data,
          });
          return;
        }
      }
      if (isEligibleResponse?.shop_with_points) {
        dispatch(cfdActions.IntiatedSWP(true));
        dispatch(cfdActions.setAltIDUserReset(false));
        dispatch(cfdActions.setAltIDUserTrigger(false));
        const ret = triggerSWPWorkFlow(
          isEligibleResponse?.shop_with_points,
          authcode,
          TotalPrice
        );
        if (ret === 'success') {
          const data = {
            offer: 'shop_with_points',
          };

          history.push({
            pathname: notificationPage,
            state: data,
          });
          return;
        }
      }
    } catch (error) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setFinalizePayStatus(false));
      global?.logger?.error(
        `[7POS UI] - processEligibleResponse Failure ${JSON.stringify(error)}`
      );
    }
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));

    history.push('/payment');
  };
  const HandleRedemptionResponse = (
    cartItems,
    basketPromo,
    isSWPIntiated,
    isItemRedemptionIntiated,
    iMemberRewardID,
    processPaymentAsMCLoyalty
  ) => {
    let iRedeemptionItemFound = false;
    let iDiscAmount = 0;
    // let ierror = 'error';
    cartItems.map(item => {
      if (item.brierleyPromos.length > 0) {
        item.brierleyPromos.map(Promo => {
          if (Promo.promoDetails.length > 0) {
            Promo.promoDetails.map(promoDetailsdata => {
              if (promoDetailsdata.details) {
                if (
                  promoDetailsdata.details.reward_member_id === iMemberRewardID
                ) {
                  iRedeemptionItemFound = true;
                  iDiscAmount = promoDetailsdata.item_discount;
                }
              }
              return promoDetailsdata;
            });
          }
          return Promo;
        });
      }
      return item;
    });

    if (basketPromo?.length > 0) {
      iDiscAmount = Number(basketPromo[0].item_discount);
    }
    if (
      (iRedeemptionItemFound && isItemRedemptionIntiated) ||
      iDiscAmount >= 0
    ) {
      const iTransactionMessage = {
        CMD: 'RedeemResponse',
        DiscountAmount: parseFloat(iDiscAmount).toFixed(2) / 100,
        Status: 'Success',
        isSpeedyStore,
        processPaymentAsMCLoyalty,
      };
      SendMessageToCFD(iTransactionMessage);
      // ierror = 'sucess';
    } else {
      throw new Error('Redeem failed');
    }
    // return ierror;
  };
  const SendNewRelicNotificationIfNeeded = (response, ReceiptTotalAmount) => {
    const MembertransactionId = localStorage.getItem('MemberTransSeqNum');
    const {
      data: {
        merchandiseArbitration: { error, response: merchResponse } = {},
        merchandiseArbitration,
      },
    } = response;
    if (!merchandiseArbitration) {
      return;
    }
    const responseStatusCode = error?.status ?? (merchResponse.status || '200');
    const todayDate = Date.now();
    const timeDifference = Math.abs(todayDate - Date.now());
    const newRelicRequest = {
      storeProfile: storeDetails,
      terminalID: deviceInfo?.id,
      tranSeq: transactionId,
      dgetranSeq: MembertransactionId,
      MemberBarcodeInfo,
      MemberID: member.loyalty_id,
      AltID: member.mobile_number,
      MessageType: 'SRPArbitration',
      statusCode: responseStatusCode,
      ResponseCode: 0,
      POSRoundTripDuration: timeDifference,
      ReceiptTotalAmount,
    };
    sendNewRelicNotifictaion(newRelicRequest, paymentTransactionId);
  };
  const processFuelArbitrateResponse = fuelArbRes => {
    if (!isFuelTransactionInProgress) {
      history.push('/payment');
      return;
    }
    // Processing Fuel Response, Extracting forced discount for selected grade
    const isSelectedGradeDisc = fuelArbRes?.fuel_data?.grades?.find(
      grade => grade?.grade_id === selectedGrade.storeProduct
    );
    const fLoyalty = {
      ...fuelArbRes,
      forcedDiscountForSelectedGrade:
        (isCashCreditStore
          ? isSelectedGradeDisc?.discount_breakdown_cash
          : isSelectedGradeDisc?.discount_breakdown) || [],
    };
    dispatch(cartActions.setFuelLoyalty(fLoyalty)); // Cart in 7POS will be updated with manadatory discounts
    SendMessageToCFD({ CMD: 'fuelLoyalty', data: fLoyalty }); // Cart in CFD will be updated with manadatory discounts
    if (fuelArbRes?.promptable_discounts?.length) {
      dispatch(cfdActions.setFuelPromptEnabled(true));
      history.push({
        pathname: '/home/SpeedyCFDNotification',
        state: {
          offer: 'fuel_discount',
        },
      });
    } else {
      history.push('/payment');
    }
  };

  // Fuel Reward Cancel
  const cancelFuelRewardInTransaction = async cancelReason => {
    try {
      if (
        isSpeedyStore &&
        callFuelRewardCancelAPI &&
        member?.loyalty_id &&
        items.length > 0
      ) {
        const payload = getPromoWrapperRequest(
          items,
          isTransactionRefund || isTransactionVoid,
          cancelReason
        );
        global?.logger?.info(
          `7POS Application - calling Cancel Fuel Reward API for ${paymentTransactionId} with payload ${payload}`
        );
        const result = await fetchCancelFuelReward(
          payload,
          paymentTransactionId
        );
        global?.logger?.info(
          `7POS Application - Cancel Fuel Reward Success for ${paymentTransactionId}`
        );
        if (result?.data?.cancelReward?.error) {
          global?.logger?.error(
            `7POS Application - cancelFuelRewardInTransaction Error ${JSON.stringify(
              result.data.cancelReward.error
            )}`
          );
        }
      }
    } catch (error) {
      global?.logger?.error(
        `7POS Application - cancelFuelRewardInTransaction Error ${JSON.stringify(
          error
        )}`
      );
    } finally {
      // reset the flag after API call
      dispatch(cartActions.setCallFuelRewardCancelAPI(false));
    }
  };

  return {
    processArbitrateResponse,
    processPromoWrapperResponse,
    processEligibleResponse,
    HandleRedemptionResponse,
    SendNewRelicNotificationIfNeeded,
    processFuelArbitrateResponse,
    cancelFuelRewardInTransaction,
  };
};
