import { useHistory } from 'react-router-dom';
import { useRouteMatch } from 'react-router';

export const useSafeDropHistory = () => {
  const history = useHistory();
  const { path } = useRouteMatch();
  const navigateTOHome = isAbort => {
    history.push({
      pathname: '/home',
      ...(isAbort ? { search: '?status=safeComplete' } : {}),
    });
  };
  const navigateToSafeStart = () => {
    history.push({
      pathname: '/home/safeDrop/start',
    });
  };
  const navigateToProcessing = () => {
    history.push({
      pathname: '/home/safeDrop/processing',
    });
  };
  const navigateToOfline = () => {
    history.push({
      pathname: '/home/safeDrop/ofline',
    });
  };
  const navigateToComplete = () => {
    history.push({
      pathname: '/home/safeDrop/complete',
      search: `?status=safeComplete`,
    });
  };
  const navigateTOOflinePayment = () => {
    history.push({
      pathname: '/home/safeDrop/ofline/payment',
    });
  };
  const navigateTOValutStart = () => {
    history.push({
      pathname: '/home/safeDrop/vaultStart',
    });
  };
  const navigateTOValutEnvlp = () => {
    history.push({
      pathname: '/home/safeDrop/ofline/envelop',
    });
  };
  const navigateToManualEnter = () => {
    history.push({
      pathname: '/home/nonIntegratedSafe/ManualEnter',
    });
  };
  const navigateToManualEnvlp = () => {
    history.push({
      pathname: '/home/nonIntegratedSafe/ManualEnter/envelop',
    });
  };
  const navigateToManualPayment = () => {
    history.push({
      pathname: '/home/nonIntegratedSafe/ManualEnter/payment',
    });
  };
  const navigateToManualComplete = () => {
    history.push({
      pathname: '/home/nonIntegratedSafe/ManualEnter/complete',
      search: `?status=safeComplete`,
    });
  };
  return {
    navigateTOHome,
    navigateTOOflinePayment,
    navigateToComplete,
    navigateToOfline,
    navigateToProcessing,
    navigateToSafeStart,
    navigateTOValutStart,
    path,
    navigateTOValutEnvlp,
    navigateToManualEnter,
    navigateToManualEnvlp,
    navigateToManualPayment,
    navigateToManualComplete,
  };
};
