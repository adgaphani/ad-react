import React, { useContext } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { useSoundToast } from './useSoundToast';
import {
  PINPAD_RESET_TIMER,
  PINPAD_RESET_START,
  PINPAD_RESET_REMINDER,
  PINPAD_RESET_START_TOASTER,
  PINPAD_RESET_SUCCESS_TOASTER,
  DEVICE_INITIALIZED,
  PINPAD_UNAVAILABLE,
  DEVICE_DISCONNECTED,
  CMD_NOT_AVAILABLE,
  USB_DEVICE_NOT_FOUND,
} from '../constants';
import { mainActions } from '../slices/main.slice';
import { cartActions } from '../slices/cart.slice';
import { cfdActions } from '../slices/cfd.slice';
import { socketActions } from '../slices/socket.slice';
import PinpadResetTimerTst from '../components/POS/ToastMessages/PinpadResetTimerTst';
import store from '../store';
import { AppContext } from '../AppContext';

export const usePinpadCQListener = () => {
  const toast = useSoundToast();
  const dispatch = useDispatch();
  const history = useHistory();
  const appContextActions = useContext(AppContext);

  const pinpadControlQueueListener = e => {
    try {
      const { message } = JSON.parse(e.body)?.messageBody;
      // eslint-disable-next-line arrow-body-style
      const renderToastMessage = () => {
        // eslint-disable-next-line react/react-in-jsx-scope
        return <PinpadResetTimerTst />;
      };
      if (message === PINPAD_RESET_REMINDER) {
        toast({
          status: 'error',
          duration: 5000,
          position: 'top-right',
          description:
            'PINPAD WILL RESET WITHIN 10 minutes NO NETWORK TRANS CAN BE PERFORMED DURING RESET',
        });
        Logger.info(
          `PinPad reset 1st reminder received and will reset in next 10 mins`
        );
      } else if (message === PINPAD_RESET_TIMER) {
        const pinPadResetTimer = new Date();
        Logger.info(`PinPad reset 2nd reminder received:${pinPadResetTimer}`);
        dispatch(mainActions.setpinpadResetRemainderTimer(pinPadResetTimer));
        toast({
          status: 'error',
          duration: 5 * 60 * 1000,
          position: 'top-right',
          description: renderToastMessage(),
        });
      } else if (message === PINPAD_RESET_START) {
        Logger.info(`PinPad reset started.`);
        dispatch(mainActions.setpinpadResetInProgress(true));
        toast({
          status: 'success',
          duration: 5000,
          position: 'top-left',
          description: PINPAD_RESET_START_TOASTER,
        });
      } else if (message === DEVICE_INITIALIZED) {
        const { pinpadResetInProgress } = store.getState().main;
        if (!pinpadResetInProgress) return;
        Logger.info(`PinPad Intialised after reset.`);
        toast({
          status: 'success',
          duration: 5000,
          position: 'top-left',
          description: PINPAD_RESET_SUCCESS_TOASTER,
        });
        dispatch(mainActions.setpinpadResetInProgress(false));
        dispatch(mainActions.setpinpadResetRemainderTimer(''));
        dispatch(mainActions.setDisablePinpadForReset(false));
      }
      // Subscription Removed from payment screen and handling DEVICE_DISCONNECTED/CMD_NOT_AVAILABLE here
      else if (
        message === DEVICE_DISCONNECTED ||
        message === CMD_NOT_AVAILABLE ||
        message === USB_DEVICE_NOT_FOUND ||
        message === PINPAD_UNAVAILABLE
      ) {
        Logger.error(`Pinpad status:${message}`);
        const { pinpadResetInProgress } = store.getState().main;
        const { isPaymentTriggered } = store.getState().cart;
        if (pinpadResetInProgress && !isPaymentTriggered) {
          // dispatch(mainActions.setpinpadResetInProgress(false));
          dispatch(mainActions.setpinpadResetRemainderTimer(''));
          return;
        }
        appContextActions?.stopLoading?.();
        dispatch(cartActions.setStatusCode(null));
        dispatch(cfdActions.setUserActionScreenActive(false));
        if (
          window.location.pathname.includes('payment') ||
          isPaymentTriggered
        ) {
          dispatch(socketActions.setCardStatus(null));
          dispatch(cartActions.setPaymentTriggerStatus(false));
          dispatch(socketActions.setCashBack(null));
          history.replace('/payment');
        }
      } else if (
        message === PINPAD_UNAVAILABLE ||
        message === 'DEVICE_BUSY' ||
        message === 'COMM_LINK_UNINITIALIZED'
      ) {
        const { pinpadResetInProgress } = store.getState().main;
        if (!pinpadResetInProgress) return;
        // dispatch(mainActions.setpinpadResetInProgress(false));
        dispatch(mainActions.setpinpadResetRemainderTimer(''));
        // dispatch(mainActions.setDisablePinpadForReset(false));
        Logger.error(`Pinpad status:${message}`);
        return;
      }
    } catch (e) {
      Logger.warn('ERROR: Pinpad Control Queue listener', e);
    }
  };
  return {
    pinpadControlQueueListener,
  };
};
