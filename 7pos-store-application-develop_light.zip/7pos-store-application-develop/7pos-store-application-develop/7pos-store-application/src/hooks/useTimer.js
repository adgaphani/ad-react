import { useRef, useEffect } from 'react';
import { useTimeLogger } from './useTimeLogger';

export const useTimer = (expiresAt = 12000, feature) => {
  const timerRef = useRef(null);
  const { logStart, expiredLog } = useTimeLogger(feature);

  const stop = () => {
    clearTimeout(timerRef.current);
    timerRef.current = null;
  };
  const start = (cb = () => {}, sec = expiresAt) => {
    logStart(); // logs and captures timer
    stop(); // Clears timer
    timerRef.current = setTimeout(() => {
      expiredLog();
      cb?.();
    }, sec);
  };
  useEffect(
    () => () => {
      stop();
    },
    []
  );
  return {
    start,
    stop,
  };
};
