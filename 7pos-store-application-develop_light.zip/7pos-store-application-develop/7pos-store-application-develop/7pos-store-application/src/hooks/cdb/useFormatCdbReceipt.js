import { EODReceiptMapping } from '../../mapping';
import {
  listOfSection1,
  listOfSection3,
  listOfSummaryItems,
} from '../../Utils/cdb/cdbUtils';

export const useFormatCdbReceipt = () => {
  const formatCdbLineItems = payload => {
    const cdbSummary = payload;
    const itemTransData =
      cdbSummary
        ?.filter(
          ({ mediaName, count }) =>
            listOfSection1.includes(mediaName) &&
            !listOfSummaryItems.includes(mediaName) &&
            count !== 0
        )
        .map(({ mediaName, count, amount }) => ({
          quantity: EODReceiptMapping[mediaName] ?? mediaName,
          description: count,
          details: !amount ? '0.00' : parseFloat(amount).toFixed(2),
        })) ?? [];
    const mediaData =
      cdbSummary
        ?.filter(
          ({ mediaName, count }) =>
            !listOfSection1.includes(mediaName) &&
            !listOfSection3.includes(mediaName) &&
            !listOfSummaryItems.includes(mediaName) &&
            count !== 0
        )
        .map(({ mediaName, count, amount }) => ({
          quantity: EODReceiptMapping[mediaName] ?? mediaName,
          description: count,
          details: !amount ? '0.00' : parseFloat(amount).toFixed(2),
        })) ?? [];
    const cdbLineItemSummary =
      cdbSummary
        ?.filter(
          ({ mediaName, count }) =>
            listOfSection3.includes(mediaName) &&
            !listOfSummaryItems.includes(mediaName) &&
            count !== 0
        )
        .map(({ mediaName, count, amount }) => ({
          quantity: EODReceiptMapping[mediaName] ?? mediaName,
          description: count,
          details: !amount ? '0.00' : parseFloat(amount).toFixed(2),
        })) ?? [];

    return { itemTransData, mediaData, cdbLineItemSummary };
  };

  return {
    formatCdbLineItems,
  };
};
