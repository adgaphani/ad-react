import moment from 'moment';
import { useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { getCashDrawerBalanceReport } from '7pos-hardtotals';
import { AppContext } from '../../AppContext';
import { useCDBReceipt } from './useCdbReceipt';
import { useSoundToast } from '../useSoundToast';
import { cartActions } from '../../slices/cart.slice';
import { cdbStaticPMNumbers } from '../../Utils/cdb/cdbUtils';
import { appIntegrationRequest } from '../../Utils/appUtils';
import { WebSocketContext } from '../../components/Common/WebSocket/WebSocketProvider';

export const useCdbUtils = () => {
  const {
    paymentTransactionId,
    storeDetails,
    deviceInfo,
    transactionId,
    user,
  } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    storeDetails: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    transactionId: state.cart.transactionId,
    user: state.auth.user,
  }));
  const appContextActions = useContext(AppContext);
  const history = useHistory();
  const { printCDBReceipt } = useCDBReceipt();
  const toast = useSoundToast();
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);

  const onCdbComplete = ({ type }) => {
    const msg =
      type === 'success'
        ? 'Print CDB Report Success'
        : 'Print CDB Report Failed';
    const status = type === 'success' ? 'success' : 'error';
    appContextActions?.stopLoading?.();
    toast({
      description: msg,
      status,
      duration: 3000,
      position: 'top-left',
    });
    return history.push('/home');
  };

  const getTransactionHeaderInfo = () => {
    const transactionHeaderInfo = {
      storeId: storeDetails?.storeId,
      deviceId: deviceInfo?.id,
      deviceType: '7POS',
      transactionType: 'CDBREPORT',
      transactionId: paymentTransactionId,
      transactionSequenceId: transactionId,
      originalTransactionId: null,
      originalTransactionSequenceId: null,
      transactionStartTime: `${moment
        .utc()
        .format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`,
      transactionEndTime: null,
      transactionStatus: 'COMPLETE',
      currencyCode: storeDetails?.address?.country === 'US' ? 'USD' : 'CAD',
      userId: user?.userId,
      userName: user?.firstName,
      transactionComment: null,
      ageVerificationInfo: null,
      storeLetterCode: storeDetails?.letterCode,
      memberDetailsInfo: null,
    };
    return transactionHeaderInfo;
  };

  const getTransactionDetails = fetchedCdbReport => {
    const cashDrawerBalanceInfo = {
      cashDrawerBalanceInfo: fetchedCdbReport,
    };
    return cashDrawerBalanceInfo;
  };

  const processCdbReportToTapi = fetchedCdbReport => {
    const matchKeys = (obj, val) =>
      Object.keys(obj).find(key => obj[key] === val);
    fetchedCdbReport.forEach(obj => {
      const key = matchKeys(cdbStaticPMNumbers, obj.paymentMediaNumber);
      if (key) {
        delete obj.paymentMediaNumber;
      }
    });
    return fetchedCdbReport;
  };

  // Post to TAPI
  const postCdbToTapi = fetchedCdbReport => {
    const cdbReport = processCdbReportToTapi(fetchedCdbReport);
    const message = {
      transactionHeaderInfo: getTransactionHeaderInfo(),
      transactionDetails: getTransactionDetails(cdbReport),
    };
    const cdbTapiRequest = appIntegrationRequest({
      type: 'cdb_Req',
      payload: JSON.stringify(message),
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/payment', {}, JSON.stringify(cdbTapiRequest));
  };

  const updateCdbReportOnCdb = async () => {
    try {
      appContextActions?.startLoading();
    } catch (error) {
      appContextActions?.stopLoading();
      global?.logger?.error(
        `[7POS UI] - Update CDB ERROR :${JSON.stringify(error)}`
      );
    } finally {
      appContextActions?.stopLoading();
    }
  };

  const onCdbReport = async () => {
    try {
      appContextActions?.startLoading?.();
      // #8484 sending reset param to reset CDB value only for Button CDB btn click.
      let fetchedCdbReport = await getCashDrawerBalanceReport({
        type: 'cdbBtnReset',
      });
      if (!fetchedCdbReport.length) {
        appContextActions?.stopLoading?.();
        fetchedCdbReport = [
          { mediaName: 'CASH', amount: 0, count: 0, paymentMediaNumber: 1 },
        ];
      }
      const payload = {
        cdbSummary: fetchedCdbReport,
      };
      if (fetchedCdbReport.length) postCdbToTapi(fetchedCdbReport);
      printCDBReceipt(payload);
      if (fetchedCdbReport.length) updateCdbReportOnCdb();
      dispatch(cartActions.emptyCart());
      onCdbComplete({ type: 'success' }); // TODO: Get confirm from Joe
      Logger.info(`[7POS UI] - Fetch CDB report success`);
    } catch (error) {
      Logger.error(`[7POS UI] - Fetch CDB report failed:${error}`);
      onCdbComplete({ type: 'fail' });
    }
  };

  return {
    onCdbReport,
  };
};
