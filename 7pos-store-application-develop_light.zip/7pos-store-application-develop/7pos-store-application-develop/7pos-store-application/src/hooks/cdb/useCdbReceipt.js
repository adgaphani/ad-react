/* eslint-disable */
import { useSelector } from 'react-redux';
import { fetchEmailReceipt } from '../../api/payment/fetchEmailReceipt';
import { cdbConstants } from '../../constants/receiptConstants';
import { EODReceiptMapping } from '../../mapping';
import { getHeader } from '../../Utils/paymentUtils';
import { getLocalTime } from '../../Utils/dateUtil';
import { useSoundToast } from '../useSoundToast';
import { useFormatCdbReceipt } from './useFormatCdbReceipt';

export const useCDBReceipt = () => {
  const {
    storeDetails,
    config,
    deviceInfo,
    user,
    transactionId,
    channel,
    paymentTransactionId,
    shiftNumber,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
    config: state.main.configuration,
    deviceInfo: state.main.deviceInfo,
    transactionId: state.cart.transactionId,
    channel: state.main.channel,
    paymentTransactionId: state.cart.paymentTransactionId,
    shiftNumber: state.main.shiftNumber,
  }));
  const { formatCdbLineItems } = useFormatCdbReceipt();

  const toast = useSoundToast();
  const showToast = msg => {
    toast({
      status: 'error',
      duration: 3000,
      position: 'top',
      description: msg,
    });
  };

  const processNetCashAmount = cdbSummary => {
    const insertBills = cdbSummary.find(obj => obj.mediaName === 'insertBills');
    const insertBillAmount = insertBills ? insertBills.amount : 0;
    const vendTube = cdbSummary.find(obj => obj.mediaName === 'vendTube');
    const vendTubeAmount = vendTube ? vendTube.amount : 0;
    const loadTube = cdbSummary.find(obj => obj.mediaName === 'loadTube');
    const loadTubeAmount = loadTube ? loadTube.amount : 0;
    const valutDrop = cdbSummary.find(obj => obj.mediaName === 'vaultDrop');
    const valutDropAmount = valutDrop ? valutDrop.amount : 0;
    const safeDrop = cdbSummary.find(
      obj => obj.mediaName === 'safeDropableAmount'
    );
    const safeDropableAmount = safeDrop ? safeDrop.amount : 0;
    const netAmt =
      safeDropableAmount +
      Math.abs(vendTubeAmount) -
      Math.abs(
        Math.abs(insertBillAmount) +
          Math.abs(loadTubeAmount) +
          Math.abs(valutDropAmount)
      );
    return netAmt;
  };

  const processDrawerTotalAmount = cdbSummary => {
    const insertBills = cdbSummary.find(obj => obj.mediaName === 'insertBills');
    const insertBillAmount = insertBills ? insertBills.amount : 0;
    const vendTube = cdbSummary.find(obj => obj.mediaName === 'vendTube');
    const vendTubeAmount = vendTube ? vendTube.amount : 0;
    const loadTube = cdbSummary.find(obj => obj.mediaName === 'loadTube');
    const loadTubeAmount = loadTube ? loadTube.amount : 0;
    const valutDrop = cdbSummary.find(obj => obj.mediaName === 'vaultDrop');
    const valutDropAmount = valutDrop ? valutDrop.amount : 0;
    const safeDrop = cdbSummary.find(
      obj => obj.mediaName === 'safeDropableAmount'
    );
    const safeDropableAmount = safeDrop ? safeDrop.amount : 0;
    const drawerTotalAmount =
      safeDropableAmount +
      Math.abs(vendTubeAmount) -
      Math.abs(
        Math.abs(insertBillAmount) +
          Math.abs(loadTubeAmount) +
          Math.abs(valutDropAmount)
      );
    return drawerTotalAmount;
  };

  // getCdbLineItems share common reuslt to CDB receipt and EOD/EOS receipt
  const getCdbLineItems = payload => {
    const { cdbSummary } = payload;
    const cdbLineItems = formatCdbLineItems(cdbSummary);
    const { itemTransData, mediaData, cdbLineItemSummary } = cdbLineItems;
    const deviceId = deviceInfo?.id;
    const fItem = {
      quantity: `SHIFT ${shiftNumber} TRML #${deviceId}`,
    };
    const line = {
      quantity: '---------------------',
    };
    const lineItemHeader = {
      quantity: 'TRANSACTION ACTIVITY',
      description: 'COUNT',
      details: 'AMOUNT',
    };
    let totalRevenueItem =
      cdbSummary
        ?.filter(({ mediaName }) => mediaName === 'totalRevenue')
        .map(({ amount }) => ({
          quantity: 'Total Revenue', // EOD And CDB Receipt shares the same mapping
          description: '',
          details: !amount ? '0.00' : parseFloat(amount).toFixed(2),
        })) ?? [];
    totalRevenueItem = totalRevenueItem.length ? totalRevenueItem[0] : {} || {};

    //Non Drawer Total
    let nonCashDrawerTotal =
      cdbSummary
        ?.filter(({ mediaName }) => mediaName === 'nonSafeDropableAmount')
        .map(({ amount }) => ({
          quantity: 'Non Drawer Total',
          description: '',
          details: !amount ? '0.00' : parseFloat(amount).toFixed(2),
        })) ?? [];
    nonCashDrawerTotal = nonCashDrawerTotal.length
      ? nonCashDrawerTotal[0]
      : {} || {};
    //End Drawer Total
    const drawerTotalAmount = processDrawerTotalAmount(cdbSummary);
    let endDrawerTotal =
      cdbSummary
        ?.filter(({ mediaName }) => mediaName === 'safeDropableAmount')
        .map(() => ({
          quantity: 'Ending Drawer Total',
          description: '',
          details: !drawerTotalAmount
            ? '0.00'
            : parseFloat(drawerTotalAmount).toFixed(2),
        })) ?? [];
    endDrawerTotal = endDrawerTotal.length ? endDrawerTotal[0] : {} || {};
    //Net Cash Amount
    const netCashAmount = processNetCashAmount(cdbSummary);
    let netCashTotal =
      cdbSummary
        ?.filter(({ mediaName }) => mediaName === 'safeDropableAmount')
        .map(() => ({
          quantity: 'Net Cash',
          description: '',
          details: !netCashAmount
            ? '0.00'
            : parseFloat(netCashAmount).toFixed(2),
        })) ?? [];
    netCashTotal = netCashTotal.length ? netCashTotal[0] : {} || {};

    const cdbLineItem = [
      fItem,
      line,
      lineItemHeader,
      ...(Object.entries(itemTransData).length !== 0
        ? [itemTransData, line].flat()
        : []),
      ...(Object.entries(mediaData).length !== 0
        ? [mediaData, line].flat()
        : []),
      ...(Object.entries(totalRevenueItem).length !== 0
        ? [totalRevenueItem, line].flat()
        : []),
      ...(Object.entries(nonCashDrawerTotal).length !== 0
        ? [nonCashDrawerTotal, line].flat()
        : []),
      ...(Object.entries(cdbLineItemSummary).length !== 0
        ? [cdbLineItemSummary, line].flat()
        : []),
      ...(Object.entries(endDrawerTotal).length !== 0
        ? [endDrawerTotal, line].flat()
        : []),
      ...(Object.entries(netCashTotal).length !== 0
        ? [netCashTotal, line].flat()
        : []),
    ];

    return cdbLineItem;
  };

  const generateCdbPayload = ({ payload }) => {
    const header = getHeader(storeDetails, config);
    const footer = [
      `${`RESET CASHDRAWER TOTALS`}`,
      `${`**END OF REPORT**`}`,
      `${`T#${deviceInfo?.id} OP${
        user?.userId
      } TRN${transactionId} ${getLocalTime()}`}`,
    ];
    const operator = user?.userId;
    header.headerLines = [
      ...header.headerLines,
      `${cdbConstants.cdbReceiptBanner}`,
      `${cdbConstants.cdbReceiptHeader1} ${operator}`,
    ];
    return {
      to: '',
      subject: 'email subject',
      receiptType: 'PRINT',
      header,
      lineItem: {
        items: getCdbLineItems(payload),
      },
      footer: {
        footer,
      },
    };
  };

  const printCDBReceipt = async payload => {
    try {
      const receiptPayload = generateCdbPayload({
        payload,
      });
      console.log('-------ReceptReq:', receiptPayload);
      await fetchEmailReceipt(receiptPayload, paymentTransactionId, channel);
      console.log('-----email fetch done-----');
      Logger?.info(`[7POS UI] -  printCDBReceipt() Success`);
    } catch (error) {
      global?.logger?.error(`[7POS UI] - printCDBReceipt() Error:`);
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        showToast(errorMessage.message);
      } else {
        showToast('Receipt could not be printed. Please try again');
      }
    }
  };
  return {
    printCDBReceipt,
    getCdbLineItems,
  };
};
