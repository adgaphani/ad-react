import { getHardTotalSummaryAttributeValues } from '7pos-hardtotals';
import { useCart } from './useCart';

export const useHardTotals = () => {
  const { setHardTotalSummary } = useCart();
  const refreshHardTotals = async () => {
    try {
      localStorage.removeItem('StoreSeqAndHardTotals');
      const summary = await getHardTotalSummaryAttributeValues('nrgt');
      setHardTotalSummary(summary);
    } catch (e) {
      Logger.error(`[HardTotal] : ${e.message}`);
    }
  };
  return {
    refreshHardTotals,
  };
};
