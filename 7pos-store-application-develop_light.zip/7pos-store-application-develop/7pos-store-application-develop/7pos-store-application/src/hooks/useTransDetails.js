import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

import { getTransPriceDetails } from '../Utils/Payments/paymentTransactionUtils';

export const useTransDetails = () => {
  const [transDetails, setTransDetails] = useState({});
  const {
    basketPromo,
    items,
    taxData,
    isTransactionRefund,
    isTransactionVoid,
  } = useSelector(({ cart }) => ({
    basketPromo: cart.basketPromo,
    items: cart.items,
    isTransactionVoid: cart.isTransactionVoid,
    isTransactionRefund: cart.isTransactionRefund,
    taxData: cart.taxInfo,
  }));

  useEffect(() => {
    const transDetails = getTransPriceDetails({
      items,
      isTransactionRefund,
      isTransactionVoid,
      basketPromo,
      taxData,
      iTransactionTaxAmount: taxData?.totalTaxAmount,
    });
    setTransDetails(transDetails);
  }, [basketPromo, items, isTransactionRefund, isTransactionVoid, taxData]);
  //   {
  //     subTotalPrice,
  //     finalsubTotalPrice,
  //     totalPrice,
  //     totalPromotionPrice,
  //     totalPromotionPriceAmt,
  //     totalTaxAmount,
  //   }
  return {
    ...transDetails,
  };
};
