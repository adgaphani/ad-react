import { useSelector } from 'react-redux';

export const useMember = () => {
  const { member } = useSelector(state => ({
    member: state.cart.member,
  }));
  return {
    memberId: member?.loyalty_id,
    altId: member?.mobile_number,
  };
};

// type member  = {
//     digital_id :string;
//     "barcode": string;
//     "country": string;
//     "email": string,
//     "email_secondary": string | null,
//     "first_name": string,
//     "is_age_verified": boolean,
//     "loyalty_id": string,
//     "loyalty_id_received_at": string,
//     "loyalty_status": string,
//     "mobile_number": number;
//     "phone_number": number,
//     "punch_cards": any[];
//     "rewards_loaded": number,
//     "rewards_points": number,
//     "points_enabled": boolean,
//     "bonus_offers_enabled": boolean,
//     "favorite_store_ids": any[],
//     "enroll_date": string,
//     "required_terms": any[],
//     "mp_needs_alias": boolean,
//     "mp_alias_id": string,
//     "android_pay_enabled": boolean,
//     "messages": any[],
//     "apple_pass_serial": string,
//     "check_legacy_pass": boolean,
//     "facebook_merge_available": null | any,
//     "is_facebook_user": boolean,
//     "ar_data": any;
//     "is_email_verified": boolean,
//     "welcome_overlay_id": string,
//     "beacon_data": string,
//     "is_sms_verified": true,
//     "scan_and_pay": {
//       "in_msp_region": false,
//       "in_msp_store": false,
//       "current_store_id": null,
//       "msp_totem_validation_response_enabled": false,
//       "msp_totem_scan_enabled": false,
//       "msp_totem_camera_enabled": true,
//       "msp_bag_payment_required": false
//     },
//     "mobile_fuel_pay": {
//       "in_mobile_fuel_region": false,
//       "in_mobile_fuel_store": false,
//       "current_store_id": null
//     },
//     "msp_transactions_placed": false,
//     "age_verified_status": "unverified",
//     "can_verify_age": true,
//     "home_screen_feed": [],
//     "paypal_verified_status": false,
//     "paypal_verification_attempted": false,
//     "apple_uid": null,
//     "required_data": null,
//     "digital_wallet": null,
//     "rewards_cash": 80,
//     "wallet_enabled": null,
//     "rewards_cash_state": "user_disabled",
//     "last_name": null,
//     "postal_code": "75038",
//     "birthdate": null,
//     "linked_cards": null,
//     "address_line_1": null,
//     "address_line_2": null,
//     "city": null,
//     "state_or_province": null,
//     "gender": null,
//     "preferences": [
//       {
//         "id": "us_communication",
//         "type": "communications",
//         "title": "Email Communication",
//         "description": "Yes, I'd like to receive new, special offers and more from 7-Eleven.",
//         "country": "US",
//         "enabled": true,
//         "display_only": false,
//         "order": 1,
//         "categories": null
//       },
//       {
//         "id": "va_tier_1",
//         "type": "promotion",
//         "title": "Veterans Advantage Tier 1",
//         "description": "VA-T1 Testing Pref Tool",
//         "country": "US",
//         "enabled": false,
//         "display_only": false,
//         "order": 6,
//         "categories": null
//       },
//       {
//         "id": "va_tier_2",
//         "type": "promotion",
//         "title": "Veterans Advantage Tier 2",
//         "description": "VA-T2 Testing Pref Tool",
//         "country": "US",
//         "enabled": false,
//         "display_only": false,
//         "order": 6,
//         "categories": null
//       },
//       {
//         "id": "fuel_preference",
//         "type": "other",
//         "title": "Fuel Grade",
//         "description": "Select preferred fuel grade to be displayed during the fueling experience.",
//         "country": "US",
//         "enabled": false,
//         "display_only": false,
//         "order": 10,
//         "categories": [
//           {
//             "id": "fuel_regular",
//             "type": "radio",
//             "title": "Regular unleaded",
//             "description": "",
//             "country": "US",
//             "enabled": false,
//             "order": 1,
//             "subcategories": null
//           },
//           {
//             "id": "fuel_mid_grade",
//             "type": "radio",
//             "title": "Mid-Grade",
//             "description": "",
//             "country": "US",
//             "enabled": false,
//             "order": 2,
//             "subcategories": null
//           },
//           {
//             "id": "fuel_premium",
//             "type": "radio",
//             "title": "Premium",
//             "description": "",
//             "country": "US",
//             "enabled": false,
//             "order": 3,
//             "subcategories": null
//           },
//           {
//             "id": "fuel_diesel",
//             "type": "radio",
//             "title": "Diesel",
//             "description": "",
//             "country": "US",
//             "enabled": false,
//             "order": 4,
//             "subcategories": null
//           }
//         ]
//       }
//     ],
//     "favorite_stores": [],
//     "username": "srinivas.sadanala@7-11.com",
//     "employee_id": null
//   }
// }
