import { useContext, useState, useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';
import { useWSocket } from './useWSocket';
import { safeRequest } from '../Utils/safeUtils';
import { safeDrop, STORE_COORDINATOR } from '../constants';
import store from '../store';
import { cartActions } from '../slices/cart.slice';
import { dailpadActions } from '../slices/dailpad.slice';
import { useSoundToast } from './useSoundToast';
import { useReciepts } from './useReceipts';
import { getDVR } from '../hardware/dvr';
// import { heartBeat, suc } from '../components/POS/Safe/event';
// import { ofline } from '../components/POS/Safe/event';
import { useSafeDropHistory } from './useSafeDropHistory';
import { useUpdatedState } from './useUpdatedState';
import { useTimer } from './useTimer';
import { AppContext } from '../AppContext';
import { getCurrentTimeInMS } from '../Utils';
import { useTAPIPosting } from './useTAPIPosting';
import { useCashDrawer } from './useCashDrawer';

export const useSafe = needSubscription => {
  const [ws] = useContext(WebSocketContext);
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const navigation = useSafeDropHistory();
  const { isConnected } = useWSocket();
  const updatedState = useUpdatedState();
  const { safeOflineTimer } = useContext(AppContext) || {};
  const { openCashDrawer } = useCashDrawer();
  const {
    deviceInfo,
    userId,
    safeDropType,
    keypadValue,
    safeOflineAmount,
    isSafeAbort,
    isSafeAbortInProgress,
    isVault,
    vaultUserEntries,
    storeId,
    paymentTransactionId,
    transactionId,
    config,
    storeDetails,
    user,
  } = useSelector(state => ({
    storeId: state.main.storeDetails?.storeId,
    deviceInfo: state.main.deviceInfo,
    userId: state.auth?.user?.userId,
    safeDropType: state.cart.safeDropType,
    dailpadValue: state.dailpad.dailpadValue,
    safeOflineAmount: state.cart.safeOflineAmount,
    keypadValue: state.dailpad.keypad?.value,
    isSafeAbort: state.cart.isSafeAbort,
    isSafeAbortInProgress: state.cart.isSafeAbortInProgress,
    sLock: state.cart.sLock,
    isVault: state.cart.safeDropType === 'vaultDrop',
    vaultUserEntries: state.cart.vaultUserEntries,
    paymentTransactionId: state.cart.paymentTransactionId,
    isSafeReady: state.peripheral.isSafeReady,
    transactionId: state.cart.transactionId,
    config: state.main.configuration,
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
  }));
  const { print } = useReciepts();
  const { postTapi } = useTAPIPosting();
  const { start, stop } = useTimer(120000);
  const [isSafeTransCompleted, setCompleted] = useState(false);
  const isCashDrawerOpen = useRef(false);

  const openCashDrwrForSafe = () => {
    openCashDrawer();
  };
  const safeTransCompleted = ({ safeDropType }) => {
    // console.log('SAFE TRANSACTION COMPLETE', safeDropType);
    global?.logger?.info(
      `[7POS UI] - Safe Transaction Complete type = ${safeDropType}`
    );
    if (safeDropType === 'vendTube') {
      // openCashDrawer();
      openCashDrwrForSafe();
    }
    setCompleted(true);
  };
  const subRef = useRef([]);
  const showToast = msg => {
    if (msg?.length > 0)
      toast?.({
        description: msg,
        status: 'error',
        duration: 3000,
        position: 'top',
      });
  };
  const showSuccessToast = msg => {
    if (msg?.length > 0)
      toast?.({
        description: msg,
        status: 'success',
        duration: 3000,
        position: 'top',
      });
  };
  const generateLockReq = ({ type = 'lock', safeType }) => {
    const req = JSON.stringify({
      ...STORE_COORDINATOR.config,
      serviceName: STORE_COORDINATOR.services.safe,
      message: STORE_COORDINATOR.services[type],
      messageDetail: {
        safeType,
      },
      timeStamp: getCurrentTimeInMS(),
    });
    return req;
  };

  const requestSafeLock = () => {
    const req = generateLockReq({ type: 'lock' });
    ws.socket?.send('/app/sync-service-msg', {}, req);
    global.logger.info(`[7POS UI] : Sending SAFE Lock Request`);
  };
  const releaseSafeLock = () => {
    // console.log('RELEASING SAFE LOCK');
    global?.logger?.info(`[7POS UI] - Releasing Safe lock`);
    ws?.socket?.send(
      '/app/sync-service-msg',
      {},
      generateLockReq({ type: 'complete' })
    );
  };
  const onSafeExit = increaseId => {
    if (increaseId) {
      dispatch(cartActions.emptyCart({ skipStoreGenNumber: true }));
      const { vaultUserEntries, safeDropResponse } = updatedState().cart;
      getDVR().sendSafe(
        storeDetails?.currencyCode === 'CAD' &&
          updatedState()?.safeDropType === 'insertBills'
          ? safeDropResponse?.[1]?.amount
          : safeDropResponse?.[0]?.amount,
        config,
        deviceInfo,
        true,
        storeDetails,
        transactionId,
        safeDrop[safeDropType]?.uLabel,
        user
      );
      print({
        vaultUserEntries,
        safeDropResponse,
        isAbort: true,
        paymentTransactionId,
      });
    }
    navigation.navigateTOHome();
    dispatch(cartActions.completeSafeDrop());
    releaseSafeLock();
  };
  const clearSafeOflineCart = () => {
    if (!safeOflineTimer.current) {
      return;
    }
    clearTimeout(safeOflineTimer.current);
    safeOflineTimer.current = null;
    onSafeExit(true);
    releaseSafeLock();
  };
  const safeOflineExit = () => {
    navigation.navigateTOHome();
    dispatch(cartActions.setSafeOflineAbort(true));
    dispatch(cartActions.setSafeCompleted(true));
    dispatch(dailpadActions.resetKeypadValue());
    clearTimeout(safeOflineTimer.current);
    safeOflineTimer.current = setTimeout(
      clearSafeOflineCart,
      safeDrop.abortTime
    );
  };

  const safeOnlineAbort = (sType, amount) => {
    postTapi({
      safeResponseStatus: 'safeAbort',
      safeDropType: sType,
      transactionStatus: 'ABORTED',
      amount,
    });
    dispatch(cartActions.emptyCart());
    dispatch(dailpadActions.resetKeypadValue());
    dispatch(cartActions.setSafeCompleted(true));
    clearTimeout(safeOflineTimer.current);
    safeOflineTimer.current = setTimeout(
      clearSafeOflineCart,
      safeDrop.abortTime
    );
  };
  const handleTimeOut = () => {
    navigation.navigateTOHome();
    showToast('Safe communication error. Please try again later');
    onSafeExit();
    // releaseSafeLock();
  };
  /**
   *
   * @param
   * @body Clears Existing and starts new Timer
   * @returns void
   */
  const resetTimer = () => {
    start(handleTimeOut);
  };
  /**
   *
   * @param  action
   * @body Sends Abort Command
   * @returns void
   */
  const abortSafe = action => {
    if (!isConnected) {
      return;
    }
    resetTimer();
    const request = safeRequest({
      messageType: action,
      cmd: 'safeAbort',
      deviceInfo: updatedState()?.main?.deviceInfo,
      userId: updatedState()?.auth?.user?.userId,
    });
    global?.logger?.info(`[7POS UI] - Sending ABORT SAFE REQUEST}`);
    // console.log('MESSAGE REQUEST SAFE', request);
    ws.socket?.send(safeDrop.channels.talkToSafe, {}, request);
  };
  const handleAquireLockFailure = ({
    displayToast = true,
    lockFailed = false,
  } = {}) => {
    global?.logger?.error(`[7POS UI] - Aquire safe Lock Failure`);
    // console.log('Handling Timeout Here');
    navigation.navigateTOHome();
    if (displayToast) {
      const MSG = lockFailed
        ? 'Safe is Busy'
        : 'Safe communication error. Please try again later';
      showToast(MSG);
    }
    dispatch(cartActions.completeSafeDrop());
  };

  const SetVaultCurreny = currencyType => {
    if (currencyType) {
      dispatch(
        cartActions.setVaultUserEntries({
          ...vaultUserEntries,
          vaultCurrency: currencyType,
        })
      );
    }
  };

  const safeEvents = e => {
    let msg;
    stop();
    try {
      const parsedBody = JSON.parse(e?.body);
      msg = parsedBody?.messageBody?.message;
    } catch (err) {
      global?.logger?.error(
        `[7POS UI] - Safe event error - ${JSON.stringify(err)}`
      );
      // console.log(':SAFE EVNT ERROR', err);
      msg = {};
    }
    global?.logger?.info(
      `[7POS UI] - Safe Event Received - ${JSON.stringify(msg)}`
    );
    // console.log('SAFE EVNT RECIVED____________________', msg);
    const status = msg?.status;
    if (safeDrop.statusCode.indexOf(status) < 0) {
      // Display message for error scenarios.
      showToast(msg?.displayMessage);
      releaseSafeLock();
      handleAquireLockFailure({ displayToast: false });
      return;
    }
    if (status === 'safeHeartbeat') {
      // Reset The Timer
      const uState = updatedState() || {};
      dispatch(cartActions.setSafeShowTransId(true));
      resetTimer();
      if (uState.cart?.vaultReserve && !isCashDrawerOpen.current) {
        // openCashDrawer();
        openCashDrwrForSafe();
        isCashDrawerOpen.current = true;
        dispatch(cartActions.setValutReserve(false));
        navigation.navigateTOValutStart();
        return;
      }
      if (uState?.isVault && !uState?.isValutDropCompleteSent) {
        return;
      }
      if (!uState.cart.isSafeAbortInProgress) {
        navigation.navigateToSafeStart();
        if (
          safeDrop.needCashDrawer.indexOf(uState?.safeDropType) > -1 &&
          !isCashDrawerOpen.current
        ) {
          // console.log(openCashDrawer);
          // openCashDrawer();
          openCashDrwrForSafe();
          isCashDrawerOpen.current = true;
        }
      }
      if (uState.cart.isSafeAbort) {
        // abortSafe(safeDrop[updatedState()?.safeDropType]?.action);
        dispatch(cartActions.setSafeDropAbort(false));
      }
    } else if (status === 'safeOffline') {
      dispatch(cartActions.setSafeShowTransId(true));
      navigation.navigateToOfline();
    } else if (status === 'SafeServerStatusGood') {
      const uState = updatedState() || {};
      const amount = uState.isVault
        ? [
            {
              amount: uState.vaultDropEntries.amount,
              envelop: uState.vaultDropEntries.envelop,
              vaultCurrency: uState.vaultDropEntries.vaultCurrency,
            },
          ]
        : msg?.responseAmount;
      safeTransCompleted({ ...msg, safeDropType: uState.safeDropType });
      releaseSafeLock();
      // 6539 handling safe exit click vs amount inserted.
      const rAmount =
        msg?.responseAmount?.find(i => Number(i.amount))?.amount || 0;
      if (uState.cart.isSafeAbortInProgress && rAmount === 0) {
        safeOnlineAbort(uState.safeDropType, rAmount);
        return;
      }
      if (uState.cart.isSafeAbortInProgress && rAmount !== 0) {
        dispatch(cartActions.setSafeDropAbort(false));
        dispatch(cartActions.setSafeAbortProgress(false));
      }
      navigation.navigateToComplete();
      dispatch(cartActions.setSafeResponse(amount));
      // POST TO TAPI on SUCCESS
      const resAmount = amount?.find(i => Number(i.amount))?.amount;
      postTapi({
        safeResponseStatus: status,
        amount: resAmount,
        envelop: uState.vaultDropEntries?.envelop,
        currencyCode: uState.vaultDropEntries?.vaultCurrency,
        safeDropType: uState.safeDropType,
        transactionStatus: 'COMPLETE',
      });
    } else {
      // Display message for error scenarios.
      // eslint-disable-next-line no-lonely-if
      if (msg?.displayMessage) {
        if (status === 'safeError') showToast(msg?.displayMessage);
        else showSuccessToast(msg?.displayMessage);
      }
    }
  };

  const performSafeEODActivities = ({
    dayNumber,
    shiftNumber,
    deviceInfo,
    userId,
    action,
    isMainTerminal = true,
    eventId,
  }) => {
    const { isSafeReady } = store.getState().peripheral;
    global?.logger?.info(
      `[7POS UI] - performSafeEODActivities safe status ${isSafeReady}`
    );
    if (!config?.safeConfig?.isIntegrated || !isSafeReady) {
      return global?.logger?.info(
        `[7POS UI] - SAFE IS NOT ENABLED - NO SAFE EOD POLLING WILL BE DONE`
      );
    }
    const updateConfigReq = safeRequest({
      deviceInfo,
      userId,
      needEncode: false,
      day: dayNumber,
      shift: shiftNumber,
    });
    if (!isMainTerminal) {
      ws?.socket?.send(
        safeDrop.channels.setDayShift,
        {},
        JSON.stringify(updateConfigReq)
      );
      global?.logger?.info(
        `[7POS UI] - SAFE SETDAYSHIFT - ${JSON.stringify(updateConfigReq)}`
      );
      return;
    }

    const eodReq = {
      ...updateConfigReq,
      messageHeader: {
        ...updateConfigReq.messageHeader,
        messageType: action,
      },
      messageBody: {
        ...updateConfigReq.messageBody,
        message: {
          ...updateConfigReq.messageBody?.message,
          command: 'safePoll',
          dayNumber,
          shiftNumber,
          eventId,
          storeId,
          deviceId: `${Number(deviceInfo?.id)}`,
          employeeNumber: `${userId}`,
        },
      },
    };
    ws?.socket?.send(safeDrop.channels.talkToSafe, {}, JSON.stringify(eodReq));
    global?.logger?.info(`[7POS UI] - SENDING SAFE POLLING REQUEST`);
  };

  const completeSafeTrans = () => {
    const { vaultUserEntries, safeDropResponse } = updatedState().cart;
    getDVR().sendSafe(
      storeDetails?.currencyCode === 'CAD' &&
        updatedState()?.safeDropType === 'insertBills'
        ? safeDropResponse?.[1]?.amount
        : safeDropResponse?.[0]?.amount,
      config,
      deviceInfo,
      false,
      storeDetails,
      transactionId,
      safeDrop[safeDropType]?.uLabel,
      user
    );
    print({ vaultUserEntries, safeDropResponse, paymentTransactionId });
    dispatch(dailpadActions.resetKeypadValue());
    navigation.navigateTOHome(true);
    releaseSafeLock();
    dispatch(cartActions.emptyCart());
    dispatch(cartActions.completeSafeDrop());
  };

  const reserveSafe = (action, vault) => {
    if (!isConnected) {
      return;
    }
    const request = safeRequest({
      messageType: safeDrop[action]?.action,
      cmd: !vault ? 'safeReserve' : 'safeAmount',
      deviceInfo,
      userId,
      ...(vault
        ? {
            amount: vault.amount,
            envelop: vault?.envelp,
            currencyCode: vault?.currencyType,
          }
        : {}),
    });
    global?.logger?.info(`[7POS UI] -SENDING SAFE REQUEST`);
    // console.log('SENT MESSAGE REQUEST SAFE', request);
    resetTimer();
    ws.socket?.send(safeDrop.channels.talkToSafe, {}, request);
  };

  const onSyncServicResponse = event => {
    let res;
    try {
      res = JSON.parse(JSON.stringify(event));
      global?.logger?.info(
        `[7POS UI] - Safe SyncService Response::- ${JSON.stringify(res)}`
      );
      const body = JSON.parse(res.body);
      if (body?.serviceName !== 'SAFE') return;
      let safeType = body?.messageDetail?.safeType;
      if (!safeType) {
        safeType = updatedState()?.safeDropType || 'loadTube';
      }
      switch (body.message) {
        case STORE_COORDINATOR.services.lock:
          global?.logger?.info(`[7POS UI] - LOCK SAFE REQUEST SENT`);
          break;
        // case STORE_COORDINATOR.services.lock:
        case STORE_COORDINATOR.services.approved:
          stop();
          if (safeType === 'vaultDrop') {
            dispatch(cartActions.setValutReserve(true));
            // Set currency default to store
            SetVaultCurreny(storeDetails?.currencyCode);
            navigation.navigateToProcessing();
          }
          reserveSafe(safeType);
          break;
        case STORE_COORDINATOR.services.released:
          break;
        case STORE_COORDINATOR.services.completed:
          break;
        case STORE_COORDINATOR.services.start:
          break;
        default:
          handleAquireLockFailure({ lockFailed: true });
          break;
      }
    } catch (e) {
      global?.logger?.error(
        `[7POS UI] - Error Processing sync service event during safe ${JSON.stringify(
          e
        )}`
      );
      // console.log('Error Processing the Sync Service Evnt', e);
    }
  };
  const subscribeTOSafe = () => {
    if (!isConnected) {
      return;
    }
    const safeSub = ws.socket?.subscribe(
      safeDrop.channels.controlQueue,
      safeEvents
    );
    const syncsub = ws.socket?.subscribe(
      '/7pos/sync-service',
      onSyncServicResponse
    );
    subRef.current.push(safeSub);
    subRef.current.push(syncsub);
  };
  useEffect(() => {
    if (needSubscription) {
      subscribeTOSafe();
    }
    return () => {
      subRef?.current?.forEach(s => s.unsubscribe());
    };
  }, []);
  const handleAbortSafe = () => {
    dispatch(cartActions.setSafeDropAbort(true));
    dispatch(cartActions.setSafeAbortProgress(true));
    navigation.navigateToProcessing();
    abortSafe(safeDrop[updatedState()?.safeDropType]?.action);
    // reserveSafe(safeDropType);
  };
  const startVaultDrop = (amount, envelp) => {
    if (!amount) {
      showToast('Missing Amount');
      return;
    }
    const { vaultUserEntries } = store.getState().cart;
    reserveSafe(safeDropType, {
      amount,
      envelp: envelp || '0',
      currencyType: vaultUserEntries?.vaultCurrency,
    });
    // const res = [{ amount }];
    dispatch(
      cartActions.setVaultUserEntries({
        amount,
        envelop: envelp,
        vaultCurrency: vaultUserEntries?.vaultCurrency,
      })
    );
    dispatch(cartActions.setisValutDropCompleteSent(true));
    navigation.navigateToSafeStart();
  };
  const aquireSafeLock = safeType => {
    const req = generateLockReq({ safeType });
    ws.socket?.send('/app/sync-service-msg', {}, req);
    global.logger.info(`[7POS UI] : SENDING SAFE Lock Request`);
    navigation.navigateToProcessing();
  };

  const onSafeSelection = type => {
    dispatch(cartActions.setSafeDropType(type));
    dispatch(cartActions.setSafeProgress(true));
    dispatch(cartActions.setPOSSystemStatus('StartedNewTransaction'));
    start(handleAquireLockFailure);
    aquireSafeLock(type);
  };
  const onOflineValueEnter = (value = keypadValue) => {
    if (!value) {
      showToast('Enter Amount');
      return;
    }
    let enteredAmount = value;
    if (navigation.path !== '/home/safeDrop/ofline') {
      return;
    }
    if (isVault && vaultUserEntries.amount && vaultUserEntries.envelop) {
      navigation.navigateToComplete();
      postTapi({
        safeResponseStatus: 'safeOfline',
        amount: vaultUserEntries?.amount,
        envelop: vaultUserEntries?.envelop,
        currencyCode: store.getState().cart.vaultUserEntries?.vaultCurrency,
        safeDropType,
        transactionStatus: 'COMPLETE',
      });
      return;
    }
    if (!safeOflineAmount) {
      dispatch(cartActions.setSafeOflineAmount(value));
      if (!isVault) {
        navigation.navigateTOOflinePayment();
        return;
      }
      dispatch(
        cartActions.setVaultUserEntries({
          ...vaultUserEntries,
          amount: enteredAmount,
        })
      );
      dispatch(dailpadActions.resetKeypadValue());
      navigation.navigateTOValutEnvlp();
    } else {
      if (isVault) {
        dispatch(
          cartActions.setVaultUserEntries({
            ...vaultUserEntries,
            envelop: enteredAmount,
          })
        );
        // dispatch(dailpadActions.resetKeypadValue());
        navigation.navigateTOOflinePayment();
        return;
      }
      enteredAmount = safeOflineAmount;
      navigation.navigateToComplete();
      postTapi({
        safeResponseStatus: 'safeOfline',
        amount: enteredAmount,
        safeDropType,
        transactionStatus: 'COMPLETE',
      });
      dispatch(cartActions.setSafeResponse([{ amount: enteredAmount }]));
    }
  };
  const onSafePaymentSelect = type => {
    if (type !== 'cash') {
      // showToast('Invalid Payment Method');
      return;
    }
    onOflineValueEnter(safeOflineAmount);
  };
  return {
    subscribeTOSafe,
    reserveSafe,
    isSafeTransCompleted,
    isCashDrawerOpen,
    onSafeSelection,
    onSafeExit,
    completeSafeTrans,
    startVaultDrop,
    onOflineValueEnter,
    safeDropType,
    onSafePaymentSelect,
    showToast,
    handleAbortSafe,
    isSafeAbort,
    isSafeAbortInProgress,
    safeOflineExit,
    clearSafeDropCart: clearSafeOflineCart,
    keypadValue,
    isVault: safeDropType === 'vaultDrop',
    vaultUserEntries,
    performSafeEODActivities,
    requestSafeLock,
    releaseSafeLock,
    SetVaultCurreny,
  };
};
