import { useSelector, useDispatch } from 'react-redux';
import { mainActions } from '../slices/main.slice';
import { getProducts } from '../Utils/configurationUtils';
import { useSoundToast } from './useSoundToast';

export const useKeyBoardConfig = () => {
  const dispatch = useDispatch();
  const soundToast = useSoundToast();
  const { paymentTransactionId, keyConfig } = useSelector(state => ({
    ProductLookUpSynEvent: state.cart.ProductLookUpSynEvent,
    paymentTransactionId: state.cart.paymentTransactionId,
    keyConfig: state.main.keyConfig,
  }));
  const refreshKeyBoardConfig = async (throwException = false) => {
    try {
      const pluResponse = await getProducts(paymentTransactionId);
      const keyBoardConfig = JSON.parse(pluResponse);
      const iskeyBoardFound =
        keyBoardConfig.findIndex(data =>
          data?.name?.toLowerCase()?.includes('keyboard')
        ) > -1;
      if (!iskeyBoardFound) throw new Error('No Keyboard Config found');
      dispatch(mainActions.setKeyConfig(pluResponse));
      return pluResponse;
    } catch (error) {
      Logger?.error(
        `[7POS-UI] : Falied to refresh KeyBoard Config, POS Might have stale KeyboardConfig ${JSON.stringify(
          error
        )}`
      );
      if (throwException) throw new Error(error.message);
    }
  };

  const getKeyBoardConfigIfNeeded = async () => {
    try {
      if (keyConfig) return keyConfig;
      Logger.info(`[7POS-UI] - Keyboard Config not exist, refetching`);
      return await refreshKeyBoardConfig(true);
    } catch (e) {
      soundToast({
        description: 'No KeyBoardConfiguartion Information',
      });
      throw new Error(e?.message);
    }
  };
  return {
    refreshKeyBoardConfig,
    getKeyBoardConfigIfNeeded,
  };
};
