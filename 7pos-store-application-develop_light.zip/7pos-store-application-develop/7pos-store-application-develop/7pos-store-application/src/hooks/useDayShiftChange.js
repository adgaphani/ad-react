import { useContext, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import moment from 'moment';

// Custom Libs
import {
  getHardTotals,
  getCashDrawerBalanceReport,
  updateHardTotalsSnapshot,
} from '7pos-hardtotals';

// Context
import { AppContext } from '../AppContext';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';

// Redux
import store from '../store';
// Hooks
import { useSoundToast } from './useSoundToast';
import { useFuel } from './useFuel';
import { useSharedFuelRequest } from './useSharedFuelRequest';
import { useSafe } from './useSafe';

// Utils
import {
  getCurrentTransactionId,
  getEodTransactionId,
} from '../Utils/paymentUtils';
import {
  generateMoneyOrderPingRequest,
  generateHardTotalSyncRequest,
  generateMOMRequest,
  getCashRequest,
  generateSafeReserveRequest,
  generateSafeReserveCancelReq,
} from '../Utils/eodUtils';
import { storeTranSeqNumber, getCorrelationID } from '../Utils/appUtils';
import { writeDataToFile } from '../Utils/fileUtils';
import { generateEODReceiptPayload } from '../Utils/receiptUtil';
import { getDVR } from '../hardware/dvr';
// Slices
import { cartActions } from '../slices/cart.slice';
import { authActions } from '../slices/auth.slice';
import { setDayShift } from '../slices/main.slice';
import { peripheralActions } from '../slices/peripheral.slice';
import { setInstallTimer } from '../slices/notifications.slice';
// Network
import {
  initiateEOS,
  initiateHardTotal,
} from '../api/otherFunctions/endOfShift';
import { fetchEmailReceipt } from '../api/payment';
import { fetchDayShift } from '../api/app/fetchDayShift';
import { useTimer } from './useTimer';

import {
  requestMoneyOrderLock,
  releaseMoneyOrderLock,
} from '../Utils/moneyOrderUtils';
import {
  MOM_NOT_INTEGRATED,
  SAFE_NOT_ENABLED,
  WAITING_FOR_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SC_MOM_LOCK_RESPONSE,
  WAITING_FOR_MOM_PING_RESPONSE,
  WAITING_FOR_SC_SAFE_LOCK_RESPONSE,
  MOM_PING_FAILED,
  MOM_PING_SUCCESS,
  SAFE_LOCK_SUCCESS,
  SAFE_LOCK_FAILED,
  safeDrop,
} from '../constants';

import { useWSocket } from './useWSocket';

export const useDayShiftChange = () => {
  const appContextActions = useContext(AppContext);
  const [ws] = useContext(WebSocketContext);
  const toast = useSoundToast();
  const dispatch = useDispatch();
  const history = useHistory();
  const {
    deviceId,
    membertransactionId,
    user,
    paymentTransactionId,
    storeId,
    config,
    deviceInfo,
    storeDetails,
    channel,
    momLockStatus,
  } = useSelector(state => ({
    deviceId: state.main.deviceInfo?.id,
    user: state.auth.user,
    membertransactionId: state.cart.MembertransactionId,
    transactionId: state.cart.transactionId,
    paymentTransactionId: state.cart.paymentTransactionId,
    storeId: state.main.storeDetails?.storeId,
    config: state.main.configuration,
    deviceInfo: state.main.deviceInfo,
    storeDetails: state.main.storeDetails,
    channel: state.main.channel,
    momLockStatus: state.peripheral.momLockStatus,
  }));
  const { isIntegratedFuelStore } = useFuel();
  const { sendEOSToDEX, sendEODToDEX } = useSharedFuelRequest();
  const { start, stop } = useTimer(40000, 'MOM Ping Request Timer');
  const {
    performSafeEODActivities,
    requestSafeLock,
    releaseSafeLock,
  } = useSafe();
  const { processRequestAsPromise } = useWSocket();
  const successToast = msg => {
    toast({
      status: 'success',
      duration: 3000,
      position: 'top',
      description: msg,
    });
  };

  const showToast = msg => {
    toast({
      status: 'error',
      duration: 3000,
      position: 'top',
      description: msg,
    });
  };
  const isEOD = action => action === 'EOD';

  const handleLogout = event => {
    successToast(`You have successfully initiated ${event}!`);
    dispatch(authActions.setAppLogInStatus(false));
    history.replace('/');
    successToast(`You have successfully logged out!`);
  };

  const handleTimeOut = () => {
    stop();
    dispatch(peripheralActions.setMOMLockStatus(MOM_PING_FAILED));
  };

  useEffect(() => {
    if (
      momLockStatus === MOM_PING_FAILED ||
      momLockStatus === MOM_PING_SUCCESS ||
      momLockStatus === null
    )
      stop();
  }, [momLockStatus]);

  const sendMOMData = (dayNo, storeNo, eodEventId, terminalId) => {
    if (
      config?.moneyOrderConfig?.isIntegrated &&
      config?.moneyOrderConfig?.isMoneyOrderStore
    ) {
      ws.socket?.send(
        '/app/mom/sendDataToMOM',
        {},
        generateMOMRequest(
          dayNo,
          storeNo,
          eodEventId,
          terminalId,
          paymentTransactionId,
          deviceId
        )
      );
    }
  };

  const performDexRequest = (dayNo, shiftNo, action) => {
    if (!isIntegratedFuelStore) {
      return;
    }
    const dexRequest = isEOD(action) ? sendEODToDEX : sendEOSToDEX;
    dexRequest({ day: dayNo, shift: shiftNo })
      .then(() => Logger.info(`[Fuel] POS:EOS->DEX request is successful`))
      .catch(e =>
        Logger.info(`[Fuel] POS:EOS->DEX request failed. Reason: ${e.message} `)
      );
  };

  const printEODReceipt = async payload => {
    try {
      const receiptPayload = generateEODReceiptPayload({
        ...payload,
        storeDetails: store.getState()?.main?.storeDetails,
        config: store.getState()?.main?.configuration,
        isCdbBtnAcive: store.getState()?.main?.isCdbBtnAcive,
      });
      await fetchEmailReceipt(receiptPayload, paymentTransactionId, channel);
      Logger?.info(`[7POS UI] -  printEODReceipt() Success`);
    } catch (error) {
      global?.logger?.error(`[7POS UI] - printEODReceipt() Error:`);
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        showToast(errorMessage.message);
      } else {
        showToast('Receipt could not be printed. Please try again');
      }
    }
  };
  const fetchHardTotals = async (eventId, transId, action) => {
    let response = {};
    try {
      response = await getHardTotals(eventId, transId);
      global?.logger?.info(
        `[7POS UI] - initiate ${action} getHardtotals result :::${JSON.stringify(
          response
        )}`
      );
    } catch (e) {
      global?.logger?.info(
        `[7POS UI] - initiate ${action} getHardtotals error :::${JSON.stringify(
          e
        )}`
      );
    }
    return response;
  };
  const triggerInitiateHardTotals = async (hardTotals, action) => {
    try {
      await initiateHardTotal(hardTotals, paymentTransactionId);
      global?.logger?.info(
        `7POS Appliction : intiate ${action} hardtotal Success.`
      );
    } catch (e) {
      global?.logger?.info(
        `7POS Appliction : intiate hardtotal Error::: - ${JSON.stringify(e)}`
      );
    }
  };
  const setLocalStorageVals = () => {
    localStorage.setItem('triggeredEODEOS', true);
    localStorage.getItem('rebootTimeout', 3.5 * 60 * 60);
    // #7655 retrive data from store instead of useSelector
    const {
      installTimer,
      receivedInstallNotification,
    } = store.getState().notifications;
    if (
      installTimer >= 0 &&
      installTimer <= 15 &&
      receivedInstallNotification
    ) {
      const remainingTimer = 15 - installTimer;
      const pushedInstallTimer = installTimer + remainingTimer;
      dispatch(setInstallTimer(pushedInstallTimer));
      Logger.info(
        `Installation pushed to ${pushedInstallTimer} mins due to EOD/EOS`
      );
      let installRemainder = localStorage.getItem('InstallRemainder');
      try {
        installRemainder = JSON.parse(installRemainder);
      } catch (error) {
        Logger.error(
          `Error retrieve installation data from memory:${JSON.stringify(
            error
          )}`
        );
        installRemainder = null;
      }
      if (installRemainder !== null) {
        let { installationData } = installRemainder;
        installationData = {
          ...installationData,
          remainingNotificationTime: pushedInstallTimer,
        };
        localStorage.setItem(
          'InstallRemainder',
          JSON.stringify({
            installationData,
          })
        );
        writeDataToFile({
          fileName: 'InstallRemainder.json',
          fileData: JSON.stringify({
            installationData,
          }),
        });
      }
    }
  };

  // Making fetchDayshift call to get and update the exchanges rate on EOD
  const getExchangeRate = async () => {
    let response = {};
    try {
      const r = await fetchDayShift({
        correlationID: paymentTransactionId,
      });
      global?.logger?.info(`[7POS UI] - getDayShift success: `);
      response = JSON.parse(r.data.data);
      dispatch(setDayShift(response));
    } catch (e) {
      global?.logger?.error(
        `[7POS UI] - getDayShift details Error ${JSON.stringify(e)}`
      );
    }
  };

  const processEODTapiRequest = async ({
    newStoreNo,
    newDayNo,
    newShiftNo,
    deviceId,
    hardTotals,
    cdbTranSeqId,
    eodTranSeqId,
  }) => {
    try {
      const cashDrawerBalanceSummary = await getCashDrawerBalanceReport({
        type: '',
      });
      const {
        eventId,
        startTransactionID,
        endTransactionID,
        skippedTransactionSeqId,
        CreationDate,
      } = hardTotals;

      const hardTotalData = {
        transactionID: eodTranSeqId,
        hardTotalSummary: hardTotals.hardTotalSummary,
        taxSummary: hardTotals.taxSummary,
      };

      const cashDrawerBalanceReport = {
        transactionID: cdbTranSeqId,
        cashDrawerBalanceSummary,
      };

      const finaleEodRequest = {
        eventId,
        storeId: newStoreNo,
        dayNumber: newDayNo,
        shiftNumber: newShiftNo,
        deviceId,
        startTransactionID,
        endTransactionID,
        skippedTransactionSeqId,
        CreationDate,
        hardTotalData,
        cashDrawerBalanceReport,
      };
      return finaleEodRequest;
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - processEODTapiRequest error :${JSON.stringify(error)}`
      );
    }
  };

  // MOM Store Cordinator Lock Request
  const sendMOMSCLockRequest = async action => {
    try {
      // Check if Money Order is Integrated
      if (isEOD(action)) {
        if (
          config?.moneyOrderConfig?.isIntegrated &&
          config?.moneyOrderConfig?.isMoneyOrderStore
        ) {
          dispatch(
            peripheralActions.setMOMLockStatus(WAITING_FOR_SC_MOM_LOCK_RESPONSE)
          );
          requestMoneyOrderLock(ws, deviceId, storeId, 'LOCK_REQUEST');
        } else {
          dispatch(peripheralActions.setMOMLockStatus(MOM_NOT_INTEGRATED));
          global?.logger?.info(`[7POS UI] - MOM IS NOT INTEGRATED `);
        }
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store Cordinator Lock Request ERROR :${JSON.stringify(
          error
        )}`
      );
    }
  };

  // MOM Middleware or MOM device Lock Request
  const sendMOMPingRequest = async () => {
    try {
      if (
        config?.moneyOrderConfig?.isIntegrated &&
        config?.moneyOrderConfig?.isMoneyOrderStore
      ) {
        ws.socket?.send(
          '/app/mom/sendDataToMOM',
          {},
          generateMoneyOrderPingRequest(deviceId)
        );
        dispatch(
          peripheralActions.setMOMLockStatus(WAITING_FOR_MOM_PING_RESPONSE)
        );
        start(handleTimeOut);
      } else {
        dispatch(peripheralActions.setMOMLockStatus(MOM_NOT_INTEGRATED));
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - MOM Lock ERROR :${JSON.stringify(error)}`
      );
    }
  };
  // Safe Store Cordinator Lock Request
  const sendSafeSCLockRequest = async () => {
    try {
      // Check if Safe is Integrated
      const { isSafeReady } = store.getState().peripheral;
      if (config?.safeConfig?.isIntegrated && isSafeReady) {
        dispatch(
          peripheralActions.setSafeLockStatus(WAITING_FOR_SC_SAFE_LOCK_RESPONSE)
        );
        requestSafeLock();
      } else {
        dispatch(peripheralActions.setSafeLockStatus(SAFE_NOT_ENABLED));
        global?.logger?.info(`[7POS UI] - SAFE IS NOT ENABLED`);
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store Cordinator Lock Request ERROR :${JSON.stringify(
          error
        )}`
      );
    }
  };

  const processSafeResponse = res => {
    let msg;
    let msgType;
    try {
      msg = res?.messageBody?.message;
      msgType = res?.messageHeader?.messageType;
    } catch (err) {
      global?.logger?.error(
        `[7POS UI] - Safe event error - ${JSON.stringify(msg)}`
      );
      msg = {};
    }
    global?.logger?.info(
      `[7POS UI] - Safe Event Received - ${JSON.stringify(res)}`
    );
    const { safeLockStatus } = store.getState().peripheral;
    if (
      msgType === 'safeActionLockWait' ||
      safeLockStatus === WAITING_FOR_SAFE_LOCK_RESPONSE
    ) {
      if (msg?.status === 'SafeServerStatusGood')
        dispatch(peripheralActions.setSafeLockStatus(SAFE_LOCK_SUCCESS));
      else dispatch(peripheralActions.setSafeLockStatus(SAFE_LOCK_FAILED));
      return;
    }
    if (msgType === 'safeActionLockCancel') {
      dispatch(peripheralActions.setSafeLockStatus(null));
    }
  };

  // send safe peripheral Lock Request
  const safeReserveRequest = async () => {
    const { isSafeReady } = store.getState().peripheral;
    if (config?.safeConfig?.isIntegrated && isSafeReady) {
      dispatch(
        peripheralActions.setSafeLockStatus(WAITING_FOR_SAFE_LOCK_RESPONSE)
      );
      const socketPayload = generateSafeReserveRequest(
        deviceInfo,
        user?.userId
      );
      processRequestAsPromise({
        subscribeTo: safeDrop.channels.controlQueue,
        sendTo: safeDrop.channels.talkToSafe,
        socketPayload,
        showLoader: false,
        timer: 30000,
        subId: 'safe-reserve-subscription',
      })
        .then(res => {
          processSafeResponse(res);
        })
        .catch(err => {
          Logger.info(
            `[7POS UI] - SAFE RESERVE REQUEST ERROR ::- ${JSON.stringify(err)}`
          );
          dispatch(peripheralActions.setSafeLockStatus(SAFE_LOCK_FAILED));
        });
    } else {
      dispatch(peripheralActions.setSafeLockStatus(SAFE_NOT_ENABLED));
    }
  };

  // send safe peripheral Lock release Request
  const safeReserveCancel = async () => {
    const { isSafeReady } = store.getState().peripheral;
    if (config?.safeConfig?.isIntegrated && isSafeReady) {
      const socketPayload = generateSafeReserveCancelReq(
        deviceInfo,
        user?.userId
      );
      processRequestAsPromise({
        subscribeTo: safeDrop.channels.controlQueue,
        sendTo: safeDrop.channels.talkToSafe,
        socketPayload,
        showLoader: false,
        timer: 30000,
        subId: 'safe-reserve-cancel-subscription',
      })
        .then(res => {
          processSafeResponse(res);
        })
        .catch(err => {
          Logger.info(
            `[7POS UI] - SAFE RESERVE CANCEL REQUEST ERROR ::- ${JSON.stringify(
              err
            )}`
          );
        });
    } else {
      dispatch(peripheralActions.setSafeLockStatus(SAFE_NOT_ENABLED));
    }
  };

  const releaseStoreCordinatorLocks = async () => {
    try {
      releaseMoneyOrderLock(ws, deviceId, storeId);
      releaseSafeLock();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Release Lock ERROR :${JSON.stringify(error)}`
      );
    }
  };

  const genrateTransactionIdForEod = transactionId => {
    const cdbTranSeqId = transactionId;
    const eodTranSeqId = (Number(transactionId) + 1)
      .toString()
      .padStart(4, '0');
    dispatch(cartActions.setTransactionId(transactionId));
    return {
      cdbTranSeqId,
      eodTranSeqId,
    };
  };

  const handleDayOrShiftClose = async action => {
    try {
      // #8119 added EOD/EOS progress check before
      if (localStorage.getItem('triggeredEODEOS')) {
        Logger.info(`EOD/EOS inprogress:${action}`);
        return;
      }
      Logger.info(`EOD/EOS Intiated:${action}`);
      localStorage.setItem('triggeredEODEOS', true);
      appContextActions?.startLoading();
      const transactionId = getCurrentTransactionId();
      const { cdbTranSeqId, eodTranSeqId } = genrateTransactionIdForEod(
        transactionId
      );
      const cashReq = getCashRequest({
        transactionId: eodTranSeqId,
        deviceId,
        userId: user?.userId,
        storeId,
        action,
      });
      setLocalStorageVals();

      // STEP :: 1 Cash API
      const response = await initiateEOS(cashReq, paymentTransactionId);
      if (response.data.message !== 'Success') {
        const r = JSON.stringify(response);
        global?.logger.error(`[7POS UI] - EOS Failed ::- ${r}`);
        throw new Error(`EOS Failed`);
      }
      // Setting the new transaction id after EOS intiated.
      const newTransId = getEodTransactionId(eodTranSeqId);
      dispatch(cartActions.setTransactionId(newTransId));
      getExchangeRate(); // Get Exchange rate in EOD
      global?.logger?.info(
        `[7POS UI] - Main Terminal initiate ${action} Success`
      );
      const { eventId: eosEventId } = response.data;
      const splitResult = eosEventId?.split('-');
      const [newStoreNo, newDayNo, newShiftNo] = splitResult;
      // STEP :: 2
      ws.socket?.send(
        '/app/sync-service-msg',
        {},
        generateHardTotalSyncRequest(response)
      );
      handleLogout(action);
      // RIS-8220 : Storing new transeqID
      await storeTranSeqNumber({
        transactionId: eodTranSeqId,
        MembertransactionId: membertransactionId,
        correlationID: paymentTransactionId,
      });
      performDexRequest(newDayNo, newShiftNo, action);
      // Temporary fix for 04/18 CDB release, Only hardtotals included in the payload
      const hardTotalsExceptCDB = await fetchHardTotals(
        eosEventId,
        eodTranSeqId,
        action
      );
      hardTotalsExceptCDB.deviceId = deviceId;
      hardTotalsExceptCDB.storeId = newStoreNo;
      hardTotalsExceptCDB.dayNumber = newDayNo;
      hardTotalsExceptCDB.shiftNumber = newShiftNo;
      const finalHardTotalsReq = await processEODTapiRequest({
        newStoreNo,
        newDayNo,
        newShiftNo,
        deviceId,
        hardTotals: hardTotalsExceptCDB,
        cdbTranSeqId,
        eodTranSeqId,
      });
      if (isEOD(action)) {
        sendMOMData(newDayNo, newStoreNo, eosEventId, deviceId);
      }
      getDVR().sendEOSEOD(
        config,
        hardTotalsExceptCDB,
        deviceInfo,
        storeDetails,
        deviceId,
        moment.utc(),
        eodTranSeqId, // Temp Fix for 0425 release
        action,
        user
      );
      performSafeEODActivities({
        dayNumber: newDayNo,
        shiftNumber: newShiftNo,
        deviceInfo,
        userId: user?.userId,
        action: isEOD(action) ? 'safeActionEndOfDay' : 'safeActionEndOfShift',
        eventId: eosEventId,
      });
      const updatedHardTotals = {
        ...hardTotalsExceptCDB,
        transactionID: eodTranSeqId,
        endTransactionID: eodTranSeqId,
      };
      triggerInitiateHardTotals(updatedHardTotals, action); // Temporary fix for 04/18 CDB release, Only hardtotals included in the payload
      dispatch(cartActions.setPaymentTransactionId(getCorrelationID()));
      printEODReceipt({
        ...finalHardTotalsReq,
        type: action,
        operator: user?.userId,
        cdbTranSeqId,
        eodTranSeqId,
      });
      // #8484 reset shift data after completion of hardtotals post.
      await updateHardTotalsSnapshot(hardTotalsExceptCDB);
    } catch (error) {
      console.log(error, 'Error');
      global?.logger?.error(
        `[7POS UI] - initiateEOS ERROR :${JSON.stringify(error)}`
      );
      if (error) {
        const e = JSON.parse(JSON.stringify(error?.response?.data));
        if (e?.message !== 'success') {
          const MSG = `Failed processing ${action}.`;
          showToast(MSG);
        }
      }
      global?.logger?.error(
        `[7POS UI] - onConfirmEndOfShift error :${JSON.stringify(error)}`
      );
      // Release locks on error
      safeReserveCancel();
      releaseMoneyOrderLock(ws, deviceId, storeId);
      releaseSafeLock();
      // Reset flags on error
      dispatch(peripheralActions.setMOMLockStatus(null));
      dispatch(peripheralActions.setSafeLockStatus(null));
      dispatch(cartActions.setIsEndOfDayorShift(false));
    } finally {
      localStorage.removeItem('triggeredEODEOS');
      appContextActions?.stopLoading();
    }
  };
  const handleDayOrShiftCloseOnSyncEvent = async (syncEvent, logout) => {
    const { eventNumber, type } = syncEvent;
    try {
      setLocalStorageVals();
      const transactionId = getCurrentTransactionId();
      const { cdbTranSeqId, eodTranSeqId } = genrateTransactionIdForEod(
        transactionId
      );
      const hardTotalsExceptCDB = await fetchHardTotals(
        eventNumber,
        eodTranSeqId,
        type
      );
      const {
        deviceInfo: { id: deviceId },
        deviceInfo,
      } = store.getState()?.main;
      hardTotalsExceptCDB.eventId = eventNumber;
      hardTotalsExceptCDB.deviceId = deviceId;
      const splitResult = eventNumber.split('-');
      const [newStoreNo, newDayNo, newShiftNo] = splitResult;
      hardTotalsExceptCDB.storeId = newStoreNo;
      hardTotalsExceptCDB.dayNumber = newDayNo;
      hardTotalsExceptCDB.shiftNumber = newShiftNo;

      const finalHardTotalsReq = await processEODTapiRequest({
        newStoreNo,
        newDayNo,
        newShiftNo,
        deviceId,
        hardTotals: hardTotalsExceptCDB,
        cdbTranSeqId,
        eodTranSeqId,
      });

      // const operator = store.getState()?.auth?.user?.userId;
      const { isAppLogin, user } = store.getState()?.auth || {};
      const operator = user?.userId;

      getDVR().sendEOSEOD(
        store.getState()?.main?.configuration,
        hardTotalsExceptCDB,
        deviceInfo,
        store.getState().main?.storeDetails,
        deviceId,
        moment.utc(),
        eodTranSeqId, // Temp Fix for 0425 release
        type,
        user
      );
      logout();
      if (isAppLogin) {
        successToast('You have successfully logged out!');
      }
      printEODReceipt({
        ...finalHardTotalsReq,
        type,
        operator,
        eodTranSeqId,
      });
      const {
        paymentTransactionId,
        MembertransactionId,
        // transactionId: tId,
      } = store.getState()?.cart;
      const newTransId = getEodTransactionId(eodTranSeqId);
      dispatch(cartActions.setTransactionId(newTransId));
      // RIS-8220 : Storing new transeqID
      await storeTranSeqNumber({
        transactionId: eodTranSeqId,
        MembertransactionId,
        correlationID: paymentTransactionId,
      });
      const updatedHardTotals = {
        ...hardTotalsExceptCDB,
        transactionID: eodTranSeqId,
        endTransactionID: eodTranSeqId,
      };
      const hardTotalResponse = await initiateHardTotal(
        updatedHardTotals, // Temp Fix for 0425 release
        paymentTransactionId
      );
      const { openDayNumber, openShiftNumber } = hardTotalResponse?.data || {};
      // sendSafeIntialize();
      console.log(
        'dayNumber : - ',
        openDayNumber,
        'shiftNumber :-',
        openShiftNumber,
        'hardTotalResponse :-',
        hardTotalResponse
      );
      getExchangeRate(); // PROD shift number issue fix
      performSafeEODActivities({
        dayNumber: openDayNumber,
        shiftNumber: openShiftNumber,
        deviceInfo,
        userId: operator,
        action: isEOD(type) ? 'safeActionEndOfDay' : 'safeActionEndOfShift',
        needEncode: false,
        isMainTerminal: false,
      });
      global?.logger?.info(
        `[7POS UI] - Secondary Terminal initiate ${type} Success :${JSON.stringify(
          hardTotalResponse
        )}`
      );
      // #8484 reset shift data after completion of hardtotals post.
      await updateHardTotalsSnapshot(hardTotalsExceptCDB);
      successToast(`You have successfully initiated ${type}`);
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Intiate Secondary terminal ${type} Error:::-${JSON.stringify(
          error
        )}`
      );
    }
    localStorage.removeItem('triggeredEODEOS');
    dispatch(cartActions.setPaymentTransactionId(getCorrelationID()));
  };

  return {
    handleDayOrShiftCloseOnSyncEvent,
    handleDayOrShiftClose,
    sendSafeSCLockRequest,
    sendMOMSCLockRequest,
    releaseStoreCordinatorLocks,
    safeReserveRequest,
    sendMOMPingRequest,
    safeReserveCancel,
  };
};
