/* eslint-disable arrow-body-style */
import { useEffect, useState } from 'react';
import { v1 as uuidv1 } from 'uuid';

import { useWSocket } from './useWSocket';
import { useTimer } from './useTimer';
import { useSoundToast } from './useSoundToast';
import {
  fetchDeviceSetupStatus,
  triggerAutoRegister,
} from '../api/app/fetchDeviceSetupStatus';

const NOTFICATION_EVENT = '7POS_AUTO_REGISTRATION_SYNC_EVENT';
const INITIAL_TIMER = 60000;
const EVENT_INTERVAL_TIMER = 30000;
const RETRY_DELAY_TIMER = 15000; // MILLI SECONDS

const electron = window.require('electron');

export const useRegistration = setRegistered => {
  const {
    isConnected,
    getActiveSocketRef,
    stopListeningToSocketResponse,
  } = useWSocket();
  const showToast = useSoundToast();
  const [isProcessing, setIsProcessing] = useState(true);
  const [canIRegister, setCanIRegister] = useState(false);
  const [step, setStep] = useState(1);
  const [retryAttempt, setRetryAttempt] = useState(0);
  const [triggerRetry, setTriggerRetry] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loadingMessage, setLoadingMessage] = useState('Please wait...');

  const { start, stop } = useTimer(EVENT_INTERVAL_TIMER, 'Auto Registration');

  const waitForGivenTime = waitTime =>
    new Promise(res => {
      setTimeout(res, waitTime);
    });
  const restartApp = () => {
    stopListeningToSocketResponse();
    stop();
    electron.ipcRenderer.send('Main-Message', 'Restart');
  };
  const incrementRetry = async () => {
    if (retryAttempt === 2) {
      setRegistered(true);
      showToast({
        description: 'Auto Registration Failed.',
        position: 'top',
      });
      Logger?.info(
        '[7POS UI]: AUTO REGISTRATION :: Failed moving to manual regisration (Login Page)'
      );
      return;
    }
    const retAtempt = retryAttempt + 1;
    const delayTime = retAtempt * RETRY_DELAY_TIMER;
    setRetryAttempt(retAtempt);
    setProgress(0);
    Logger?.info(
      `[7POS UI]: AUTO REGISTRATION :: RETRY ATTEMPT ${retAtempt} will be initiated after ${delayTime} Milli Seconds`
    );
    await waitForGivenTime?.(retAtempt * RETRY_DELAY_TIMER);
    setTriggerRetry(true);
  };

  const handleEventWithTimer = (rej, res) => {
    Logger?.info(
      `[7POS UI]: AUTO REGISTRATION:: Adding 60 Secs timer for Event to recive`
    );
    start(rej, INITIAL_TIMER);
    return event => {
      setStep(2);
      Logger?.info(`[7POS UI]: AUTO REGISTRATION :: SYNC EVENT: ${event}`);
      const payload = JSON.parse(event.body);
      const { type, meta } = payload;
      if (type === 'SYNC_PROGRESS') {
        setProgress(meta.progress);
        if (meta.progress === 100) {
          res();
          restartApp();
          return;
        }
      }
      start(rej);
    };
  };

  const processSyncRequest = async () => {
    if (!retryAttempt) {
      setStep(1);
    }

    return new Promise(async (resolve, reject) => {
      try {
        getActiveSocketRef()?.subscribe?.(
          `/7pos/appnotifications`,
          handleEventWithTimer(reject, resolve),
          {
            id: NOTFICATION_EVENT,
          }
        );
        await triggerAutoRegister({
          correlationID: uuidv1(),
        });
        setIsProcessing(false);
      } catch (e) {
        if (`${e.response?.status}`.startsWith(5)) {
          Logger?.info(
            '[7POS UI]:: AUTO REGISTRATION :: 500 Error Retrying will be intiated'
          );
          reject();
        } else if (`${e.response?.status}`.startsWith(4)) {
          Logger?.info(
            '[7POS UI]:: AUTO REGISTRATION :: 400 Error Moving on to Login page'
          );
          //   setRegistered(true);
          setIsProcessing(false);
          showToast({
            description: 'Auto Registration Failed.',
            position: 'top',
          });
          resolve();
        }
      }
    });
  };

  const triggerAutoRegistration = async () => {
    setTriggerRetry(false);
    try {
      await processSyncRequest();
      setRegistered(true);
    } catch (e) {
      incrementRetry();
    } finally {
      stopListeningToSocketResponse(NOTFICATION_EVENT);
      stop();
    }
  };

  const getDeviceStatus = async () => {
    try {
      const res = await fetchDeviceSetupStatus({
        correlationID: uuidv1(),
      });
      const { isSetupCompleted } = res.data?.data || {};
      Logger?.info(
        `[7POS UI]: AUTO REAGISTRATION: isDevice Registration Needed: ${!isSetupCompleted} `
      );
      if (isSetupCompleted) {
        setIsProcessing(false);
        setRegistered(true);
        return;
      }
      setCanIRegister(true);
      if (!isConnected) {
        setLoadingMessage('Waiting for connection...');
      }
    } catch (error) {
      setIsProcessing(false);
      setRegistered(true); // #should redirect to login screen if any failure on Device status
      Logger.info(
        `[7POS UI]: AUTO REAGISTRATION: DEVICE SETUP STATUS FAILED ${JSON.stringify(
          error
        )}`
      );
    }
  };

  const onRetry = () => {
    Logger.info(
      `[7POS UI]: AUTO REGISTRATION :: Retry Attempt ${retryAttempt}`
    );
    triggerAutoRegistration();
  };

  useEffect(() => {
    if (!triggerRetry) {
      return;
    }
    onRetry();
  }, [triggerRetry]);

  useEffect(() => {
    if (!isConnected) {
      Logger?.info(
        `[7POS UI]: AUTO REGISTRATION:: Waiting for Socket to connect`
      );
      return;
    }
    if (canIRegister) {
      setLoadingMessage('Please wait..., Initiating Device Registration');
      triggerAutoRegistration();
    }
  }, [isConnected, canIRegister]);

  useEffect(() => {
    getDeviceStatus();
  }, []);

  return {
    isProcessing,
    retryAttempt,
    step,
    progress,
    // canIRegister,
    loadingMessage,
  };
};
