import { useSelector, useDispatch } from 'react-redux';
import { cartActions } from '../slices/cart.slice';
import { EBT_BAG_FEE_DEPT_NUM } from '../constants';

export const useEBTBagFee = () => {
  const {
    items,
    ebtBagFeeConfig,
    allPayments,
    mediaAbortedPaymentList,
    ebtBagFeeitems,
    storeProfile,
  } = useSelector(state => ({
    items: state.cart.items,
    ebtBagFeeConfig: state.main.ebtbagFeeExemptDetails,
    allPayments: state.cart.allPayments,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    ebtBagFeeitems: state.cart.ebtBagFeeitems,
    storeProfile: state.main.storeDetails,
  }));
  const dispatch = useDispatch();

  // Moved to one place to check state code check when configuration change.
  const isValidEBTBagFeeExemptState = () => {
    let isValidExempt = false;
    try {
      if (Array.isArray(ebtBagFeeConfig)) {
        const iEBTBagFeeState = ebtBagFeeConfig.find(
          ({ code }) => code === storeProfile?.address?.state
        );
        // store state need to match and active flag should be true
        if (iEBTBagFeeState?.code && iEBTBagFeeState?.isActive) {
          isValidExempt = true;
        }
      }
      return isValidExempt;
    } catch (error) {
      Logger.error(
        `[7POS UI] - isValidEBTBagFeeExemptState error ${JSON.stringify(error)}`
      );
      return isValidExempt;
    }
  };

  const AddOrRemovalEBTBagFeeItem = ({
    iRemoveIntiate = true,
    isEBTBagFeeRemoved,
    isSkipPaymentCheck = false,
  }) => {
    if (!isValidEBTBagFeeExemptState()) return false;
    if (iRemoveIntiate && !isEBTBagFeeRemoved) {
      let iBagFeeRemoved = false;
      // #7378 convert department ID as string before slice
      const iBagFeeItems = items?.filter(
        item =>
          item?.category?.id?.toString()?.slice(0, 4) ===
            EBT_BAG_FEE_DEPT_NUM ||
          (
            item?.PSAGroupInfo?.psaCode +
            item?.PSAGroupInfo?.catCode +
            item?.PSAGroupInfo?.subcatCode
          )
            ?.toString()
            ?.slice(0, 4) === EBT_BAG_FEE_DEPT_NUM
      );
      if (iBagFeeItems && iBagFeeItems[0]) {
        iBagFeeRemoved = true;
        dispatch(cartActions.setBagFeeItems());
        dispatch(cartActions.removeEBTBagFeeFromCart());
        Logger.info(`[7POS UI] - EBT Bag fee item removed.`);
      }
      return iBagFeeRemoved;
      // eslint-disable-next-line no-else-return
    } else if (isEBTBagFeeRemoved && ebtBagFeeitems) {
      let isEbtSnapPresent = false;
      let isMediaAbort = [];
      let iEBTBagFeeAdded = false;
      if (!isSkipPaymentCheck)
        allPayments
          ?.filter(
            pml =>
              pml?.paymentMediaType === 'EBTSNAP' ||
              pml?.paymentMediaType === 'EBTCB'
          )
          ?.map(pml => {
            if (mediaAbortedPaymentList[0]) {
              isMediaAbort = mediaAbortedPaymentList?.filter(
                payment =>
                  payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
              );
              if (!isMediaAbort[0]) {
                isEbtSnapPresent = true;
              }
            } else {
              isEbtSnapPresent = true;
            }
            return pml;
          });
      if (!isEbtSnapPresent && ebtBagFeeitems && ebtBagFeeitems[0]) {
        iEBTBagFeeAdded = true;
        dispatch(cartActions.addEBTBagFeeToCart());
        Logger.info(`[7POS UI] - EBT Bag fee item added.`);
      }
      return iEBTBagFeeAdded;
    }
  };
  return {
    AddOrRemovalEBTBagFeeItem,
  };
};
