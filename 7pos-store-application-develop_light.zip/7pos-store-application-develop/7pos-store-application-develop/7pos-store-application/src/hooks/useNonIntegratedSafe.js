import { useSelector, useDispatch } from 'react-redux';
import { useCashDrawer } from './useCashDrawer';
import { cartActions } from '../slices/cart.slice';
import { dailpadActions } from '../slices/dailpad.slice';
import { useTAPIPosting } from './useTAPIPosting';
import { useSoundToast } from './useSoundToast';
import { useSafeDropHistory } from './useSafeDropHistory';
import { useUpdatedState } from './useUpdatedState';
import { useReciepts } from './useReceipts';
import { safeDrop } from '../constants';
import { getDVR } from '../hardware/dvr';
import store from '../store';

export const useNonIntegratedSafe = () => {
  const { openCashDrawer } = useCashDrawer();
  const dispatch = useDispatch();
  const { postTapi } = useTAPIPosting();
  const toast = useSoundToast();
  const navigation = useSafeDropHistory();
  const updatedState = useUpdatedState();
  const { print } = useReciepts();
  const showToast = msg => {
    if (msg?.length > 0)
      toast?.({
        description: msg,
        status: 'error',
        duration: 3000,
        position: 'top',
      });
  };
  const {
    storeDetails,
    config,
    deviceInfo,
    user,
    keypadValue,
    safeDropType,
    isVault,
    vaultUserEntries,
    safeOflineAmount,
    paymentTransactionId,
    transactionId,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    config: state.main.configuration,
    deviceInfo: state.main.deviceInfo,
    user: state.auth.user,
    keypadValue: state.dailpad.keypad?.value,
    safeDropType: state.cart.safeDropType,
    isVault: state.cart.safeDropType === 'vaultDrop',
    vaultUserEntries: state.cart.vaultUserEntries,
    safeOflineAmount: state.cart.safeOflineAmount,
    paymentTransactionId: state.cart.paymentTransactionId,
    transactionId: state.cart.transactionId,
  }));

  const openCashDrwrForSafe = () => {
    openCashDrawer();
  };

  const onSafeComplete = () => {
    const { vaultUserEntries, safeDropResponse } = updatedState().cart;
    getDVR().sendSafe(
      storeDetails?.currencyCode === 'CAD' &&
        updatedState()?.safeDropType === 'insertBills'
        ? safeDropResponse?.[1]?.amount
        : safeDropResponse?.[0]?.amount,
      config,
      deviceInfo,
      false,
      storeDetails,
      transactionId,
      safeDrop[safeDropType]?.uLabel,
      user
    );
    print({ vaultUserEntries, safeDropResponse, paymentTransactionId });
    dispatch(dailpadActions.resetKeypadValue());
    navigation.navigateTOHome(true);
    dispatch(cartActions.emptyCart());
    dispatch(cartActions.completeSafeDrop());
  };

  const onSafeSelection = type => {
    openCashDrwrForSafe();
    dispatch(cartActions.setSafeDropType(type));
    dispatch(cartActions.setSafeProgress(true));
    dispatch(cartActions.setPOSSystemStatus('StartedNewTransaction'));
    navigation.navigateToManualEnter();
  };

  const onValueEnter = (value = keypadValue) => {
    if (!value) {
      showToast('Enter Amount');
      return;
    }
    let enteredValue = value;
    if (isVault && vaultUserEntries.amount && vaultUserEntries.envelop) {
      navigation.navigateToManualComplete();
      postTapi({
        safeResponseStatus: 'safeOffline',
        amount: vaultUserEntries?.amount,
        envelop: vaultUserEntries?.envelop,
        currencyCode: store.getState().cart.vaultUserEntries?.vaultCurrency,
        safeDropType,
        transactionStatus: 'COMPLETE',
      });
      return;
    }
    if (!safeOflineAmount) {
      dispatch(cartActions.setSafeOflineAmount(value));
      if (!isVault) {
        navigation.navigateToManualPayment();
        return;
      }
      dispatch(
        cartActions.setVaultUserEntries({
          ...vaultUserEntries,
          amount: enteredValue,
        })
      );
      dispatch(dailpadActions.resetKeypadValue());
      navigation.navigateToManualEnvlp();
    } else {
      if (isVault) {
        dispatch(
          cartActions.setVaultUserEntries({
            ...vaultUserEntries,
            envelop: enteredValue,
          })
        );
        dispatch(dailpadActions.resetKeypadValue());
        navigation.navigateToManualPayment();
        return;
      }
      enteredValue = safeOflineAmount;
      navigation.navigateToManualComplete();
      postTapi({
        safeResponseStatus: 'safeOffline',
        amount: enteredValue,
        safeDropType,
        transactionStatus: 'COMPLETE',
      });
      dispatch(cartActions.setSafeResponse([{ amount: enteredValue }]));
    }
  };

  const onPaymentSelect = type => {
    if (type !== 'cash') {
      return;
    }
    onValueEnter(safeOflineAmount);
  };

  return {
    onSafeSelection,
    onValueEnter,
    onPaymentSelect,
    onSafeComplete,
  };
};
