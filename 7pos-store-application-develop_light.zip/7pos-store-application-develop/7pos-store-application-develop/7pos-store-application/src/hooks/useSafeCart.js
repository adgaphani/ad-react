import React from 'react';

import { POSCart } from '../components/Common/Cart/POSCart';
import { TransactionTypeText } from '../components/Common/Cart/TransactionTypeText';

export const useSafeCart = () => {
  const Footer = TransactionTypeText;
  const renderSafeCart = () => <POSCart footer={Footer} />;
  return {
    renderSafeCart,
  };
};
