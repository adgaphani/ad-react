/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import { useCallback } from 'react';
import { useSelector, useDispatch, shallowEqual } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { CarwashUtils } from '../Utils';
import { FISActions, FISCommManager } from '../components/Fuel';
import { cwStatusMapper, cwStatus } from '../components/Fuel/Carwash';
import { fuelActions } from '../slices/fuel.slice';
import { useWSocket } from './useWSocket';
import { WSTopics, WSSubscriptions } from '../constants';
import { useCart } from './useCart';
import { useFuelCache } from './useFuelCache';
import { useSoundToast } from './useSoundToast';

export const useCarWash = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { processRequestAsPromise } = useWSocket();
  const { setCarwashConfig } = useFuelCache();
  const toast = useSoundToast();

  const { addItemToCart, isTransactionRefund, isTransactionVoid } = useCart();
  const { processFISResponse } = FISCommManager;
  const {
    isCarWashEnabled,
    packages,
    items,
    isCarwashInProgress,
    selectedCarwash,
  } = useSelector(state => {
    const { carwash } = state.fuel || {};
    return {
      isCarWashEnabled: CarwashUtils.isCarwashEnabled(carwash),
      packages: CarwashUtils.getCarwashPackages(carwash),
      items: state.cart.items,
      isCarwashInProgress: !!state.cart.items?.filter(i => i.isCarwash)?.length,
      selectedCarwash: state.fuel.selectedCarwash,
    };
  }, shallowEqual);
  const showToast = ({
    msg,
    duration = 600,
    position = 'top',
    status = 'error',
  }) => {
    toast({
      description: msg,
      position,
      duration,
      status,
    });
  };
  const addCarwashItemToCart = ({ item, isPromo, meta }, isRefund = false) => {
    const cartItem = CarwashUtils.getCarwashCartitem({
      name: item.name,
      amount: isPromo ? 0 : item.price * 100,
      isRefund,
      price: item.price,
    });
    cartItem.metaInfo = {
      ...item,
      carwashCode: meta.carwashCode,
      expiresAt: meta.expirationDate,
      expirationDate: meta.expirationDate,
      isPromoWash: isPromo,
      description: item.description,
    };
    addItemToCart(cartItem);
  };

  const getCode = (selectedpackage, isPromo) => {
    const { name, price, id } = selectedpackage;
    const socketConfig = {
      ...FISActions.getCarwashCode,
      carwashPackageId: id,
    };
    const socketPayload = FISCommManager.getpayloadForCarwash({
      body: socketConfig,
    });
    return processRequestAsPromise({
      subscribeTo: WSTopics.fis.commandResponse,
      sendTo: WSTopics.fis.sendCommand,
      isDummy: isDev ?? false,
      socketPayload,
      isResValid: ({ status }) => status === 1,
      subId: WSSubscriptions.fis.carwashResponse,
    })
      .then(res => {
        const eRes = processFISResponse(res);
        Logger.info(
          `[CARWASH] Generated Carwash code, Adding Carwash to the cart`
        );
        addCarwashItemToCart({
          item: { ...selectedpackage },
          isPromo,
          meta: eRes,
        });
        if (isPromo) {
          return history.push('/payment', {
            isPromoCarwash: true,
          });
        }
        history.replace('/home');
      })
      .catch(e => {
        Logger.info(
          `[CARWASH] Failed to generate Carwash code ::- ${JSON.stringify(e)}`
        );
        showToast({
          msg: 'Car wash is not available, Please Try Again',
          position: 'top-left',
          duration: 3000,
        });
        return history.replace('/fuel/nocarwash');
      });
  };

  const handleCarwash = isFreePromo => {
    if (isFreePromo && (isTransactionRefund || isTransactionVoid)) {
      return showToast({
        msg: Messages.ik_transaction.replace(
          '$',
          isTransactionRefund ? 'Refund' : 'Void'
        ),
        position: 'top-left',
        duration: 3000,
      });
    }
    if (isFreePromo && !!items.length) {
      return showToast({
        msg: Messages.invalid_key_transaction,
        position: 'top-left',
        duration: 3000,
      });
    }
    let route = isFreePromo ? 'promocarwash' : 'carwash';
    if (!packages?.length) {
      route = 'nocarwash';
      // return showToast(Messages.no_carwash_packages);
    }
    if (isCarwashInProgress) {
      showToast({
        msg: Messages.multiple_carwash,
        position: 'top-left',
        duration: 3000,
      });
      return history.replace('/home');
    }
    return history.push(`fuel/${route}`);
  };

  const onPackageSelect = (selectedpackage = {}, isPromo = false) => {
    dispatch(fuelActions.setSelectedCarwash(selectedpackage));
    if (isTransactionRefund || isTransactionVoid) {
      return history.push('/fuel/enterCode');
    }
    Logger.info(`[CARWASH] Selected : ${selectedpackage.name} `);
    return getCode(selectedpackage, isPromo);
  };
  const clearCode = useCallback(
    ({ cwMeta, isConfirmScreen = false, showLoader = true }) => {
      if (!isConfirmScreen && (isTransactionVoid || isTransactionRefund)) {
        return Promise.resolve();
      }
      const meta = cwMeta ?? items.filter(i => i.isCarwash)?.[0]?.metaInfo;
      if (!meta) {
        return Promise.reject('Meta not found, Unable to Clear carwash code');
      }
      const { carwashCode, id } = meta || {};
      const socketConfig = {
        ...FISActions.clearCarwashCode,
        carwashPackageId: id,
        carwashCode,
      };
      const socketPayload = FISCommManager.getpayloadForCarwash({
        body: socketConfig,
      });
      return processRequestAsPromise({
        subscribeTo: WSTopics.fis.commandResponse,
        sendTo: WSTopics.fis.sendCommand,
        isDummy: isDev ?? false,
        socketPayload,
        isResValid: res => res.status === 1,
        subId: WSSubscriptions.fis.carwashResponse,
        showLoader,
      }).then(() => Logger.info(`[CARWASH] Code Cleared`));
      // .catch(e => {
      //   console.log('Unable TO Clear carwash code'.e);
      //   showToast({ msg: 'Unable to void carwash Code' });
      // });
    },
    []
  );
  const validateCode = code => {
    if (!code) {
      return showToast({ msg: 'Please Enter Car Wash Code' });
    }
    const { name, price, id } = selectedCarwash;
    const socketConfig = {
      ...FISActions.validateCarwashCode,
      carwashCode: code,
      carwashPackageId: id,
    };
    const socketPayload = FISCommManager.getpayloadForCarwash({
      body: socketConfig,
    });
    return processRequestAsPromise({
      subscribeTo: WSTopics.fis.commandResponse,
      sendTo: WSTopics.fis.sendCommand,
      isDummy: isDev ?? false,
      socketPayload,
      isResValid: res => true,
      subId: WSSubscriptions.fis.carwashResponse,
    })
      .then(res => {
        console.log('carwash code validated', res);
        const eRes = processFISResponse(res);
        if (eRes.status === 1) {
          Logger.info(`[CARWASh] Code Validated`);
          addCarwashItemToCart(
            {
              item: {
                name,
                price,
                reason: 'REGULAR_WASH',
                id,
              },
              meta: { ...selectedCarwash, carwashCode: code },
            },
            true
          );
          return history.replace('/home');
        }
        Logger.info(
          `[CARWASh] unable to Validate code:: status is ${eres.status}`
        );

        return showToast({
          msg: cwStatusMapper[eRes.status] ?? Messages.cw_expired_code,
        });
      })
      .catch(e => {
        Logger.info(`[CARWASh] Error Validating code:: ${JSON.stringify(e)}`);
        showToast({ msg: cwStatusMapper[cwStatus.invalid] });
      });
  };
  const onExit = () => {
    dispatch(fuelActions.setSelectedCarwash());
    history.replace('/fuel');
  };
  const handlePromoCarwash = selected => {
    if (items?.length) {
      showToast({
        msg: Messages.invalid_key_transaction,
        duration: 3000,
        position: 'top-left',
      });
      return history.replace('/home');
    }
    history.push({
      pathname: '/fuel/freecarwash',
      state: {
        selected,
      },
    });
  };

  const handleCarWashPriceUpdate = msg => {
    try {
      if (!msg?.includes('FUEL_CARWASH_UPDATE')) return;
      const newConfig = msg?.split('FUEL_CARWASH_UPDATE')?.[1]?.trim();
      const { carwash } = JSON.parse(newConfig);
      Logger?.info(`[carwash] UPDATED PACKAGES: ${JSON.stringify(carwash)}`);
      console.log('updated packages', newConfig);
      setCarwashConfig(carwash);
    } catch (e) {
      console.log('Error parsing in CARWASH PACKAGE UPDATE', e);
    }
  };
  return {
    isCarWashEnabled,
    packages,
    onPackageSelect,
    onExit,
    handlePromoCarwash,
    clearCode,
    isCarwashInProgress,
    validateCode,
    handleCarwash,
    handleCarWashPriceUpdate,
    showToast,
  };
};
