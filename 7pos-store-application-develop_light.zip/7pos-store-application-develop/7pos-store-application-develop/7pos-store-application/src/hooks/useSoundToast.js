import { useToast } from '@chakra-ui/react';
import { useContext } from 'react';
import { AppContext } from '../AppContext';

export const useSoundToast = () => {
  const toast = useToast();
  const { errorSound, successSound } = useContext(AppContext) || global;
  const playSound = ({ status = 'error', ...config }) => {
    try {
      toast({ ...config, status });
      if (status === 'error') {
        errorSound?.play().catch(e => console.log('Sound error', e));
      } else if (status === 'success') {
        successSound?.play?.().catch(e => console.log('Sound error', e));
      }
    } catch (error) {
      Logger.error(`Display toast render issue:${JSON.stringify(error)}`);
    }
  };
  return playSound;
};
