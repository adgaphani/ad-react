import { useDispatch } from 'react-redux';
import { dailpadActions } from '../slices/dailpad.slice';

export const useKeyPad = () => {
  const dispatch = useDispatch();

  const resetKeypadValue = () => {
    dispatch(dailpadActions.resetKeypadValue());
  };

  return {
    resetKeypadValue,
  };
};
