import { useContext, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';

import { AppContext } from '../AppContext';

import { MO_FLG_INVALID, CARD_LOAD_BASE_INDEX, ITEM_TYPE } from '../constants';
import { useSoundToast } from './useSoundToast';
import { cartActions } from '../slices/cart.slice';
import { isLottery } from '../Utils/lotteryUtils';
import store from '../store';
import { usePrivileges } from './usePrivileges';
import { useSharedFuelRequest } from './useSharedFuelRequest';
import { useCarWash } from './useCarWash';
import { dailpadActions } from '../slices/dailpad.slice';
import { actionsByScreen } from '../Utils/dailpadUtils';
import {
  getItemPriceSuffix,
  getDepositTaxPrefix,
  getDiscountsTaxPrefix,
  getLineTax,
} from '../Utils/cartUtils';

export const useCartItemUtils = () => {
  const { keyPressSound } = useContext(AppContext);
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const history = useHistory();
  const { isValidUserFunction } = usePrivileges();
  const { processUnlockPumpIfNeeded } = useSharedFuelRequest();
  const { clearCode } = useCarWash();
  const displayToast = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };
  const incItemQuantity = useCallback((item, pathname) => {
    const {
      iMaxallowedItemQty: MaxallowedItemQty,
      disableFinalizePay,
      UserActionScreenActive: userActionScreenActive,
    } = store.getState()?.cart;
    if (item?.agePrefetch) return;
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (
      userActionScreenActive ||
      (pathname !== '/home' && pathname !== '/home/group')
    ) {
      return;
    }
    // #8636 Disable qty for Department sale
    if (
      item?.isMoneyOrder ||
      item?.isFuel ||
      item?.itemTypeID === ITEM_TYPE.CARD_LOAD ||
      item?.itemTypeID === ITEM_TYPE.DEPT
    ) {
      displayToast('Quantity not allowed');
      return;
    }
    if (item.quantity >= Number(MaxallowedItemQty)) {
      displayToast('Max Quantity exceeded');
      return;
    }
    const payload = {
      itemId:
        (item?.itemTypeID === ITEM_TYPE.DEPT && item?.departmentId) ||
        item.itemId,
      quantity: item.quantity + 1,
      indx: item.itemSeq,
    };
    // #1245 Credit Item Restriction handling
    const maxCreditItems = localStorage.getItem('maxCreditItems');
    if (item?.negativeSalesFlag && !isLottery(item)) {
      if (item?.quantity >= maxCreditItems) {
        displayToast(
          'INVALID ENTRY - MAX CREDIT ITEMS ALREADY EXISTS IN THE TRANSACTION'
        );
        return;
      }
    }
    if (!disableFinalizePay) dispatch(cartActions.setFinalizePayStatus(true));
    Logger?.info(`incItemQuantity Qty: ${JSON.stringify(payload)}`);
    dispatch(cartActions.updateQuantity(payload));
  }, []);
  const decItemQuantity = useCallback((item, pathname) => {
    if (item?.agePrefetch) return;
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    const {
      UserActionScreenActive,
      disableFinalizePay,
    } = store.getState()?.cart;
    if (
      UserActionScreenActive ||
      (pathname !== '/home' && pathname !== '/home/group')
    ) {
      return;
    }
    if (item.quantity <= 1) return;
    // #5503 Added function security for void Item
    const isUserHavePermission = isValidUserFunction('voiditem');
    if (!isUserHavePermission) {
      dispatch(cartActions.setFunctionSecurityData(item));
      history.push({
        pathname: '/home/functionSecurity',
        redirectionData: {
          pathname: '/home',
        },
        iFunctionName: 'voiditem',
        triggerFrom: 'voidItem',
      });
    } else {
      if (!disableFinalizePay) dispatch(cartActions.setFinalizePayStatus(true));
      const payload = {
        itemId:
          (item?.itemTypeID === ITEM_TYPE.DEPT && item?.departmentId) ||
          item.itemId,
        quantity: item.quantity - 1,
        indx: item.itemSeq,
      };
      // remove associate coupons
      if (item.couponRemainQty < 1) {
        dispatch(cartActions.removeAssociateCoupon({ item }));
      }
      dispatch(cartActions.updateQuantity(payload));
      global?.logger?.info(`decItemQuantity Qty: ${JSON.stringify(payload)}`);
    }
  }, []);

  const removeItemFromCart = useCallback(item => {
    keyPressSound?.play?.().catch(e => Logger.warn('Sound error', e));
    const { cartItems, disableFinalizePay } = store.getState()?.cart;
    if (cartItems?.length === 1) {
      const isUserHavePermission = isValidUserFunction('aborttransaction');
      if (!isUserHavePermission) {
        history.push({
          pathname: '/home/functionSecurity',
          redirectionData: {
            pathname: '/home/removelastitem',
          },
          iFunctionName: 'aborttransaction',
        });
      } else {
        history.push('/home/removelastitem');
      }
    } else {
      // #5503 Added function security for void Item
      const isUserHavePermission = isValidUserFunction('voiditem');
      if (!isUserHavePermission) {
        dispatch(cartActions.setFunctionSecurityData(item));
        history.push({
          pathname: '/home/functionSecurity',
          redirectionData: {
            pathname: '/home',
          },
          iFunctionName: 'voiditem',
          triggerFrom: 'removeItem',
        });
      } else {
        if (!disableFinalizePay)
          dispatch(cartActions.setFinalizePayStatus(true));
        const payload = {
          itemId: item.itemId,
          itemSeq: item.itemSeq,
          sttn: item?.sttn || 0,
        };
        if (item.couponRemainQty < 1) {
          dispatch(cartActions.removeAssociateCoupon({ item }));
        }
        dispatch(cartActions.removeFromCart(payload));
        global?.logger?.info(
          `removeItemFromCart Qty: ${JSON.stringify(payload)}`
        );
      }
    }
  }, []);

  const onDeleteItem = useCallback(async (item, pathname) => {
    // Added this to block voiding the items from screens except HOME
    const { cartItems, UserActionScreenActive } = store.getState()?.cart;
    const isMerchIncluded = cartItems?.findIndex(i => !i.isFuel) > -1;
    if (
      UserActionScreenActive ||
      item?.agePrefetch ||
      item?.quantity > 1 ||
      (pathname !== '/home' && pathname !== '/home/group') ||
      (item?.isMoneyOrder && item?.MoneyOrderFlag === MO_FLG_INVALID)
    ) {
      // #7764 adde MO decline item check and added toast message
      displayToast('Invalid action for this item');
      return;
    }
    try {
      if (item.isFuel && isMerchIncluded) {
        await processUnlockPumpIfNeeded();
      }
      if (item.isCarwash) {
        console.log('Clear carwash code');
        await clearCode({ cwMeta: item?.metaInfo }).catch(e => {
          Logger.error(`[Carwash] Clear Code Failed: ${e.message}`);
        });
      }
      removeItemFromCart(item);
    } catch (e) {
      Logger.error(`[Fuel] Prepay abort is failed: ${e.message}`);
      displayToast('Failed to Unlock the pump. please try again.');
    }
  }, []);
  const onRemoveCoupon = useCallback((item, couponItemseq, pathname) => {
    // Block coupon removing when abort confirmation screen and last item remove
    if (
      pathname.includes('/removelastitem') ||
      pathname.includes('/abortConfirmation')
    )
      return;
    if (item.CouponLinkDetails && item.CouponLinkDetails[0]) {
      dispatch(cartActions.removeCouponFromCart({ item, couponItemseq }));
    }
    // Update tax after remove coupon
    dispatch(cartActions.setUpdateTaxFlag(true));
  }, []);

  const openPriceOverride = useCallback(item => {
    const { UserActionScreenActive } = store.getState()?.cart;
    if (UserActionScreenActive) return;
    if (
      item.itemTypeID === ITEM_TYPE.FUEL ||
      item.itemTypeID === ITEM_TYPE.CARD_LOAD ||
      (item.itemTypeID === ITEM_TYPE.DEPT && item.isMoneyOrder)
    )
      return;
    // #4290 once coupon/promo applied should not allowed override
    if (
      !item.totalPromoDiscount &&
      !item.storeCoupon[0] &&
      !item.negativeSalesFlag // #6779 added skip price override for credit item
    ) {
      const isUserHavePermission = isValidUserFunction('priceoverride');
      if (!isUserHavePermission) {
        history.push({
          pathname: '/home/functionSecurity',
          redirectionData: {
            pathname: '/home/priceOverride',
            search: `?itemId=${item.itemId}`,
            state: { item },
          },
          iFunctionName: 'priceoverride',
        });
      } else {
        history.push({
          pathname: '/home/priceOverride',
          search: `?itemId=${item.itemId}`,
          state: { item },
        });
      }
    } else {
      // eslint-disable-next-line  no-lonely-if
      if (item?.negativeSalesFlag)
        displayToast('Price Override Not Applicable For Credit Items');
      else displayToast('Price Override Not Applicable');
    }
  }, []);

  const showCustomDailpad = useCallback(
    item => () => {
      const { UserActionScreenActive } = store.getState()?.cart;
      if (UserActionScreenActive || item?.agePrefetch) return;
      // #8636 Disable qty for Department sale
      if (
        item.isMoneyOrder ||
        item.isFuel ||
        item.itemTypeID === ITEM_TYPE.CARD_LOAD ||
        item?.itemTypeID === ITEM_TYPE.DEPT
      ) {
        displayToast('Quantity not allowed');
        return;
      }
      const payload = {
        currentAction: actionsByScreen.updateCartQuantity,
        currentActionPayload: item,
      };
      setTimeout(() => {
        dispatch(dailpadActions.toggleCustomDailPad(true));
      }, 100);
      dispatch(dailpadActions.setCurrentAction(payload));
      dispatch(
        dailpadActions.setCustomDailpadProps({
          showDollarAmounts: false,
          showSymbols: false,
        })
      );
    },
    []
  );

  const onCartItemClick = useCallback((item, itemsuffix, pathname) => {
    if (pathname.includes('coupons')) {
      // #4824 added few more filter for coupon.
      if (
        item?.itemTypeID === ITEM_TYPE.DEPT ||
        item?.itemTypeID === ITEM_TYPE.CARD_LOAD ||
        item?.itemTypeID === ITEM_TYPE.FUEL ||
        item?.isFuel ||
        item?.isCarwash
      )
        return;
      dispatch(cartActions.setSelectedItem(item));
    } else if (pathname.includes('TaxExempt')) {
      if (itemsuffix.includes('T') || itemsuffix.includes('B')) {
        dispatch(cartActions.setSelectedTaxExemptItems(item));
      }
    } else {
      openPriceOverride(item);
    }
  }, []);

  const getTaxIndicator = useCallback((data, item) => {
    const { taxInfo: taxData } = store.getState()?.cart;
    let itemsuffix = '';
    if (data?.type === 'BOTTLE_DEPOSIT') {
      itemsuffix = getDepositTaxPrefix({
        item: data,
        taxData,
        primaryItem: item,
      });
    } else {
      itemsuffix = getItemPriceSuffix({ item: data, taxData });
    }
    return itemsuffix;
  }, []);

  const getItemSuffix = useCallback(item => {
    const { taxInfo: taxData } = store.getState()?.cart;
    return getItemPriceSuffix({ item, taxData });
  }, []);
  const getDiscountTaxPrefix = useCallback((item, data) => {
    const { taxInfo: taxData } = store.getState()?.cart;
    return getDiscountsTaxPrefix({
      item,
      taxData,
      discountDetails: data,
    });
  }, []);
  const getCardLoadPrefix = useCallback(item => {
    const { taxInfo: taxData } = store.getState()?.cart;
    let cardLoadfeePrefix = '';
    if (item?.feeDetails?.retailPrice) {
      const lineNumber = Number(
        parseFloat(
          `${item.tranItemSeqNumber * CARD_LOAD_BASE_INDEX +
            item.tranItemSeqNumber}`
        )
      );
      const cardTax = getLineTax(item.feeDetails, taxData, lineNumber);
      if (Math.abs(cardTax) > 0) {
        cardLoadfeePrefix = 'T';
      }
    }
    return cardLoadfeePrefix;
  }, []);

  return {
    incItemQuantity,
    decItemQuantity,
    onDeleteItem,
    openPriceOverride,
    onRemoveCoupon,
    showCustomDailpad,
    getTaxIndicator,
    onCartItemClick,
    getItemSuffix,
    getDiscountTaxPrefix,
    getCardLoadPrefix,
  };
};
