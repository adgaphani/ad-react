import { useContext, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import PromiseTimeoutUtil from 'promise-timeout';
import { socketStatus } from '../constants';

import { AppContext } from '../AppContext';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';
import { WSPayloadUtil } from '../Utils';

const sample = {
  messageHeader: {
    source: {
      version: '01.01',
      sourceType: 'pump',
      sourceIdentifier: 1,
    },
    timeStamp: '2022-05-04',
    destination: {
      version: '01.01',
      destinationType: 'pos',
      destinationIdentifier: 1,
    },
    messageType: 'transaction',
  },
  messageDetails: {
    status: 1,
    carwashCode: '0',
    cmd: 85,
    requestType: 1,
    expirationDate: '20220513',
    carwashPackageId: 1,
  },
};
export const useWSocket = () => {
  const [ws] = useContext(WebSocketContext);
  const appContextActions = useContext(AppContext);
  const socketRef = useRef();
  const { status } = useSelector(state => ({
    status: state.socket.status,
  }));

  useEffect(() => {
    if (!ws) return;
    socketRef.current = ws;
  }, [ws]);

  const getActiveSocket = () => {
    const socket = ws?.socket;
    if (socket && socket.connected) {
      return socket;
    }
    return undefined;
  };

  const getActiveSocketRef = () => socketRef?.current?.socket;
  const stopListeningToSocketResponse = subId => {
    const subscriptions = Object.keys(ws?.socket?.subscriptions || {}) || [];
    if (subscriptions.includes(subId)) {
      ws?.socket?.unsubscribe(subId);
    }
  };
  const processRequest = (sendTo, body) => {
    const socket = getActiveSocket();
    if (!socket) return;
    // const { includePump = true, clearSelections = false } = options;
    // Logger.info(`[Fuel] Request : ${fuelRequestPayload}`);
    socket?.send(sendTo, {}, body);
  };
  const processRequestAsPromise = async ({
    subscribeTo,
    isResValid = () => true,
    sendTo,
    isDummy = false,
    socketPayload,
    onComplete = () => {},
    subId,
    showLoader = true,
    timer = 15000,
  }) => {
    console.log('SOCKET PAYLOAD *********', socketPayload);
    console.log('SUBSCRIPTIONS', ws.socket?.subscriptions);
    if (isDummy) return sample;
    showLoader && appContextActions?.startLoading?.();
    const handleSocketRes = (result, resolve, reject) => {
      const transformedResponse = WSPayloadUtil.getPayload(result);
      console.log('response transformed_____________', transformedResponse);
      if (isResValid(transformedResponse?.messageDetails)) {
        return resolve(transformedResponse);
      }
      reject?.(new Error(result));
    };
    const handleSocketReq = (resolve, reject) => {
      if (!ws?.socket) {
        return reject(new Error(Messages.connection_error));
      }
      // Unsubscribe
      // stopListeningToTopic();
      // Subscribe
      stopListeningToSocketResponse(subId);
      ws?.socket.subscribe(
        subscribeTo,
        event => handleSocketRes(event, resolve, reject),
        {
          id: subId,
        }
      );
      processRequest(sendTo, socketPayload);
    };
    return PromiseTimeoutUtil.timeout(new Promise(handleSocketReq), timer)
      .catch(e => {
        const isTimeout = e instanceof PromiseTimeoutUtil.TimeoutError;
        throw isTimeout ? new Error(Messages.request_timeout) : e;
      })
      .finally(() => {
        onComplete?.();
        showLoader && appContextActions?.stopLoading?.();
        stopListeningToSocketResponse(subId);
      });
  };
  return {
    isConnected: status === socketStatus.connected,
    isDisconnected: status === socketStatus.disconnected,
    isSocketError: status === socketStatus.error,
    socketStatus: status,
    socket: ws?.socket,
    processRequestAsPromise,
    getActiveSocket,
    stopListeningToSocketResponse,
    getActiveSocketRef,
    ws,
  };
};
