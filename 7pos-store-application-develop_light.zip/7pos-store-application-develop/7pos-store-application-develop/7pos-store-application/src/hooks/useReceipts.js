import { useSelector } from 'react-redux';
import {
  createSafeFooter,
  createSafeHeaderLines,
  getReceiptHeader,
} from '../Utils/receiptUtil';
import { fetchEmailReceipt } from '../api/payment';
import { safeDrop } from '../constants';
import { currencyFixed } from '../Utils/appUtils';

export const useReciepts = () => {
  const {
    storeDetails,
    config,
    safeDropType,
    isVault,
    deviceInfo,
    user,
    transactionId,
    isInsertBills,
    channel,
    paymentTransactionId,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
    config: state.main.configuration,
    safeDropType: state.cart.safeDropType,
    safeDropResponse: state.cart.safeDropResponse,
    isVault: state.cart?.safeDropType === 'vaultDrop',
    vaultUserEntries: state.cart.vaultUserEntries,
    deviceInfo: state.main.deviceInfo,
    transactionId: state.cart.transactionId,
    isInsertBills: state.cart?.safeDropType === 'insertBills',
    channel: state.main.channel,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));

  const getLineItems = (vaultRes, safeDropResponse) => {
    const lineItems = Array(2)
      .fill()
      .map((i, idx) => ({
        description: idx ? 'TOTAL' : 'CASH',
        details:
          storeDetails?.currencyCode === 'CAD' && isInsertBills
            ? currencyFixed(safeDropResponse?.[1]?.amount / 100) ||
              parseFloat(0).toFixed(2)
            : currencyFixed(safeDropResponse?.[0]?.amount / 100) ||
              parseFloat(0).toFixed(2),
        ...(isVault
          ? {
              details:
                currencyFixed(vaultRes?.amount / 100) ||
                parseFloat(0).toFixed(2),
            }
          : {}),
      }));
    if (!isVault) {
      return lineItems;
    }
    const envlpLine = {
      description: 'ENVELOPE ID',
      details: vaultRes.envelop,
    };
    return [...lineItems, envlpLine];
  };

  const generatePayload = ({
    header,
    to = '',
    receiptType,
    vaultUserEntries,
    safeDropResponse,
    isAbort,
  }) => {
    const receiptHeader = header || getReceiptHeader(storeDetails, config);
    return {
      to,
      subject: 'email subject',
      receiptType,
      header: {
        headerLines: createSafeHeaderLines(
          receiptHeader.headerLines,
          isAbort,
          safeDrop[safeDropType]?.uLabel
        ),
      },
      footer: {
        footer: createSafeFooter(deviceInfo, user, transactionId),
      },
      lineItem: {
        items: getLineItems(vaultUserEntries, safeDropResponse),
      },
    };
  };

  const print = config => {
    const { paymentTransactionId } = config;
    const payload = generatePayload({
      ...config,
      to: '',
      receiptType: 'PRINT',
    });
    fetchEmailReceipt(payload, paymentTransactionId, channel).catch(() => {
      console.log('PRINT RECEIPT FAILED, CALLER : SAFE');
    });
  };
  const email = config => {
    const payload = generatePayload({
      ...config,
      to: 's1975046@7-11.com',
      receiptType: 'EMAIL',
    });
    fetchEmailReceipt(payload, paymentTransactionId, channel).catch(() => {
      console.log('PRINT RECEIPT FAILED, CALLER : SAFE');
    });
  };
  return {
    print,
    email,
  };
};
