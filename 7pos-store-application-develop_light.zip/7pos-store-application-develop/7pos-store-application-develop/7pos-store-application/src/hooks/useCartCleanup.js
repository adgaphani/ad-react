import { useSelector, useDispatch } from 'react-redux';
import { cartActions } from '../slices/cart.slice';
import { cfdActions } from '../slices/cfd.slice';
import { socketActions } from '../slices/socket.slice';
import { buildCartChangeTrial } from '../Utils/cartUtils';
import { useSoundToast } from './useSoundToast';
import { usePromoWrapper, usePromoUtils } from '.';
import { useEBTBagFee } from './useEBTBagFee';

export const useCartCleanup = () => {
  const {
    cartItems,
    basketPromo,
    cartChangeTrial,
    runningTotal,
    ebtBagFeeitems,
  } = useSelector(state => ({
    cartItems: state.cart.cartItems,
    basketPromo: state.cart.basketPromo,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    ebtBagFeeitems: state.cart.ebtBagFeeitems,
  }));
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const { cancelSWPInTransaction } = usePromoWrapper();
  const { AddOrRemovalEBTBagFeeItem } = useEBTBagFee();
  const { cancelFuelRewardInTransaction } = usePromoUtils();

  const creditTaxOverrideCleanup = () => {
    // removing auto tax override during payment
    let isTaxAppliedForCreditItem = false;
    const creditItems = cartItems.filter(
      item => item?.negativeSalesFlag && item?.isAutoTaxOverride
    );
    creditItems?.map(item => {
      isTaxAppliedForCreditItem = true;
      dispatch(cartActions.setSelectedTaxExemptItems(item));
      return item;
    });
    if (isTaxAppliedForCreditItem) {
      dispatch(cartActions.taxExemptConfirm({ isAutoTaxOverride: true }));
    }
  };

  const cleanUpTransactionItems = async () => {
    Logger?.debug(`[7POS UI] - Cleanup triggerred. `);
    dispatch(cartActions.setPinpadProcessMsg(''));
    dispatch(cartActions.setTaxBeforeEBTExempt(0));
    dispatch(cartActions.setTaxDeductionAmount(0));
    dispatch(cartActions.setTaxableBeforeEBTExempt(0));
    localStorage.removeItem('taxInfoBeforeEBT');
    localStorage.removeItem('finalTaxCallTriggered');
    // #7795 no need remove taxInfoRequest during idle/logoff data will update always tax call triggered.
    // localStorage.removeItem('taxInfoRequest');
    dispatch(cartActions.setEBTPaymentIntiateStatus(false));
    dispatch(cartActions.setCardLoadReset());
    dispatch(socketActions.setCashDrawerStatus(null));
    dispatch(cfdActions.setTransactionFinalize(false));
    dispatch(socketActions.setCashBack(null));
    dispatch(cartActions.setPaymentTriggerStatus(false));
    dispatch(cartActions.setIsMediaAbortTriggered(false));
    dispatch(cartActions.setFinalizeClick(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    localStorage.removeItem('isMemberTrigger');
    localStorage.removeItem('isMemberPromoTrigger');
    // removing round up charity item
    // eslint-disable-next-line array-callback-return
    cartItems?.map(item => {
      if (item.isRoundUpCharityItem) {
        dispatch(
          cartActions.removeFromCart({
            itemId: item.itemId,
            itemSeq: item.itemSeq,
          })
        );
        toast({
          description: 'RoundUp charity item removed',
          status: 'success',
          duration: 3000,
          position: 'top-left',
        });
      }
    });

    let promodiscount = 0;
    if (basketPromo?.length > 0) {
      promodiscount = Number(basketPromo[0].item_discount);
      if (promodiscount > 0) {
        const irunningTotal =
          runningTotal + Number(Math.abs(basketPromo[0].item_discount));
        const CartTrialPayLoad = buildCartChangeTrial({
          item: {
            name: basketPromo[0].name,
            upc: basketPromo[0].upc,
            itemId: basketPromo[0].slin,
            tranItemSeqNumber: basketPromo[0].tranItemSeqNumber,
          },
          overridedPrice: basketPromo[0].item_discount,
          eventType: 'voidLineItem',
          eventSeq: cartChangeTrial.length,
          runningTotal: irunningTotal,
        });
        dispatch(
          cartActions.addToCartChangeTrial({
            CartTrialPayLoad,
            Amount: basketPromo[0].item_discount,
          })
        );
        dispatch(cartActions.setBasketPromo([]));
        await cancelSWPInTransaction();
      }
    }
    // Add back EBT Bag fee items when payment redirect to home screen
    if (ebtBagFeeitems && ebtBagFeeitems[0]) {
      const isEBTBagFeeUpAdded =
        AddOrRemovalEBTBagFeeItem({
          iRemoveIntiate: false,
          isEBTBagFeeRemoved: true,
          isSkipPaymentCheck: true,
        }) || false;
      if (isEBTBagFeeUpAdded)
        toast({
          description: 'Bag fee added',
          status: 'success',
          duration: 3000,
          position: 'top-left',
        });
    }

    await cancelFuelRewardInTransaction('dispenserCanceled'); // SCALE-1567 - cancel/abort scenario
  };
  return {
    cleanUpTransactionItems,
    creditTaxOverrideCleanup,
  };
};
