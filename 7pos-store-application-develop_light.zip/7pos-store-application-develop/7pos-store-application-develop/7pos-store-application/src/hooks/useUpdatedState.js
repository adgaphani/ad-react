import { useStore } from 'react-redux';

export const useUpdatedState = () => {
  const store = useStore();
  return (s = store) => {
    const state = s.getState();
    if (!state) {
      return {};
    }
    return {
      ...state,
      isVault: state.cart?.safeDropType === 'vaultDrop',
      isValutDropCompleteSent: state.cart?.isVaultDropCompleteSent,
      vaultDropEntries: state.cart?.vaultUserEntries,
      safeDropType: state.cart?.safeDropType,
      isPIPOCashDrwrOpen: state.peripheral?.isPIPOCashDrwrOpen,
    };
  };
};
