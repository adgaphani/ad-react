import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { useContext } from 'react';
import { cartActions } from '../slices/cart.slice';
import { useSoundToast } from './useSoundToast';
import { AppContext } from '../AppContext';
import { useSyncService } from './useSyncService';
import { ITEM_TYPE } from '../constants';

export const useTransHold = () => {
  const dispatch = useDispatch();
  const { transHoldTimer } = useContext(AppContext);
  const { sendTransHoldReq } = useSyncService();
  const history = useHistory();
  const {
    isTransHold,
    items,
    itemsInMemory,
    isActive,
    disableTransHoldFP,
    UserActionScreenActive,
    allPayments,
    config,
    storeDetails,
    deviceInfo,
    user,
  } = useSelector(state => ({
    items: state.cart.items,
    isTransHold: state.cart.isTransHold,
    transactionId: state.cart.transactionId,
    itemsInMemory: state.cart.transactionMemory?.items,
    isActive: state.balance.isActive,
    disableTransHoldFP: state.cart.disableTransHoldFP,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    allPayments: state.cart.allPayments,
    config: state.main.configuration,
    storeDetails: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    user: state.auth.user,
  }));
  const toast = useSoundToast();

  const handleEOD = () => {
    toast({
      description: 'End of shift/day requested - Clear memory',
      status: 'error',
      duration: 5000,
      position: 'top-left',
    });
  };
  const clearTransHoldCart = () => {
    if (transHoldTimer.current) {
      clearTimeout(transHoldTimer.current);
      transHoldTimer.current = null;
      dispatch(cartActions.emptyCartForTransHold());
    }
  };
  const handleTranHold = location => {
    let msg = '';
    let status = 'success';
    const isCardLoadItem =
      items?.filter(item => item.itemTypeID === ITEM_TYPE.CARD_LOAD) || false;
    if (!items?.length && !itemsInMemory?.length && !isTransHold) {
      msg = 'Nothing to Store/Recall';
      status = 'error';
    } else if (
      disableTransHoldFP ||
      UserActionScreenActive ||
      (allPayments && allPayments?.length > 0)
    ) {
      if (allPayments && allPayments?.length > 0)
        toast({
          description:
            'Transaction Hold Not Available when media has been tendered. Please complete the transaction.',
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      return;
    } else if (
      (isTransHold && itemsInMemory.length && items.length) ||
      isActive ||
      location.pathname.indexOf('/home') < 0 ||
      isCardLoadItem[0] ||
      location.pathname.includes('payment')
    ) {
      msg = isCardLoadItem[0]
        ? 'TRANS HOLD NOT ALLOWED FOR CARD LOADS'
        : 'Please Complete transaction first';
      status = 'error';
    } else if (isTransHold && itemsInMemory.length) {
      // Release
      msg = `Transaction Hold Off`;
      setTimeout(() => {
        dispatch(
          cartActions.setTransRelease({
            config,
            storeDetails,
            terminalNumber: deviceInfo?.id,
            operator: user?.userId?.toString() || '',
            user,
          })
        );
        sendTransHoldReq(true);
      }, 0);
      transHoldTimer.current = null;
    } else if (!isTransHold && items.length) {
      // HOLD
      dispatch(cartActions.setTransHold(true));
      // Disable FINALIZE AND PAY FOR 3000 MS
      dispatch(cartActions.setdisableTransHoldFP(true));
      clearTimeout(transHoldTimer.current);
      transHoldTimer.current = setTimeout(() => {
        dispatch(cartActions.emptyCartForTransHold());
        transHoldTimer.current = null;
        sendTransHoldReq(false);
        dispatch(cartActions.setdisableTransHoldFP(false));
        if (window.location.pathname === '/') return; // Handling Timing issue with parallel logout
        history.push('/home');
      }, 3000);
      msg = 'Transaction Hold On';
    }
    if (msg) {
      toast({
        description: msg,
        status,
        duration: 3000,
        position: 'top-left',
      });
    }
  };
  return {
    handleEOD,
    handleTranHold,
    clearTransHoldCart,
  };
};
