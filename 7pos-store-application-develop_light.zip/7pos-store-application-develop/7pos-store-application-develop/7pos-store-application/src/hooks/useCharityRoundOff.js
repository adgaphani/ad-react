import { v1 as uuidv1 } from 'uuid';
import { useSelector, useDispatch } from 'react-redux';
import { cfdActions } from '../slices/cfd.slice';
import { cartActions } from '../slices/cart.slice';
import { setShowNotifications } from '../slices/notifications.slice';
import { SendMessageToCFD } from '../Communication';
import { fetchDepartmentInfo } from '../api/app/fetchDepartmentInfo';
import { ITEM_TYPE } from '../constants';

export const useCharityRoundOff = () => {
  const {
    items,
    config,
    isTransactionRefund,
    isTransactionVoid,
    isRoundOffDept,
    allPayments,
    mediaAbortedPaymentList,
    tranItemSeqNumber,
    processPaymentAsMCLoyalty,
  } = useSelector(state => ({
    items: state.cart.items,
    config: state.main.configuration,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
    isRoundOffDept: state.cart.isRoundOffDept,
    allPayments: state.cart.allPayments,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
  }));
  const dispatch = useDispatch();

  const isRoundOffCharityApplicable = ({
    ienteredCash = 0,
    paymentMedia,
    finalTotalPrice,
  }) => {
    if (processPaymentAsMCLoyalty) {
      return { isRoundUpRequired: false, iCharityAmt: 0 };
    }
    const isRoundUpEnabled =
      config?.storeConfig?.isRoundUpCharityEnabled || false;
    let iActiveRoundOffConfig = null;
    if (config?.roundupcharityConfig) {
      iActiveRoundOffConfig = config?.roundupcharityConfig.filter(
        item => item.isActive === true
      );
    }
    if (
      (paymentMedia !== 'CASH' ||
        (paymentMedia === 'CASH' &&
          ienteredCash > 0 &&
          finalTotalPrice !== ienteredCash)) &&
      !isTransactionRefund &&
      !isTransactionVoid &&
      isRoundUpEnabled &&
      finalTotalPrice > 0 &&
      iActiveRoundOffConfig &&
      iActiveRoundOffConfig[0] &&
      iActiveRoundOffConfig[0]?.imageUrl &&
      Number(iActiveRoundOffConfig[0]?.productCategoryId) > 0 &&
      isRoundOffDept &&
      isRoundOffDept !== null
    ) {
      const iVerifyCharityAmt = Number(finalTotalPrice * 100);
      let iRoundOffCharityAmt = 0;
      if (iVerifyCharityAmt > 0 && iVerifyCharityAmt > 100) {
        iRoundOffCharityAmt = iVerifyCharityAmt % 100;
        if (iRoundOffCharityAmt)
          iRoundOffCharityAmt = 100 - iRoundOffCharityAmt;
      } else if (iVerifyCharityAmt > 0 && iVerifyCharityAmt < 100) {
        iRoundOffCharityAmt = 100 - iVerifyCharityAmt;
      }
      // #5953 Cross check given amount is lessthan next round off dollar amount
      if (
        iRoundOffCharityAmt > 0 &&
        Number(finalTotalPrice) < Number(ienteredCash) &&
        Number(iRoundOffCharityAmt) / 100 + finalTotalPrice >
          Number(ienteredCash)
      ) {
        iRoundOffCharityAmt =
          parseFloat(Number(ienteredCash) - Number(finalTotalPrice)).toFixed(
            2
          ) * 100;
      }

      if (iRoundOffCharityAmt > 0) {
        const maxallowedItemPrice =
          config?.storeConfig?.maxAllowedItemPrice !== undefined
            ? Number(config?.storeConfig?.maxAllowedItemPrice)
            : 0;
        if (
          isRoundOffDept?.lowAmountLockout &&
          isRoundOffDept?.lowAmountLockout > 0 &&
          Number(iRoundOffCharityAmt / 100) < isRoundOffDept?.lowAmountLockout
        ) {
          Logger?.error(
            `[7POS UI] - Charity Amount Too Small $${isRoundOffDept.lowAmountLockout}`
          );
        } else if (
          (isRoundOffDept?.highAmountLockout &&
            isRoundOffDept?.highAmountLockout > 0 &&
            Number(iRoundOffCharityAmt / 100) / 100 >
              isRoundOffDept.highAmountLockout) ||
          Number(iRoundOffCharityAmt / 100) / 100 > 999999 ||
          (maxallowedItemPrice !== 0 &&
            Number(iRoundOffCharityAmt / 100) / 100 > maxallowedItemPrice)
        ) {
          Logger?.error(
            `[7POS UI] - Charity Amount Too Big $${isRoundOffDept.highAmountLockout}`
          );
        } else {
          dispatch(cfdActions.setUserActionScreenActive(true));
          dispatch(setShowNotifications(false));
          const iTransactionMessage = {
            CMD: 'RoundUpTrigger',
            ImageURL: iActiveRoundOffConfig[0]?.imageUrl,
            Amount: iRoundOffCharityAmt,
          };
          SendMessageToCFD(iTransactionMessage);
          return { isRoundUpRequired: true, iRoundOffCharityAmt };
        }
      }
    }
    return { isRoundUpRequired: false, iCharityAmt: 0 };
  };

  const getRoundOffCharityItem = async () => {
    try {
      const isRoundUpEnabled =
        config?.storeConfig?.isRoundUpCharityEnabled || false;
      if (config?.roundupcharityConfig && isRoundUpEnabled) {
        const iActiveRoundOffConfig = config?.roundupcharityConfig.filter(
          item => item.isActive === true
        );
        const iproductCategoryId = iActiveRoundOffConfig[0].productCategoryId;
        let deptResponse = await fetchDepartmentInfo(
          Number(iproductCategoryId)
        );
        deptResponse = JSON.parse(deptResponse.data.data);
        deptResponse = deptResponse.length > 0 ? deptResponse[0] : {};
        if (deptResponse) {
          const cartItemObj = {
            familyId: iproductCategoryId,
            isRoundUpCharityItem: true,
            itemTypeID: ITEM_TYPE.DEPT,
            productCategoryId: iproductCategoryId,
            name: deptResponse.description,
            retailPrice: parseFloat(0.01).toFixed(2) / 100,
            quantity: 1,
            category_id: iproductCategoryId,
            departmentId: iproductCategoryId,
            category: { id: iproductCategoryId },
            connexxusCode: deptResponse.connexxusCode || null,
            PSAGroupInfo: deptResponse.psaGroup,
            isFoodStampAllowed: deptResponse.foodStampAllowed === 'Y' ? 1 : 0,
            updatedAt: Date.now(),
            negativeSalesFlag:
              deptResponse.negativeSalesFlag === 'Y' ||
              deptResponse.negativeSalesFlag === true ||
              false,
            manufacturerCouponAllowed: deptResponse.manufacturerCouponAllowed,
            otherCouponAllowed: deptResponse.otherCouponAllowed,
            storeCouponAllowed: deptResponse.storeCouponAllowed,
            itemTaxes: {
              exciseTaxAmount: null,
              isItemLevelTaxOverride: false,
              taxId: deptResponse.taxId,
            },
            arbitration: [],
            itemRestrictionCode: deptResponse.itemRestrictionCode,
            requiredAge: deptResponse.requiredAge,
            storeCoupon: [],
            mif: iActiveRoundOffConfig[0]?.id,
            itemSeq: uuidv1(), // dont have item ID so make one unique identifier
            lowAmountLockout: deptResponse?.lowAmountLockout,
            highAmountLockout: deptResponse?.highAmountLockout,
            restrictedMediaTypes: deptResponse?.restrictedMediaTypes,
          };
          dispatch(cartActions.setisRoundOffDept(cartItemObj));
        }
      }
    } catch (error) {
      Logger?.error(
        `[7POS UI] - fetchDepartmentInfo details Error ${JSON.stringify(error)}`
      );
    }
  };

  const AddOrRemovalRoundOffCharity = ({
    iRemoveIntiate = true,
    isRoundUpRemoved,
  }) => {
    if (iRemoveIntiate && !isRoundUpRemoved) {
      let iRoundUpRemoved = false;
      items.map(item => {
        if (item.isRoundUpCharityItem) {
          iRoundUpRemoved = true;
          dispatch(
            cartActions.removeFromCart({
              itemId: item.itemId,
              itemSeq: item.itemSeq,
            })
          );
          Logger?.info(`[7POS UI] - Round of Charity item removed.`);
        }
        return item;
      });
      return iRoundUpRemoved;
      // eslint-disable-next-line no-else-return
    } else if (isRoundUpRemoved && isRoundOffDept !== null) {
      let isEbtSnapPresent = false;
      let isMediaAbort = [];
      let iRoundUpAdded = false;
      allPayments
        ?.filter(
          pml =>
            pml?.paymentMediaType === 'EBTSNAP' ||
            pml?.paymentMediaType === 'EBTCB'
        )
        ?.map(pml => {
          if (mediaAbortedPaymentList[0]) {
            isMediaAbort = mediaAbortedPaymentList?.filter(
              payment =>
                payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
            );
            if (!isMediaAbort[0]) {
              isEbtSnapPresent = true;
            }
          } else {
            isEbtSnapPresent = true;
          }
          return pml;
        });
      if (!isEbtSnapPresent) {
        iRoundUpAdded = true;
        dispatch(cartActions.addToCart(isRoundOffDept));
        dispatch(
          cartActions.addCartItems([
            {
              ...isRoundOffDept,
              retailPrice: isRoundOffDept.retailPrice * 100,
              tranItemSeqNumber: tranItemSeqNumber + 1,
            },
            ...items,
          ])
        );
        Logger?.info(`[7POS UI] - Round of Charity item added.`);
      }
      return iRoundUpAdded;
    }
  };

  return {
    AddOrRemovalRoundOffCharity,
    getRoundOffCharityItem,
    isRoundOffCharityApplicable,
  };
};
