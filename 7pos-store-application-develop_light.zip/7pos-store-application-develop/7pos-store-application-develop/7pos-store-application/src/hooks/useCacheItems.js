import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCachedItems } from '../api/app/fetchCachedItems';
import { mainActions } from '../slices/main.slice';

export const useCacheItems = () => {
  const dispatch = useDispatch();

  const {
    paymentTransactionId,
    ProductLookUpSynEvent,
    cachedItems,
  } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    ProductLookUpSynEvent: state.cart.ProductLookUpSynEvent,
    cachedItems: state?.main?.cachedItems,
  }));

  const retrieveCachedItems = async () => {
    // added null check for cachedItems
    if (!cachedItems || ProductLookUpSynEvent) {
      const isCachedItemsEmpty = Object.keys(cachedItems)?.length === 0;
      if (ProductLookUpSynEvent || isCachedItemsEmpty) {
        const response = await fetchCachedItems({
          correlationID: paymentTransactionId,
        });
        dispatch(mainActions.setCachedItems(response));
      }
    }
  };

  // When the event for changed UPC's trigger then call the API again.
  useEffect(() => {
    retrieveCachedItems();
  }, [ProductLookUpSynEvent]);
};
