/* eslint-disable */
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { useEffect, useRef } from 'react';
import { FuelUtils } from '../Utils';
import { fuelActions } from '../slices/fuel.slice';
import { notificationsActions } from '../slices/notifications.slice';
import { useCart } from './useCart';
import { useTransDetails } from './useTransDetails';
import { cartActions } from '../slices/cart.slice';

export const useFuel = () => {
  const dispatch = useDispatch();
  const {
    isFuelTransactionInProgress,
    getCartMetrics,
    getFullTransactionId,
    paymentDetails,
    taxInfo,
  } = useCart();
  const {
    selectedPump,
    currentPumpConfig,
    fuelPumps,
    fuelPrices,
    currentAction,
    isIntegratedFuelStore,
    isFuelIntegrated,
    isFuelEnabled,
    isFuelIncluded,
    items,
    fuelParams,
    isDEXOnline,
    isAuthConfirmInProgress = false,
    crindDenialsReason,
    isGradeSelectionOn,
    selectedGrade,
    dexComFormat,
    loyalty,
    isSpeedyStore,
    fuelPrepaidAmount,
    openAllResponse,
    closeAllResponse,
  } = useSelector(state => {
    const {
      fuelPumps,
      selectedPump,
      fuelPrices,
      fisAction,
      fuelParams,
      isDEXOnline = false,
      crindDenialsReason,
      isGradeSelectionOn,
      openAllResponse,
      closeAllResponse,
    } = state.fuel;
    const { configuration, isSpeedyStore } = state.main;
    const { items, selectedGrade, loyalty } = state.cart;
    return {
      selectedPump,
      currentPumpConfig: FuelUtils.getSelectedPumpConfig(
        fuelPumps,
        selectedPump
      ),
      fuelPumps,
      fuelPrices,
      dexComFormat: configuration?.gas?.dexComFormat,
      currentAction: fisAction,
      isIntegratedFuelStore: FuelUtils.isIntegratedFuelStore(configuration),
      isFuelIntegrated: FuelUtils.isIntegrated(configuration),
      isFuelEnabled: FuelUtils.isFuelStore(configuration),
      dexComFormat: configuration?.gas?.dexComFormat,
      isAuthConfirmInProgress: FuelUtils.checkIfAuthConfirmInProgress(
        fuelPumps
      ),
      items,
      fuelParams,
      isDEXOnline,
      crindDenialsReason,
      isGradeSelectionOn,
      selectedGrade,
      loyalty,
      isSpeedyStore,
      fuelPrepaidAmount: items?.find(item => item.isFuel)?.totalRetailPrice,
      openAllResponse,
      closeAllResponse,
    };
  }, shallowEqual);
  const transDetails = useTransDetails();
  const fuelPumpsRef = useRef(fuelPumps || []);
  useEffect(() => {
    fuelPumpsRef.current = fuelPumps;
  }, [fuelPumps]);

  const deselectPump = () => {
    if (!selectedPump) {
      return;
    }
    // Logger.info(`[Fuel] Deselect Pump --->  ${selectedPump}`);
    dispatch(fuelActions.selectPump(undefined));
  };

  const selectPump = pump => {
    if (pump?.pumpNumber === selectedPump) {
      return deselectPump();
    }
    // Logger.info(`[Fuel] Select Pump: ${pump?.pumpNumber}`);
    dispatch(fuelActions.selectPump(pump));
  };

  const selectAction = action => {
    // Logger.info(`[Fuel] Select Action: ${JSON.stringify(action)}`);
    dispatch(fuelActions.selectPumpAction(action));
  };

  const deselectAction = () => {
    // Logger.info(`[Fuel] Deselect Action`);
    dispatch(fuelActions.selectPumpAction(undefined));
  };

  const setCrindDenialReason = msg => {
    dispatch(fuelActions.setCrindDenialsReason(msg));
  };

  const setGradeSelection = isOn => {
    dispatch(fuelActions.setGradeSelection(isOn));
  };

  const setSelectedGrade = grade => {
    dispatch(cartActions.setSelectedGrade(grade));
  };
  const setFuelCalculatedDiscounts = discounts => {
    dispatch(cartActions.setFuelCalculatedDiscounts(discounts));
  };

  const saveFuelNotification = ({ isGlobal, ...payload }) => {
    let expiry = 3000;
    const fuelMsg = {
      isFuel: true,
      isGlobal,
      ...payload,
      expiry: 3000,
    };
    if (isGlobal) {
      expiry = 1000 * 60;
    }
    dispatch(notificationsActions.setNotifications({ ...fuelMsg, expiry }));
  };

  const getPumpConfig = pumpNumber =>
    FuelUtils.getSelectedPumpConfig(fuelPumpsRef.current, pumpNumber);

  const getPumpRefunds = (pumpNumber = selectedPump) =>
    FuelUtils.getRefundsToBeFinalized(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpIsInUse = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpIsInUse(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpIsLocked = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpIsLocked(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpCanBeStopped = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpCanBeStopped(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpCanBeRestarted = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpCanBeRestarted(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpIsClosed = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpIsClosed(fuelPumpsRef.current, pumpNumber);

  const checkIfAuthInProgress = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfAuthInProgress(fuelPumpsRef.current, pumpNumber);

  const checkifAuthIsAllowed = (pumpNumber = selectedPump) =>
    FuelUtils.checkifAuthIsAllowed(fuelPumpsRef.current, pumpNumber);

  const checkIfPumpIsAvailable = (pumpNumber = selectedPump) =>
    FuelUtils.checkIfPumpIsAvailable(fuelPumpsRef.current, pumpNumber);

  const getSelectedPumpFuelState = (pumpNumber = selectedPump) =>
    FuelUtils.getSelectedPumpFuelState(fuelPumpsRef.current, pumpNumber);

  const toFixedDigits = (n, digits = 2) =>
    parseFloat((n / 10 ** digits).toString()).toFixed(digits);

  const getPriceWithProductNumber = productNumber => {
    const fuelPrice = fuelPrices.find(
      ({ productNumber: fProductNumber }) => fProductNumber === productNumber
    );
    if (!fuelPrice) {
      Logger.info(
        `[Fuel] ProductNumber: ${productNumber}, Prices: ${JSON.stringify(
          fuelPrices
        )}`
      );
    }
    return fuelPrice;
  };

  const getMultiPumpMsgs = pumpConfig => FuelUtils.getMultiPumpMsgs(pumpConfig);

  const getPumpRedbarMsg = config => FuelUtils.getPumpRedBarMsg(config);

  const getFuelReceiptAttts = () => {
    const { transactionType, originalTransactionSequenceId } =
      items?.find(i => i.isFuel)?.metaInfo || {};
    const { transactionTotal: tTotal } = getCartMetrics() || {};
    return {
      ...(isFuelTransactionInProgress
        ? {
            fileMeta: {
              ...(tTotal
                ? {
                    saleAmount: toFixedDigits(tTotal, 2),
                  }
                : {}),
              origTranSeqNumber: originalTransactionSequenceId,
              discountsAmount: transDetails.totalPromotionPrice,
              paymentMediaType:
                paymentDetails?.paymentMedia?.paymentMediaType ?? 'CASH',
              cardName:
                paymentDetails?.paymentMedia?.receiptDetails?.cardName ??
                'CASH',
              transactionType,
              transactionNumber: getFullTransactionId(),
              saleTaxAmount: taxInfo?.totalTaxAmount
                ? parseFloat(taxInfo?.totalTaxAmount)?.toFixed(2)
                : '0.00',
              fuelItems: items
                ?.filter(i => i.isFuel)
                .map(i => ({
                  dispenserNumber: i.metaInfo?.fuelDispenserId,
                  totalFuelPrice: toFixedDigits(i.metaInfo?.fuelAmount * 100),
                })),
            },
          }
        : {}),
    };
  };

  const getInactivePumpsCount = () =>
    FuelUtils.getInactivePumpsCount(fuelPumpsRef.current);

  const checkPendingFuelRefunds = () =>
    FuelUtils.checkPendingFuelRefunds(fuelPumpsRef.current);

  const setOpenAllResponse = resp =>
    dispatch(fuelActions.setOpenAllResponse(resp));

  const setCloseAllResponse = resp =>
    dispatch(fuelActions.setCloseAllResponse(resp));

  return {
    fuelPumps: fuelPumpsRef.current,
    fuelPrices,
    getPriceWithProductNumber,
    selectedPump,
    selectPump,
    deselectPump,
    currentAction,
    selectAction,
    deselectAction,
    currentPumpConfig,
    getPumpConfig,
    getPumpRefunds,
    toFixedDigits,
    checkIfPumpIsInUse,
    checkIfPumpIsAvailable,
    checkIfPumpIsLocked,
    checkIfAuthInProgress,
    getSelectedPumpFuelState,
    isIntegratedFuelStore,
    isFuelIntegrated,
    isFuelEnabled,
    saveFuelNotification,
    getMultiPumpMsgs,
    getPumpRedbarMsg,
    checkIfPumpCanBeStopped,
    checkIfPumpCanBeRestarted,
    checkIfPumpIsClosed,
    isFuelIncluded,
    getFuelReceiptAttts,
    fuelParams,
    getInactivePumpsCount,
    isDEXOnline,
    isAuthConfirmInProgress,
    setCrindDenialReason,
    crindDenialsReason,
    setGradeSelection,
    isGradeSelectionOn,
    setSelectedGrade,
    selectedGrade,
    dexComFormat,
    loyalty,
    isSpeedyStore,
    dexComFormat,
    checkPendingFuelRefunds,
    fuelPrepaidAmount,
    isFuelPrepay: fuelPrepaidAmount > 0,
    setFuelCalculatedDiscounts,
    checkifAuthIsAllowed,
    setOpenAllResponse,
    setCloseAllResponse,
    openAllResponse,
    closeAllResponse,
  };
};
