import { useRef } from 'react';

export const useTimeLogger = (feature = 'SAFE') => {
  const timeRef = useRef(null);
  const timeTaken = expired => {
    if (!timeRef.current && !expired) {
      console.log(feature, `TIMER STARTED AT :::-- ${new Date()}`);
      Logger.info(`[7POS UI] : ${feature} TIMER STARTED`);
      return;
    }
    console.log(
      feature,
      `TIMER ${expired ? 'EXPIRED' : 'RESTARTED'} in`,
      Date.now() - timeRef.current,
      'MILLISECONDS'
    );
    return Logger.info(
      `[7POS UI] : ${feature} TIMER ${
        expired ? 'EXPIRED' : 'RESTARTED'
      } in ${Date.now() - timeRef.current} in Milliseconds`
    );
  };
  const logStart = () => {
    timeTaken();
    timeRef.current = Date.now();
  };
  const expiredLog = () => {
    timeTaken(true);
    timeRef.current = null;
  };
  return {
    logStart,
    expiredLog,
  };
};
