import { useDispatch } from 'react-redux';
import { notificationsActions } from '../slices/notifications.slice';

export const useNotifications = () => {
  const dispatch = useDispatch();
  const setNotifications = notifications => {
    dispatch(notificationsActions.setNotifications(notifications));
  };

  const dismissNotification = id => {
    dispatch(notificationsActions.dismissNotification({ id }));
  };

  const setBulkNotifications = notifications => {
    dispatch(notificationsActions.setBulkNotifications(notifications));
  };

  return {
    setNotifications,
    dismissNotification,
    setBulkNotifications,
  };
};
