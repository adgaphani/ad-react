import moment from 'moment';
import { useSelector } from 'react-redux';
import { useContext } from 'react';
// import { updateCacheHardTotals } from '7pos-hardtotals';
import { getDVR } from '../hardware/dvr';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';
import { getCurrentISODate, getCurrentUTCDate } from '../Utils';
import { currencyFixed } from '../Utils/appUtils';

export const useTAPIPosting = () => {
  const [ws] = useContext(WebSocketContext) || [];
  const {
    user,
    deviceInfo,
    transactionId,
    storeDetails,
    paymentTransactionId,
    vaultUserEntries,
    safeStartTime,
    exchangeRate,
  } = useSelector(state => ({
    user: state.auth.user,
    deviceInfo: state.main.deviceInfo,
    safeDropType: state.cart.safeDropType,
    storeDetails: state.main.storeDetails,
    transactionId: state.cart.transactionId,
    paymentTransactionId: state.cart.paymentTransactionId,
    safeDropResponse: state.cart.safeDropResponse,
    vaultUserEntries: state.cart.vaultUserEntries,
    safeStartTime: state.cart.safeStartTime,
    exchangeRate: state.main.currencyConversion,
  }));
  const getMessageHeader = () => ({
    timeStamp: getCurrentUTCDate(),
    messageType: 'SAFEACTION',
    correlationId: paymentTransactionId,
    source: {
      sourceType: 'POS',
      sourceIdentifier: deviceInfo?.id || '1',
      version: process.env.REACT_APP_VERSION,
    },
    destination: {
      destinationType: '7POS',
      destinationIdentifier: '1',
    },
  });
  const getTransHeader = ({ type = 'SAFEACTION', transactionStatus }) => ({
    storeId: `${storeDetails?.storeId}`,
    deviceId: deviceInfo?.id,
    deviceType: '7POS',
    transactionType: type,
    transactionId: paymentTransactionId,
    transactionSequenceId: transactionId,
    originalTransactionId: null,
    originalTransactionSequenceId: null,
    transactionStartTime: safeStartTime,
    transactionEndTime: getCurrentISODate(),
    transactionStatus,
    currencyCode: storeDetails?.currencyCode,
    userId: user?.userId,
    userName: user?.firstName,
    transactionComment: null,
    ageVerificationInfo: null,
    storeLetterCode: storeDetails?.letterCode,
  });
  const getTransDetails = ({
    type = 'SAFEACTION',
    amount,
    safeResponseStatus,
    safeDropType,
    currencyCode,
  }) => {
    const isCanada = storeDetails?.address?.country === 'CA';
    const cartChangeTrail = [
      {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        eventType: 'addLineItem',
        eventSeq: 1,
        eventResult: safeResponseStatus,
        itemName: safeDropType,
        price: amount ? `${currencyFixed(amount / 100)}` : 0,
        transactionLineId: 1,
      },
    ];
    getDVR().setSafeCartChangeTrail(cartChangeTrail);

    return {
      ...(type === 'SAFEACTION'
        ? {
            storeActivityInfo: {
              amount: amount ? `${currencyFixed(amount / 100)}` : 0,
              transactionLineId: 1,
              ...(safeDropType === 'vaultDrop'
                ? {
                    envelopeId:
                      vaultUserEntries?.envelop &&
                      Number(vaultUserEntries.envelop),
                    ...(isCanada
                      ? {
                          currencyCode,
                          exchangeRate,
                        }
                      : {}),
                  }
                : {}),
              status: safeResponseStatus, // String
              action: safeDropType, // String
              isoCode: 'SAFE', // String
            },
            cartChangeTrail,
          }
        : {}),
    };
  };
  const getMsgBody = config => ({
    transactionHeaderInfo: getTransHeader(config),
    transactionDetails: getTransDetails(config),
  });

  const postTapi = async (config = {}) => {
    /* const request = JSON.stringify(getMsgBody(config));
    await updateCacheHardTotals(request); */
    try {
      const payload = {
        messageHeader: getMessageHeader(),
        messageBody: {
          message: JSON.stringify(getMsgBody(config)),
        },
      };
      Logger.info(`SAFE TAPI_POSTING_SUCCESS ::- ${JSON.stringify(payload)}`);
      const req = JSON.stringify(payload);
      if (!(config?.safeResponseStatus || '').toLowerCase().includes('abort')) {
        localStorage.setItem('finalPaymentRequest', req);
      }
      ws.socket?.send('/app/transaction/data', {}, req);
    } catch (e) {
      console.log(`Error Posting TAPI MESSAGE :- CALLER : ${config.type}`, e);
      Logger.info(
        `SAFE TAPI_POSTING_ERROR ::- SAFE TYPE : ${config.type} ERROR :: - ${e}`
      );
    }
  };
  return {
    postTapi,
    getTAPITransHeader: getTransHeader,
    getTAPITransDetails: getTransDetails,
    getTAPIMsgBody: getMsgBody,
    getTAPIMsgHeader: getMessageHeader,
  };
};
//  config = {
//      type : 'SAFE',
//      safeResponseStatus : 'safeOfline'
//  }
