import { useCallback } from 'react';
import store from '../store';

export const usePrivileges = () => {
  const isValidUserFunction = useCallback(iFunctionName => {
    const {
      isTransactionRefund,
      isTransactionVoid,
      cartItems,
      member,
    } = store.getState()?.cart;
    const {
      keypad: { value: KeypadValue },
    } = store.getState().dailpad;
    const {
      functionSecuirtyData: functionSecurityDetails,
    } = store.getState()?.main;
    const { user } = store.getState()?.auth;
    const funcdata = functionSecurityDetails?.filter(
      func =>
        (iFunctionName === 'moneyorder'
          ? func?.name?.trim()?.toLowerCase() === iFunctionName ||
            func?.name?.trim()?.toLowerCase() === 'mowithfee' // #5843 MO WITH FEE will be applicable for MO As well
          : iFunctionName === 'scanload'
          ? func?.name?.trim()?.toLowerCase() === 'load'
          : func?.name?.trim()?.toLowerCase() === iFunctionName) &&
        func?.securityLevelId !== 0
    );
    // corrected the feild check
    if (funcdata === 'undefined' || !funcdata?.length) {
      return true;
    }
    let iSkipValidation = false;
    if (
      iFunctionName === 'load' ||
      iFunctionName === 'prepaid' ||
      iFunctionName === 'scanload'
    ) {
      if (isTransactionRefund) {
        iSkipValidation = true;
      } else if (iFunctionName === 'load' && !Number(KeypadValue) > 0) {
        iSkipValidation = true;
      }
    } else if (
      iFunctionName === 'balanceinquiry' ||
      iFunctionName === 'nosale' ||
      iFunctionName === 'safedrop' ||
      iFunctionName === 'refund' ||
      iFunctionName === 'endofday' ||
      iFunctionName === 'endofshift' ||
      iFunctionName === 'receiptreprint'
    ) {
      if (
        cartItems.length > 0 ||
        isTransactionRefund ||
        isTransactionVoid ||
        member
      ) {
        iSkipValidation = true;
      }
    } else if (iFunctionName === 'voidmoneyorderfee') {
      const isMoneyItem = cartItems.filter(item => item.isMoneyOrder === true);
      if (!isMoneyItem[0]) iSkipValidation = true;
    } else if (iFunctionName === 'paidin' || iFunctionName === 'paidout') {
      if (cartItems.length > 0 || member) {
        iSkipValidation = true;
      }
    } else if (
      iFunctionName === 'taxexempt' ||
      iFunctionName === 'priceoverride'
    ) {
      if (cartItems.length <= 0) {
        iSkipValidation = true;
      }
    }
    if (!iSkipValidation) {
      if (Number(user?.levelId) <= Number(funcdata[0]?.securityLevelId)) {
        iSkipValidation = true;
        global?.logger?.info(`User have permission to do ${iFunctionName}`);
      } else {
        iSkipValidation = false;
        global?.logger?.info(
          `User don't have permission to do ${iFunctionName} and user level:${user?.levelId},required levelID:${funcdata[0]?.securityLevelId}`
        );
      }
    }
    return iSkipValidation;
  }, []);
  return {
    isValidUserFunction,
  };
};
