import { useEffect, useRef, useCallback } from 'react';
import { useHistory } from 'react-router-dom';
import { FISActions } from '../components/Fuel';
import { FuelUtils, toFixedDigits, toDecimalNumber } from '../Utils';
import { useFuelRequest } from './useFuelRequest';
import { useFuel } from './useFuel';
import { useFuelCache } from './useFuelCache';
import { useCart } from './useCart';
import { TransactionTypes } from '../TransactionTypes';
import { useSoundToast } from './useSoundToast';
import { useMember } from './useMember';
import store from '../store';
import { VANGUARD_STANDIN } from '../constants';
import { getUpadtedFuelDiscounts } from '../Utils/cartUtils';

export const useSharedFuelRequest = () => {
  const history = useHistory();
  const {
    addItemToCart,
    getCartMetrics,
    voidPrepayItemFromCart,
    // nonFuelItems,
  } = useCart();
  const {
    currentAction,
    selectedPump,
    checkIfPumpIsLocked,
    getPriceWithProductNumber,
    setFuelCalculatedDiscounts,
  } = useFuel();
  const {
    prepayCache,
    resetPrepayCache,
    setRefundCache,
    resetRefundCache,
    refundCache,
    setFuturePreauthCancelCache,
  } = useFuelCache();
  const { memberId, altId } = useMember();
  const { processFuelRequestAsPromise } = useFuelRequest();
  const refundCacheRef = useRef(refundCache);
  const prepayCacheRef = useRef(prepayCache);
  const toast = useSoundToast();

  /**
   * refund object should be passed from pump status.
   *    -> Send ReadSale request to DEX
   *    -> Add refund fuel item to cart
   *          -> Add tapi, papi details as cart item meta (Will be needed to finalize)
   *          -> No further data massaging needed. All the attribute names are as per contract.
   * @param refund
   * @returns {*}
   */
  const processRefundRequest = refund => {
    const { sequenceNumber } = refund;
    return processFuelRequestAsPromise(
      FISActions.readSale(sequenceNumber),
      selectedPump,
      { resetActions: false }
    ).then(response => {
      Logger.info(`[Fuel] REFUND : Response from dex`);
      const {
        currentSale: {
          prepayAmount,
          amountPumped,
          refundAmount,
          ppu,
          volume,
          productNumber,
          hoseNumber,
          priceGroup,
          primaryTank,
          primaryTankVolume,
          secondaryTank,
          secondaryTankVolume,
          creepage,
          priceTable,
          originalSequenceNumber,
          originalTransactionId,
        },
        saleDiscounts = {},
      } = response;
      const { appliedLoyaltyDiscounts, appliedHostDiscounts } =
        saleDiscounts || {};
      if (
        appliedLoyaltyDiscounts?.length ||
        appliedHostDiscounts?.discountInfo?.length
      ) {
        setFuelCalculatedDiscounts({
          loyaltyDiscounts: [
            ...(appliedLoyaltyDiscounts?.length
              ? [...appliedLoyaltyDiscounts]
              : []),
            ...(appliedHostDiscounts?.length
              ? [
                  ...appliedHostDiscounts?.[0].discountInfo?.map(d => ({
                    // TODO : remove the [0]
                    ...d,
                    discount: d.discountAmount * 100,
                    isHostDiscount: true,
                    pos_text: d.receiptDiscountLabel,
                  })),
                ]
              : []), // Adding HostDiscounts as its needed only for display purpose and sending it to TAPI
          ],
        });
      }
      const fuelGrade = getPriceWithProductNumber(productNumber);
      console.log(
        '*****FUEL GRADE::-',
        fuelGrade,
        '****Product Number:::-',
        productNumber,
        saleDiscounts
      );
      const { sequenceNumber: cartSequenceNumber } = currentAction; // we will need the sequenceNumber to prepare cart item.
      const cartItem = FuelUtils.getRefundCartItem({
        sequenceNumber: cartSequenceNumber,
        selectedPumpNumber: selectedPump,
        prepayAmount,
        amountPumped,
        refundAmount,
        ppu,
        volume,
        fuelGrade,
      });
      cartItem.metaInfo = {
        originalTransactionSequenceId: originalSequenceNumber?.toString(),
        originalTransactionId,
        selectedGrade: fuelGrade
          ? {
              code: fuelGrade?.product,
              description: fuelGrade?.storeProductName,
              quantity: toFixedDigits(volume, 3),
              unitPrice: fuelGrade?.unitPrice,
              restricted: fuelGrade?.restricted || false,
            }
          : undefined,
        fuelDispenserId: selectedPump.toString(),
        code: fuelGrade?.product,
        description: fuelGrade?.storeProductName,
        hoseNumber,
        priceGroup: priceGroup.toString(),
        pricePerUnit: toDecimalNumber(ppu, 3),
        primaryTankNumber: primaryTank,
        primaryTankVolume: toDecimalNumber(primaryTankVolume, 3),
        secondaryTankNumber: secondaryTank,
        secondaryTankVolume: toDecimalNumber(secondaryTankVolume, 3),
        totalFuelAmount: toDecimalNumber(amountPumped, 2),
        totalFuelVolume: toDecimalNumber(volume, 3),
        creepageAmount: creepage,
        fuelPriceTable: priceTable,
        transactionType: TransactionTypes.preAuthCompletion,
        fuelAmount: -1 * toDecimalNumber(refundAmount, 2),
        prepayAmount: toDecimalNumber(prepayAmount, 2),
        seiProductId: productNumber,
        // fuelAdjustmentAmountPerUnit: 0.0, // Not in Use
        // totalFuelAdjustmentAmount: 0.0,  // Not in Use
      };
      setRefundCache({
        pumpNumber: selectedPump,
        sequenceNumber: response?.tranSeq, // From ReadSale.
        fuelAmount: refundAmount,
        refundCartItem: cartItem, // This is to implement Refund abort where the fuel item stay as is and other items get aborted.
        // This cache will be cleared on cash finalize. No need to pull item from cart items as there is dependency on cart trail and updated time number etc.
        // Before using this cartItem, deepcopy the object and update the following attribute values
        // itemSeq --> guid
        // updatedAt --> currentTimestamp
      });
      // Promise.resolve();
      return processFuelRequestAsPromise(
        FISActions.clearSale(sequenceNumber),
        selectedPump
      ).then(() => {
        addItemToCart(cartItem);
        history.replace('/home');
      });
    });
  };

  const processClearSaleIfNeeded = () => {
    if (!refundCacheRef.current) {
      Logger.debug('[Fuel] Not a fuel refund transaction.');
      return undefined;
    }
    return resetRefundCache();
    // const { pumpNumber, sequenceNumber } = refundCacheRef.current;
    // return processFuelRequestAsPromise(
    //   FISActions.clearSale(sequenceNumber),
    //   pumpNumber
    // )
    //   .then(response => {
    //     console.log(response);
    //   })
    //   .finally(resetRefundCache);
  };

  const processUnlockPumpIfNeeded = useCallback((stopSpinner = true) => {
    Logger.info('[Fuel] processUnlockPumpIfNeeded --->');
    if (!prepayCacheRef.current) {
      Logger.debug('[Fuel] Not a fuel prepay transaction.');
      return undefined;
    }
    Logger.info(
      `[Fuel] Unlock Prepay Details: ${JSON.stringify(prepayCacheRef.current)}`
    );
    const { pumpNumber, sequenceNumber } = prepayCacheRef.current;
    if (!checkIfPumpIsLocked(pumpNumber)) {
      Logger.info(
        `[Fuel] PUMP : ${pumpNumber} is not locked at the moment. Not proceeding with unlock.`
      );
      return resetPrepayCache();
    }
    toast({
      description: Messages.releasing_pump,
      status: 'success',
      position: 'top-left',
      duration: 1000,
    });
    console.info('[Fuel] Sending Unlock request...');
    return processFuelRequestAsPromise(
      FISActions.unlockPump(sequenceNumber),
      pumpNumber,
      { stopSpinner }
    )
      .then(response => {
        Logger.info('[Fuel] Pump is unlocked.');
        console.log(response);
      })
      .finally(resetPrepayCache);
  }, []);
  /**
   *
   *  CASH - System knows that the media number is 1
   *  CARD - System needs wait until middleware responds with mediaNumber and call this method with relavent mediaNumber
   * @returns
   *            Promise - If the valid prepay cache exists
   *            undefined - otherwise
   */
  const processPrepayApprovalIfNeeded = paymentResp => {
    if (!prepayCacheRef.current) {
      Logger.debug('[Fuel] Not a fuel prepay transaction.');
      return undefined;
    }

    Logger.info(
      `[Fuel] Prepay Details: ${JSON.stringify(prepayCacheRef.current)}`
    );
    Logger.debug(`[Fuel] Cart Metrics: ${JSON.stringify(getCartMetrics())}`);
    const { transactionTotal = '0.0' } = getCartMetrics();
    const {
      pumpNumber,
      sequenceNumber,
      fuelAmount,
      transactionId,
      paymentTransactionId,
      mediaNumber,
      paymentTenderId,
    } = prepayCacheRef.current;

    const handleAuthRejection = () => {
      if (mediaNumber === 1) {
        voidPrepayItemFromCart();
        // resetPrepayCache();
        // When cart is empty take the user to the home page.
        // #8167 For cash POS need to complete the transaction regradless auth failed/success
        /* if (!nonFuelItems.length) {
          history.push('/home');
        } */
      } else {
        // Setting future preauth cancel data to trigger auto preauth cancel from payment confirmation page automatically.
        setFuturePreauthCancelCache({
          originalTransactionId: paymentTransactionId,
          originalPaymentTenderId: paymentTenderId,
          fuelAmount,
          originalTransactionSequenceId: transactionId,
          pumpNumber,
          mediaNumber,
          sequenceNumber,
        });
      }
    };

    if (!IS_DEV && !checkIfPumpIsLocked(pumpNumber)) {
      Logger.info(
        `[Fuel]: [Warning] Pumps ${pumpNumber} is not reserved. Not proceeding with auth request...`
      );
      handleAuthRejection();
      return Promise.reject(new Error('Pump Reject')).finally(resetPrepayCache);
    }
    let preAuthPayload = FISActions.authPump({
      amount: fuelAmount,
      transactionTotal,
      transactionId,
      sequenceNumber,
      paymentTransactionId,
      mediaNumber,
      paymentTenderId,
      memberId,
      altMemberId: altId,
    });
    const approvalStatus =
      paymentResp?.paymentMedia?.payment?.approvalStatus || null;
    if (mediaNumber !== 1 && approvalStatus && approvalStatus !== null) {
      preAuthPayload.approvalStatus = VANGUARD_STANDIN;
    }
    const priceTier = paymentResp?.paymentMedia?.priceTier || null;
    const { isCashCreditStore } = store.getState().main;
    if (priceTier !== null && isCashCreditStore) {
      preAuthPayload.priceTier = priceTier;
    }
    // Taking this directly from store as these needs to be added when paymentresponse is received for card payments
    const {
      main: { isSpeedyStore },
      cart: {
        fuelLoyalty: loyalty,
        calculatedFuelDiscounts,
        calculatedPrices,
        hostDiscounts,
        calculatedFuelCashPrices,
        paymentMethod,
        selectedGrade,
        updatedDiscounts,
      },
    } = store.getState();
    const referenceNumber =
      paymentResp?.paymentMedia?.payment?.referenceNumber || null;
    if (referenceNumber && isSpeedyStore) {
      preAuthPayload.referenceNumber = referenceNumber;
    }
    let { loyaltyDiscounts } = calculatedFuelDiscounts;
    let calculatedHostPrice = hostDiscounts;
    if (isSpeedyStore) {
      preAuthPayload = {
        ...preAuthPayload,
        ...(loyalty
          ? {
              loyaltyResponse: {
                ...loyalty, // updadte forcedDiscountForSelectedGrade
                forcedDiscountForSelectedGrade: getUpadtedFuelDiscounts(
                  loyalty?.forcedDiscountForSelectedGrade,
                  updatedDiscounts
                ),
              },
            }
          : {}),
        // hostDiscounts,
        // calculatedPrices: {
        //   grades: calculatedPrices,
        //   appliedLoyaltyDiscounts: loyaltyDiscounts?.length
        //     ? loyaltyDiscounts.map(l => l.id)
        //     : null,
        //   // appliedHostDiscounts: hostDiscounts?.discountInfo?.length
        //   //   ? hostDiscounts.discountInfo
        //   //       .filter(h => h.productCode === selectedGrade.grade_id)
        //   //       .map(i => i.discountProgramID)
        //   //   : null,
        // },
      };
      loyaltyDiscounts = getUpadtedFuelDiscounts(
        loyaltyDiscounts,
        updatedDiscounts,
        'id'
      );
      const hostDisc = hostDiscounts?.discountInfo?.find(
        o => o.productCode === selectedGrade?.product
      );
      const gradeDisc = calculatedPrices?.find(
        o => o?.grade_id === selectedGrade?.product
      );
      if (!!hostDisc && !!gradeDisc) {
        const price = gradeDisc.final_price / 1000 - hostDisc?.discountAmount;
        if (price > 0.1) {
          calculatedHostPrice = hostDiscounts;
        } else {
          calculatedHostPrice = {};
        }
      }
    }

    preAuthPayload = {
      ...preAuthPayload,
      hostDiscounts: calculatedHostPrice,
      calculatedPrices: {
        grades:
          isCashCreditStore && paymentMethod === 'CASH'
            ? calculatedFuelCashPrices
            : calculatedPrices,
        appliedLoyaltyDiscounts: loyaltyDiscounts?.length
          ? loyaltyDiscounts.map(l => l.id)
          : null,
        // appliedHostDiscounts: hostDiscounts?.discountInfo?.length
        //   ? hostDiscounts.discountInfo
        //       .filter(h => h.productCode === selectedGrade.grade_id)
        //       .map(i => i.discountProgramID)
        //   : null,
      },
    };
    console.log('Fuel PREAUTH PAYLOAD________', preAuthPayload);
    return processFuelRequestAsPromise(preAuthPayload, pumpNumber)
      .catch(async e => {
        if (IS_DEV) return;
        Logger.error(
          `[Fuel] PrepayPumpRequestFailure. Request: ${JSON.stringify(
            preAuthPayload
          )} Reason: ${e?.message}`
        );
        handleAuthRejection();
        await processUnlockPumpIfNeeded()?.catch(() =>
          console.log('Absorbing the error')
        );
        throw e;
      })
      .finally(resetPrepayCache);
  };

  const sendFuelEODEOS = (isEOD, { day, shift }) =>
    processFuelRequestAsPromise(
      FISActions.eoseod({
        isEOD,
        day,
        shift,
      })
    );

  const sendEODToDEX = eodDetails => {
    Logger.info(`[Fuel] Sending EOD to DEX: ${JSON.stringify(eodDetails)}`);
    return sendFuelEODEOS(true, eodDetails);
  };

  const sendEOSToDEX = eosDetails => {
    Logger.info(`[Fuel] Sending EOS to DEX: ${JSON.stringify(eosDetails)}`);
    return sendFuelEODEOS(false, eosDetails);
  };

  useEffect(() => {
    refundCacheRef.current = refundCache;
  }, [refundCache]);

  useEffect(() => {
    prepayCacheRef.current = prepayCache;
  }, [prepayCache]);

  return {
    processRefundRequest,
    processPrepayApprovalIfNeeded,
    processClearSaleIfNeeded,
    processUnlockPumpIfNeeded,
    sendEOSToDEX,
    sendEODToDEX,
  };
};
