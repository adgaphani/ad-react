import PromiseTimeoutUtil from 'promise-timeout';
import { useContext } from 'react';
import { useFuel } from './useFuel';
import { FuelErrorMappings, WSPayloadUtil } from '../Utils';
import { WSSubscriptions, WSTopics } from '../constants';
import { WebSocketContext } from '../components/Common/WebSocket/WebSocketProvider';
import { FISCommManager } from '../components/Fuel';
import { AppContext } from '../AppContext';
import { useFuelCache } from './useFuelCache';

export const useFuelRequest = () => {
  const { selectedPump } = useFuel();
  const { resetFuelSelections, scheduleResetFuelSelections } = useFuelCache();
  const [ws] = useContext(WebSocketContext);
  const appContextActions = useContext(AppContext);
  const { processFISResponse, getPayloadForPump } = FISCommManager;
  const parseResponse = event =>
    processFISResponse(WSPayloadUtil.getPayload(event));
  const defaultOptions = { includePump: true, clearSelections: false };

  const getActiveSocket = () => {
    const socket = ws?.socket;
    if (socket && socket.connected) {
      return socket;
    }
    return undefined;
  };

  const stopListeningToFuelResponse = () => {
    const subscriptions = Object.keys(ws?.socket?.subscriptions) || [];
    const responseTopic = WSSubscriptions.fis.response;
    if (subscriptions.includes(responseTopic)) {
      ws?.socket?.unsubscribe(responseTopic);
    }
  };

  const processFuelRequest = (
    messageDetails,
    pumpNumber = selectedPump,
    options = defaultOptions
  ) => {
    const socket = getActiveSocket();
    if (!socket) return;
    const { includePump = true, clearSelections = false } = options;
    const fuelRequestPayload = getPayloadForPump(
      includePump ? pumpNumber : undefined,
      messageDetails
    );
    Logger.debug(`[Fuel] Request Sent`);
    socket?.send(WSTopics.fis.sendCommand, {}, fuelRequestPayload);
    clearSelections && scheduleResetFuelSelections();
  };

  const processFuelRequestAsMultiResolve = (messageDetails, callback) => {
    Logger.info(`[Fuel] processFuelRequestAsMultiResolve --->`);
    const socket = getActiveSocket();
    if (!socket || !callback) {
      return;
    }
    const handleFISResponse = event => {
      const response = parseResponse(event);
      Logger.info(`[Fuel] MultiResolve Response: ${JSON.stringify(response)}`);
      callback(response);
    };
    socket.unsubscribe(WSSubscriptions.fis.response);
    // Subscribe
    socket.subscribe(
      WSTopics.fis.commandResponse,
      event => handleFISResponse(event),
      {
        id: WSSubscriptions.fis.response,
      }
    );
    processFuelRequest(messageDetails, selectedPump, defaultOptions);
  };

  const processFuelRequestAsPromise = (
    messageDetails,
    pumpNumber = selectedPump,
    options = { resetActions: true, stopSpinner: true, displayLoader: true }
  ) => {
    const { stopSpinner = true, displayLoader = true } = options;
    const handleFISResponse = (event, resolve, reject) => {
      const response = parseResponse(event);
      // Logger.info(`[Fuel] Response: ${JSON.stringify(response)}`);
      if (response?.status === 1) {
        return resolve?.(response);
      }
      Logger.error(`[Fuel] ERRORResponse: ${JSON.stringify(response)}`);
      reject?.(
        new Error(
          FuelErrorMappings[response?.status] ?? Messages.request_failed
        )
      );
    };
    const handlePromise = (resolve, reject) => {
      const socket = getActiveSocket();
      if (!socket) {
        return reject(new Error(Messages.connection_error));
      }
      // Unsubscribe
      stopListeningToFuelResponse();
      // Subscribe
      socket.subscribe(
        WSTopics.fis.commandResponse,
        event => handleFISResponse(event, resolve, reject),
        {
          id: WSSubscriptions.fis.response,
        }
      );
      processFuelRequest(messageDetails, pumpNumber, defaultOptions);
    };
    if (displayLoader) {
      appContextActions?.startLoading?.();
    }
    return PromiseTimeoutUtil.timeout(
      new Promise(handlePromise),
      options.timeout || 5000
    )
      .catch(e => {
        const isTimeout = e instanceof PromiseTimeoutUtil.TimeoutError;
        throw isTimeout ? new Error(Messages.request_timeout) : e;
      })
      .finally(() => {
        stopListeningToFuelResponse();
        options?.resetActions && resetFuelSelections(); // Not applicable in all the scenarios.
        stopSpinner && appContextActions?.stopLoading?.();
      });
  };

  return {
    processFuelRequestAsMultiResolve,
    processFuelRequestAsPromise,
    processFuelRequest,
    stopListeningToFuelResponse,
  };
};
