import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { getArbitrationRequest } from '../../Utils/arbirtationUtils';
import { ArbitrationUtils } from '../../Utils/promoUtil';
import { Arbitration } from '../../Utils/arbitration';
import { BASE_URI, LOCAL_TIMEOUT } from '../../constants';
// import { Arbitration } from "ris-js-common";

export const fetchOnePromoArbitration = async (
  member,
  transactionId,
  storeDetails,
  cartitems,
  MembertransactionId,
  isReturnVoid,
  terminalID,
  MemberBarcodeInfo,
  correlationID,
  ReceiptTotalAmount
) => {
  const cancelRequestSource = Axios.CancelToken.source();
  const isOnlinePromo = true;
  const onePromoArbitrationReq = getArbitrationRequest(
    member,
    transactionId,
    cartitems,
    storeDetails,
    MembertransactionId,
    isReturnVoid,
    terminalID,
    isOnlinePromo,
    MemberBarcodeInfo
  );
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, LOCAL_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/sale/transaction/promo`;

  if (onePromoArbitrationReq.items.length) {
    const promoResponse = await Axios({
      cancelToken: cancelRequestSource.token,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': correlationID,
      },
      data: onePromoArbitrationReq,
      url: apiurl,
    });
    apiroundTripTracker(
      correlationID,
      apiStartTime,
      apiurl,
      promoResponse.status
    );
    global?.logger?.info(
      `[7POS UI] - promo API response:${JSON.stringify(promoResponse)}`
    );
    const res = await new Arbitration(promoResponse).processData();
    const {
      data: {
        response: { basket, fees, items },
        pmb,
        external = [],
        display_message = '',
      },
    } = res;

    const respa = new ArbitrationUtils(cartitems, {
      basket,
      fees,
      items,
      external,
      ReceiptTotalAmount,
    }).processPromos();

    return {
      items: respa,
      pmb,
      arbitration: { basket, fees, items, external },
      display_message,
    };
  }
  return { items: cartitems };
};
