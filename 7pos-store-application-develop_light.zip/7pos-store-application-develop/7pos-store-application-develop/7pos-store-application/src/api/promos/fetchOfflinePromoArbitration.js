import { getArbitrationRequest } from '../../Utils/arbirtationUtils';
import { ArbitrationUtils } from '../../Utils/promoUtil';
import { Arbitration } from '../../Utils/arbitration';
import { BASE_URI /* , NETWORK_TIMEOUT */ } from '../../constants';

const PROMO_TIME_OUT = 3000;

// eslint-disable-next-line arrow-body-style
const getOfflinePromo = async onePromoArbitrationReq => {
  return new Promise(resolve => {
    const opts = {
      config: {
        MONGO_REALM_URL: `http://${BASE_URI}:9510/v1/api/offline/promo`,
      },
    };
    const onepromo = require('@service-apis/onepromo-offline')(opts);
    const arbitrationServices = onepromo.services.arbitration;

    const promoTimeOut = setTimeout(() => {
      global?.logger?.info(
        `[7POS UI] - Offline promo API timeout(${PROMO_TIME_OUT} sec).`
      );
      return resolve();
    }, PROMO_TIME_OUT);

    arbitrationServices
      .arbitrate(onePromoArbitrationReq)
      .then(result => {
        global?.logger?.info(`[7POS UI] - Offline promo API Success`);
        clearTimeout(promoTimeOut);
        return resolve(result);
      })
      .catch(e => {
        global?.logger?.info(
          `[7POS UI] - Offline promo API error:${JSON.stringify(e)}`
        );
        clearTimeout(promoTimeOut);
        return resolve();
      });
  });
};

export const fetchOfflinePromoArbitration = async (
  member,
  transactionId,
  storeDetails,
  cartitems,
  MembertransactionId,
  isReturnVoid,
  terminalID
) => {
  try {
    const onePromoArbitrationReq = getArbitrationRequest(
      member,
      transactionId,
      cartitems,
      storeDetails,
      MembertransactionId,
      isReturnVoid,
      terminalID
    );
    const promoResponse = await getOfflinePromo(onePromoArbitrationReq);
    if (!promoResponse || !promoResponse?.response) {
      global?.logger?.info(`[7POS UI] - Offline promo API call failed.`);
      return 'error';
    }
    if (promoResponse?.response) {
      const promodata = {
        data: promoResponse,
      };
      const res = await new Arbitration(promodata).processData();
      const {
        data: {
          response: { basket, fees, items },
          pmb,
          external = [],
        },
      } = res;
      const respa = new ArbitrationUtils(cartitems, {
        basket,
        fees,
        items,
        external,
      }).processPromos();
      return {
        items: respa,
        pmb,
        arbitration: { basket, fees, items, external },
      };
    }
  } catch (error) {
    global?.logger?.info(
      `[7POS UI] - Offline promo API call failed:${JSON.stringify(error)}`
    );
    return 'error';
  }
};
