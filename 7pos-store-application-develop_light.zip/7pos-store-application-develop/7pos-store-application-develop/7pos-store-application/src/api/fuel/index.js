import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

const fetchFuelPumps = () =>
  Axios({
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    url: `http://${BASE_URI}:9510/v1/api/fuel/controller`,
  });

const fetchFuelParameters = () =>
  Axios({
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    url: `http://${BASE_URI}:9510/v1/api/fuel/parameters`,
  });

const fetchFuelPrices = data =>
  Axios({
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    data,
    url: `http://${BASE_URI}:9510/v1/api/fuel/prices`,
  });

// const fetchFuelPrices = () =>
//   new Promise(res => {
//     setTimeout(() => {
//       res({
//         data: {
//           messageSource: 'RIS',
//           storeId: '36949',
//           priceUpdateDateTime: '2022-10-17T17:09:14.446Z',
//           groupId: 3013,
//           prices: [
//             {
//               pricingUID: '45ed194d-7337-41c2-9b1a-f27eb7900a8a',
//               product: '001',
//               productName: 'REGULAR UNLEADED',
//               storeProduct: '001',
//               storeProductName: 'RUL',
//               price: 4.599,
//               unit: 'USD/Gallon',
//               cashPrice: 4.599,
//               seiProductId: '1',
//             },
//             {
//               pricingUID: 'eb56efd5-f886-432e-a8d1-038c1d5caec0',
//               product: '003',
//               productName: 'PREMIUM UNLEADED',
//               storeProduct: '003',
//               storeProductName: 'PUL',
//               price: 6.999,
//               unit: 'USD/Gallon',
//               cashPrice: 6.999,
//               seiProductId: '2',
//             },
//             {
//               pricingUID: '166d57be-2b57-4325-beec-097c1dd1c0f7',
//               product: '073',
//               productName: 'NORMAL MIDGRADE BLEND',
//               storeProduct: '073',
//               storeProductName: 'NMB',
//               price: 5.999,
//               unit: 'USD/Gallon',
//               cashPrice: 5.999,
//               seiProductId: '11',
//             },
//             {
//               pricingUID: '71a24754-b678-4879-8c22-28f2369ce3d3',
//               product: '019',
//               productName: 'DIESEL',
//               storeProduct: '019',
//               storeProductName: 'DSL',
//               price: 8.999,
//               unit: 'USD/Gallon',
//               cashPrice: 9.999,
//               seiProductId: '6',
//             },
//           ],
//         },
//       });
//     });
//   });

const fetchFuelReceipts = async ({ correlationID, selectedPump }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  const sPump = selectedPump ? `/${selectedPump}` : '';

  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/fuelreceipts${sPump}`;

  const receiptResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    receiptResponse.status
  );
  return receiptResponse;
};

const fetchCrindDenials = async ({ correlationID, selectedPump }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  const sPump = selectedPump ? `/${selectedPump}` : '';
  console.log(correlationID, sPump);
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/crinddenials${sPump}`;

  const crindDenials = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(correlationID, apiStartTime, apiurl, crindDenials.status);
  return crindDenials;
};

export const fetchFuelArbitrate = async ({ correlationID, data }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/loyalty/rewards/fuel-arbitrate`;

  const fuelDiscount = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
      Channel: '7pos_spw',
    },
    url: apiurl,
    data,
  });
  apiroundTripTracker(correlationID, apiStartTime, apiurl, fuelDiscount.status);
  return fuelDiscount;
};

export const FuelApi = {
  fetchFuelPumps,
  fetchFuelPrices,
  fetchFuelParameters,
  fetchFuelReceipts,
  fetchCrindDenials,
  fetchFuelArbitrate,
};
