export { fetchEmailReceipt } from './fetchEmailReceipt';
