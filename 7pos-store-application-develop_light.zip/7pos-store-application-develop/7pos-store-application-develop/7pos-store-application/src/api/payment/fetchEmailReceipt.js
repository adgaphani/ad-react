import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

export const fetchEmailReceipt = async (
  emailReceiptReq,
  correlationID,
  channel
) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);

  global?.logger?.info(
    `[7POS UI] - fetchEmailReceipt: ${JSON.stringify(emailReceiptReq)}`
  );
  const isReceiptNonPrintableTags = [
    '********* END OF SHIFT ************',
    'VAULT DROP CASH',
    'INSERT BILLS',
    'LOAD TUBE',
    'VEND TUBE',
    'NO SALE',
    '********* END OF DAY ************',
    '**  CASH DRAWER  **',
  ];
  let isNotReprintable = isReceiptNonPrintableTags.some(i =>
    emailReceiptReq?.header?.headerLines.includes(i)
  );
  if (
    !emailReceiptReq?.lineItem?.items?.length ||
    !emailReceiptReq?.lineItem?.items
  )
    isNotReprintable = true;

  emailReceiptReq = {
    ...emailReceiptReq,
    isReprintable: !isNotReprintable,
  };
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/receipt/email`;

  const emailResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
      Channel: channel,
    },
    data: emailReceiptReq,
    url: apiurl,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    emailResponse.status
  );
  return emailResponse;
};
