/* eslint-disable no-unused-vars */
import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

import arbData from '../fuel/data.json';

const data = {
  data: {
    // isEligible: {
    //   response: {
    //     best_reward: {
    //       id: '3000005650',
    //       title: 'Fresh HOT Pizza Slice',
    //       description: 'Redeem for 1 Slice of Fresh Pizza',
    //       legal_text:
    //         'Store offer. Available while supplies last. Product selection may vary by store. Offer good at participating U.S. 7-Eleven® stores, excludes Hawaii. Offer not valid with any other coupon or discount. No cash value. Consumer pays applicable sales taxes. COPIES OR REPRODUCTION BY ANY MEANS IS PROHIBITED AND SHALL VOID THE COUPON. ©2017 7-Eleven, Inc. All rights reserved.',
    //       image_thumb:
    //         'https://d1se8uetpsj0rs.cloudfront.net/media/7rp/raw/coupons/us/pizza_slices_removebg.png',
    //       image_large:
    //         'https://d1se8uetpsj0rs.cloudfront.net/media/7rp/raw/coupons/us/pizza_slices_removebg.png',
    //       currency_to_earn: 1000,
    //       tier: '1000 to 2000',
    //       tier_id: '1000_US',
    //       shop_with_points: false,
    //       shop_with_points_value: null,
    //       tax_type: '',
    //       name: 'RM66 US Fresh HOT Pizza Slice',
    //       long_description:
    //         'Redeem for 1 Slice of Fresh Pizza, Redeem for 1 Slice of Fresh Pizza for 10000 points Redeem for 1 Slice of Fresh Pizza',
    //       category_id: 232,
    //       catalog_start_date: '2020-09-02T05:00:00Z',
    //       catalog_end_date: '2024-01-01T05:59:59Z',
    //       currency_types: [
    //         'US Points Balance Adjustment',
    //         'US BonusPoint',
    //         'US BasePoint',
    //       ],
    //       active: true,
    //       logo_file_name: null,
    //       slin: '174080',
    //     },
    //     best_fuel_reward: {
    //       id: '3000005677',
    //       title: 'Save 3¢/gal off',
    //       description: 'When you redeem 3000 points',
    //       legal_text:
    //         'Store offer. Available while supplies last. Product selection may vary by store. Offer good at participating U.S. 7-Eleven® stores, excludes Hawaii. Offer not valid with any other coupon or discount. No cash value. Consumer pays applicable sales taxes. COPIES OR REPRODUCTION BY ANY MEANS IS PROHIBITED AND SHALL VOID THE COUPON.  7-ELEVEN, GULP, BIG GULP, DOUBLE GULP and SUPER BIG GULP are registered trademarks of 7-Eleven, Inc. 7-ELEVEN and 7-ELEVEN CHILLERS are registered trademarks of 7-Eleven, Inc. ©2017 7-Eleven, Inc. All rights reserved.',
    //       image_thumb:
    //         'https://d1se8uetpsj0rs.cloudfront.net/media/7rp/raw/coupons/us/Medium_Cold_Brew_9.21-removebg-preview.png',
    //       image_large:
    //         'https://d1se8uetpsj0rs.cloudfront.net/media/7rp/raw/coupons/us/Medium_Cold_Brew_9.21-removebg-preview.png',
    //       currency_to_earn: 3000,
    //       tier: '3000 to 4000',
    //       tier_id: '3000_US',
    //       shop_with_points: false,
    //       shop_with_points_value: null,
    //       tax_type: '',
    //       name: 'When you redeem 3000 points',
    //       long_description: 'Save 3¢/gal off When you redeem 3000 points',
    //       category_id: 99999,
    //       catalog_start_date: '2020-09-02T05:00:00Z',
    //       catalog_end_date: '2024-01-01T05:59:59Z',
    //       currency_types: [
    //         'US Points Balance Adjustment',
    //         'US BonusPoint',
    //         'US BasePoint',
    //       ],
    //       active: true,
    //       logo_file_name: null,
    //       slin: 'fuel-slin',
    //     },
    //     shop_with_points: null,
    //     zip_code: '75063',
    //     upsell: null,
    //   },
    // },
    ...arbData,
  },
};

export const fetchEligibleArbitrate = async (payload, correlationID) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/loyalty/rewards/eligible-arbitrate`;

  const eligibleArbitrateResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
      Channel: CHANNEL,
    },
    url: apiurl,
    data: payload,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    eligibleArbitrateResponse.status
  );
  return eligibleArbitrateResponse;
};

// export const fetchEligibleArbitrate = async (payload, correlationID) => {
//   const cancelRequestSource = Axios.CancelToken.source();
//   console.log('data_____', data);
//   setTimeout(() => {
//     cancelRequestSource.cancel();
//   }, NETWORK_TIMEOUT);
//   return data;
// };
