import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';
import store from '../../store';

const getItemInfo = async (upc, itemId = '', correlationID) => {
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  itemId = itemId || '';
  const cacheKey = itemId;
  const { cachedItems } = store.getState().main;
  if (cacheKey && cachedItems?.[cacheKey]) {
    apiroundTripTracker(correlationID, apiStartTime, 'CachedItems', 200);
    return cachedItems?.[cacheKey];
  }
  const queryString = new URLSearchParams({ upc, itemId }).toString();
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiurl = `http://${BASE_URI}:9510/v1/api/item?${queryString}`;

  const itemResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(correlationID, apiStartTime, apiurl, itemResponse.status);
  return itemResponse;
};

const getSuffix = i => {
  const { isFoodStampAllowed, itemTaxes } = i;
  const { taxId = [] } = itemTaxes;
  if (isFoodStampAllowed && taxId.length) {
    return 'B';
  }
  if (isFoodStampAllowed && !taxId.length) {
    return 'F';
  }
  if (!isFoodStampAllowed && taxId.length) {
    return 'T';
  }
  return '';
};

const getEcoFees = item => {
  const {
    adjustedItem,
    category,
    familyId,
    foodStampAllowed,
    itemId,
    shortName,
    itemRegistration,
    itemSize,
    itemSizeIndex,
    PSAGroupInfo,
    negativeSalesFlag,
    connexxusCode,
    itemClassification,
    itemUPC,
    markupType,
    itemTaxes,
    selling: { customRetailPrice, suggestedRetailPrice },
  } = item;
  const retailPrice =
    typeof customRetailPrice === 'number'
      ? customRetailPrice
      : suggestedRetailPrice;
  const { adjustedItemPrice, adjustedItemSize, adjustedItemSizeIndex } =
    adjustedItem || {};
  const { psa, cat, subcat, id } = category || {};
  return {
    ...item,
    flag: getSuffix({
      isFoodStampAllowed: foodStampAllowed === 'Y',
      itemTaxes,
    }),
    tapiObj: {
      actualPricePerUnit: retailPrice,
      adjustedItemPrice,
      adjustedItemSize,
      adjustedItemSizeIndex,
      cat,
      departmentId: id || (psa + cat + subcat).toString(),
      discountAmount: 0,
      familyId,
      fees: [],
      isFoodStampAllowed: foodStampAllowed === 'Y' ? 1 : 0,
      isFoodStampUsed: false,
      isItemLevelTaxOverride: false,
      isRestricted: false,
      itemFlags: {
        priceOverrideFlag: false,
        taxOverrideAppliedFlag: false,
        restrictionCode: null,
        itemType: 1,
      },
      isLinked: true,
      itemId,
      itemName: shortName,
      itemRegistrationStatus: itemRegistration?.status,
      itemSize,
      itemSizeIndex,
      itemType: itemClassification?.itemType,
      lineComment: PSAGroupInfo?.description,
      markupType,
      negativeSalesFlag,
      pricePerUnit: retailPrice,
      prodCode: connexxusCode,
      productCategory: id,
      psa,
      subCat: subcat,
      type: 'ECO_FEE',
      totalItemAmount: retailPrice,
      upc: itemUPC[0].UPC,
      itemTaxes,
    },
  };
};

export const getFees = async (item, correlationID) => {
  const { itemSize: ipq, linkedFeeItems, deposit } = item;
  const { isTransactionVoid, isTransactionRefund } = store.getState().cart;
  const isNegativeAmount = isTransactionVoid || isTransactionRefund;
  let feeData = [];
  if (deposit?.amount && Math.abs(deposit?.amount > 0)) {
    const { storeDetails } = store.getState().main;
    const {
      amount = 0,
      deptTaxId,
      departmentId,
      departmentFlags,
      prodCode,
      lowAmountLockout = 0,
      highAmountLockout = 0,
    } = deposit || {};
    // #7748 added LALO and HALO check for Deposit
    if (Math.abs(lowAmountLockout > 0) && amount < lowAmountLockout) {
      Logger.error(
        `Deposit not added to the transaction deposit amount lessthan LALO: ${lowAmountLockout}`
      );
    } else if (Math.abs(highAmountLockout > 0) && amount > highAmountLockout) {
      Logger.error(
        `Deposit not added to the transaction deposit amount lessthan HALO: ${highAmountLockout}`
      );
    } else {
      const { foodStampAllowed, discountAllowed, negativeSalesFlag } =
        departmentFlags || {};
      feeData = feeData.concat({
        name: 'Btl Dep-N',
        type: 'BOTTLE_DEPOSIT',
        id: Date.now(),
        itemTaxes: { taxId: deptTaxId },
        isFoodStampAllowed: foodStampAllowed === 'Y' ? 1 : 0,
        discountAllowed: discountAllowed === 'Y',
        negativeSalesFlag: negativeSalesFlag === 'Y',
        retailPrice: amount * ipq * 100 * (isNegativeAmount ? -1 : 1),
        categoryId: departmentId,
        departmentId,
        innerPackQuantity: ipq,
        prodCode,
        quantity: 1,
        flag: getSuffix({
          isFoodStampAllowed: foodStampAllowed === 'Y',
          itemTaxes: { taxId: deptTaxId },
        }),
        familyId: Number(departmentId),
        // itemId: Number(departmentId), // #5951 department cant be treat as item ID
        itemDiscount: 0,
        tapiObj: {
          isFoodStampAllowed: foodStampAllowed === 'Y',
          discountAllowed: discountAllowed === 'Y',
          negativeSalesFlag: negativeSalesFlag === 'Y',
          departmentId,
          amount: amount * ipq,
          stateCode: storeDetails.address.state,
          prodCode,
        },
      });
    }
  }

  if (linkedFeeItems?.length) {
    const [{ itemId }] = linkedFeeItems;
    try {
      const response = await getItemInfo('', itemId, correlationID);
      const data = response?.data?.data;
      const items = JSON.parse(data);
      feeData = items?.length
        ? feeData.concat({
            ...getEcoFees(items[0]),
            retailPrice:
              Number(items[0].retailPrice || 0) *
              100 *
              (isNegativeAmount ? -1 : 1),
            type: 'ECO_FEE',
            isFoodStampAllowed: items[0].foodStampAllowed === 'Y' ? 1 : 0,
            id: Date.now(),
          })
        : feeData;
    } catch (error) {
      global?.logger?.error(`[7POS UI] - getItemInfo ${JSON.stringify(error)}`);
    }
  }
  return feeData;
};

const processItemResponse = async (response, correlationID) => {
  const data = response?.data?.data;
  let items = [];
  items = JSON.parse(data);
  items = items.map(dItem => ({
    ...dItem,
    ...(!dItem.isDominantSellingUnit && items.length > 1 // Shared UPC
      ? {
          category: items.find(j => j.isDominantSellingUnit)?.category,
        }
      : {}),
    ...(items.length === 1 && // Linked Items
    !!items[0]?.chainedItems?.length &&
    !items[0]?.isDominantSellingUnit
      ? {
          category: dItem?.chainedItems?.filter(
            ({ isDominantSellingUnit }) => !!isDominantSellingUnit
          )[0]?.category,
        }
      : {}),
  }));
  items = Promise.all(
    items.map(async i => ({ ...i, fees: await getFees(i, correlationID) }))
  );
  return items;
};
export const getItembyUpcApi = async (upc, itemId = '', correlationID) => {
  try {
    // #8820 blocking F&P click if Item query inprogress
    localStorage.setItem('isItemQueryInProgress', true);
    const itemResponse = await getItemInfo(upc, itemId, correlationID);
    return processItemResponse(itemResponse, correlationID);
  } catch (error) {
    global?.logger?.error(
      `[7POS UI] - getItembyUpcApi ${JSON.stringify(error)}`
    );
  } finally {
    localStorage.removeItem('isItemQueryInProgress');
  }
  return null;
};
