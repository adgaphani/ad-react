import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

export const fetchMemberDetails = async (
  phoneNumber,
  correlationID,
  queryParams
) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/loyalty/profile/${phoneNumber}`;

  const memberResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
      Channel: CHANNEL,
    },
    url: apiurl,
    params: queryParams,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    memberResponse.status
  );
  return memberResponse;
};
