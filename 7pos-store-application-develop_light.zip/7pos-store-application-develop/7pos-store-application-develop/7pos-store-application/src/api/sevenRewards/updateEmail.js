import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

export const updateEmail = async (payload, correlationID) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/loyalty/update/email`;

  const updateEmailResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'PATCH',
    headers: {
      mode: 'no-cors',
      'Access-Control-Allow-Origin': '*',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
    data: payload,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    updateEmailResponse.status
  );
  return updateEmailResponse;
};
