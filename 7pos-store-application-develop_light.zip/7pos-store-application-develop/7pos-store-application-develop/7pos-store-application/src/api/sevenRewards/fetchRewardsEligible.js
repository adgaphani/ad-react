import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, NETWORK_TIMEOUT } from '../../constants';

export const fetchRewardsEligible = async (payload, correlationID) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, NETWORK_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/loyalty/rewards/eligible`;

  const rewardResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
    data: payload,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    rewardResponse.status
  );
  return rewardResponse;
};
