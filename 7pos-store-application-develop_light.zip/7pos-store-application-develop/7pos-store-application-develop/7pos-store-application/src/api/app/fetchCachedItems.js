import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, LOCAL_TIMEOUT } from '../../constants';

export const fetchCachedItems = async ({ correlationID }, retry = 3) => {
  try {
    const cancelRequestSource = Axios.CancelToken.source();
    setTimeout(() => {
      cancelRequestSource.cancel();
    }, LOCAL_TIMEOUT);
    const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
    const apiurl = `http://${BASE_URI}:3010/api/productlookups/cache`;

    const itemsResponse = await Axios({
      cancelToken: cancelRequestSource.token,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-Id': correlationID,
      },
      url: apiurl,
    });
    apiroundTripTracker(
      correlationID,
      apiStartTime,
      apiurl,
      itemsResponse.status
    );
    // format the response to object keyValue pair
    const itemsMapper = {};
    itemsResponse?.data?.forEach(data => {
      if (data?.itemId) {
        itemsMapper[data?.itemId] = {
          data: { data: JSON.stringify([data]) },
        };
      } else {
        // TODO:: no itemID found for that plu key
      }
    });
    return itemsMapper;
  } catch (error) {
    // when error retry again
    if (retry > 0) {
      fetchCachedItems({ correlationID }, retry - 1);
    } else {
      global?.logger?.error(
        `[7POS UI] - fetchCachedItems ${JSON.stringify(error)}`
      );
    }
  }
};
