import Axios from 'axios';
import moment from 'moment';
import { BASE_URI, LOCAL_TIMEOUT } from '../../constants';

const apiroundTripTracker = (
  paymentTransactionId,
  apiStartTime,
  apiName,
  statusCode
) => {
  const apiEndTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}`;
  global?.logger?.info(
    `[7POS UI] - ${apiName} statuscode:${statusCode} start time:${apiStartTime} and end Time:${apiEndTime} correlationId:${paymentTransactionId}`
  );
  if (apiStartTime !== '') {
    const transStartTime = apiStartTime?.slice(0, -1);
    let totalApiCompleteTime = moment
      .utc(
        moment(apiEndTime, 'YYYY-MM-DDTHH:mm:ss.SSS').diff(
          moment(transStartTime, 'YYYY-MM-DDTHH:mm:ss.SSS')
        )
      )
      .format('x');
    totalApiCompleteTime = Number(totalApiCompleteTime);
    global?.logger?.info(
      `[7POS UI] - ${apiName} RoundTrip:${totalApiCompleteTime} statusCode:${statusCode}`,
      { completeReqTTms: totalApiCompleteTime }
    );
  }
};

export const fetchDeviceSetupStatus = async ({ correlationID }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, LOCAL_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/auth/deviceSetupStatus`;

  const configResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    configResponse.status
  );
  return configResponse;
};

export const triggerAutoRegister = async ({ correlationID }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, LOCAL_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/auth/autoRegister`;

  const configResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    configResponse.status
  );
  return configResponse;
};

export const updateDeviceRegistrationStatus = async ({ correlationID }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, LOCAL_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9512/v1/api/updateSetupStatus`;

  const configResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  }).catch(e =>
    Logger?.info(
      `7POS Auto Registration: Writefile failed::- ${JSON.stringify(e)} `
    )
  );
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    configResponse.status
  );
  return configResponse;
};
