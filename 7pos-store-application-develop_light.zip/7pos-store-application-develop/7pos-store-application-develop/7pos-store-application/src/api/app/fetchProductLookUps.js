import Axios from 'axios';
import moment from 'moment';
import { apiroundTripTracker } from '../../Utils/appUtils';
import { BASE_URI, LOCAL_TIMEOUT } from '../../constants';

export const fetchProductLookUps = async ({ correlationID }) => {
  const cancelRequestSource = Axios.CancelToken.source();
  setTimeout(() => {
    cancelRequestSource.cancel();
  }, LOCAL_TIMEOUT);
  const apiStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
  const apiurl = `http://${BASE_URI}:9510/v1/api/productlookups`;

  const productResponse = await Axios({
    cancelToken: cancelRequestSource.token,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-Correlation-Id': correlationID,
    },
    url: apiurl,
  });
  apiroundTripTracker(
    correlationID,
    apiStartTime,
    apiurl,
    productResponse.status
  );
  return productResponse;
};
