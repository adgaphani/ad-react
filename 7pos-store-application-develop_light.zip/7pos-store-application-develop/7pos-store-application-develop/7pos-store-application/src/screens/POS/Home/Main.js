/* eslint-disable react/prop-types */
/* eslint-disable import/order */

import React from 'react';
import { Box, Flex, Grid, Heading, Text } from '@chakra-ui/react';
import { Button } from '../../../components/Common';
import { Route, Switch, useHistory, useRouteMatch } from 'react-router-dom';

import UserActionNotification from './UserActionNotification';
import SpeedyUserNotification from './SpeedyUserNotification';
import IdVerification from './IdVerification';
import ManualEntry from './IdVerification/ManualEntry';
import ItemGroupContainer from '../../../components/POS/Items/ItemGroupContainer';
import ItemGroup from '../../../components/POS/Items/ItemGroup';
import Keypad from '../../../components/Common/DailPad/Keypad/Keypad';
import OtherDepartments from '../../../components/POS/OtherDepartments/OtherDepartments';
import OtherFunctions from '../../../components/POS/OtherFunctions/OtherFunctions';
import PaidInOutParent from '../../../components/POS/OtherFunctions/PaidInOut/PaidInOutParent';
import PluSale from '../../../components/POS/PluSale/PluSale';
import Lottery from '../../../components/POS/Lottery/Lottery';
import SafeDrop from '../../../components/POS/Safe/SafeDrop';
import SharedUPC from '../../../components/POS/SharedUPC/SharedUPC';
import PriceOverride from '../Cart/PriceOverride/PriceOverride';
import MemberError from '../../../components/POS/7RewardsMemberError/7RewardsMemberError';
import MoneyOrderSale from '../MoneyOrder/moneyorderSale';
import TaxExempt from '../../../components/POS/OtherFunctions/TaxExempt';
import MoMRestrictionStatus from '../MoneyOrder/momRestriction';
import SevenRewards from '../SevenRewards/SevenRewards';
import Coupons from '../Coupons/Coupons';
import CardProcess from '../PrepaidCard/cardProcess';
import GS1Coupon from '../Coupons/GS1Coupon';
import PrepaidCardMenu from '../PrepaidCard/prepaidCardMenu';
import PrepaidCardLookup from '../PrepaidCard/prepaidCardLookup/prepaidCardLookup';
import Icon_Warning from '../../../Icons/Icon_Warning.svg';
import Charity from '../../../components/POS/OtherDepartments/Charity';
import TransactionInProgress from '../../../components/POS/BalanceInquiry/TransactionInProgress';
import BalanceInquiry from '../../../components/POS/BalanceInquiry/BalanceInquiryForCard';
import BalanceInquirySuccess from '../../../components/POS/BalanceInquiry/BalanceInquiryForCardResponse';
import ReceiptReprintCntrl from '../ReceiptReprint/receiptReprintCtrl';
import CurrencyConverter from '../../../components/POS/CurrencyConverter';
import Restart from '../../../components/POS/Restart/Restart';
import HandlingItemRemove from '../Cart/RemoveItemhandling';
import AbortConfirmation from '../Cart/abortConfirmation';
import ItemPrice from '../../../components/POS/PluSale/itemPrice';
import ItemReHeatScreen from '../../../components/POS/ItemReHeatScreen/ItemReHeatScreen';
import FunctionSecurity from './FunctionSecurity';
import { InvalidKey } from '../../../components/POS/InvalidKey';
import SearchPage from '../search/search';
import {
  PumpMaintenance,
  MPSPriceApproval,
  MPSPriceChangeConfirmation,
} from '../../../components/Fuel';
import POSOperatorMenu from '../../../components/POS/OperatorMenu/POSOperatorMenu';
import NetworkMaintenance from '../../../components/POS/OperatorMenu/NetworkMaintenance/NetworkMaintenance';
import OverrideItem from '../../../components/POS/OtherFunctions/OverrideItem';
import ForceFinalizeScreen from './ForceFinalizeScreen';
import NonIntegratedSafe from '../../../components/POS/Safe/NonIntegrated/NonIntegratedSafe';

const Main = ({
  items,
  onItemClickHandler,
  isTransactionRefund,
  refundPrepaidFlag,
  onCancel,
  onSelectItem,
  appRestart,
}) => {
  const { path } = useRouteMatch();
  const history = useHistory();

  const goToHome = () => {
    history.push('/home');
  };
  return (
    <Switch>
      <Route path={`${path}/`} exact>
        {/* <EmailR /> */}
        <Grid templateColumns="50% 50%">
          <Box marginLeft="7px">
            <Keypad />
          </Box>
          {isTransactionRefund && refundPrepaidFlag ? (
            <Box bg="rgb(255, 255, 255)" p={10}>
              <Flex justifyContent="center">
                <img
                  src={Icon_Warning}
                  // height="80px"
                  // width="80px"
                  alt="success"
                />
              </Flex>
              <Flex
                flexDirection="column"
                justifyContent="space-between"
                height="100%"
              >
                <Flex
                  flexDirection="column"
                  justifyContent="center"
                  textAlign="center"
                  alignItems="center"
                >
                  <Heading
                    textAlign="center"
                    justifyContent="center"
                    // color="rgb(111, 110, 127)"
                    mt={46}
                    style={{
                      width: '300px',
                      height: '64px',
                      color: 'rgb(44, 47, 53)',
                      fontSize: '24px',
                      fontFamily: 'Roboto-Bold',
                      fontWeight: 'bold',
                      textAlign: 'center',
                      lineHeight: '32px',
                    }}
                  >
                    Cannot return a sale containing a load.
                    <br />
                    <br />
                    {`Please use Other Functions > Void Transaction, to complete
                  this process.`}
                  </Heading>
                </Flex>
                <div style={{ textAlign: 'right' }}>
                  <Button
                    className="btn secondaryButton"
                    alignSelf="flex-end"
                    mb={30}
                    mr={15}
                    onClick={onCancel}
                  >
                    <Text>CANCEL</Text>
                  </Button>
                </div>
              </Flex>
            </Box>
          ) : (
            <ItemGroup
              items={items}
              minItems={24}
              onItemClick={onItemClickHandler}
            />
          )}
        </Grid>
      </Route>
      <Route path={`${path}/balance`} exact>
        <BalanceInquiry />
      </Route>
      <Route path={`${path}/currencyConverter`} exact>
        <CurrencyConverter />
      </Route>
      <Route path={`${path}/balance_success`} exact>
        <BalanceInquirySuccess />
      </Route>
      <Route path={`${path}/group`}>
        <ItemGroupContainer onItemClick={onItemClickHandler} />
      </Route>
      <Route path={`${path}/pluSale`}>
        <PluSale onExit={goToHome} />
      </Route>
      <Route path={`${path}/lottery`}>
        <Lottery />
      </Route>
      <Route path={`${path}/sharedUPC`} exact>
        <SharedUPC onExit={goToHome} onSelectItem={onSelectItem} />
      </Route>
      <Route path={`${path}/coupons`}>
        <Flex ml="7.5px">
          <Coupons />
        </Flex>
      </Route>
      <Route path={`${path}/7Rewards`}>
        <Flex width="97.5%" ml="7.5px">
          <SevenRewards />
        </Flex>
      </Route>
      <Route path={`${path}/priceOverride`}>
        <PriceOverride />
      </Route>
      <Route path={`${path}/CFDNotification`}>
        <UserActionNotification />
      </Route>
      <Route path={`${path}/SpeedyCFDNotification`}>
        <SpeedyUserNotification />
      </Route>
      <Route path={`${path}/forceFinalize`}>
        <ForceFinalizeScreen />
      </Route>
      <Route path={`${path}/otherDepartments`}>
        <OtherDepartments />
      </Route>
      <Route path={`${path}/charity`}>
        <Charity />
      </Route>
      <Route path={`${path}/otherFunctions`}>
        <OtherFunctions />
      </Route>
      <Route path={`${path}/PaidInOutParent`}>
        <PaidInOutParent />
      </Route>
      <Route path={`${path}/blockBalance`}>
        <TransactionInProgress />
      </Route>
      <Route path={`${path}/TaxExempt`}>
        <TaxExempt />
      </Route>
      <Route path={`${path}/OverrideItem`}>
        <OverrideItem />
      </Route>
      <Route path={`${path}/safeDrop`}>
        <SafeDrop />
      </Route>
      <Route path={`${path}/nonIntegratedSafe`}>
        <NonIntegratedSafe />
      </Route>
      <Route path={`${path}/verification`}>
        <Flex width="97.5%" ml="7.5px">
          <IdVerification />
        </Flex>
      </Route>
      <Route path={`${path}/manualEntry`}>
        <ManualEntry />
      </Route>
      <Route path={`${path}/7PosAppError`}>
        <MemberError />
      </Route>
      <Route path={`${path}/prepaidCardMenu`}>
        <PrepaidCardMenu />
      </Route>
      <Route path={`${path}/cardProcess`}>
        <CardProcess />
      </Route>
      <Route path={`${path}/prepaidCardLookup`}>
        <PrepaidCardLookup />
      </Route>
      <Route path={`${path}/itemPrice`}>
        <ItemPrice />
      </Route>
      <Route path={`${path}/GS1Coupon`}>
        <GS1Coupon />
      </Route>
      <Route path={`${path}/moneyorder`}>
        <MoneyOrderSale />
      </Route>
      <Route path={`${path}/momRestriction`}>
        <MoMRestrictionStatus />
      </Route>
      <Route path={`${path}/recieptReprint`}>
        <ReceiptReprintCntrl />
      </Route>
      <Route path={`${path}/invalidKey`}>
        <InvalidKey />
      </Route>
      <Route path={`${path}/restart`}>
        <Restart appRestart={appRestart} />
      </Route>
      <Route path={`${path}/operatormenu`} component={POSOperatorMenu} />
      <Route
        path={`${path}/networkMaintenance`}
        component={NetworkMaintenance}
      />
      <Route path={`${path}/pumpMaintenance`} component={PumpMaintenance} />
      <Route path={`${path}/mpsPriceApproval`} component={MPSPriceApproval} />
      <Route
        path={`${path}/mpsPriceChangeConfirmation`}
        component={MPSPriceChangeConfirmation}
      />
      <Route path={`${path}/removelastitem`}>
        <HandlingItemRemove />
      </Route>
      <Route path={`${path}/abortConfirmation`}>
        <AbortConfirmation />
      </Route>
      <Route path={`${path}/itemReHeatScreen`}>
        <ItemReHeatScreen />
      </Route>
      <Route path={`${path}/search`}>
        <SearchPage onItemClick={onItemClickHandler} />
      </Route>
      <Route path={`${path}/functionSecurity`}>
        <FunctionSecurity />
      </Route>
      <Route path={`${path}/operatormenu`} component={POSOperatorMenu} />
    </Switch>
  );
};

export default Main;
