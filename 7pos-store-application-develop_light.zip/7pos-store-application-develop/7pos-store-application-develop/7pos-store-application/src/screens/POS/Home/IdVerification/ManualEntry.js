import React, { useEffect, useContext, useState } from 'react';
import { Box, Flex, Grid, Text } from '@chakra-ui/react';
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import Keypad from '../../../../components/Common/DailPad/Keypad/Keypad';
import ExitButton from '../../../../components/POS/ExitButton';
import { MANUAL_ENTRY_CONTENT } from '../../../../constants';
import { cartActions } from '../../../../slices/cart.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import { buildCartChangeTrial } from '../../../../Utils/cartUtils';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { AppContext } from '../../../../AppContext';
import BirthDateInvalid from '../../../../components/POS/ModalPopups/ageRestriction/birthDateInvalidModal';

const ManualEntry = () => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const [isOpen, setIsOpen] = useState(false);
  const [ws] = useContext(WebSocketContext);
  const { errorSound } = useContext(AppContext) || {};
  const item = location?.state?.item;
  const restriction = location?.state?.restriction;
  const underAged = location?.state?.underAged;
  const {
    paymentTransactionId,
    tranItemSeqNumber,
    cartChangeTrial,
  } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    cartChangeTrial: state.cart.cartChangeTrial,
  }));

  const ageRestrictionCancelCMD = () => {
    const dlSwipeReq = appIntegrationRequest({
      type: 'Dlswipe_Complete',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
  };

  const createCartTrial = ({ name, eventResult }) => {
    const CartTrialPayLoad = buildCartChangeTrial({
      item: {
        name,
        tranItemSeqNumber: tranItemSeqNumber + 1,
      },
      eventType: 'addItemError',
      eventSeq: cartChangeTrial.length,
      eventResult,
    });
    dispatch(
      cartActions.addToCartChangeTrial({
        CartTrialPayLoad,
        tranItemSeqNumber: tranItemSeqNumber + 1,
      })
    );
  };

  const handleDOB = date => {
    const today = moment();
    const userDate = moment(date, 'MM/DD/YYYY');
    const age = today.diff(userDate, 'years');
    if (age >= restriction.ageRestriction) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      // ADDING Other Depts items with differant payload
      ageRestrictionCancelCMD();
      if (item?.otherDeptsCartPayload) {
        dispatch(cartActions.addToCart(item.otherDeptsCartPayload));
      } else {
        dispatch(cartActions.addToCart(item));
      }
      dispatch(dailpadActions.resetDailpadState());
      const agInformation = {
        birthDate: date,
        age,
      };
      dispatch(cartActions.setTranAgeVerifyInfo(agInformation));
      history.replace('/home');
    } else {
      errorSound && errorSound.play().catch(e => console.log('Sound error', e));
      setIsOpen(true);
      createCartTrial({
        name: 'Age Verification',
        eventResult: 'Age verification failed',
      });
    }
  };

  const onExit = () => {
    ageRestrictionCancelCMD();
    dispatch(dailpadActions.resetDailpadState());
    // #7339 added flag reset when user exit from validation
    dispatch(cfdActions.setUserActionScreenActive(false));
    createCartTrial({
      name: 'Age Verification',
      eventResult: 'SA Cancelled Age Verification',
    });
    history.replace('/home');
  };

  const onOk = () => {
    setIsOpen(false);
    ageRestrictionCancelCMD();
    dispatch(dailpadActions.resetDailpadState());
    dispatch(cfdActions.setUserActionScreenActive(false));
    history.replace('/home');
  };

  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(true));
    if (underAged) {
      ageRestrictionCancelCMD();
      errorSound && errorSound.play().catch(e => console.log('Sound error', e));
      setIsOpen(true);
      createCartTrial({
        name: 'Age Verification',
        eventResult: 'Age verification failed',
      });
    }
    return () => {};
  }, []);

  return (
    <>
      <Grid templateColumns="50% 50%">
        <Box marginLeft="7px">
          <Keypad onEnter={handleDOB} showAmounts={false} />
        </Box>
        <Flex
          h="100%"
          flexDirection="column"
          justifyContent="space-between"
          bg="rgb(255, 255, 255)"
          mr="0.5rem"
          ml="7px"
        >
          <Flex flexDirection="column" h="100%" pl="1.5rem">
            <Box
              color="rgb(50, 53, 61)"
              fontFamily="Roboto-Bold"
              fontSize="24px"
              fontWeight="bold"
              my="1.25rem"
            >
              Manual Entry
            </Box>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="20px"
              fontWeight="normal"
            >
              {MANUAL_ENTRY_CONTENT}
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExit} />
          </Box>
        </Flex>
      </Grid>
      <BirthDateInvalid
        isOpen={isOpen}
        onClose={onOk}
        onOk={onOk}
        item={item}
        MSG="BIRTHDATE INVALID"
      />
    </>
  );
};

export default ManualEntry;
