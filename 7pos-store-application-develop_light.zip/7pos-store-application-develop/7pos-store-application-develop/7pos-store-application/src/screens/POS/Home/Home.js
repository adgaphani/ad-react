/* eslint-disable no-else-return */
import moment from 'moment';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Box, Grid } from '@chakra-ui/react';
import { isValidUPC, getBarcodeData } from 'ris-js-common';
import {
  getHardTotalSummaryAttributeValues,
  // updateCacheHardTotals,
} from '7pos-hardtotals';
import {
  useCart,
  useCartCleanup,
  useSafe,
  useWSocket,
  useSoundToast,
  useTransHold,
  usePrivileges,
  useCacheItems,
} from '../../../hooks';
import { getItembyUpcApi } from '../../../api/cart';
import { SendMessageToCFD } from '../../../Communication';
import Cart from '../Cart/Cart';
import ConfirmModal from '../../../components/POS/ConfirmModal/ConfirmModal';
import AlphaNumericDailpad from '../../../components/Common/DailPad/AlphaNumericDailpad/AlphaNumericDailpad';
import CustomDailPad from '../../../components/Common/DailPad/CustomDailPad/CustomDailPad';
import { FuelPumps } from '../../../components/Fuel';
import Header from '../../../components/POS/Header/Header';
import MenuBar from '../../../components/POS/MenuBar/menuBar';
import Notifications from '../../../components/POS/Notifications/Notifications';
import { WebSocketContext } from '../../../components/Common/WebSocket/WebSocketProvider';
import { authActions } from '../../../slices/auth.slice';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { socketActions } from '../../../slices/socket.slice';
import {
  getStorageItems,
  getCorrelationID,
  verifyUserId,
  appendAdditionalPlu,
  appIntegrationRequest,
} from '../../../Utils/appUtils';
import { getPriceDetails } from '../../../Utils/cartUtils';
// import {
//   getDeviceInfo,
//   getStoreProfile,
//   getStoreDocumentsCount,
// } from '../../../Utils/configurationUtils';
import Styles from './home.module.css';

import Main from './Main';
import {
  getNewTransactionId,
  handlePayRequest,
  paymentRecepitRequest,
} from '../../../Utils/paymentUtils';
import { fetchPrepaidCardMenu } from '../../../api/app/fetchPrepaidCardMenu';
import { fetchDepartmentInfo } from '../../../api/app/fetchDepartmentInfo';
import { balanceCancelRequest } from '../../../Utils/balanceInquiryUtils';
import { fetchEmailReceipt } from '../../../api/payment';
import { getCartPayload } from '../../../Utils/otherDepartmentsUtils';

import {
  lookupRequest,
  isCardLoadsLimitCrossed,
} from '../../../Utils/cardLoadUtils';
import {
  BALANCE_INQUIRY_INVALID_CARD,
  BALANCE_INQUIRY,
  STTN_ENTRY_PROMPT,
  LOAD_REQUEST_INPROGRESS,
  WSTopics,
  ITEM_TYPE,
} from '../../../constants';
import { AppContext } from '../../../AppContext';
import { getDVR } from '../../../hardware/dvr';
import store from '../../../store';
import { useKeyBoardConfig } from '../../../hooks/useKeyBoardConfig';
// import { fetchCancelReward } from '../../../api/promoWrapper';

const NO_SALE_RESET = 0;
const NO_SALE_TRIGGER = 1;
const NO_SALE_TRIGGERED = 2;

const Home = ({ appRestart }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const toast = useSoundToast();
  const { clearTransHoldCart } = useTransHold();
  const [ws] = useContext(WebSocketContext);
  const [isOpen, setIsOpen] = useState(false);
  const [refundPrepaidFlag, setRefundPrepaidFlag] = useState(false);
  const [pluItems, setPluItems] = useState(null);
  const node = useRef();
  const { isConnected } = useWSocket();
  const { startLoading, stopLoading, errorSound } = useContext(AppContext);
  const { clearSafeDropCart } = useSafe();
  const { isFuelTransactionInProgress } = useCart();
  const { isValidUserFunction } = usePrivileges();
  const { cleanUpTransactionItems } = useCartCleanup();
  useCacheItems();
  const { getKeyBoardConfigIfNeeded } = useKeyBoardConfig();
  const {
    showAlphaNumericDailpad,
    dailpadValue,
    KeypadValue,
    showCustomDailPad,
    isTransactionFinalize,
    customDailpadProps,
    cartItems,
    member,
    // MemberRewardID,
    lookupCodes,
    saleHours,
    storeProfile,
    isTransactionRefund,
    isTransactionVoid,
    storeDetails,
    user,
    deviceInfo,
    transactionId,
    config,
    loadConfirm,
    loadSttn,
    prepaidAccNumberValue,
    RegistrationInvoke,
    keyConfig,
    displayToaster,
    loadPromptRequest,
    isTransHold,
    transactionMemory,
    EODEOSDetails,
    paymentTransactionId,
    hardTotal,
    taxInfo,
    transactionStartTime,
    pinpadPayStartTime,
    UserActionScreenActive,
    isFunctionSecurityTriggered,
    iFunctionSecurityData,
    isSpeedyStore,
    isCreditItem,
    isCreditItemInformation,
    channel,
    isPaymentTriggered,
    shiftNumber,
    isTransactionAborted,
    isAppLogin,
    itemQuantity,
    restrictedItemSale,
  } = useSelector(state => ({
    showAlphaNumericDailpad: state.dailpad.showAlphaNumericDailpad,
    showCustomDailPad: state.dailpad.showCustomDailPad,
    dailpadValue: state.dailpad.dailpadValue,
    KeypadValue: state.dailpad.keypad.value,
    isTransactionFinalize: state.cfd.isTransactionFinalize,
    customDailpadProps: state.dailpad.customDailpadProps,
    cartItems: state.cart.cartItems,
    taxInfo: state.cart.taxInfo,
    member: state.cart.member,
    // MemberRewardID: state.cfd.MemberRewardID,
    lookupCodes: state.main.lookupCodes,
    saleHours: state.main.saleHours,
    storeProfile: state.main.storeDetails,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
    notifications: state.notifications.notifications,
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
    deviceInfo: state.main.deviceInfo,
    transactionId: state.cart.transactionId,
    config: state.main.configuration,
    loadConfirm: state.cart.loadConfirm,
    loadSttn: state.cart.loadSttn,
    prepaidAccNumberValue: state.cart.prepaidAccNumberValue,
    ProductLookUpSynEvent: state.cart.ProductLookUpSynEvent,
    RegistrationInvoke: state.auth.RegistrationInvoke,
    keyConfig: state.main.keyConfig,
    displayToaster: state.cart.displayToaster,
    loadPromptRequest: state.cart.loadPromptRequest,
    isTransHold: state.cart.isTransHold,
    transactionMemory: state.cart.transactionMemory,
    EODEOSDetails: state.cart.EODEOSDetails,
    paymentTransactionId: state.cart.paymentTransactionId,
    hardTotal: state.cart.hardTotalSummary,
    transactionStartTime: state.cart.transactionStartTime,
    pinpadPayStartTime: state.cart.pinpadPayStartTime,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    isFunctionSecurityTriggered: state.cart.isFunctionSecurityTriggered,
    iFunctionSecurityData: state.cart.iFunctionSecurityData,
    functionSecuirtyData: state.main.functionSecuirtyData,
    isSpeedyStore: state.main.isSpeedyStore,
    isCreditItem: state.cart.isCreditItem,
    isCreditItemInformation: state.cart.isCreditItemInformation,
    channel: state.main.channel,
    isPaymentTriggered: state.cart.isPaymentTriggered,
    shiftNumber: state.main.shiftNumber,
    isTransactionAborted: state.cart.isTransactionAborted,
    isAppLogin: state.auth.isAppLogin,
    documentsCount: state.main.documentsCount,
    itemQuantity: state.cart.itemQuantity,
    restrictedItemSale: state.cart.restrictedItemSale,
  }));

  const [iNoSaleAction, setNoSaleAction] = useState(NO_SALE_RESET);

  const cashDrawerStatus = useSelector(state => state.socket.cashDrawerStatus);
  const cardStatus = useSelector(state => state.socket.cardStatus);
  const paymentMethod = useSelector(state => state.cart.paymentMethod);
  const loadBarcodeData = useSelector(state => state.cart.loadBarcodeData);
  const loadAmount = useSelector(state => state.cart.loadAmount);
  const tranAgeVerifyInfo = useSelector(state => state.cart.tranAgeVerifyInfo);

  const triggerDLSwipe = () => {
    const dlSwipeReq = appIntegrationRequest({
      type: 'Dlswipe_Req',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
    dispatch(cartActions.setFinalizePayStatus(false));
  };

  const DisplayToastMsg = (MSG, position = 'top-left', duration = 3000) => {
    toast({
      description: MSG,
      status: 'error',
      duration,
      position,
    });
  };

  const onCancel = () => {
    if (cartItems.length === 0) {
      dispatch(cartActions.setRefundTransaction(false));
      const iTransactionMessage = {
        CMD: 'IntialState',
        COUNTRY: storeDetails?.address?.country,
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
    }
    setRefundPrepaidFlag(false);
  };

  const updateDailPadValue = newValue => {
    dispatch(dailpadActions.setDailpadValue(newValue));
  };
  const [forcelogoff, setForceLogoff] = useState(false);
  const updatekeyConfig = async () => {
    try {
      const keyConfig = await getKeyBoardConfigIfNeeded();
      const keyBoardConfig = JSON.parse(keyConfig);
      const groups = keyBoardConfig.find(data =>
        data?.name?.toLowerCase()?.includes('keyboard')
      )?.groups;
      setPluItems(groups);
    } catch (e) {
      setForceLogoff(true);
      Logger.info(`7POS-UI : Exception Fetching Keyboard config, logging off`);
    }
  };
  useEffect(() => {
    if (!location?.state?.reset) return;
    updatekeyConfig();
    location.state.reset = false;
    history.push('/home');
  }, [location?.state]);

  const printRecepitData = async (type, receiptType = 'PRINT') => {
    let transInfo;
    if (type === 'noSale') {
      transInfo = {
        SUBTOTAL: '0.00',
        'TOTAL DUE': '0.00',
      };
    }
    const paymentReqdata = paymentRecepitRequest({
      storeDetails,
      deviceInfo,
      user,
      transactionId,
      transactionType: type,
      transInfo,
      config,
    });
    try {
      paymentReqdata.receiptType = receiptType;
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
      global?.logger?.info(`[7POS UI] - Print receipt API successful`);
    } catch (error) {
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        global?.logger?.error(
          `[7POS UI] - Print receipt API Failure ${JSON.stringify(error)}`
        );
        DisplayToastMsg(errorMessage.message);
      } else DisplayToastMsg('Receipt could not be printed. Please try again');
    }
  };
  const noSaleFlow = async () => {
    if (
      cashDrawerStatus === 'CD_OPEN_FAILED' ||
      cashDrawerStatus === 'CD_NOT_INITIALIZED'
    ) {
      dispatch(socketActions.setCashDrawerStatus(null));
      getDVR().setDrawerStatus(null, user);
      DisplayToastMsg('Unable to open Cash drawer');
      return;
    }
    const transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
    const noSaleReq = handlePayRequest({
      storeDetails,
      user,
      deviceInfo,
      member,
      transactionId,
      transactionStartTime: transStartTime,
      paymentTransactionId,
    });

    noSaleReq.transactionHeaderInfo.transactionType = 'NOSALE';
    noSaleReq.transactionHeaderInfo.transactionStatus = 'COMPLETE';
    const hardTotalSummary = [];
    hardTotalSummary.push(hardTotal);
    hardTotalSummary.push({
      name: 'runningTotal',
      count: 0,
      amount: 0,
    });
    noSaleReq.transactionDetails.hardTotalSummary = hardTotalSummary;
    const request = JSON.stringify(noSaleReq);
    /* await updateCacheHardTotals(request); */
    // CDB Media Number is not required for CASH, Adding only for CDB db
    // updateCdbReport({
    //   transactionRequest: request,
    // }); // CDB Update Nosale Media

    const noSaleRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'NOSALE',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PINPAD',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${request}`,
      },
    };
    const cPayrequest = JSON.stringify(noSaleRequest);
    localStorage.setItem('finalPaymentRequest', cPayrequest);
    global?.logger?.info(`[7POS UI] - pay request(NoSale) SENT`);
    ws.socket?.send('/app/payment', {}, JSON.stringify(noSaleRequest));
    getDVR().sendNoSale(
      config,
      deviceInfo,
      storeDetails,
      transStartTime,
      transactionId,
      user
    );
    printRecepitData('noSale');
    history.push({
      pathname: '/payment/cashDrawer',
      search: `?status=noSale`,
    });
  };

  const onSelectItem = (data, upc, saleHours, cb) => {
    if (
      !isTransactionFinalize &&
      (!UserActionScreenActive ||
        (UserActionScreenActive && // #5304 added path name as well to bypass notification
          (location?.pathname === '/home' ||
            location?.pathname === '/home/group')))
    ) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      const {
        citem,
        lookup,
        notVerified,
        underAged,
        restrictedHours,
      } = verifyUserId({
        data,
        lookupCodes,
        tranAgeVerifyInfo,
        saleHours,
        cartItems,
        storeDetails,
      });
      dispatch(dailpadActions.resetKeypadValue());
      if (Number(citem.itemRestrictionCode) === 6) {
        // Multi item click should not trigger reHeat on top of ageVerification: RISPIN5069
        if (
          window?.location?.pathname.includes('verification') ||
          window?.location?.pathname.includes('manualEntry')
        ) {
          return;
        }
        // Reheat screen trigger for code 6 items
        history.push({
          pathname: '/home/itemReHeatScreen',
          state: { item: citem, upc },
        });
        dispatch(cartActions.setFinalizePayStatus(false));
        return;
      }
      if (isFuelTransactionInProgress && citem.negativeSalesFlag) {
        // throw new Error('Invalid action with Fuel prepay')
        DisplayToastMsg(Messages.invalid_action_fuel);
        return;
      }
      const state = { item: { ...citem, upc }, restriction: lookup };
      if (restrictedHours && saleHours) {
        dispatch(cartActions.setRestrictedSale(true));
        return;
      }
      if (underAged) {
        // If Item Reheat Trigger, Reheat item need to be add to cart first
        if (window?.location?.pathname.includes('itemReHeatScreen')) {
          return;
        }
        history.push({
          pathname: '/home/manualEntry',
          state: {
            ...state,
            underAged: true,
            restriction: lookup,
          },
        });
        dispatch(cartActions.setFinalizePayStatus(false));
        return;
      }
      if (notVerified) {
        // If Item Reheat Trigger, Reheat item need to be add to cart first
        if (window?.location?.pathname.includes('itemReHeatScreen')) {
          return;
        }
        triggerDLSwipe();
        history.push({
          pathname: '/home/verification',
          state: { ...state, restriction: lookup },
        });
        return;
      }
      clearTransHoldCart();
      data.forEach(item => {
        dispatch(
          cartActions.addToCart({
            ...item,
            requiredAge: citem.requiredAge,
            upc,
          })
        );
      });
    } else {
      global?.logger?.error(
        `[7POS UI] - plusale Finalize inprogress ignore to add item.`
      );
    }
    dispatch(dailpadActions.resetKeypadValue());
    cb?.();
  };

  const addItemByUPC = async upc => {
    let formattedUPC = upc;
    if (!upc) {
      DisplayToastMsg('Please enter valid UPC.');
      return;
    } else if (upc.length > 14) {
      DisplayToastMsg('Invalid UPC number. Please check and re-enter.');
      global?.logger?.error(`[7POS UI] - Invalid UPC number:${upc}`);
      return;
    } else if (
      (UserActionScreenActive && // #5304 added path name as well to bypass notification
        location?.pathname !== '/home' &&
        location?.pathname !== '/home/group') ||
      isTransactionFinalize
    ) {
      global?.logger?.error(
        `[7POS UI] - plusale Finalize inprogress ignore to add item.`
      );
      return;
    }
    try {
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setFinalizePayStatus(true));
      const barcode = isSpeedyStore
        ? getBarcodeData(upc, 'MANUAL', 'SpeedyStore')
        : getBarcodeData(upc, 'MANUAL');
      formattedUPC = barcode.gtin;
      if (barcode.gtin) {
        const response = await getItembyUpcApi(
          barcode.gtin,
          '',
          paymentTransactionId
        );
        const data = response;
        global?.Logger?.debug(`[7POS UI] - fetch Item Success`);
        if (data.length > 1) {
          const eligibleLItems = data?.filter(i => i.retailPrice);
          if (!eligibleLItems.length) {
            throw new Error(
              'Linked Items :- Items not found with retails Price'
            );
          }
          if (eligibleLItems.length > 1) {
            history.push({
              pathname: '/home/sharedUPC',
              state: {
                items: eligibleLItems,
              },
            });
            dispatch(cartActions.setFinalizePayStatus(false));
            return;
          } else {
            dispatch(cartActions.setFinalizePayStatus(false));
            onSelectItem(eligibleLItems, barcode.gtin);
            return;
          }
        }
        onSelectItem(data, barcode.gtin);
      } else {
        DisplayToastMsg('Invalid UPC number. Please check and re-enter.');
        global?.logger?.error(`[7POS UI] - Invalid UPC number:${barcode.gtin}`);
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - fetch Item failed:${JSON.stringify(error)}`
      );
      // #6369 updated formatted upc to transaction area
      const item = {
        upc: formattedUPC,
      };
      const isValid = isValidUPC(formattedUPC);
      if (isValid) {
        DisplayToastMsg('Item Not Found');
        history.push({
          pathname: '/home/itemPrice',
          state: { item },
        });
      } else {
        DisplayToastMsg('Invalid UPC number. Please check and re-enter.');
        global?.logger?.error(`[7POS UI] - Invalid UPC number:${upc}`);
      }
    }
    dispatch(cartActions.setFinalizePayStatus(false));
  };
  const loadRequest = () => {
    if (!KeypadValue || Number(KeypadValue) <= 0) {
      DisplayToastMsg('Please enter load amount then press load.');
      history.push('/home');
      return;
    }
    history.push({
      pathname: '/home/cardProcess',
      state: { type: 'load', amount: Number(KeypadValue) / 100 },
    });
  };

  const addDepartmentItemInCart = async (itemId, item = {}, DeptAmt) => {
    try {
      let deptResponse = await fetchDepartmentInfo(
        itemId,
        paymentTransactionId
      );
      deptResponse = JSON.parse(deptResponse.data.data)?.map(i => ({
        ...i,
        itemRestrictionCode: Number(i.ageRestriction),
      }));
      deptResponse = deptResponse.length > 0 ? deptResponse[0] : {};
      global?.Logger?.debug(
        `[7POS UI] - fetch Department  Success:${JSON.stringify(deptResponse)}`
      );
      const MaxallowedItemPrice =
        config?.storeConfig?.maxAllowedItemPrice !== undefined
          ? Number(config?.storeConfig?.maxAllowedItemPrice)
          : 0;
      if (
        deptResponse?.lowAmountLockout &&
        deptResponse?.lowAmountLockout > 0 &&
        Number(DeptAmt / 100) < deptResponse?.lowAmountLockout
      ) {
        DisplayToastMsg(
          `Amount too small. Minimum is $${parseFloat(
            deptResponse?.lowAmountLockout
          ).toFixed(2)}`
        );
      } else if (
        (deptResponse?.highAmountLockout &&
          deptResponse?.highAmountLockout > 0 &&
          Number(DeptAmt) / 100 > deptResponse.highAmountLockout) ||
        Number(DeptAmt) / 100 > 999999 ||
        (MaxallowedItemPrice !== 0 &&
          Number(DeptAmt) / 100 > MaxallowedItemPrice)
      ) {
        const Amount = parseFloat(
          deptResponse.highAmountLockout < MaxallowedItemPrice ||
            MaxallowedItemPrice === 0
            ? deptResponse.highAmountLockout
            : MaxallowedItemPrice
        ).toFixed(2);
        DisplayToastMsg(`Amount too large. Maximum is $${Amount}`);
      } else {
        const {
          citem,
          lookup,
          notVerified,
          underAged,
          restrictedHours,
        } = verifyUserId({
          data: deptResponse,
          lookupCodes,
          tranAgeVerifyInfo,
          cartItems,
          storeDetails,
        });
        const payload = getCartPayload({
          productCategoryId: itemId,
          deptInfo: {
            ...deptResponse,
            requiredAge: citem.requiredAge,
          },
          selectedItem: item.name,
          departmentAmount: DeptAmt,
        });
        dispatch(dailpadActions.resetKeypadValue());
        const state = {
          item: { ...item, otherDeptsCartPayload: payload },
          restriction: lookup,
        };
        if (restrictedHours && saleHours) {
          dispatch(cartActions.setRestrictedSale(true));
          return;
        }
        if (underAged) {
          history.push({
            pathname: '/home/manualEntry',
            state: { ...state, underAged: true },
          });
          return;
        }
        if (notVerified) {
          triggerDLSwipe();
          history.push({ pathname: '/home/verification', state });
          return;
        }
        dispatch(cartActions.addToCart(payload));
        global?.logger?.info(`[7POS UI] - fetchDepartmentInfo successful`);
      }
    } catch (error) {
      DisplayToastMsg(`Department Not Found`);
      global?.logger?.error(
        `[7POS UI] - fetchDepartmentInfo details Error ${JSON.stringify(error)}`
      );
    }
    history.push('/home');
    dispatch(dailpadActions.resetKeypadValue());
  };

  const onItemClickHandler = async item => {
    if (
      cashDrawerStatus === 'CD_OPEN_OK' ||
      cashDrawerStatus === 'CD_IS_OPEN' ||
      cashDrawerStatus === 'CD_ALARM_ON'
    ) {
      DisplayToastMsg('Please close cash drawer', 'top');
      return;
    }
    const { name } = item;
    const itemLabel = name;
    clearSafeDropCart();
    if (itemQuantity > 1) {
      if (
        itemLabel?.toLowerCase() !== 'other functions' &&
        itemLabel?.toLowerCase() !== 'otherfunctions' &&
        itemLabel?.toLowerCase() !== 'operatormenu' &&
        itemLabel?.toLowerCase() !== 'otherdepartment' &&
        itemLabel?.toLowerCase() !== 'other depts' &&
        itemLabel?.toLowerCase() !== 'safedrop' &&
        (item.upc ||
          itemLabel?.toLowerCase() === 'plusale' ||
          item.type.toLowerCase() === 'subgroup' ||
          itemLabel?.toLowerCase() === 'pluinquiry' ||
          (item.type.toLowerCase() === 'group' &&
            item?.keys[0].subKeys?.length > 0))
      ) {
        Logger.info(
          `7POS Application -onItemClickHandler with Qty:${itemQuantity}`
        );
      } else {
        Logger.error(
          `7POS Application -onItemClickHandler with Qty:${itemQuantity} Action:${name} not applicable`
        );
        DisplayToastMsg('Invalid key for qty multiplier.');
        return;
      }
    }
    let isUserHavePermission = true;
    if (isFunctionSecurityTriggered === '') {
      isUserHavePermission = isValidUserFunction(itemLabel?.toLowerCase());
    } else {
      dispatch(cartActions.setFunctionSecurityTriggered(''));
    }
    if (!isUserHavePermission) {
      // #5245 added screen redirection for only refund on home screen
      dispatch(cartActions.setFunctionSecurityData(item));
      history.push({
        pathname: '/home/functionSecurity',
        redirectionData:
          item?.name?.toLowerCase() === 'refund'
            ? {
                pathname: '/home',
              }
            : undefined,
        KeypadValue,
        triggerFrom: 'home',
        iFunctionName: itemLabel?.toLowerCase(),
      });
      return;
    }
    const { finalTotalPrice } = getPriceDetails(cartItems, taxInfo);
    if (`${itemLabel}`?.toLowerCase().includes('mediaexchange')) {
      if (!Number(finalTotalPrice || 0)) {
        DisplayToastMsg('Invalid key');
        return;
      }
      history.push({
        pathname: '/home/currencyConverter',
        search: `?itemId=${Date.now()}`,
        route: '/home',
      });
      return;
    } else if (`${itemLabel}`?.toLowerCase().includes('ageverify')) {
      let transStartTime = transactionStartTime;
      if (transactionStartTime === '') {
        transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
        dispatch(cartActions.setTransactionStartTime(transStartTime));
      }
      // trigger enable MSR for DL Swipe Age verification
      triggerDLSwipe();
      const stateCode = storeDetails?.address?.state;
      const listOfRestrictedStates = ['AB', 'SK', 'MB'];
      const ageRestriction = listOfRestrictedStates.includes(stateCode)
        ? 18
        : 19;
      history.push({
        pathname: '/home/verification',
        search: `?itemId=${Date.now()}`,
        state: {
          restriction: {
            ageRestriction,
            code: 1,
            description: `ID is required for 30 and under. Must be ${ageRestriction} to purchase. \n Picture on ID must match the customer`,
            driverLicenseVerifyFlag: true,
            enterIdForVerificafionFlag: true,
            isVisualIdVerficationAllowed: false,
          },
          item: {
            name: 'Age Verify',
            quantity: 1,
            preAgeVerify: true,
            retailPrice: 0,
            itemTaxes: { taxId: [] },
          },
        },
      });
      return;
    } else if (itemLabel?.toLowerCase() === 'pluinquiry') {
      history.push({
        pathname: '/home/search',
        state: {},
      });
      return;
    } else if (name?.toLowerCase() === 'operatormenu') {
      // #4231 Added member/void/refund/item
      if (
        cartItems?.length ||
        member ||
        isTransactionRefund ||
        isTransactionVoid
      ) {
        DisplayToastMsg('Invalid key,You are in a transaction.');
        return;
      } else {
        history.push({
          pathname: '/home/operatormenu',
          state: {
            items: item.keys ? item.keys : item.subKeys,
          },
        });
        return;
      }
    } else if (
      itemLabel?.toLowerCase() === 'plu sale' ||
      itemLabel?.toLowerCase() === 'plusale'
    ) {
      clearTransHoldCart();
      const upc = KeypadValue;
      const BarcodeData = `${upc}`;
      if (BarcodeData[0] === '5' && BarcodeData.length === 12) {
        dispatch(cartActions.setGS1CouponBarcode(BarcodeData));
        dispatch(cartActions.settriggerCouponValidation(true));
        dispatch(dailpadActions.resetKeypadValue());
      } else {
        addItemByUPC(upc);
      }
      history.push('/home');
      return;
    } else if (itemLabel?.toLowerCase() === 'lottery') {
      history.push('/home');
      return;
    } else if (
      itemLabel?.toLowerCase() === 'sub total' ||
      itemLabel?.toLowerCase() === 'subtotal'
    ) {
      history.push('/home');
      return;
    } else if (
      itemLabel?.toLowerCase() === 'balance inquiry' ||
      itemLabel?.toLowerCase() === 'balanceinquiry'
    ) {
      clearTransHoldCart();
      if (
        cartItems.length > 0 ||
        isTransactionRefund ||
        isTransactionVoid ||
        member
      ) {
        errorSound?.play?.().catch(e => console.log('Sound error', e));
        return history.push('/home/blockBalance');
      }
      localStorage.removeItem('StoreSeqAndHardTotals');
      const summary = await getHardTotalSummaryAttributeValues('nrgt');
      global?.logger?.info(
        `[7POS UI] - getHardTotalSummaryAttributeValues ${JSON.stringify(
          summary
        )}`
      );
      dispatch(cartActions.setHardTotalSummary(summary));
      if (transactionStartTime === '') {
        const transactionStartTime = `${moment
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
        dispatch(cartActions.setTransactionStartTime(transactionStartTime));
      }
      if (pinpadPayStartTime === '') {
        const pPayStartTime = `${moment
          .utc()
          .format('YYYY-MM-DDTHH:mm:ss.SSS')}`;
        dispatch(cartActions.setPinpadPayStartTime(pPayStartTime));
      }
      history.push('/home/balance');
      return;
    } else if (
      itemLabel?.toLowerCase() === 'no sale' ||
      itemLabel?.toLowerCase() === 'nosale'
    ) {
      // #4231 Added member/void/refund/item check before trigger No sale
      if (
        cartItems?.length ||
        member ||
        isTransactionRefund ||
        isTransactionVoid
      ) {
        DisplayToastMsg('Invalid key,You are in a transaction.');
        history.push('/home'); // #7167 move redirection from below return
        return;
      } else {
        localStorage.removeItem('StoreSeqAndHardTotals');
        clearTransHoldCart();
        const summary = await getHardTotalSummaryAttributeValues('nrgt');
        global?.logger?.info(
          `[7POS UI] - getHardTotalSummaryAttributeValues ${JSON.stringify(
            summary
          )}`
        );
        dispatch(cartActions.setHardTotalSummary(summary));
        setNoSaleAction(NO_SALE_TRIGGER);
        ws.socket?.send(WSTopics.cashdrawer.open);
        global?.logger?.info(
          `[7POS UI] -  Sent cash drawer open event(No sale)`
        );
      }
      return;
    } else if (
      itemLabel?.toLowerCase() === 'other functions' ||
      itemLabel?.toLowerCase() === 'otherfunctions'
    ) {
      history.push({
        pathname: '/home/otherFunctions',
        search: `?itemId=${item.id}`,
        state: {
          items: item.keys ? item.keys : item.subKeys,
        },
      });
      return;
    } else if (
      itemLabel?.toLowerCase() === 'other depts' ||
      itemLabel?.toLowerCase() === 'otherdepartment'
    ) {
      if (KeypadValue === 0 || KeypadValue === '0' || KeypadValue === '') {
        DisplayToastMsg('Please enter the amount.');
        history.push('/home');
        return;
      }
      history.push({
        pathname: '/home/otherDepartments',
        search: `?itemId=${item.id}`,
        state: {
          items: item.keys ? item.keys : item.subKeys,
        },
      });
      return;
    } else if (
      itemLabel?.toLowerCase() === 'safe drop' ||
      itemLabel?.toLowerCase() === 'safedrop'
    ) {
      if (
        isTransactionRefund ||
        isTransactionVoid ||
        cartItems.length > 0 ||
        !isConnected
      ) {
        DisplayToastMsg(
          isTransactionRefund || isTransactionVoid
            ? Messages.invalid_key
            : !isConnected
            ? 'No Websocket Connection'
            : 'Another transaction in progress'
        );
        history.push('/home');
        return;
      }
      dispatch(cartActions.setIsSafeDrop(true));
      if (config?.safeConfig?.isIntegrated) history.push('/home/safeDrop');
      else history.push('/home/nonIntegratedSafe');
      return;
    } else if (
      itemLabel?.toLowerCase() === 'prepaid card' ||
      itemLabel?.toLowerCase() === 'prepaidcard'
    ) {
      // Here checking only Max cardload Qty so putting loadAmount zero
      const loadAmount = 0;
      const { isError, displayErrorMsg } = isCardLoadsLimitCrossed(
        cartItems,
        config,
        loadAmount,
        isTransactionVoid,
        isFuelTransactionInProgress,
        Messages
      );
      if (isError) {
        dispatch(dailpadActions.resetDailpadState());
        DisplayToastMsg(displayErrorMsg);
        history.push('/home');
        return;
      }
      if (isTransactionRefund) {
        setRefundPrepaidFlag(true);
      } else {
        try {
          startLoading();
          const pluResponse = await fetchPrepaidCardMenu({
            correlationID: paymentTransactionId,
          });
          const response = JSON.parse(JSON.stringify(pluResponse.data));
          global?.logger?.info(
            `[7POS UI] - fetchPrepaidCardMenu details success ${JSON.stringify(
              response
            )}`
          );
          history.push({
            pathname: '/home/prepaidCardMenu',
            state: {
              borderClass: item.borderClass,
              cardList: response.keys,
            },
          });
        } catch (error) {
          stopLoading();
          console.error(error);
          global?.logger?.error(
            `[7POS UI] - fetchPrepaidCardMenu details Error ${JSON.stringify(
              error
            )}`
          );
          history.push('/home');
        }
        stopLoading();
      }
      return;
    } else if (itemLabel?.toLowerCase() === 'coupon') {
      if (cartItems?.length) {
        history.push('/home/coupons');
      } else {
        DisplayToastMsg('Invalid Operation, Cart is Empty');
        history.push('/home');
      }
      return;
    } else if (itemLabel?.toLowerCase() === 'load') {
      const loadAmount = Number(KeypadValue) / 100;
      const { isError, displayErrorMsg } = isCardLoadsLimitCrossed(
        cartItems,
        config,
        loadAmount,
        isTransactionVoid,
        isFuelTransactionInProgress,
        Messages
      );
      if (isError) {
        dispatch(dailpadActions.resetDailpadState());
        DisplayToastMsg(displayErrorMsg);
        history.push('/home');
        return;
      }
      if (isTransactionRefund) {
        dispatch(dailpadActions.resetDailpadState());
        setRefundPrepaidFlag(true);
      } else {
        loadRequest();
      }
      return;
    } else if (itemLabel?.toLowerCase() === 'refund') {
      if (cartItems?.length === 0 && !member && !isTransactionVoid) {
        dispatch(cartActions.setRefundTransaction(true));
      } else {
        DisplayToastMsg('Refund Not Allowed');
        history.push('/home');
      }
      return;
    } else if (
      itemLabel?.toLowerCase() === 'money order' ||
      itemLabel?.toLowerCase() === 'moneyorder'
    ) {
      if (
        config?.moneyOrderConfig?.isIntegrated &&
        config?.moneyOrderConfig?.isMoneyOrderStore
      ) {
        history.push('/home/moneyorder');
      } else {
        DisplayToastMsg('MO NOT CONNECTED');
        history.push('/home');
      }
      return;
    } else if (
      itemLabel?.toLowerCase() === 'receipt reprint' ||
      itemLabel?.toLowerCase() === 'receiptreprint'
    ) {
      if (cartItems.length > 0) {
        DisplayToastMsg('RECEIPT REPRINT NOT AVAILABLE');
        return history.push('/home');
      }
      return history.push('/home/recieptReprint');
    } else if (itemLabel?.toLowerCase() === 'lotto') {
      const DeptAmt = store.getState().dailpad.keypad.value;
      if (DeptAmt === 0 || DeptAmt === '0' || DeptAmt === '') {
        DisplayToastMsg('Please enter the amount.');
        history.push('/home');
        return;
      }
      const lItem = [
        {
          name: 'Lotto Sale',
          productCategoryId: 62,
        },
      ];
      const itemId = item.productCategoryId.toString() || '62';
      // #8342 reset key board value and amount send as argument
      dispatch(dailpadActions.resetKeypadValue());
      addDepartmentItemInCart(itemId, lItem, DeptAmt);
      return;
    } else if (
      // home screen changes
      itemLabel?.toLowerCase() === 'lottowins' ||
      itemLabel?.toLowerCase() === 'lotto wins'
    ) {
      const DeptAmt = store.getState().dailpad.keypad.value;
      if (DeptAmt === 0 || DeptAmt === '0' || DeptAmt === '') {
        DisplayToastMsg('Please enter the amount.');
        history.push('/home');
        return;
      }
      const lItem = [
        {
          name: 'Lotto win',
          productCategoryId: 63,
        },
      ];
      const itemId = item.productCategoryId.toString() || '63';
      dispatch(dailpadActions.resetKeypadValue());
      addDepartmentItemInCart(itemId, lItem, DeptAmt);
      return;
    } else if (itemLabel?.toLowerCase() === 'scratch') {
      const DeptAmt = store.getState().dailpad.keypad.value;
      if (DeptAmt === 0 || DeptAmt === '0' || DeptAmt === '') {
        DisplayToastMsg('Please enter the amount.');
        history.push('/home');
        return;
      }
      const lItem = [
        {
          name: 'Scratch',
          productCategoryId: 60,
        },
      ];
      const itemId = item.productCategoryId.toString() || '60';
      dispatch(dailpadActions.resetKeypadValue());
      addDepartmentItemInCart(itemId, lItem, DeptAmt);
      return;
    } else if (
      itemLabel?.toLowerCase() === 'scratch wins' ||
      itemLabel?.toLowerCase() === 'scratchwins'
    ) {
      const DeptAmt = store.getState().dailpad.keypad.value;
      if (DeptAmt === 0 || DeptAmt === '0' || DeptAmt === '') {
        DisplayToastMsg('Please enter the amount.');
        history.push('/home');
        return;
      }
      const lItem = [
        {
          name: 'Scratch Win',
          productCategoryId: 61,
        },
      ];
      const itemId = item.productCategoryId.toString() || '61';
      dispatch(dailpadActions.resetKeypadValue());
      addDepartmentItemInCart(itemId, lItem, DeptAmt);
      return;
    }
    if (
      (item.type.toLowerCase() === 'group' ||
        item.type.toLowerCase() === 'subgroup') &&
      item.isNextLevelExist
    ) {
      history.push({
        pathname: '/home/group',
        search: `?itemId=${item.id}`,
        state: {
          items: item.keys ? item.keys : item.subKeys,
        },
      });
    } else {
      try {
        if (
          !item.upc ||
          (UserActionScreenActive && // #5304 added path name as well to bypass notification
            location?.pathname !== '/home' &&
            location?.pathname !== '/home/group')
        ) {
          return;
        }
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setFinalizePayStatus(true));
        const response = await getItembyUpcApi(
          item.upc,
          item.itemId,
          paymentTransactionId
        );
        const data = response;
        global?.Logger?.debug(`[7POS UI] - fetch Item Success`);
        if (data.length > 1) {
          const eligibleLinkedItems = data.filter(i => i.retailPrice);
          if (!eligibleLinkedItems.length) {
            throw new Error('Item Not Found');
          }
          if (eligibleLinkedItems?.length > 1) {
            history.push({
              pathname: '/home/sharedUPC',
              state: {
                items: eligibleLinkedItems,
              },
            });
            dispatch(cartActions.setFinalizePayStatus(false));
            return;
          } else {
            dispatch(cartActions.setFinalizePayStatus(false));
            onSelectItem(eligibleLinkedItems, item.upc, saleHours);
            return;
          }
        }
        onSelectItem(data, item.upc, saleHours);
      } catch (error) {
        global?.logger?.error(
          `[7POS UI] - fetch Item failed:${JSON.stringify(error)}`
        );
        const isitem = {
          upc: item.upc,
        };
        const isValid = isValidUPC(item.upc);
        if (isValid) {
          DisplayToastMsg('Item Not Found');
          history.push({
            pathname: '/home/itemPrice',
            state: { item: isitem },
          });
        } else {
          DisplayToastMsg('Invalid UPC number. Please check and re-enter.');
          global?.logger?.error(`[7POS UI] - Invalid UPC number:${item.upc}`);
          history.push('/home');
        }
      }
      dispatch(cartActions.setFinalizePayStatus(false));
    }
  };

  useEffect(() => {
    if (
      isFunctionSecurityTriggered === 'home' &&
      iFunctionSecurityData !== null
    ) {
      const item = iFunctionSecurityData;
      dispatch(cartActions.setFunctionSecurityData(null));
      onItemClickHandler(item);
    } else if (
      // #5503 Added function security for void Item
      isFunctionSecurityTriggered === 'voidItem' &&
      iFunctionSecurityData !== null
    ) {
      dispatch(cartActions.setFinalizePayStatus(true));
      const item = iFunctionSecurityData;
      const payload = {
        itemId:
          (item?.itemTypeID === ITEM_TYPE.DEPT && item?.departmentId) ||
          item.itemId,
        quantity: item.quantity - 1,
        indx: item.itemSeq,
      };
      if (item.couponRemainQty < 1) {
        dispatch(cartActions.removeAssociateCoupon({ item }));
      }
      dispatch(cartActions.updateQuantity(payload));
      dispatch(cartActions.setFunctionSecurityData(null));
      dispatch(cartActions.setFunctionSecurityTriggered(''));
      global?.logger?.info(`decItemQuantity Qty: ${JSON.stringify(payload)}`);
    } else if (
      isFunctionSecurityTriggered === 'removeItem' &&
      iFunctionSecurityData !== null
    ) {
      dispatch(cartActions.setFinalizePayStatus(true));
      const item = iFunctionSecurityData;
      const payload = {
        itemId: item.itemId,
        itemSeq: item.itemSeq,
        sttn: item?.sttn || 0,
      };
      if (item.couponRemainQty < 1) {
        dispatch(cartActions.removeAssociateCoupon({ item }));
      }
      dispatch(cartActions.removeFromCart(payload));
      dispatch(cartActions.setFunctionSecurityData(null));
      dispatch(cartActions.setFunctionSecurityTriggered(''));
      global?.logger?.info(
        `removeItemFromCart Qty: ${JSON.stringify(payload)}`
      );
    }
  }, [isFunctionSecurityTriggered]);

  // #1245 Credit Item Restriction handling
  useEffect(() => {
    if (isCreditItem) {
      const maxCreditItems = localStorage.getItem('maxCreditItems');
      dispatch(cartActions.setCreditItem(false));
      let count = 0;
      cartItems.forEach(item => {
        if (
          item?.itemId === isCreditItemInformation?.itemId &&
          item?.upc === isCreditItemInformation?.upc
        ) {
          count += item.quantity;
        }
      });
      if (count >= maxCreditItems || count + itemQuantity > maxCreditItems) {
        DisplayToastMsg(
          'INVALID ENTRY - MAX CREDIT ITEMS ALREADY EXISTS IN THE TRANSACTION'
        );
        dispatch(cartActions.setCreditItemInformation(null));
        dispatch(cartActions.setCreditItemOverride(false));
        dispatch(cartActions.setItemQuantity(0));
      } else {
        dispatch(cartActions.setCreditItemOverride(true));
        dispatch(cartActions.addToCart(isCreditItemInformation));
        dispatch(cartActions.setCreditItemInformation(null));
      }
    }
  }, [isCreditItem]);

  const loadReqCall = () => {
    const { item, type = '' } = location?.state || {};
    if (loadAmount > 0) {
      const { isError, displayErrorMsg } = isCardLoadsLimitCrossed(
        cartItems,
        config,
        loadAmount,
        isTransactionVoid,
        isFuelTransactionInProgress,
        Messages
      );
      if (isError) {
        global?.logger?.error(
          `[7POS UI] - card lookup failed:${displayErrorMsg}`
        );
        dispatch(dailpadActions.resetDailpadState());
        DisplayToastMsg(displayErrorMsg);
        const cancelLoadFromPos = true;
        SendMessageToCFD({ CMD: 'PrepaidLoadConfirm', cancelLoadFromPos });
        dispatch(cartActions.setCardLoadReset());
        history.push('/home');
        return;
      }
    }
    startLoading();
    const lookupReq = lookupRequest({
      item,
      type,
      amount: loadAmount * 100,
      loadBarcodeData,
      storeDetails,
      deviceInfo,
      location,
      prepaidAccNumberValue,
      isTransactionVoid,
      loadSttn,
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/pinpad/cardLoad', {}, JSON.stringify(lookupReq));
    dispatch(cartActions.setLookUpCallProgress(LOAD_REQUEST_INPROGRESS));
  };

  const retrieveOldTransaction = () => {
    const transactionId = localStorage.getItem('transactionId');
    const cartInfo = getStorageItems();
    if (!cartInfo) return;

    try {
      const {
        cartItems = [],
        taxInfo = {},
        member = {},
        fuel = [],
        isTransactionVoid,
        isTransactionRefund,
        cartChangeTrial = [],
        runningTotal = 0,
        preCartItems = [],
        loadCardMediaList = [],
        EODEOSDetails = {},
        isTransHold,
        transactionMemory,
        showTransHoldText,
        tenderSequenceNumber,
        transactionStartTime,
        MemberBarcodeInfo = {},
        tranAgeVerifyInfo = [],
        tranItemSeqNumber = 0,
        isMoMAllowed,
      } = cartInfo;
      const transHoldDetails = {
        isTransHold,
        transactionMemory,
        showTransHoldText,
      };
      global?.logger?.info(`[7POS UI] - retrieve cartInfo to local store `);
      dispatch(cartActions.setMoMAllowedStatus(isMoMAllowed));
      dispatch(cartActions.emptyCart({ skipStoreSeqNumber: true }));
      if (runningTotal && Math.abs(runningTotal) > 0) {
        dispatch(cartActions.setrunningTotal(runningTotal));
      }
      if (transactionStartTime !== '') {
        dispatch(cartActions.setTransactionStartTime(transactionStartTime));
      }
      if (preCartItems && preCartItems?.length > 0) {
        dispatch(cartActions.setPreCartItems(preCartItems));
      }
      if (loadCardMediaList && loadCardMediaList?.length > 0) {
        dispatch(cartActions.setCardMediaList(loadCardMediaList));
      }
      // Preserve tender sequence number for Idle logout.
      if (tenderSequenceNumber && tenderSequenceNumber > 0)
        dispatch(cartActions.setTenderSequenceNumber(tenderSequenceNumber));
      if (EODEOSDetails?.length > 0) {
        dispatch(
          cartActions.setEODEOS({
            eventNumber: EODEOSDetails?.eventNumber,
            type: EODEOSDetails?.type,
            IntiateEODEOS: EODEOSDetails?.IntiateEODEOS,
            isCartItemsOnClear: EODEOSDetails?.isCartItemsOnClear,
          })
        );
      }
      if (tranAgeVerifyInfo)
        dispatch(cartActions.setAgeInformation(tranAgeVerifyInfo));
      if (member) dispatch(cartActions.setMemberDetails(member));
      if (fuel?.length) {
        fuel.forEach(fuelItem => dispatch(cartActions.saveFuelData(fuelItem)));
      }
      if (isTransactionVoid !== null || isTransactionVoid !== undefined) {
        dispatch(cartActions.setVoidTransaction(isTransactionVoid));
      }
      if (isTransactionRefund !== null || isTransactionRefund !== undefined) {
        dispatch(cartActions.setRefundTransaction(isTransactionRefund));
      }
      if (cartItems?.length) {
        if (transactionId) {
          dispatch(cartActions.setTransactionId(transactionId));
        }
        cartItems.forEach(item => {
          dispatch(
            cartActions.addToCart({
              ...item,
              retailPrice: item.retailPrice / 100,
              retrieveOldTransaction: true,
            })
          );
        });
      }
      if (taxInfo)
        dispatch(
          cartActions.setTaxInfo({
            tax: taxInfo,
          })
        );
      if (cartChangeTrial && cartChangeTrial?.length) {
        dispatch(cartActions.setCartChangeTrial(cartChangeTrial));
      }
      if (MemberBarcodeInfo) {
        dispatch(cartActions.setMemberBarcodeInfo(MemberBarcodeInfo));
      }
      // #6883 retrieve current running item sequence number.
      if (tranItemSeqNumber !== 0) {
        dispatch(cartActions.settranItemSeqNumber(tranItemSeqNumber));
      }
      // eslint-disable-next-line no-empty
      dispatch(cartActions.setStaleTrnsHoldDetails(transHoldDetails));
      dispatch(cartActions.setOfflinePromoTrigger(true));
    } catch (error) {
      // #6137/6138/6947 any error occured during retrieve cart information need to start from scratch
      // Generate new correlation ID with same tran sequence
      dispatch(cartActions.emptyCart({ skipStoreGenNumber: true }));
      global?.logger?.error(
        `[7POS UI] - retrieveOldTransaction details Error ${JSON.stringify(
          error
        )}`
      );
    } finally {
      setIsOpen(false);
      localStorage.removeItem('cartInfo');
    }
  };
  const startNewTransaction = () => {
    setIsOpen(false);
  };
  const handleClick = e => {
    const isClickOutsideDailpad = !node?.current?.contains(e.target);
    if (isClickOutsideDailpad && showCustomDailPad) {
      dispatch(dailpadActions.toggleCustomDailPad(false));
    }
  };

  useEffect(() => {
    const cartInfo = getStorageItems();
    if (cartInfo?.cartItems?.length) {
      setIsOpen(true);
    }
  }, []);

  useEffect(() => {
    if (!user?.userId || forcelogoff) {
      if (!user?.userId && isAppLogin)
        DisplayToastMsg('Logoff - User Information Not Available');
      const iTransactionMessage = {
        CMD: 'IntialState',
        COUNTRY: storeProfile?.address?.country,
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      dispatch(authActions.setAppLogInStatus(false));
      history.replace('/');
    }
    return () => {};
  }, [user, forcelogoff]);

  useEffect(() => {
    if (RegistrationInvoke === 1) {
      dispatch(authActions.setRegistrationInvoke(2));
    }
  }, [RegistrationInvoke]);

  useEffect(() => {
    if (!keyConfig) return;
    const keyBoardConfig = JSON.parse(keyConfig);
    const groups = keyBoardConfig.find(data =>
      data?.name?.toLowerCase()?.includes('keyboard')
    )?.groups;
    setPluItems(groups);
  }, [keyConfig]);

  const hideDailPad = () => {
    dispatch(dailpadActions.toggleAlphaNumericDailpad(false));
  };

  const cleanUpTransaction = async () => {
    await cleanUpTransactionItems();
  };

  useEffect(() => {
    if (
      !isTransactionAborted &&
      isTransactionFinalize &&
      cartItems.length !== 0 &&
      !location.pathname.includes('/payment') &&
      !isPaymentTriggered // #6646 make sure no active payment inprogress
    ) {
      Logger.debug(
        `[7POS UI] - Redirect to Home from payment screen. ${isTransactionFinalize} and  ${isPaymentTriggered} `
      );
      // Async message sender
      const iTransactionMessage = {
        CMD: 'InTransaction',
      };
      SendMessageToCFD(iTransactionMessage);
      cleanUpTransaction();
      dispatch(cfdActions.setTransactionFinalize(false));
      const cartInfo = getStorageItems();
      if (!cartInfo?.cartItems?.length && cartItems.length !== 0) {
        dispatch(cartActions.setOfflinePromoTrigger(true));
      }
    }
    return () => {};
  }, [isTransactionFinalize, isPaymentTriggered]); // #6797 added payment status as well

  useEffect(() => {
    document.addEventListener('click', handleClick);
    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, [showCustomDailPad, dailpadValue]);

  useEffect(() => {
    if (
      cashDrawerStatus === 'CD_OPEN_OK' &&
      iNoSaleAction === NO_SALE_TRIGGER &&
      cartItems.length === 0
    ) {
      setNoSaleAction(NO_SALE_TRIGGERED);
      noSaleFlow(shiftNumber);
      setNoSaleAction(NO_SALE_RESET);
    } else if (
      cashDrawerStatus === 'CD_OPEN_OK' &&
      iNoSaleAction === NO_SALE_TRIGGER &&
      cartItems.length !== 0
    ) {
      setNoSaleAction(NO_SALE_RESET);
    }
    return () => {};
  }, [cashDrawerStatus]);

  const autoPrint = async paymentReqdata => {
    try {
      paymentReqdata.subject = 'Receipt';
      paymentReqdata.receiptType = 'PRINT';
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
      global?.Logger?.debug(`7POS- autoPrint Success`);
    } catch (error) {
      global?.logger?.error(`7POS- autoPrint error: ${error}`);
      toast({
        description: 'Receipt could not be printed.please try again',
        status: 'error',
        duration: 5000,
        position: 'top',
      });
    }
  };

  useEffect(() => {
    if (
      cardStatus === BALANCE_INQUIRY_INVALID_CARD &&
      paymentMethod === BALANCE_INQUIRY
    ) {
      const paymentReqdata = balanceCancelRequest({
        storeDetails,
        user,
        transactionId,
        deviceInfo,
        MSG: 'BALANCE INQUIRY NOT ALLOWED',
        config,
      });
      getDVR().sendBalanceRequest(
        true,
        config,
        user,
        transactionId,
        storeDetails,
        deviceInfo,
        paymentReqdata.lineItem.items
      );
      autoPrint(paymentReqdata);
      dispatch(cartActions.setTransactionId(getNewTransactionId()));
      dispatch(cartActions.setPaymentTransactionId(getCorrelationID()));
      // RISPIN 4282: Balance Inquiry card status should remove after display
      dispatch(socketActions.setCardStatus(null));
    }
  }, [cardStatus]);

  useEffect(() => {
    if ((isTransactionRefund || itemQuantity > 1) && loadBarcodeData) {
      const MSG =
        itemQuantity > 1
          ? 'Invalid scan for qty multiplier.'
          : 'Card Load Not Allowed';
      DisplayToastMsg(MSG);
      Logger.error(
        `[7POS UI] - Card Load Not Allowed for refund transaction ${isTransactionRefund} or Qty:${itemQuantity}`
      );
      dispatch(cartActions.setCardLoadReset());
      return;
    }
    if (loadPromptRequest > 0) {
      Logger.info(
        `[7POS UI] - Card Load return from home for prompt request: ${loadPromptRequest}`
      );
      return;
    }
    if (!loadConfirm && !loadBarcodeData) {
      return;
    }
    if (isTransactionVoid && !loadSttn && loadBarcodeData) {
      Logger.info(`[7POS UI] - Card Load redirect STTN prompt`);
      dispatch(cartActions.setloadPromptRequest(STTN_ENTRY_PROMPT));
      history.push({
        pathname: '/home/cardProcess',
        state: {
          type: 'load',
        },
      });
      return;
    }
    const { item } = location?.state || {};
    if (item?.productCategory === 'RTR') {
      if (prepaidAccNumberValue && !isTransactionRefund) {
        Logger.info(`[7POS UI] - Card Load trigger for RTR card`);
        loadReqCall();
      }
    } else if (
      (loadBarcodeData || loadConfirm) &&
      (!isTransactionVoid || (isTransactionVoid && loadSttn))
    ) {
      Logger.info(`[7POS UI] - Card Load triggered`);
      loadReqCall();
    } else if (loadSttn) {
      Logger.info(`[7POS UI] - Card Load triggered for STTN update`);
      loadReqCall();
    }
    return () => {};
  }, [loadConfirm, loadBarcodeData, prepaidAccNumberValue, loadSttn]);

  useEffect(() => {
    let msg = '';
    if (displayToaster === 'LOAD_ITEM') {
      msg = 'Card Item not found';
    } else if (displayToaster === 'MONEY_ORDER_LOCKED') {
      msg = 'Money order is in use';
    } else if (displayToaster === 'EOD_TOAST') {
      msg = `EOD/EOS initiated, Please Complete Transaction`;
      if (isTransHold && transactionMemory?.items.length) {
        msg = 'End of shift/day requested. Clear memory';
      } else if (EODEOSDetails?.type)
        msg = `${EODEOSDetails?.type} initiated, Please Complete Transaction`;
    } else if (displayToaster === 'EOD_RECEIPT_FAILED') {
      msg = 'Receipt could not be printed.';
    } else {
      return;
    }
    dispatch(cartActions.setDisplayToaster(''));
    DisplayToastMsg(msg);
    return () => {};
  }, [displayToaster]);

  useEffect(() => {
    if (restrictedItemSale) {
      dispatch(cartActions.setRestrictedSale(false));
      DisplayToastMsg(
        'CANNOT SELL THIS ALOCHOLIC BEVERAGE DURING RESTRICTED HOURS',
        'top-left',
        5000
      );
    }
  }, [restrictedItemSale]);

  const setBgColor = () => {
    if (window.location.pathname.includes('search')) {
      return 'white';
    }
    return '#efefef';
  };

  return (
    <>
      <Box backgroundColor={setBgColor()}>
        <FuelPumps />
        <Grid templateColumns="34% 66%">
          <Box
            w="100%"
            boxShadow="-2px 0px 6px 0px rgba(0, 0, 0, 0.2)"
            borderRight="1px solid rgb(233, 233, 233)"
            background="rgb(255, 255, 255)"
          >
            <Cart />
          </Box>
          <Box>
            <Header />
            <Notifications />
            <Main
              items={appendAdditionalPlu(pluItems, storeProfile, history)}
              onItemClickHandler={onItemClickHandler}
              isTransactionRefund={isTransactionRefund}
              refundPrepaidFlag={refundPrepaidFlag}
              onCancel={onCancel}
              onSelectItem={onSelectItem}
              appRestart={appRestart}
            />

            {showCustomDailPad && (
              <Box ref={node} className={Styles.customDailpadContainer}>
                <CustomDailPad
                  dailPadValue={dailpadValue}
                  setDailPadValue={updateDailPadValue}
                  {...customDailpadProps}
                />
              </Box>
            )}
          </Box>
        </Grid>

        {showAlphaNumericDailpad && (
          <Box className={Styles.AlphaNumericDailpadContainer}>
            <AlphaNumericDailpad onEnter={hideDailPad} />
          </Box>
        )}
        <MenuBar />
        <ConfirmModal
          header="YOU ARE LOGGED IN"
          isOpen={isOpen}
          onClose={startNewTransaction}
          onYes={retrieveOldTransaction}
          body="There is a transaction in progress, please complete or abort it."
        />
      </Box>
    </>
  );
};
export default Home;
