import { Box, Flex, Text } from '@chakra-ui/react';
import moment from 'moment';
import React, { memo, useEffect, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Button } from '../../../../components/Common';
import Warning_Icon from '../../../../Icons/Warning_Icon.svg';
import ExitButton from '../../../../components/POS/ExitButton';
import BirthDateInvalid from '../../../../components/POS/ModalPopups/ageRestriction/birthDateInvalidModal';
import { cartActions } from '../../../../slices/cart.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import { isEcigItem, appIntegrationRequest } from '../../../../Utils/appUtils';
import { buildCartChangeTrial } from '../../../../Utils/cartUtils';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { AppContext } from '../../../../AppContext';

const IdVerification = () => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const {
    isCanada,
    paymentTransactionId,
    tranItemSeqNumber,
    cartChangeTrial,
    idCardInfo,
    deviceInfo,
    storeId,
    config,
  } = useSelector(state => ({
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    paymentTransactionId: state.cart.paymentTransactionId,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    cartChangeTrial: state.cart.cartChangeTrial,
    idCardInfo: state.cart.idCardInfo,
    deviceInfo: state.main.deviceInfo,
    storeId: state.main.storeDetails?.storeId,
    config: state.main.configuration,
  }));
  const { errorSound } = useContext(AppContext) || {};
  const [isOpen, setIsOpen] = useState(false);
  const [isScanPassport, setScanPassport] = useState(false);
  const [errorDisplayMsg, setErrorDisplayMsg] = useState('BIRTHDATE INVALID');
  const item = location?.state?.item;
  const [ws] = useContext(WebSocketContext);
  const restriction = location?.state?.restriction || {};
  const { isVisualIdVerficationAllowed, driverLicenseVerifyFlag } = restriction;
  const dateBefore = moment()
    .subtract(Number(restriction?.ageRestriction), 'years')
    .format('MM/DD/YYYY');

  const ageRestrictionCancelCMD = () => {
    const dlSwipeReq = appIntegrationRequest({
      type: 'Dlswipe_Complete',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
  };

  const createCartTrial = ({ name, eventResult }) => {
    const CartTrialPayLoad = buildCartChangeTrial({
      item: {
        name,
        tranItemSeqNumber: tranItemSeqNumber + 1,
      },
      eventType: 'addItemError',
      eventSeq: cartChangeTrial.length,
      eventResult,
    });
    dispatch(
      cartActions.addToCartChangeTrial({
        CartTrialPayLoad,
        tranItemSeqNumber: tranItemSeqNumber + 1,
      })
    );
  };

  const isScanPassportEnabled =
    config?.storeConfig?.isScanPassportEnabled || false;

  const onVisualIdClick = () => {
    ageRestrictionCancelCMD();
    dispatch(cfdActions.setUserActionScreenActive(false));
    if (item?.otherDeptsCartPayload) {
      dispatch(cartActions.addToCart(item.otherDeptsCartPayload));
      dispatch(dailpadActions.resetKeypadValue());
    } else {
      dispatch(cartActions.addToCart({ ...item, upc: item.upc }));
    }
    const agInformation = {
      age: restriction.ageRestriction,
      visualIdChecked: true,
    };
    dispatch(cartActions.setTranAgeVerifyInfo(agInformation));
    history.replace('/home');
  };

  const onManualEntryClick = async () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    history.push({
      pathname: '/home/manualEntry',
      state: { restriction, item },
    });
  };

  const onScanPassportClick = async () => {
    setScanPassport(true);
    dispatch(cfdActions.setUserActionScreenActive(false));

    const payload = {
      from: 'POS',
      action: 'SCAN_PASSPORT',
      storeId,
      terminalId: deviceInfo?.id,
    };

    const request = appIntegrationRequest({
      type: 'Notification_Bar',
      payload,
      correlationId: paymentTransactionId,
    });
    Logger.info(
      `7POS Application - Scan Passport request for Age verification:, ${JSON.stringify(
        request
      )}`
    );
    ws.socket?.send('/app/7pos/appnotifications', {}, JSON.stringify(request));
  };

  const sendScanPassportCancel = async () => {
    const payload = {
      from: 'POS',
      action: 'SCAN_PASSPORT_CANCEL',
      storeId,
      terminalId: deviceInfo?.id,
    };

    const request = appIntegrationRequest({
      type: 'Notification_Bar',
      payload,
      correlationId: paymentTransactionId,
    });
    Logger.info(
      `7POS Application - Scan Passport cancel request for Age verification:, ${JSON.stringify(
        request
      )}`
    );
    ws.socket?.send('/app/7pos/appnotifications', {}, JSON.stringify(request));
  };

  const onClickExitBtn = () => {
    ageRestrictionCancelCMD();
    dispatch(cfdActions.setUserActionScreenActive(false));
    if (isScanPassport) {
      sendScanPassportCancel();
    }
    createCartTrial({
      name: 'Age Verification',
      eventResult: 'SA Cancelled Age Verification',
    });
    history.push('/home');
  };

  const closePopup = () => {
    ageRestrictionCancelCMD();
    setIsOpen(false);
    const dlExpireDate = moment(idCardInfo?.docExpireDate, 'MM/DD/YYYY');
    if (dlExpireDate) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      history.replace('/home');
    }
  };
  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(true));
    dispatch(setShowNotifications(true));
  }, []);

  const blockEcigs = () => {
    if (isCanada) return false;
    return isEcigItem(item);
  };

  useEffect(() => {
    if (idCardInfo && idCardInfo?.docExpireDate && idCardInfo?.dateBirth) {
      // #6847 Ignore ID scan/swipe durinrg Invalid Date
      if (isOpen) {
        dispatch(cartActions.setIdCardInfo({}));
        Logger.info(
          `Ignore ID scan/swipe during Invalid DOB/ DL expired prompt.`
        );
        return;
      }
      const today = moment();
      const userDate = moment(idCardInfo?.dateBirth, 'MM/DD/YYYY');
      const age = today.diff(userDate, 'years');
      const dlExpireDate = moment(idCardInfo?.docExpireDate, 'MM/DD/YYYY');
      if (age >= restriction.ageRestriction && dlExpireDate.isAfter(today)) {
        let cartItem = { ...item };
        dispatch(cfdActions.setUserActionScreenActive(false));
        if (item?.otherDeptsCartPayload) {
          cartItem = {
            ...item.otherDeptsCartPayload,
          };
        }
        ageRestrictionCancelCMD();
        dispatch(cartActions.addToCart(cartItem));
        const agInformation = {
          age,
          stateCode: idCardInfo?.stateCode || null,
          countryCode: idCardInfo?.countryCode || null,
          driverLicense: idCardInfo?.driverLicense || null,
          expiryDate: idCardInfo?.docExpireDate || null,
          birthDate: idCardInfo?.dateBirth || null,
          issuingAuthority: null,
          idType: idCardInfo?.documentType || null,
          id: idCardInfo?.licenseNumber || null,
        };
        dispatch(cartActions.setTranAgeVerifyInfo(agInformation));
        history.replace('/home');
      } else {
        errorSound &&
          errorSound.play().catch(e => console.log('Sound error', e));
        setIsOpen(true);
        const displayMsg = dlExpireDate.isAfter(today)
          ? 'BIRTHDATE INVALID'
          : 'I.D. / BIRTHDATE INVALID';
        setErrorDisplayMsg(displayMsg);
        createCartTrial({
          name: 'Age Verification',
          eventResult: 'Age verification failed',
        });
        Logger.info(`Age verification failed due to ${displayMsg}`);
      }
      dispatch(cartActions.setIdCardInfo({}));
    }
    return () => {};
  }, [idCardInfo]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      bg="rgb(255, 255, 255)"
      width="100%"
      h="calc(100vh - 275px)"
    >
      <Box textAlign="center" mt="1.9rem" mb="0.5rem">
        <img src={Warning_Icon} alt="warningIcon" />
      </Box>
      <Box textAlign="center" mb="0.5rem">
        <Text
          mb="0.5rem"
          color="rgb(44, 47, 53)"
          fontFamily="Roboto-Bold"
          fontSize="24px"
          fontWeight="bold"
          textAlign="center"
        >
          ID Verification Required
        </Text>
        <Text textAlign="center" mx="4.5rem">
          {`${restriction?.description}. ${
            isVisualIdVerficationAllowed
              ? `Picture on ID must match the customer.`
              : ''
          } `}
          <strong> Scan or Swipe ID</strong>
          {driverLicenseVerifyFlag &&
            ` or if the birthdate is on or before ${dateBefore}, press “`}
          {driverLicenseVerifyFlag && <strong>Manual Enter</strong>}
          {driverLicenseVerifyFlag && `”`}.
        </Text>
      </Box>

      <Flex flexDirection="column">
        <Flex flexDirection="column" alignItems="center" my={4}>
          <Button
            background={
              item?.preAgeVerify ? 'rgb(16, 127, 98)' : 'rgb(226, 239, 236)'
            }
            borderRadius="3px"
            height="50px"
            isDisabled={!driverLicenseVerifyFlag || blockEcigs()}
            mb="1.5rem"
            width="360px"
            border="1px solid rgb(16, 127, 98)"
            _hover={{
              ...(driverLicenseVerifyFlag
                ? { bg: 'rgb(16, 127, 98)', color: 'rgb(255, 255, 255)' }
                : {}),
            }}
            onClick={onManualEntryClick}
          >
            <Text
              fontFamily="Roboto-Medium"
              fontSize="18px"
              fontWeight="500"
              color={item?.preAgeVerify ? 'white' : 'black'}
            >
              Manual Enter
            </Text>
          </Button>
          {!item?.preAgeVerify ? (
            <Button
              background={
                item?.preAgeVerify ? 'rgb(16, 127, 98)' : 'rgb(226, 239, 236)'
              }
              borderRadius="3px"
              height="50px"
              width="360px"
              mb="1.5rem"
              isDisabled={!isVisualIdVerficationAllowed || blockEcigs()}
              border="1px solid rgb(16, 127, 98)"
              _hover={{
                ...(isVisualIdVerficationAllowed
                  ? { bg: 'rgb(16, 127, 98)', color: 'rgb(255, 255, 255)' }
                  : {}),
              }}
              onClick={onVisualIdClick}
            >
              <Text
                fontFamily="Roboto-Medium"
                fontSize="18px"
                fontWeight="500"
                color={item?.preAgeVerify ? 'white' : 'black'}
              >
                Visual ID Ok
              </Text>
            </Button>
          ) : null}
          {isScanPassportEnabled ? (
            <Button
              background={
                item?.preAgeVerify ? 'rgb(16, 127, 98)' : 'rgb(226, 239, 236)'
              }
              borderRadius="3px"
              height="50px"
              width="360px"
              border="1px solid rgb(16, 127, 98)"
              _hover={{
                ...(driverLicenseVerifyFlag
                  ? { bg: 'rgb(16, 127, 98)', color: 'rgb(255, 255, 255)' }
                  : {}),
              }}
              onClick={onScanPassportClick}
            >
              <Text
                fontFamily="Roboto-Medium"
                fontSize="18px"
                fontWeight="500"
                color={item?.preAgeVerify ? 'white' : 'black'}
              >
                Scan Passport On 7MD
              </Text>
            </Button>
          ) : null}
        </Flex>
      </Flex>
      <Box display="block" textAlign="right" mt="-2rem" p="1rem" w="100%">
        <ExitButton onClick={onClickExitBtn} />
      </Box>
      <BirthDateInvalid
        isOpen={isOpen}
        onClose={closePopup}
        onOk={closePopup}
        item={item}
        MSG={errorDisplayMsg}
      />
    </Flex>
  );
};

export default memo(IdVerification);
