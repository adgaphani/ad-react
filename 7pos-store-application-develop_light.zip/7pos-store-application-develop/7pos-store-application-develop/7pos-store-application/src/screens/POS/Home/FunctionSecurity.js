import React, { useState, useContext, useEffect } from 'react';
import { Grid, Box, Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useSoundToast } from '../../../hooks';
import Keypad from '../../../components/Common/DailPad/Keypad/Keypad';
import ExitButton from '../../../components/POS/ExitButton';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { cartActions } from '../../../slices/cart.slice';
import { loginApi } from '../../../api/user/loginApi';
import warrningSymbol from '../../../Icons/Icon_Warning.svg';
import { AppContext } from '../../../AppContext';
import { cfdActions } from '../../../slices/cfd.slice';

const functionSecurity = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const history = useHistory();
  const { paymentTransactionId, functionSecuirtyData } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    functionSecuirtyData: state.main.functionSecuirtyData,
  }));
  const { startLoading, stopLoading } = useContext(AppContext);
  const [isPasswordScreen, setPasswordScreen] = useState(false);
  const [screenText, setscreenText] = useState('Enter Supervisor ID');
  const [userID, setuserID] = useState(null);
  const redirectionData = location?.redirectionData || null;
  const triggerFrom = location?.triggerFrom || '';
  const iFunctionName = location?.iFunctionName || '';
  const KeypadValue = location?.KeypadValue || 0;
  // console.log('Selection Function:', redirectionData);

  // #5615 make keypad reset as an optional field
  const resetFlags = (resetKeypad = true) => {
    setuserID('');
    setscreenText('Enter Supervisor ID');
    setPasswordScreen(false);
    if (resetKeypad) dispatch(dailpadActions.resetKeypadValue());
  };

  useEffect(() => {
    dispatch(dailpadActions.resetKeypadValue());
    dispatch(cfdActions.setUserActionScreenActive(true));
  }, []);

  const onExitClick = () => {
    resetFlags();
    dispatch(cartActions.setFunctionSecurityData(null));
    dispatch(cartActions.setFunctionSecurityTriggered(''));
    dispatch(cartActions.setTransactionAborted(false));
    dispatch(cfdActions.setUserActionScreenActive(false));
    history.push('/home');
  };

  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };

  const onEnterValue = async keyValue => {
    if (!keyValue) return;
    if (Number(keyValue) > 0) {
      if (!isPasswordScreen) {
        setuserID(keyValue);
        setscreenText('Enter Supervisor Password');
        setPasswordScreen(true);
        dispatch(dailpadActions.resetKeypadValue());
      } else if (isPasswordScreen) {
        try {
          const req = {
            userId: userID,
            password: keyValue,
          };
          dispatch(dailpadActions.setKeypadValue({ value: '' }));
          startLoading();
          const res = await loginApi(req, paymentTransactionId);
          stopLoading();
          if (res.data.status === '200 OK') {
            const user = res?.data?.data || null;
            const funcdata = functionSecuirtyData?.filter(
              func =>
                (iFunctionName === 'moneyorder'
                  ? func?.name?.trim()?.toLowerCase() === iFunctionName ||
                    func?.name?.trim()?.toLowerCase() === 'mowithfee' // #5843 MO WITH FEE will be applicable for MO As well
                  : iFunctionName === 'scanload'
                  ? func?.name?.trim()?.toLowerCase() === 'load'
                  : func?.name?.trim()?.toLowerCase() === iFunctionName) &&
                func?.securityLevelId !== 0
            );
            if (
              user &&
              iFunctionName &&
              Number(user?.levelId) <= Number(funcdata[0]?.securityLevelId)
            ) {
              global?.logger?.info(
                `User have permission to do ${iFunctionName}`
              );
              if (KeypadValue !== 0) {
                dispatch(dailpadActions.setKeypadValue({ value: KeypadValue }));
              }
              dispatch(cartActions.setFunctionSecurityTriggered(triggerFrom));
              dispatch(cfdActions.setUserActionScreenActive(false));
              if (redirectionData !== null) {
                history.push(redirectionData);
              }
            } else {
              global?.logger?.info(
                `User don't have permission to do ${iFunctionName} and required levelID:${Number(
                  funcdata[0]?.securityLevelId
                )} and user Login levelID:${Number(user?.levelId)}`
              );
              DisplayToastMsg(`User don't have permission`);
              resetFlags();
            }
          } else {
            DisplayToastMsg('Failed to Authenticate');
            resetFlags();
          }
        } catch (error) {
          stopLoading();
          DisplayToastMsg('Failed to Authenticate');
          resetFlags();
        } finally {
          if (iFunctionName !== 'scanload' && iFunctionName !== 'load')
            stopLoading();
          resetFlags(false);
        }
      }
    } else {
      DisplayToastMsg('Enter valid credentials');
    }
  };

  return (
    <>
      <Grid templateColumns="50% 50%" width="100%">
        <Box marginLeft="7px" pr="0.5rem">
          <Keypad
            onEnter={onEnterValue}
            disableDecimal
            showAmounts={false}
            isPassword={isPasswordScreen}
          />
        </Box>
        <Flex
          h="100%"
          flexDirection="column"
          justifyContent="space-between"
          bg="rgb(255, 255, 255)"
          mr="0.5rem"
        >
          <Flex flexDirection="column">
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Bold"
              fontSize="24px"
              fontWeight="bold"
              justifyContent="center"
              textAlign="center"
              alignItems="center"
              my="1.75rem"
            >
              Secured Function
            </Text>
            <Flex
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              alignItems="center"
            >
              <img src={warrningSymbol} alt="warning" />
            </Flex>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Bold"
              fontSize="20px"
              fontWeight="bold"
              justifyContent="center"
              textAlign="center"
              alignItems="center"
              my="1.75rem"
            >
              {screenText}
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExitClick} />
          </Box>
        </Flex>
      </Grid>
    </>
  );
};

export default functionSecurity;
