import React, { useContext, useEffect } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { iMemberMsg, iNonMemberMsg } from '../../../constants';
import { Button } from '../../../components/Common/Buttons';
import { AppContext } from '../../../AppContext';
import Styles from './UserActionNotification.module.css';
import membericon from '../../../Icons/member.svg';
import nonmembericon from '../../../Icons/non-member.svg';
import { cfdActions } from '../../../slices/cfd.slice';
import { SendMessageToCFD } from '../../../Communication';
import { cartActions } from '../../../slices/cart.slice';
import { useSoundToast } from '../../../hooks';

const ForceFinalizeScreen = () => {
  const toast = useSoundToast();
  const { showLoader } = useContext(AppContext);
  const dispatch = useDispatch();
  const history = useHistory();
  const { altIDEntryIntiate, member } = useSelector(state => ({
    altIDEntryIntiate: state.cfd.AltIDEntryIntiate,
    member: state.cart.member,
  }));

  const onForceFinalize = () => {
    const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;
    if (isMemberTrigger) {
      toast({
        description: 'Waiting for Member response',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn waiting for Member response.`
      );
      return;
    }
    if (altIDEntryIntiate) {
      global?.logger?.info(`[7POS UI] - iForceFinalize - CancelUserEntry`);
      dispatch(cfdActions.setAltIDUserTrigger(false));
      const iTransactionMessage = {
        CMD: 'CancelUserEntry',
      };
      SendMessageToCFD(iTransactionMessage);
    }
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    global?.logger?.info(
      `[7POS UI] - iForceFinalize redirect to payment screen`
    );
    dispatch(cartActions.setFinalizeClick(false));
    history.push('/payment');
  };

  const onExit = () => {
    global?.logger?.info(
      `[7POS UI] - onClickForceFinalizeOkBtn redirect to home`
    );
    showLoader(false);
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cartActions.setFinalizeClick(false));
    history.push('/home');
  };

  useEffect(() => {
    if (member) {
      history.push({
        pathname: '/home/CFDNotification',
        state: 'AltID_Notify',
      });
    }
  }, [member]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="70%"
      background="rgb(255,255,255)"
      boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
      my="0.6rem"
      ml="0.5rem"
      mr="0.6rem"
    >
      <Flex justifyContent="center" flexDirection="column" mt="10%">
        <Text className={Styles.ForceFinalizeTitle}>
          Is Customer a 7 Rewards Member?
        </Text>
        <Flex
          flexDirection="row"
          justifyContent="space-between"
          textAlign="center"
          mt="5%"
          px={4}
        >
          <Flex
            alignItems="center"
            justifyContent="center"
            flexDirection="column"
            ml="5%"
          >
            <img src={nonmembericon} alt="pinpad" />`
            <Text className={Styles.ForceFinalizeMember}>NON MEMBER</Text>
            <Text className={Styles.ForceFinalizeMsg}>
              Recommend customer to
              <Text as="span" color="#107f62">
                {' '}
                signup
              </Text>
            </Text>
            <Text
              className={Styles.ForceFinalizeMsg}
              dangerouslySetInnerHTML={{ __html: iNonMemberMsg }}
            />
          </Flex>
          <Flex height="60px" mt="15%">
            <hr border="1px solid" color="#d3d3d3" width="0" />
          </Flex>
          <Flex
            alignItems="center"
            justifyContent="center"
            flexDirection="column"
            mr="5%"
          >
            <img src={membericon} alt="pinpad" />`
            <Text className={Styles.ForceFinalizeMember}>MEMBER</Text>
            <Text
              className={Styles.ForceFinalizeMsg}
              dangerouslySetInnerHTML={{ __html: iMemberMsg }}
            />
          </Flex>
        </Flex>
        <Flex
          flexDirection="row"
          justifyContent="space-between"
          textAlign="center"
          height="80px"
          mt="3%"
          pb={4}
        >
          <Button
            className={Styles.ForceFinalizeBtn}
            ml="10%"
            width="28%"
            onClick={onForceFinalize}
          >
            FORCE FINALIZE
          </Button>
          <Button
            className={Styles.ForceFinalizeBtn}
            mr="12%"
            width="20%"
            onClick={onExit}
          >
            OK
          </Button>
        </Flex>
      </Flex>
    </Flex>
  );
};

export default ForceFinalizeScreen;
