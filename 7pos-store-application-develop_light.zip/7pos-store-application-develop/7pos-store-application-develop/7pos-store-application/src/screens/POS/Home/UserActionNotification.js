/* eslint-disable max-lines */
/* eslint-disable no-use-before-define */
/* eslint-disable array-callback-return */
import React, { useEffect, useState, useContext } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { usePromoWrapper, useSoundToast } from '../../../hooks';
import { getPriceDetails } from '../../../Utils/cartUtils';
import { isLottery } from '../../../Utils/lotteryUtils';
import { cfdActions } from '../../../slices/cfd.slice';
import { cartActions } from '../../../slices/cart.slice';
import loader from '../../../Icons/Icons_loader.svg';
import Styles from './UserActionNotification.module.css';
import { SendMessageToCFD } from '../../../Communication';
import ExitButton from '../../../components/POS/ExitButton';
import { AppContext } from '../../../AppContext';
import { iNotificationMsg } from '../../../constants';

const UserActionNotification = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const { showLoader } = useContext(AppContext);
  const {
    member,
    cartItems,
    isUserTriggerReward,
    UserRewardOpted,
    taxInfo,
    isSWPIntiated,
    isItemRedemptionIntiated,
    AltIDEntryIntiate,
    AltIDEntryReset,
    isTransactionVoid,
    isTransactionRefund,
    isCanada,
    tempArbitRes,
    processPaymentAsMCLoyalty,
  } = useSelector(
    state => ({
      member: state.cart.member,
      items: state.cart.items,
      cartItems: state.cart.cartItems,
      isUserTriggerReward: state.cfd.isUserTriggerReward,
      UserRewardOpted: state.cfd.UserRewardOpted,
      BeforeRedeemptionTotalPrice: state.cfd.BeforeRedeemptionTotalPrice,
      taxInfo: state.cart.taxInfo,
      isItemRedemptionIntiated: state.cfd.isItemRedemptionIntiated,
      isSWPIntiated: state.cfd.isSWPIntiated,
      AltIDEntryIntiate: state.cfd.AltIDEntryIntiate,
      AltIDEntryReset: state.cfd.AltIDEntryReset,
      basketPromo: state.cart.basketPromo,
      isTransactionVoid: state.cart.isTransactionVoid,
      isTransactionRefund: state.cart.isTransactionRefund,
      paymentTransactionId: state.cart.paymentTransactionId,
      isCanada: state.main.storeDetails?.address?.country === 'CA',
      channel: state.main.channel,
      tempArbitRes: state.cart.tempArbitRes,
      processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
    }),
    shallowEqual
  );
  const toast = useSoundToast();
  const [isRedeemUserOpt, setUseOptRedeemption] = useState(false);
  const { getEligiblePromos, redeemDiscounts } = usePromoWrapper();

  let isSkipTaxPromoVerify = false;
  if (cartItems?.length > 0) {
    isSkipTaxPromoVerify = cartItems?.every(
      item =>
        item.isFuel === true || item.isMoneyOrder === true || isLottery(item)
    );
  }

  const [isRedeemScreenMsg, setRedeemScreenMsg] = useState(
    'Awaiting customer action...'
  );
  const taxData = taxInfo;
  const { finalTotalPrice } = getPriceDetails(
    cartItems,
    taxData,
    isTransactionVoid || isTransactionRefund
  );

  const iForceFinalize = () => {
    if (AltIDEntryIntiate) {
      global?.logger?.info(`[7POS UI] - iForceFinalize - CancelUserEntry`);
      dispatch(cfdActions.setAltIDUserTrigger(false));
      const iTransactionMessage = {
        CMD: 'CancelUserEntry',
      };
      SendMessageToCFD(iTransactionMessage);
    }
    setUseOptRedeemption(false);
    showLoader(false);
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    global?.logger?.info(
      `[7POS UI] - iForceFinalize redirect to payment screen`
    );
    dispatch(cartActions.setFinalizeClick(false));
    history.push('/payment');
  };

  const iRedeemFailed = () => {
    global?.logger?.info(`[7POS UI] - iRedeemFailed`);
    const iTransactionMessage = {
      CMD: 'RedeemResponse',
      Status: 'Failure',
      processPaymentAsMCLoyalty,
    };
    SendMessageToCFD(iTransactionMessage);
    iForceFinalize();
  };

  const iRedeemItem = async () => {
    // If redeem already in-progress dont trigger one more time
    if (isRedeemUserOpt) {
      return;
    }
    try {
      setRedeemScreenMsg('Processing Request...');
      localStorage.setItem('isMemberPromoTrigger', true);
      await redeemDiscounts();
      iForceFinalize();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - redeem item failure ${JSON.stringify(error)}`
      );
      iRedeemFailed();
    } finally {
      localStorage.removeItem('isMemberPromoTrigger');
      dispatch(cfdActions.setUserRewardAction(''));
      showLoader(false);
    }
  };

  const onExit = () => {
    const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;
    const isMemberPromoTrigger =
      localStorage.getItem('isMemberPromoTrigger') || false;
    if (isMemberTrigger || isMemberPromoTrigger) {
      toast({
        description: isMemberTrigger
          ? 'Waiting for Member response'
          : 'Waiting for Member Promo response',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn waiting for Member response.`
      );
      return;
    }
    if (!member) {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt non-memebr`
      );
      iForceFinalize();
      return;
    }
    if (isSWPIntiated || isItemRedemptionIntiated) {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt DismissReward`
      );
      const iTransactionMessage = {
        CMD: 'DismissReward',
      };
      SendMessageToCFD(iTransactionMessage);
      if (tempArbitRes) {
        return dispatch(cartActions.setRejectedReward(true));
      }
    } else {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt force finalize`
      );
    }
    iForceFinalize();
  };

  useEffect(() => {
    if (isUserTriggerReward) {
      dispatch(cfdActions.setRewardUserTrigger(false));
      if (isCanada)
        setRedeemScreenMsg('Awaiting customer action for postalcode entry...');
      else setRedeemScreenMsg('Awaiting customer action for zipcode entry...');
    } else if (UserRewardOpted !== '') {
      // #8270 regardless user opt YES/NO state need update
      setUseOptRedeemption(true);
      iRedeemItem();
    }
    return () => {};
  }, [isUserTriggerReward, UserRewardOpted]);

  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(true));
    if (
      location.state !== 'AltID_Notify' &&
      location.state?.offer !== 'best_reward' &&
      location.state?.offer !== 'shop_with_points' &&
      location.state?.offer !== 'fuel_discount'
    ) {
      iForceFinalize();
    } else {
      global?.logger?.info(`[7POS UI] - Waiting for customer input.`);
    }
    return () => {};
  }, []);

  // Get store promo and member before execute isEligible Call
  const TriggerPromoCall = async () => {
    try {
      if (!isSkipTaxPromoVerify) {
        dispatch(cartActions.setFinalizePayStatus(true));
        localStorage.setItem('isMemberPromoTrigger', true);
        await getEligiblePromos({ finalTotalPrice });
        dispatch(cartActions.setFinalizePayStatus(false));
      } else iForceFinalize();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - iRedeemItem Failure ${JSON.stringify(error)}`
      );
    } finally {
      localStorage.removeItem('isMemberPromoTrigger');
    }
  };

  useEffect(() => {
    if (AltIDEntryReset && AltIDEntryIntiate) {
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      if (member) {
        TriggerPromoCall();
      } else {
        iForceFinalize();
      }
    }
  }, [AltIDEntryReset, AltIDEntryIntiate]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="70%"
      background="rgb(255,255,255)"
      boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
      my="0.6rem"
      ml="0.5rem"
      mr="0.6rem"
    >
      <Flex
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        mt={isItemRedemptionIntiated || isSWPIntiated ? '10%' : '20%'}
      >
        {localStorage.getItem('isMemberPromoTrigger') ||
        localStorage.getItem('isMemberTrigger') ? (
          <>
            <object type="image/svg+xml" data={loader} width="100px">
              svg-animation
            </object>
            <Text as="strong" fontSize={28}>
              Processing Request...
            </Text>
          </>
        ) : (
          <>
            {isItemRedemptionIntiated || isSWPIntiated ? (
              <>
                <Box
                  mb={15}
                  mt={localStorage.getItem('isMemberPromoTrigger') ? 0 : 50}
                >
                  <Text as="strong" fontSize={28}>
                    {isRedeemScreenMsg}
                  </Text>
                </Box>

                <Text fontSize={20}>
                  Please{' '}
                  <Text as="span" color="#107f62" fontWeight={600}>
                    allow the customer to complete 7Rewards
                  </Text>{' '}
                </Text>
                <Text fontSize={20}>
                  <Text as="span" color="#107f62" fontWeight={600}>
                    redemption choice
                  </Text>{' '}
                  or Press Skip Loyalty.
                </Text>
              </>
            ) : (
              <Text
                className={Styles.userentrynotification}
                dangerouslySetInnerHTML={{ __html: iNotificationMsg }}
              />
            )}
          </>
        )}
      </Flex>
      {// #7847/#7682 disable exit button once promo trigger
      !localStorage.getItem('isMemberTrigger') &&
        !localStorage.getItem('isMemberPromoTrigger') && (
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExit} label="SKIP LOYALTY" />
          </Box>
        )}
    </Flex>
  );
};

export default UserActionNotification;
