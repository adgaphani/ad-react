/* eslint-disable max-lines */
/* eslint-disable no-use-before-define */
/* eslint-disable array-callback-return */
import React, { useEffect, useState, useContext } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { useCart, usePromoWrapper, useSoundToast } from '../../../hooks';
import { getPriceDetails } from '../../../Utils/cartUtils';
import { isLottery } from '../../../Utils/lotteryUtils';
import { cfdActions } from '../../../slices/cfd.slice';
import { cartActions } from '../../../slices/cart.slice';
import loader from '../../../Icons/Icons_loader.svg';
import Styles from './UserActionNotification.module.css';
import { SendMessageToCFD } from '../../../Communication';
import ExitButton from '../../../components/POS/ExitButton';
import { AppContext } from '../../../AppContext';
import { iNotificationMsg } from '../../../constants';
import store from '../../../store';

const SpeedyUserNotification = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const { showLoader } = useContext(AppContext);
  const {
    member,
    cartItems,
    isUserTriggerReward,
    UserRewardOpted,
    taxInfo,
    isSWPIntiated,
    isItemRedemptionIntiated,
    AltIDEntryIntiate,
    AltIDEntryReset,
    isTransactionVoid,
    isTransactionRefund,
    isCanada,
    speedyFuelprompt,
    isFuelPromptEnabled,
    tempArbitRes,
    isSpeedyStore,
    processPaymentAsMCLoyalty,
  } = useSelector(
    state => ({
      member: state.cart.member,
      items: state.cart.items,
      cartItems: state.cart.cartItems,
      isUserTriggerReward: state.cfd.isUserTriggerReward,
      UserRewardOpted: state.cfd.UserRewardOpted,
      BeforeRedeemptionTotalPrice: state.cfd.BeforeRedeemptionTotalPrice,
      taxInfo: state.cart.taxInfo,
      isItemRedemptionIntiated: state.cfd.isItemRedemptionIntiated,
      isSWPIntiated: state.cfd.isSWPIntiated,
      AltIDEntryIntiate: state.cfd.AltIDEntryIntiate,
      AltIDEntryReset: state.cfd.AltIDEntryReset,
      basketPromo: state.cart.basketPromo,
      isTransactionVoid: state.cart.isTransactionVoid,
      isTransactionRefund: state.cart.isTransactionRefund,
      paymentTransactionId: state.cart.paymentTransactionId,
      isCanada: state.main.storeDetails?.address?.country === 'CA',
      speedyFuelprompt: state.cfd.speedyFuelprompt,
      isFuelPromptEnabled: state.cfd.isFuelPromptEnabled,
      tempArbitRes: state.cart.tempArbitRes,
      isSpeedyStore: state.main.isSpeedyStore,
      processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
    }),
    shallowEqual
  );
  const toast = useSoundToast();
  const [isRedeemUserOpt, setUseOptRedeemption] = useState(false);
  const { getEligiblePromos, speedyRedeemDiscount } = usePromoWrapper();
  const { isFuelTransactionInProgress } = useCart();

  let isSkipTaxPromoVerify = false;
  if (cartItems?.length > 0) {
    isSkipTaxPromoVerify = cartItems?.every(
      item =>
        item.isFuel === true || item.isMoneyOrder === true || isLottery(item)
    );
  }

  const [isRedeemScreenMsg, setRedeemScreenMsg] = useState(
    'Awaiting customer action...'
  );
  const [speedyRedeemCounter, setSpeedyRedeemCounter] = useState(1);
  const taxData = taxInfo;
  const { finalTotalPrice } = getPriceDetails(
    cartItems,
    taxData,
    isTransactionVoid || isTransactionRefund
  );

  const proceedToPayment = () => {
    if (AltIDEntryIntiate) {
      global?.logger?.info(`[7POS UI] - iForceFinalize - CancelUserEntry`);
      dispatch(cfdActions.setAltIDUserTrigger(false));
      const iTransactionMessage = {
        CMD: 'CancelUserEntry',
      };
      SendMessageToCFD(iTransactionMessage);
    }
    setUseOptRedeemption(false);
    showLoader(false);
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    global?.logger?.info(`[7POS UI] - redirect to payment screen`);
    const { isFuelPromptEnabled } = store.getState().cfd;
    if (isFuelPromptEnabled) {
      setRedeemScreenMsg('Awaiting customer action');
      return;
    }
    setSpeedyRedeemCounter(1);
    dispatch(cartActions.setFinalizeClick(false));
    history.push('/payment');
  };

  const iRedeemFailed = isInCorrectPwdErr => {
    if (isInCorrectPwdErr) {
      const iTransactionMessage = {
        CMD: 'RedeemSpeedyResponse',
        Status: 'Failure',
      };
      showLoader(false);
      dispatch(cfdActions.setUserRewardAction(''));
      setRedeemScreenMsg('Awaiting customer action for passcode entry...');
      setUseOptRedeemption(false);
      SendMessageToCFD(iTransactionMessage);
      if (speedyRedeemCounter + 1 > 3 || !isInCorrectPwdErr) {
        const iTransactionMessage = {
          CMD: 'RedeemResponse',
          Status: 'Failure',
          isSpeedyStore: true,
          isPassCodeIncorrect: isInCorrectPwdErr,
          processPaymentAsMCLoyalty,
        };
        SendMessageToCFD(iTransactionMessage);
        proceedToPayment();
        return;
      }
      setSpeedyRedeemCounter(speedyRedeemCounter + 1);
      return;
    }
    const iTransactionMessage = {
      CMD: 'RedeemResponse',
      Status: 'Failure',
      isSpeedyStore: true,
      isPassCodeIncorrect: isInCorrectPwdErr,
      processPaymentAsMCLoyalty,
    };
    SendMessageToCFD(iTransactionMessage);
    proceedToPayment();
  };

  const iRedeemItem = async () => {
    // If redeem already in-progress dont trigger one more time
    if (isRedeemUserOpt) {
      return;
    }
    try {
      setRedeemScreenMsg('Processing Request...');
      localStorage.setItem('isMemberPromoTrigger', true);
      await speedyRedeemDiscount(speedyRedeemCounter);
      proceedToPayment();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - iRedeemItem Failure ${JSON.stringify(error)}`
      );
      if (error?.message?.includes('invalid_passcode')) {
        iRedeemFailed(true);
      } else iRedeemFailed(false);
    } finally {
      localStorage.removeItem('isMemberPromoTrigger');
      dispatch(cfdActions.setUserRewardAction(''));
      dispatch(cfdActions.setSpeedyEnteredPin());
      dispatch(cfdActions.setSelectedSpeedyRewardType());
      SendMessageToCFD({
        CMD: 'redeemOfferInProgress',
        isProgress: false,
      });
    }
  };

  const onExit = () => {
    const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;
    const isMemberPromoTrigger =
      localStorage.getItem('isMemberPromoTrigger') || false;
    if (isMemberTrigger || isMemberPromoTrigger) {
      toast({
        description: isMemberTrigger
          ? 'Waiting for Member response'
          : 'Waiting for Member Promo response',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn waiting for Member response.`
      );
      return;
    }
    if (!member) {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt non-memebr`
      );
      proceedToPayment();
      return;
    }
    // PROMPTABLE DISCOUNT
    if (isFuelPromptEnabled) {
      dispatch(cfdActions.setFuelPromptEnabled(false));
    }
    if (isSWPIntiated || isItemRedemptionIntiated) {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt DismissReward`
      );
      const iTransactionMessage = {
        CMD: 'DismissReward',
      };
      SendMessageToCFD(iTransactionMessage);
      if (isFuelTransactionInProgress) {
        return iRedeemItem();
      }
      if (tempArbitRes) {
        return dispatch(cartActions.setRejectedReward(true));
      }
    } else {
      global?.logger?.info(
        `[7POS UI] - onClickForceFinalizeBtn opt force finalize`
      );
    }
    proceedToPayment();
  };

  useEffect(() => {
    if (isUserTriggerReward || isFuelPromptEnabled) {
      dispatch(cfdActions.setRewardUserTrigger(false));
      if (isFuelPromptEnabled)
        setRedeemScreenMsg('Awaiting customer action...');
      else if (isSpeedyStore)
        setRedeemScreenMsg('Awaiting customer action for passcode entry...');
      else if (isCanada)
        setRedeemScreenMsg('Awaiting customer action for postalcode entry...');
      else setRedeemScreenMsg('Awaiting customer action for zipcode entry...');
    } else if (UserRewardOpted !== '') {
      // #8270 regardless user opt YES/NO state need update
      setUseOptRedeemption(true);
      iRedeemItem();
    }
    return () => {};
  }, [isUserTriggerReward, UserRewardOpted, isFuelPromptEnabled]);

  // Checks the location in state and moves to payment screen
  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(true));
    if (
      location.state !== 'AltID_Notify' &&
      location.state?.offer !== 'best_reward' &&
      location.state?.offer !== 'shop_with_points' &&
      location.state?.offer !== 'fuel_discount'
    ) {
      proceedToPayment();
    } else {
      global?.logger?.info(
        `[7POS UI] - Waiting for customer input for : ${location.state?.offer}`
      );
    }
    return () => {};
  }, []);
  // Get store promo and member before execute isEligible Call
  const TriggerPromoCall = async () => {
    try {
      if (!isSkipTaxPromoVerify) {
        dispatch(cartActions.setFinalizePayStatus(true));
        localStorage.setItem('isMemberPromoTrigger', true);
        await getEligiblePromos({ type: 'Eligible', finalTotalPrice });
        dispatch(cartActions.setFinalizePayStatus(false));
      } else proceedToPayment();
    } catch (error) {
      global?.logger?.error(
        `7POS Application - iRedeemItem Failure ${JSON.stringify(error)}`
      );
    } finally {
      localStorage.removeItem('isMemberPromoTrigger');
    }
  };

  useEffect(() => {
    if (AltIDEntryReset && AltIDEntryIntiate) {
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      if (member) {
        TriggerPromoCall();
      } else {
        proceedToPayment();
      }
    }
  }, [AltIDEntryReset, AltIDEntryIntiate]);

  useEffect(() => {
    if (speedyFuelprompt) {
      history.push('/payment');
      dispatch(cfdActions.setSpeedyFuelPrompt(false));
    }
  }, [speedyFuelprompt]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="70%"
      background="rgb(255,255,255)"
      boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
      my="0.6rem"
      ml="0.5rem"
      mr="0.6rem"
    >
      <Flex
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        mt={isItemRedemptionIntiated || isSWPIntiated ? '10%' : '20%'}
      >
        {localStorage.getItem('isMemberPromoTrigger') ||
        localStorage.getItem('isMemberTrigger') ? (
          <>
            <object type="image/svg+xml" data={loader} width="100px">
              svg-animation
            </object>
            <Text as="strong" fontSize={28}>
              Processing Request...
            </Text>
          </>
        ) : (
          <>
            {isItemRedemptionIntiated || isSWPIntiated ? (
              <>
                <Box
                  mb={15}
                  mt={localStorage.getItem('isMemberPromoTrigger') ? 0 : 50}
                >
                  <Text as="strong" fontSize={28}>
                    {isRedeemScreenMsg}
                  </Text>
                </Box>

                <Text fontSize={20}>
                  Please{' '}
                  <Text as="span" color="#107f62" fontWeight={600}>
                    allow the customer to complete SpeedyRewards
                  </Text>{' '}
                </Text>
                <Text fontSize={20}>
                  <Text as="span" color="#107f62" fontWeight={600}>
                    redemption choice
                  </Text>{' '}
                  or Press Skip Loyalty.
                </Text>
              </>
            ) : (
              <Text
                className={Styles.userentrynotification}
                dangerouslySetInnerHTML={{ __html: iNotificationMsg }}
              />
            )}
          </>
        )}
      </Flex>
      {// #7847/#7682 disable exit button once promo trigger
      !localStorage.getItem('isMemberTrigger') &&
        !localStorage.getItem('isMemberPromoTrigger') && (
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExit} label="SKIP LOYALTY" />
          </Box>
        )}
    </Flex>
  );
};

export default SpeedyUserNotification;
