/* eslint-disable react/prop-types */
import React from 'react';
import { Text, Flex } from '@chakra-ui/react';

const VoidTransactionText = ({ type }) => (
  <Flex flexDirection="row" justifyContent="center" alignItems="center" my={5}>
    <Text
      border="1px solid rgb(224, 32, 32)"
      height="1px"
      width="20px"
      pr={2}
      mr={2}
    />
    <Text
      color="rgb(224, 32, 32)"
      fontWeight="500"
      fontFamily="Roboto-Medium"
      fontSize="14px"
    >
      {type === 'VOID' ? 'VOID TRANSACTION' : 'REFUND PURCHASE'}
    </Text>
    <Text
      border="1px solid rgb(224, 32, 32)"
      height="1px"
      width="20px"
      pl={2}
      ml={2}
    />
  </Flex>
);

export default VoidTransactionText;
