/* eslint-disable react/prop-types */
import React from 'react';
import { Text, Flex } from '@chakra-ui/react';

const TransactioHoldText = ({ isTransHold }) => (
  <>
    <Flex
      flexDirection="row"
      justifyContent="center"
      alignItems="center"
      my={5}
    >
      <Text border="1px" height="1px" width="20px" pr={2} mr={2} />
      <Text fontWeight="500" fontFamily="Roboto-Medium" fontSize="14px">
        {isTransHold ? 'STORE IN MEMORY' : 'RECALL FROM MEMORY'}
      </Text>
      <Text border="1px" height="1px" width="20px" pl={2} ml={2} />
    </Flex>
    {isTransHold && (
      <Flex
        flexDirection="row"
        justifyContent="center"
        alignItems="center"
        my={5}
      >
        <Text border="1px" height="1px" width="20px" pr={2} mr={2} />
        <Text fontWeight="500" fontFamily="Roboto-Medium" fontSize="14px">
          TRANSACTION COMPLETE
        </Text>
        <Text border="1px" height="1px" width="20px" pl={2} ml={2} />
      </Flex>
    )}
  </>
);

export default TransactioHoldText;
