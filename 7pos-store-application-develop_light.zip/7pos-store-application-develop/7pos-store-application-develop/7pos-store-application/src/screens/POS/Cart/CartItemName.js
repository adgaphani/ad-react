import React from 'react';
import { Text } from '@chakra-ui/react';
import * as Constants from '../../../constants';
import Styles from './cart.module.css';

export const CartItemName = ({ item, isSelectedItemTaxExempt }) => {
  const nameLines =
    // #6650 Added description feild also incase name is null
    item?.name?.split(Constants.cartItemDelimiter) ||
    item?.description?.split(Constants.cartItemDelimiter);
  const itemColour =
    (item.isMoneyOrder && item.MoneyOrderFlag === Constants.MO_FLG_INVALID) ||
    (item?.itemTypeID === Constants.ITEM_TYPE.CARD_LOAD &&
      item?.CardLoadFlag === Constants.LOAD_FLG_INVALID)
      ? '#ec2526'
      : isSelectedItemTaxExempt
      ? 'rgb(16, 127, 98)'
      : 'black';
  return (
    nameLines?.map((name, idx) => (
      <Text
        key={idx.toString()}
        fontFamily="Roboto-Medium"
        className={Styles.itemName}
        isTruncated
        color={itemColour}
      >
        {name}
      </Text>
    )) || (
      <Text
        key={1}
        fontFamily="Roboto-Medium"
        className={Styles.itemName}
        isTruncated
        color={itemColour}
      >
        No Item Name
      </Text>
    )
  );
};
