import React, { memo } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import Styles from './Member.module.css';

const Member = ({ member, isSpeedyStore }) => (
  <Flex
    className={
      isSpeedyStore ? Styles.memberContainerSpeedy : Styles.memberContainer
    }
  >
    <Text
      fontFamily="Roboto-Bold"
      fontWeight="bold"
      fontSize="18px"
      width="100%"
      my={2}
    >
      {member?.iMemberStatus === 'Unknown' ? (
        'Member Transaction'
      ) : (
        <>
          {member?.first_name?.toUpperCase()}
          {member?.first_name && ` | `}
          {member.rewards_points} points
        </>
      )}
    </Text>
  </Flex>
);

export default memo(Member);
