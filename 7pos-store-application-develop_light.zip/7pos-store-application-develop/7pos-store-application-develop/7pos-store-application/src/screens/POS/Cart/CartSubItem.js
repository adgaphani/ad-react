/* eslint-disable react/no-children-prop */
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import { Button } from '../../../components/Common/Buttons';
import Icon_Delete from '../../../Icons/Icon_Delete.svg';
import { displayCurrency } from '../../../Utils/appUtils';

const cartItemSubLine = props => {
  const {
    itemName,
    itemAmount,
    itemColour = '',
    itemAmtColour = '',
    KeyIndex = 0,
    DeleteIcon = 0,
    clearCoupon,
    isRemoved = false,
    type,
    flag,
    depositFee,
  } = props;

  const location = useLocation();

  const [isMouseHover, setMouseHover] = useState(false);

  const mouseEnter = () => {
    if (location.pathname.toLowerCase() === '/home') setMouseHover(true);
  };
  /* const mouseLeave = () => {
    // console.log('blur');
    setMouseHover(false);
  }; */
  useEffect(() => {
    let isTimer = null;
    if (isMouseHover) {
      isTimer = setTimeout(() => {
        setMouseHover(false);
      }, 5000);
    }
    return () => {
      if (isTimer) clearTimeout(isTimer);
    };
  }, [isMouseHover]);

  const isFees = () => type === 'BOTTLE_DEPOSIT' || type === 'ECO_FEE';

  const getItemAmtColour = () => {
    if (isFees()) {
      return 'rgb(16, 127, 98)';
    }
    return itemAmtColour;
  };

  const getItemAmount = () => {
    if (isFees()) {
      return `${displayCurrency({ price: depositFee })}${flag}`;
    }
    return itemAmount;
  };

  return (
    <Flex
      key={KeyIndex}
      flexDirection="row"
      alignItems="center"
      pl={3}
      border={isMouseHover ? '1px solid rgb(16, 127, 98)' : 0}
      borderBottom={!isMouseHover ? '1px' : ''}
      borderBottomColor={!isMouseHover ? 'lightgray' : ''}
      borderLeft={isMouseHover ? '4px solid rgb(16, 127, 98)' : 0}
      alignSelf="center"
      py={2}
      fontSize="14px"
      color="rgb(91, 97, 107)"
      fontWeight="normal"
      fontFamily="Roboto-Regular"
      onMouseEnter={() => mouseEnter()}
      // onMouseLeave={() => mouseLeave()}
      onTouchStart={() => mouseEnter()}
      // onTouchEnd={() => mouseLeave()}
    >
      <Text color={getItemAmtColour()} as={isRemoved ? 's' : ''}>
        {getItemAmount()}
      </Text>
      <Text ml={2} color={itemColour} width="60%">
        {itemName}
      </Text>
      {DeleteIcon === 1 && isMouseHover && (
        <Button
          alignItems="right"
          rounded={0}
          border="none"
          backgroundColor="white"
          height="none"
          children={<img src={Icon_Delete} alt="dlt" />}
          _hover={{ bg: 'white' }}
          _active={{ bg: 'white' }}
          onClick={clearCoupon}
        />
      )}
    </Flex>
  );
};
cartItemSubLine.defaultProps = {
  itemName: '',
  itemAmount: '',
  itemColour: '',
  itemAmtColour: '',
  KeyIndex: 0,
  DeleteIcon: 0,
  clearCoupon: () => null,
  isRemoved: false,
};

cartItemSubLine.propTypes = {
  itemName: PropTypes.string,
  itemAmount: PropTypes.string,
  itemColour: PropTypes.string,
  itemAmtColour: PropTypes.string,
  KeyIndex: PropTypes.number,
  DeleteIcon: PropTypes.number,
  clearCoupon: PropTypes.func,
  isRemoved: PropTypes.bool,
};
export default cartItemSubLine;
