/* eslint-disable react/no-children-prop */
/* eslint-disable no-use-before-define */

import {
  Box,
  Flex,
  InputGroup,
  InputLeftAddon,
  InputRightAddon,
  NumberInput,
  NumberInputField,
  Text,
} from '@chakra-ui/react';
import React, { useEffect } from 'react';
import Icon_Decrease from '../../../Icons/Icon_Decrease.svg';
import Icon_Delete from '../../../Icons/Icon_Delete.svg';
import Icon_Increase from '../../../Icons/Icon_Increase.svg';
import Styles from './cart.module.css';
import ItemSubline from './CartSubItem';
import { getMergedCouponPromo } from '../../../Utils/cartUtils';
import {
  MO_FLG_INVALID,
  LOAD_FLG_INVALID,
  ITEM_TYPE,
} from '../../../constants';
import { CartItemName } from './CartItemName';

export default React.memo(
  ({
    item,
    keyindex,
    fuelPrepaidAmount,
    incItemQuantity,
    decItemQuantity,
    onDeleteItem,
    onRemoveCoupon,
    showCustomDailpad,
    onCartItemClick,
    getTaxIndicator,
    itemsuffix,
    isTransactionRefund,
    isTransactionVoid,
    getDiscountsTaxPrefix,
    cardLoadfeePrefix,
    selectedItemId,
    isSelectedItemTaxExempt,
    MaxallowedItemQty,
    isSpeedyStore,
    selectedItem,
    itemColour,
    pathname,
    updatedFuelDiscounts,
    ...props
  }) => {
    useEffect(() => {
      console.log('ITEM RENDER');
    });

    const itemOverrideprice =
      (item.quantity * parseFloat(item?.overridedPrice).toFixed(2)) / 100;

    const itemRetailprice =
      (item.quantity * parseFloat(item?.retailPrice).toFixed(2)) / 100;

    const renderItem = () => {
      const fees = item.fees?.length ? [...item.fees] : [];
      return [...getMergedCouponPromo(item), ...fees];
    };
    let LoadDiscount = null;
    let LoadFeeDiscount = null;
    if (item.cardDiscounts) {
      LoadDiscount = item.cardDiscounts.filter(i => i.type === 'L');
      LoadFeeDiscount = item.cardDiscounts.filter(i => i.type === 'F');
    }
    const itemAmountStrike =
      item?.overridedPrice ||
      (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
      (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
        item?.CardLoadFlag === LOAD_FLG_INVALID);

    const subLines = renderItem();
    return (
      <Box
        bg={
          selectedItemId === item?.itemId &&
          !item?.isFuel &&
          item?.itemTypeID !== ITEM_TYPE.CARD_LOAD &&
          item?.itemId !== undefined
            ? '#d4d4d4'
            : ''
        }
        className={
          isSelectedItemTaxExempt
            ? item.isExemptTax
              ? Styles.cartItemRedBorder
              : Styles.cartItemBorder
            : ''
        }
        key={keyindex}
      >
        <Flex
          flexDirection="row"
          justifyContent="space-between"
          alignItems="center"
          pl={4}
          pr={2}
          py={2}
          border={
            item.itemId === selectedItem?.itemId && item.itemId !== undefined
              ? '1px solid rgb(16, 127, 98)'
              : 0
          }
          borderLeft={
            item.itemId === selectedItem?.itemId && item.itemId !== undefined
              ? '4px solid rgb(16, 127, 98)'
              : '1px solid  lightgray'
          }
          borderBottom={
            item.itemId !== selectedItem?.itemId || item.itemId === undefined
              ? '1px solid lightgray'
              : '1px solid rgb(16, 127, 98)'
          }
        >
          <Box
            className={Styles.minWidth}
            onClick={() => onCartItemClick(item, itemsuffix, pathname)}
          >
            <CartItemName
              item={item}
              isSelectedItemTaxExempt={isSelectedItemTaxExempt}
            />
            <Flex flexDirection="row">
              {item.overridedPrice && (
                <Text mr={2} className={Styles.retailPrice} color={itemColour}>
                  {Number(itemOverrideprice) >= 0
                    ? `$${parseFloat(itemOverrideprice).toFixed(2)}`
                    : `-$${parseFloat(
                        Math.abs(Number(itemOverrideprice))
                      ).toFixed(2)}`}
                  {`${itemsuffix}`}
                </Text>
              )}
              <Text
                className={Styles.retailPrice}
                color={itemColour}
                as={itemAmountStrike ? 's' : ''}
              >
                {Number(itemRetailprice) >= 0
                  ? `$${parseFloat(itemRetailprice).toFixed(2)}`
                  : `-$${parseFloat(Math.abs(Number(itemRetailprice))).toFixed(
                      2
                    )}`}
                {`${itemsuffix}`}
              </Text>
            </Flex>
          </Box>
          {(!item?.agePrefetch && item.isFuel && item.totalRetailPrice > 0) ||
          item.isCarwash ||
          (!item.isFuel && !item.isCarwash) ? (
            <InputGroup
              background="rgb(233, 233, 233)"
              borderRadius="24px"
              height="48px"
              width={!item.isFuel && !item.isCarwash && '144px'}
              marginRight={
                !isSpeedyStore && (item.isFuel || item.isCarwash) && '96px'
              }
              border="none"
            >
              {item.quantity > 1 ? (
                <InputLeftAddon
                  rounded={0}
                  border="none"
                  background="transparent"
                  bg="none"
                  height="none"
                  onClick={() => decItemQuantity(item, pathname)}
                  children={<img src={Icon_Decrease} alt="dec" />}
                />
              ) : (
                <InputLeftAddon
                  rounded={0}
                  border="none"
                  background="transparent"
                  height="none"
                  onClick={() => onDeleteItem(item, pathname)}
                  children={<img src={Icon_Delete} alt="dlt" />}
                  className={item?.agePrefetch ? Styles.zeroOpacity : ''}
                />
              )}
              {!item.isFuel && !item.isCarwash && (
                <>
                  <NumberInput
                    defaultValue={item.quantity}
                    max={MaxallowedItemQty}
                    clampValueOnBlur={false}
                    value={item.quantity}
                    onFocus={showCustomDailpad(item)}
                    className={
                      item?.agePrefetch
                        ? Styles.zeroOpacity
                        : Styles.cartItemCount
                    }
                  >
                    <NumberInputField p={0} height="100%" />
                  </NumberInput>
                  <InputRightAddon
                    rounded={0}
                    border="none"
                    background="transparent"
                    height="none"
                    onClick={() => incItemQuantity(item, pathname)}
                    children={<img src={Icon_Increase} alt="Inc" />}
                    className={item?.agePrefetch ? Styles.zeroOpacity : ''}
                  />
                </>
              )}
            </InputGroup>
          ) : null}
        </Flex>
        {item?.itemTypeID === ITEM_TYPE.CARD_LOAD && (
          <>
            {LoadDiscount && LoadDiscount.length > 0 && (
              <ItemSubline
                {...props}
                itemName={LoadDiscount[0]?.description}
                itemAmount={
                  isTransactionRefund || isTransactionVoid
                    ? `$${parseFloat(LoadDiscount[0]?.amount).toFixed(
                        2
                      )}${itemsuffix}`
                    : `-$${parseFloat(LoadDiscount[0]?.amount).toFixed(
                        2
                      )}${itemsuffix}`
                }
                itemAmtColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                itemColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              />
            )}
            {item?.feeDetails && (
              <ItemSubline
                {...props}
                itemName={item?.feeDetails.name}
                itemAmount={
                  Number(item?.feeDetails.retailPrice) >= 0
                    ? `$${parseFloat(item?.feeDetails.retailPrice).toFixed(
                        2
                      )}${cardLoadfeePrefix}`
                    : `-$${parseFloat(
                        Math.abs(Number(item?.feeDetails.retailPrice))
                      ).toFixed(2)}${cardLoadfeePrefix}`
                }
                itemAmtColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                itemColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              />
            )}
            {LoadFeeDiscount && LoadFeeDiscount.length > 0 && (
              <ItemSubline
                {...props}
                itemName={LoadFeeDiscount[0]?.description}
                itemAmount={
                  isTransactionRefund || isTransactionVoid
                    ? `$${parseFloat(LoadFeeDiscount[0]?.amount).toFixed(
                        2
                      )}${cardLoadfeePrefix}`
                    : `-$${parseFloat(LoadFeeDiscount[0]?.amount).toFixed(
                        2
                      )}${cardLoadfeePrefix}`
                }
                itemAmtColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                itemColour={
                  item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
                }
                isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              />
            )}
          </>
        )}
        {item.isMoneyOrder && Number(item?.moneyOrderFee) > 0 && (
          <ItemSubline
            itemName={item.moneyOrderFeeName}
            itemAmount={`$${parseFloat(item?.moneyOrderFee / 100).toFixed(
              2
            )} ${itemsuffix}`}
            itemAmtColour={
              item.moneyOrderFeeOverride === 'Y' ||
              item.MoneyOrderFlag === MO_FLG_INVALID
                ? '#ec2526'
                : ''
            }
            itemColour={
              item.moneyOrderFeeOverride === 'Y' ||
              item.MoneyOrderFlag === MO_FLG_INVALID
                ? '#ec2526'
                : ''
            }
            isRemoved={
              item.moneyOrderFeeOverride === 'Y' ||
              item.MoneyOrderFlag === MO_FLG_INVALID
            }
          />
        )}
        {subLines?.length > 0 && (
          <>
            {subLines.map((data, KeyIndex) => (
              <>
                {(data.itemDiscount || data?.retailPrice) && (
                  <ItemSubline
                    key={KeyIndex}
                    itemName={data.short_name ? data.short_name : data.name}
                    type={data.type}
                    flag={
                      data?.type === 'BOTTLE_DEPOSIT' ||
                      data?.type === 'ECO_FEE'
                        ? getTaxIndicator(data, item)
                        : ''
                    }
                    depositFee={((data.retailPrice || 0) / 100) * item.quantity}
                    itemAmount={
                      isTransactionRefund || isTransactionVoid
                        ? `$${parseFloat(data.itemDiscount).toFixed(2) /
                            100}${getDiscountsTaxPrefix(item, data)}`
                        : `-$${parseFloat(data.itemDiscount).toFixed(2) /
                            100}${getDiscountsTaxPrefix(item, data)}`
                    }
                    itemAmtColour="#ec2526"
                  />
                )}
                {data.amount && (
                  <ItemSubline
                    key={KeyIndex}
                    itemName={data.name}
                    itemAmount={
                      isTransactionRefund || isTransactionVoid
                        ? `$${parseFloat(Math.abs(data.amount)).toFixed(
                            2
                          )}${getDiscountsTaxPrefix(item, data)}`
                        : `-$${parseFloat(Math.abs(data.amount)).toFixed(
                            2
                          )}${getDiscountsTaxPrefix(item, data)}`
                    }
                    itemAmtColour="#ec2526"
                    DeleteIcon={1}
                    clearCoupon={() =>
                      onRemoveCoupon(item, data.couponseq, pathname)
                    }
                  />
                )}
              </>
            ))}
          </>
        )}
        {isSpeedyStore &&
          item.isFuel &&
          fuelPrepaidAmount < 0 &&
          updatedFuelDiscounts?.map((dItem, i) => (
            <ItemSubline
              key={i}
              itemName={dItem.pos_text}
              itemAmount={`${parseFloat(dItem.discount / 100).toFixed(2)}/gal`}
            />
          ))}
        {item.isExemptTax && pathname?.includes('/home') && (
          <Flex
            flexDirection="row"
            alignItems="center"
            pl={3}
            borderBottom="1px"
            borderBottomColor="lightgray"
            alignSelf="center"
            py={2}
            fontSize="14px"
            color="rgb(91, 97, 107)"
            fontWeight="normal"
            fontFamily="Roboto-Regular"
          >
            <Text>****TAX EXEMPT****</Text>
          </Flex>
        )}
      </Box>
    );
  }
);
