/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/prop-types */
import { Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Button } from '../../../components/Common/Buttons';
import Icon_twarning from '../../../Icons/warning_yellow.svg';
import { setShowNotifications } from '../../../slices/notifications.slice';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';

const HandlingItemRemove = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    dispatch(setShowNotifications(false));
    dispatch(cartActions.setFinalizePayStatus(true));
    dispatch(cfdActions.setUserActionScreenActive(true));
    return () => {};
  }, []);

  const handleItemRemoveCancel = () => {
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(setShowNotifications(true));
    return history.push('/home');
  };

  const handleItemRemoveContinue = () => {
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cartActions.setTransactionAborted(true));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(setShowNotifications(true));
    return history.push('/home');
  };

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="calc(100vh - 80px)"
      flexDirection="column"
    >
      <img src={Icon_twarning} height="48px" width="54px" />
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Regular"
        fontSize="18px"
        fontWeight="normal"
        textAlign="center"
        mx="5rem"
        my="1rem"
      >
        You are about to remove the last item.
      </Text>
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Regular"
        fontSize="18px"
        fontWeight="normal"
        textAlign="center"
        mx="5rem"
      >
        Press CONTINUE to abort the transaction or CANCEL to proceed with the
        transaction.
      </Text>
      <Flex direction="row" mt="2.5rem">
        <Button
          className="btn secondaryButton"
          borderRadius="3px"
          height="50px"
          width="140px"
          mr="1rem"
          onClick={handleItemRemoveCancel}
        >
          <Text>Cancel</Text>
        </Button>
        <Button
          className="btn primaryButton"
          // border="1px solid rgb(77, 184, 86)"
          height="50px"
          width="140px"
          mr={3}
          _hover={{ bg: 'primary' }}
          onClick={handleItemRemoveContinue}
        >
          <Text>Continue</Text>
        </Button>
      </Flex>
    </Flex>
  );
};

export default HandlingItemRemove;
