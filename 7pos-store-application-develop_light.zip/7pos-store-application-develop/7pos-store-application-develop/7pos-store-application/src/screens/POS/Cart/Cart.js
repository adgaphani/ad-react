/* eslint-disable max-lines */
/* eslint-disable react/prop-types */
/* eslint-disable no-unreachable */

import React, {
  useEffect,
  useRef,
  memo,
  useState,
  useContext,
  useMemo,
} from 'react';

import { Flex, Text, Box } from '@chakra-ui/react';
import { debounce } from 'lodash';
import moment from 'moment';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import {
  getHardTotalSummaryAttributeValues,
  names as hardTotalsNames,
  // updateCacheHardTotals,
} from '7pos-hardtotals';
import { Button } from '../../../components/Common';
import {
  useSharedFuelRequest,
  useSoundToast,
  useCartHandler,
  useFuelCache,
  useSafeCart,
  useFuel,
  usePrivileges,
  usePromoWrapper,
  useCarWash,
  usePMB,
  useCartItemUtils,
  // usePromoRequests,
} from '../../../hooks';
import Styles from './cart.module.css';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import CartItem from './CartItem';
import EmptyCart from './EmptyCart';
import Member from './Member';
import ItemQty from './ItemQty';
import {
  getPriceDetails,
  GetTaxForTransaction,
  GetPromoItem,
  buildCartInfoCFD,
  getMerchItemsTotalAmount,
  tranFinalAmountValidation,
  getUpadtedFuelDiscounts,
} from '../../../Utils/cartUtils';
import { socketActions } from '../../../slices/socket.slice';
import {
  handlePayRequest,
  paymentRecepitRequest,
  createTaxObject,
} from '../../../Utils/paymentUtils';
import { WebSocketContext } from '../../../components/Common/WebSocket/WebSocketProvider';
import { SendMessageToCFD } from '../../../Communication';
import MediaAbortedText from './MediaAbortedText';
import VoidTransactionText from './VoidTransactionText';
import TransactionHoldText from './TransactionHoldText';
import {
  removeDuplicates,
  CreditItemRunningTotal,
  initiaizeAppLogger,
  // getTaxDetails,
  getScreenTaxDetails,
  captureHardTotals,
  finalizeHardTotals,
  storeTranSeqNumber,
} from '../../../Utils/appUtils';
import { fetchEmailReceipt } from '../../../api/payment';
import CartSummary from './cartSummary';
import CartHeader from './cartHeader';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { isLottery } from '../../../Utils/lotteryUtils';
import {
  SKIP_PROMO,
  SKIP_PROMO_TAX,
  MO_FLG_INVALID,
  LOAD_FLG_INVALID,
  SKIP_PROMO_VALIDATION,
  ITEM_TYPE,
} from '../../../constants';
import { AppContext } from '../../../AppContext';
import { PIPOTransaction } from '../Payment/PainInOut/PIPOTransaction';
import { cashFunctionActions } from '../../../slices/cashFunctions.slice';
import store from '../../../store';
import * as coinDispenser from '../../../hardware/coin_dispenser';
import { getDVR } from '../../../hardware/dvr';
import { CartItems } from './CartItems';

const Cart = ({ isFuelScreen = false }) => {
  const history = useHistory();
  const location = useLocation();
  const itemEndRef = useRef();
  const { keyPressSound, startLoading, stopLoading, showToast } = useContext(
    AppContext
  );
  const toast = useSoundToast();
  const { realTimeQuanity } = useCartHandler();
  const { processUnlockPumpIfNeeded } = useSharedFuelRequest();
  const { refundCache, resetRefundCache } = useFuelCache();
  const { getFuelReceiptAttts, fuelPrepaidAmount } = useFuel();
  const { isValidUserFunction } = usePrivileges();
  const { clearCode } = useCarWash();
  const { getEligiblePromos } = usePromoWrapper();
  const { submitPMB } = usePMB();
  const {
    incItemQuantity,
    decItemQuantity,
    onDeleteItem,
    onRemoveCoupon,
    openPriceOverride,
    getItemSuffix,
    getTaxIndicator,
    getDiscountTaxPrefix,
    getCardLoadPrefix,
    showCustomDailpad,
    onCartItemClick,
  } = useCartItemUtils();

  const {
    member,
    items,
    transactionId,
    taxInfo,
    taxData,
    storeDetails,
    UserActionScreenActive,
    user,
    paymentDetails,
    deviceInfo,
    AltIDEntryIntiate,
    AltIDEntryReset,
    config,
    basketPromo,
    disableFinalizePay,
    isTransactionVoid,
    MemNotFoundNotification,
    paymentHistory,
    paymentMediaList,
    triggerCouponValidation,
    NotifyItemScanStatus,
    allPayments,
    isTransactionRefund,
    paymentTransactionId,
    cartChangeTrial,
    isTransactionAborted,
    runningTotal,
    balanceActive,
    MemberBarcodeInfo,
    loadCardMediaList,
    pipoTransaction,
    transactionMemory,
    isTransHold,
    cashBack,
    isSafeDrop,
    safeDropType,
    IntiateTaxExempt,
    isAgePrefetch,
    showTransHoldText,
    isMediaAborted,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    isPromoCallSkip,
    disableTransHoldFP,
    isTransactionFinalize,
    preCartItems,
    isOnlyFuelInTheCart,
    mediaAbortedPaymentList,
    isPrintChargereversalMessage,
    chargeReversalMediaPaymentList,
    transactionComments,
    transactionStartTime,
    isPromoInProgress,
    isTransactionTriggered,
    updateTax,
    tranAgeVerifyInfo,
    channel,
    isPaymentTriggered,
    isOfflinePromoTriggered,
    isSpeedyStore,
    isFinalizeClick,
    itemQuantity,
    fuelDiscounts,
    cartItems,
    selectedTaxExemptItems,
    MaxallowedItemQty,
    selectedItem,
    updatedDiscounts,
  } = useSelector(
    state => ({
      fuelDiscounts: state.cart?.calculatedFuelDiscounts?.loyaltyDiscounts,
      balanceActive: state.balance.isActive,
      member: state.cart.member,
      items: state.cart.items,
      transactionId: state.cart.transactionId,
      taxInfo: state.cart.taxInfo,
      storeDetails: state.main.storeDetails,
      user: state.auth.user,
      paymentDetails: state.cart.paymentDetails,
      deviceInfo: state.main.deviceInfo,
      UserActionScreenActive: state.cfd.UserActionScreenActive,
      AltIDEntryIntiate: state.cfd.AltIDEntryIntiate,
      AltIDEntryReset: state.cfd.AltIDEntryReset,
      config: state.main.configuration,
      basketPromo: state.cart.basketPromo,
      disableFinalizePay: state.cart.disableFinalizePay,
      isTransactionVoid: state.cart.isTransactionVoid,
      MemNotFoundNotification: state.cfd.MemNotFoundNotification,
      paymentHistory: state.cart.paymentHistory,
      paymentMediaList: state.cart.paymentMediaList,
      triggerCouponValidation: state.cart.triggerCouponValidation,
      NotifyItemScanStatus: state.cart.NotifyItemScanStatus,
      allPayments: state.cart.allPayments,
      isTransactionRefund: state.cart.isTransactionRefund,
      isPromoCallSkip: state.cart.isPromoCallSkip,
      paymentTransactionId: state.cart.paymentTransactionId,
      cartChangeTrial: state.cart.cartChangeTrial,
      isTransactionAborted: state.cart.isTransactionAborted,
      runningTotal: state.cart.runningTotal,
      MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
      loadCardMediaList: state.cart.loadCardMediaList,
      pmb: state.cart.pmb,
      pipoTransaction: state.cashFunctions.pipoTransaction,
      isTransHold: state.cart.isTransHold,
      transactionMemory: state.cart.transactionMemory,
      cashBack: state.socket.cashBack,
      isSafeDrop: state.cart.isSafeDrop,
      safeDropType: state.cart.safeDropType,
      IntiateTaxExempt: state.cart.IntiateTaxExempt,
      isAgePrefetch: state.main.storeDetails?.address?.country === 'CA',
      showTransHoldText: state.cart.showTransHoldText,
      isMediaAborted: state.cart.isMediaAborted,
      taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
      taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
      disableTransHoldFP: state.cart.disableTransHoldFP,
      isTransactionFinalize: state.cfd.isTransactionFinalize,
      preCartItems: state.cart.preCartItems,
      isOnlyFuelInTheCart: !state.cart.cartItems.filter(i => !i.isFuel)?.length,
      isFuelIncluded: state.cart.cartItems.filter(i => i.isFuel).length > 0,
      mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
      isPrintChargereversalMessage: state.cart.isPrintChargereversalMessage,
      chargeReversalMediaPaymentList: state.cart.chargeReversalMediaPaymentList,
      transactionComments: state.cart.transactionComments,
      transactionStartTime: state.cart.transactionStartTime,
      isPromoInProgress: state.cart.isPromoInProgress,
      isTransactionTriggered: state.cart.isTransactionTriggered,
      updateTax: state.cart.updateTax,
      functionSecuirtyData: state.main.functionSecuirtyData,
      tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
      channel: state.main.channel,
      isPaymentTriggered: state.cart.isPaymentTriggered,
      isOfflinePromoTriggered: state.cart.isOfflinePromoTriggered,
      isSpeedyStore: state.main.isSpeedyStore,
      isFinalizeClick: state.cart.isFinalizeClick,
      itemQuantity: state.cart.itemQuantity,
      cartItems: state.cart.cartItems,
      taxData: state.cart.taxInfo,
      selectedTaxExemptItems: state.cart.selectedTaxExemptItems,
      selectedItem: state.cart.selectedItem,
      MaxallowedItemQty: state.cart.iMaxallowedItemQty,
      updatedDiscounts: state.cart?.updatedDiscounts,
    }),
    shallowEqual
  );
  const [ws] = useContext(WebSocketContext);
  const { renderSafeCart } = useSafeCart();
  const dispatch = useDispatch();
  const [IntiateTransaction, setIntiateTransaction] = useState(false);
  const [isAbort, setIsAbort] = useState(false);
  const [isPromoRetrigger, setPromoRetrigger] = useState(false);
  const [salesTaxValue, setsalesTaxValue] = useState(null);

  const ItemsMemo = useMemo(() => {
    if (isAgePrefetch) {
      if (tranAgeVerifyInfo?.some(data => data?.birthDate || data?.dateBirth)) {
        return [
          {
            retailPrice: 0,
            name: 'Age Verify',
            quantity: 1,
            agePrefetch: true,
          },
          ...cartItems,
        ];
      }
    }
    return cartItems;
  }, [isAgePrefetch, tranAgeVerifyInfo, cartItems]);

  // #3208 combine all condition for tax data check during finalize button
  const isSkipTaxPromoVerify = useMemo(() => {
    if (!cartItems?.length) {
      return false;
    }
    return cartItems?.every(
      item =>
        item.isMoneyOrder === true ||
        item.isCarwash === true ||
        isLottery(item) ||
        item.isFuel
    );
  }, [cartItems]);

  const {
    finalsubTotalPrice,
    finalTotalPrice,
    totalPromotionPrice,
  } = useMemo(() => {
    console.log('Memo to calculate Price details');
    return getPriceDetails(
      cartItems,
      taxData,
      isTransactionVoid || isTransactionRefund
    );
  }, [cartItems, taxData, isTransactionVoid, isTransactionRefund]);

  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };

  const getsalesTaxValue = () => {
    const taxAssessments = createTaxObject(
      taxInfo,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      isTransactionRefund || isTransactionVoid
    );
    const stateCode = storeDetails?.address?.state;
    const saleTaxValues = getScreenTaxDetails(
      taxAssessments,
      taxInfo,
      isTransactionRefund || isTransactionVoid,
      taxableBeforeEBTExempt,
      taxBeforeEBTExempt,
      stateCode
    );
    setsalesTaxValue(saleTaxValues);
    return saleTaxValues;
  };

  // #5214 added media dependcy as well to send Media abort information
  useEffect(() => {
    getsalesTaxValue();
    // eslint-disable-next-line no-use-before-define
    SendMessageToCFD(buildCartInfo('UpdateTransaction', true));
  }, [taxInfo, allPayments]);

  const buildCartInfo = (command, isForceFetchTax = false) => {
    const iTransactionMessage = buildCartInfoCFD({
      command,
      cartItems,
      member,
      storeDetails,
      isTransactionVoid,
      isTransactionRefund,
      allPayments,
      taxInfo,
      salesTaxValue:
        salesTaxValue === null ||
        (salesTaxValue && salesTaxValue?.length <= 0) ||
        isForceFetchTax
          ? getsalesTaxValue()
          : salesTaxValue,
      isAgePrefetch,
      isMediaAborted,
      tranAgeVerifyInfo,
    });
    return iTransactionMessage;
  };

  const [
    currentPaymentTransactionID,
    setcurrentPaymentTransactionID,
  ] = useState(null);

  useEffect(() => {
    if (
      storeDetails?.storeId !== undefined &&
      paymentTransactionId !== currentPaymentTransactionID
    ) {
      setcurrentPaymentTransactionID(paymentTransactionId);
      initiaizeAppLogger(
        storeDetails?.storeId,
        paymentTransactionId,
        '7pos-store-application',
        null,
        null
      );
    }
  }, [storeDetails, paymentTransactionId]);

  useEffect(() => {
    let isRedirect = false;
    let transStartTime = transactionStartTime;
    if (MemNotFoundNotification) {
      DisplayToastMsg('Member Not Found');
      dispatch(cfdActions.setMemberNFNotificationStatus(false));
      isRedirect = true;
    } else if (NotifyItemScanStatus?.length > 0) {
      DisplayToastMsg(NotifyItemScanStatus);
      dispatch(cartActions.setNotifyScanStatus(''));
    } else if (
      ((ItemsMemo.length === 1 && !member) ||
        isTransactionVoid ||
        isTransactionRefund) &&
      !IntiateTransaction
    ) {
      setIntiateTransaction(true);
      if (transactionStartTime === '') {
        transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
        dispatch(cartActions.setTransactionStartTime(transStartTime));
      }

      const dvr = getDVR();
      dvr.startTransaction(
        config,
        transactionId,
        storeDetails,
        deviceInfo?.id,
        transStartTime,
        isTransactionVoid ? 'Void' : isTransactionRefund ? 'Refund' : 'Sale',
        user?.userId?.toString() || '',
        user
      );
      (cartChangeTrial || []).forEach(cartChangePayload => {
        dvr.handleCartChange(cartChangePayload);
      });
      SendMessageToCFD(buildCartInfo('StartTransaction'));
    } else if (cartItems.length > 0 || ItemsMemo.length > 0 || member) {
      const dvr = getDVR();
      if (!dvr.transactionActive) {
        dvr.startTransaction(
          config,
          transactionId,
          storeDetails,
          deviceInfo?.id,
          transStartTime,
          isTransactionVoid ? 'Void' : isTransactionRefund ? 'Refund' : 'Sale',
          user?.userId?.toString() || '',
          user
        );
        (cartChangeTrial || []).forEach(cartChangePayload => {
          dvr.handleCartChange(cartChangePayload);
        });
      }
      SendMessageToCFD(buildCartInfo('UpdateTransaction'));
    }
    // Redirect to home when user enter phone number via CFD and POS on 7rewards screen
    if (
      window.location.pathname.includes('7Rewards') &&
      (member || isRedirect)
    ) {
      if (transactionStartTime === '') {
        transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
        dispatch(cartActions.setTransactionStartTime(transStartTime));
      }
      // #6505 clear number entry
      dispatch(dailpadActions.resetKeypadValue());
      history.push('/home');
    }
    return () => {};
  }, [
    MemNotFoundNotification,
    member,
    NotifyItemScanStatus,
    isTransactionVoid,
    isTransactionRefund,
    items,
  ]);

  // Sets Transaction Details in Cart page, Will be printed in receipt.
  const updateTransactionDetails = () => {
    try {
      const {
        finalsubTotalPrice,
        finalTotalPrice,
        totalPromotionPrice,
      } = getPriceDetails(
        cartItems,
        null,
        isTransactionVoid || isTransactionRefund
      );
      const itransDetails =
        Number(totalPromotionPrice) > 0
          ? {
              SUBTOTAL: finalsubTotalPrice,
              'DISCOUNT(S)':
                isTransactionRefund || isTransactionVoid
                  ? Number(totalPromotionPrice).toFixed(2)
                  : -Number(totalPromotionPrice).toFixed(2),
            }
          : {
              SUBTOTAL: finalsubTotalPrice,
            };
      // For Abort transaction there is no tax/change need to print on receipt
      itransDetails['TOTAL DUE'] = Number(isNaN(finalTotalPrice))
        ? Number('0.00')
        : Number(finalTotalPrice).toFixed(2);
      dispatch(cartActions.setTransDetails(itransDetails));
      getDVR().handleTransactionSummary(
        cashBack,
        isTransactionRefund,
        isTransactionVoid,
        itransDetails,
        items
      );
      coinDispenser.processSummary(
        cashBack,
        isTransactionRefund || isTransactionVoid,
        itransDetails,
        items
      );
      return itransDetails;
    } catch (e) {
      global?.logger?.error(
        `[7POS UI] - gettransDetails error ${JSON.stringify(e)}`
      );
    }
  };

  const updatePromoAndTax = async ({
    skippromo = 0,
    isOfflinePromo = true,
  }) => {
    let result = null;
    if (
      location.pathname.includes('/CFDNotification') ||
      location.pathname.includes('/payment')
    ) {
      global?.logger?.error(
        `[7POS UI] - updatePromoAndTax skip promo call not applicable in this step (${location.pathname})`
      );
      return;
    }
    if (skippromo !== SKIP_PROMO && skippromo !== SKIP_PROMO_TAX) {
      const totalQuantity = realTimeQuanity();
      const { items, preCartItems } = store.getState().cart;
      try {
        result = await GetPromoItem({
          member,
          transactionId,
          storeDetails,
          items,
          isOfflinePromo,
          isReturnVoid: isTransactionRefund || isTransactionVoid,
          terminalID: deviceInfo?.id || 1,
          MemberBarcodeInfo,
          paymentTransactionId,
          ReceiptTotalAmount: finalTotalPrice,
        });
        if (
          location.pathname.includes('/CFDNotification') ||
          location.pathname.includes('/payment')
        ) {
          setPromoRetrigger(false);
          dispatch(cartActions.setPromoInProgress(false));
          global?.logger?.error(
            `[7POS UI] - updatePromoAndTax skip promo call not applicable in this step (${location.pathname})`
          );
          return;
        }
        if (result !== 'error') {
          if (result?.display_message) {
            DisplayToastMsg(result?.display_message);
          }
          const beforePromoQtyList = result?.items?.map(item => ({
            quantity: item.quantity,
            itemId: item.itemId,
          }));
          const { items: currentItems } = store.getState().cart;
          const afterPromoQtyList = currentItems?.map(item => ({
            quantity: item.quantity,
            itemId: item.itemId,
          }));
          let SkipPromoUpdate = false;
          beforePromoQtyList?.forEach(Item => {
            const isMatchItemQty = afterPromoQtyList?.filter(
              item =>
                item.itemId === Item.itemId && item.quantity === Item.quantity
            );
            if (isMatchItemQty <= 0 && !SkipPromoUpdate) SkipPromoUpdate = true;
          });
          afterPromoQtyList?.forEach(Item => {
            const isMatchItemQty = beforePromoQtyList?.filter(
              item =>
                item.itemId === Item.itemId && item.quantity === Item.quantity
            );
            if (isMatchItemQty <= 0 && !SkipPromoUpdate) SkipPromoUpdate = true;
          });
          const uQuanity = realTimeQuanity();
          // Online promo response also need to validate with current items in the cart.
          if (SkipPromoUpdate || totalQuantity !== uQuanity) {
            global?.logger?.error(
              `[7POS UI] - Skip promo response parse due to promo call ${JSON.stringify(
                beforePromoQtyList
              )} and update ${JSON.stringify(
                afterPromoQtyList
              )}  and ${SkipPromoUpdate}`
            );
            if (isOfflinePromo) {
              // eslint-disable-next-line no-use-before-define
              getOfflinePromo({ skippromo: 0 });
            }
            return;
          }
          if (result?.pmb) {
            dispatch(cartActions.setPmbDetails(result.pmb));
          }
          if (result?.items) {
            let isRequiredItemRefersh = result?.items?.filter(
              item => item?.arbitration?.length > 0
            );
            if (isRequiredItemRefersh?.length <= 0)
              isRequiredItemRefersh = preCartItems?.filter(
                item => item?.arbitration?.length > 0
              );
            if (isRequiredItemRefersh?.length > 0) {
              dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO_TAX));
              dispatch(cartActions.updateItems(result.items));
            } else {
              dispatch(cartActions.addCartItems(result.items));
              dispatch(cartActions.setPreCartItems(result.items));
            }
          }
          if (result?.arbitration) {
            dispatch(cartActions.setArbitration(result.arbitration));
            if (result.arbitration?.basket) {
              const basketPromos = result.arbitration?.basket || [];
              if (basketPromos[0]) {
                // exclude round off charity item
                const iMerchItems = items?.filter(
                  item => !item.isRoundUpCharityItem
                );
                const ignoreLinkedItem = true;
                const { totalMerchSaleAmount } = getMerchItemsTotalAmount(
                  iMerchItems,
                  null,
                  false,
                  null,
                  ignoreLinkedItem
                );
                if (
                  totalMerchSaleAmount <
                  Number(Math.abs(basketPromos[0].item_discount)) / 100
                ) {
                  global?.logger?.info(
                    `[7POS UI] - ignoring basket promo due to eligible items price:${totalMerchSaleAmount} lessthan basket promo:${Number(
                      Math.abs(basketPromos[0].item_discount)
                    ) / 100}`
                  );
                } else
                  dispatch(
                    cartActions.setBasketPromo(
                      removeDuplicates(basketPromos, 'id')
                    )
                  );
              }
            }
          }
        } else {
          global?.logger?.error(`[7POS UI] - promo call failed`);
          const { items: currentItems } = store.getState().cart;
          // #8784 along with items promo also need to refresh calling updateItems for failed scenario
          // dispatch(cartActions.addCartItems(currentItems));
          dispatch(cartActions.updateItems(currentItems));
        }
      } catch (error) {
        const { items: currentItems } = store.getState().cart;
        // #8784 along with items promo also need to refresh calling updateItems for failed scenario
        // dispatch(cartActions.addCartItems(currentItems));
        dispatch(cartActions.updateItems(currentItems));
        global?.logger?.error(
          `[7POS UI] - Offline promo call failed ${JSON.stringify(error)}`
        );
      }
    }
    if (isPromoRetrigger) {
      // eslint-disable-next-line no-use-before-define
      getOfflinePromo({ skippromo: 0 });
    } else {
      dispatch(cartActions.setPromoInProgress(false));
      if (isOfflinePromo) dispatch(cartActions.setUpdateTaxFlag(true));
    }
  };

  const debounceConfig = {
    // leading: true,
    // trailing: true,
  };
  const debouncedUpdatePromoAndTax = debounce(
    ({ skippromo }) => {
      updatePromoAndTax({ skippromo });
    },
    300,
    debounceConfig
  );

  const getOfflinePromo = ({ skippromo = 0 }) => {
    if (!isFinalizeClick) {
      setPromoRetrigger(false);
      const { isPromoInProgress } = store.getState().cart;
      if (!isPromoInProgress) dispatch(cartActions.setPromoInProgress(true));
      debouncedUpdatePromoAndTax({
        skippromo,
      });
    } else {
      Logger?.info(
        `[7POS UI] - Skip offline Promo call : items length:${items?.length} and F&P click status:${isFinalizeClick}`
      );
    }
  };

  const calculateTax = async () => {
    try {
      dispatch(cartActions.setUpdateTaxFlag(false));
      dispatch(cartActions.setFinalizePayStatus(true));
      if (IntiateTaxExempt) startLoading();
      const resulttax = await GetTaxForTransaction(
        items,
        storeDetails,
        isTransactionRefund || isTransactionVoid,
        paymentTransactionId,
        taxData,
        config
      );
      if (resulttax !== 'error' && resulttax?.data) {
        const taxResult = resulttax.data;
        const taxInfoData = JSON.parse(taxResult.data);
        taxInfoData.totalTaxAmount = taxInfoData.totalTaxAmount || '0.00';
        // #9069 make sure tax update only eligible item avialable
        const { items } = store.getState().cart;
        const nonPromoTaxEligibleItems = items.filter(
          i => !i.isFuel && !i.isCarwash && !i.isMoneyOrder
        );
        if (nonPromoTaxEligibleItems.length) {
          dispatch(cartActions.setTaxInfo({ tax: taxInfoData }));
        }
      } else if (resulttax === 'error') {
        DisplayToastMsg('Tax engine failure');
        global?.logger?.error(`[7POS UI] - Tax engine failure`);
      } else if (resulttax === 'resetTax') {
        dispatch(cartActions.setTaxInfo({ tax: null }));
        global?.logger?.info(`[7POS UI] - Reset tax have only lottery/MO`);
      }
      if (IntiateTaxExempt) {
        dispatch(cartActions.setIntiateTaxExempt(false));
        stopLoading();
      }
    } catch (error) {
      stopLoading();
      global?.logger?.error(
        `[7POS UI] - tax call failed ${JSON.stringify(error)}`
      );
    } finally {
      dispatch(cartActions.setFinalizePayStatus(false));
    }
  };

  useEffect(() => {
    if (updateTax) {
      calculateTax();
      // TODO Need to Uncomment ??
      // dispatch(cartActions.setFinalizePayStatus(false));
      setPromoRetrigger(false);
    }
  }, [updateTax]);

  useEffect(() => {
    if (isPromoCallSkip === SKIP_PROMO_TAX)
      dispatch(cartActions.setPromoCallSkipFlag(0));
    if (items.length === 0 || ItemsMemo?.length === 0) {
      setIntiateTransaction(false);
      dispatch(cfdActions.setCatlogID(''));
      dispatch(cfdActions.setMemberRewardID(''));
      dispatch(cartActions.setBasketPromo([]));
      dispatch(cartActions.setTaxInfo({ tax: null }));
      // #9285 removed isAgePrefetch check to send CFD command
      if (!member && !isTransactionVoid && !isTransactionRefund) {
        const iTransactionMessage = {
          CMD: 'IntialState',
          COUNTRY: storeDetails?.address?.country,
        };
        SendMessageToCFD(iTransactionMessage);
        dispatch(cfdActions.setAltIDUserReset(false));
        dispatch(cfdActions.setAltIDUserTrigger(false));
      }
      return;
    }
    const nonPromoTaxEligibleItems = items.filter(
      i => !i.isFuel && !i.isCarwash && !i.isMoneyOrder
    );
    if (!nonPromoTaxEligibleItems.length) {
      // When Non Fuel Items.length is Zero need to reset tax
      global?.logger?.info(
        `[7POS UI] - Skipping PROMO & Tax calls for Fuel Only Cart...`
      );
      // cross check promo clean up after remove promo eligible item and left with prepay
      if (items && preCartItems && items !== preCartItems) {
        dispatch(cartActions.updateItems(items));
      }
      dispatch(cartActions.setTaxInfo({ tax: null }));
      dispatch(cartActions.setPromoInProgress(false));
      dispatch(cartActions.setFinalizePayStatus(false));
      return;
    }
    let isPromoUpdateRequired = false;
    if (
      isPromoCallSkip !== SKIP_PROMO_VALIDATION &&
      isPromoCallSkip !== SKIP_PROMO &&
      !IntiateTaxExempt &&
      !location.pathname.includes('/priceOverride') &&
      preCartItems?.length === items?.length
    ) {
      const beforePromoQtyList = preCartItems?.map(item => ({
        quantity: item.quantity,
        itemId: item.itemId,
        itemSeq: item.itemSeq,
      }));
      const afterPromoQtyList = items?.map(item => ({
        quantity: item.quantity,
        itemId: item.itemId,
        itemSeq: item.itemSeq,
      }));
      beforePromoQtyList?.forEach(Item => {
        const isMatchItemQty = afterPromoQtyList?.filter(item =>
          item?.itemId
            ? item.itemId === Item.itemId && item.quantity === Item.quantity
            : item.itemSeq === Item.itemSeq && item.quantity === Item.quantity
        );
        if (isMatchItemQty <= 0 && !isPromoUpdateRequired)
          isPromoUpdateRequired = true;
      });
      afterPromoQtyList?.forEach(Item => {
        const isMatchItemQty = beforePromoQtyList?.filter(item =>
          item?.itemId
            ? item.itemId === Item.itemId && item.quantity === Item.quantity
            : item.itemSeq === Item.itemSeq && item.quantity === Item.quantity
        );
        if (isMatchItemQty <= 0 && !isPromoUpdateRequired)
          isPromoUpdateRequired = true;
      });
    } else isPromoUpdateRequired = true;
    if (
      !isPaymentTriggered && // #6646 make sure no active payment inprogress
      isPromoUpdateRequired &&
      !isTransactionFinalize &&
      items.length > 0 &&
      !isTransactionAborted &&
      !location.pathname.includes('/CFDNotification') && // promo will call in CFDActionNotification.js
      !location.pathname.includes('/payment') // execute only home screen
    ) {
      const skippromo = 0 || isPromoCallSkip;
      if (isPromoCallSkip === SKIP_PROMO || IntiateTaxExempt) {
        dispatch(cartActions.addCartItems(items));
        dispatch(cartActions.setPreCartItems(items));
        dispatch(cartActions.setUpdateTaxFlag(true));
      } else if (isPromoCallSkip !== SKIP_PROMO_TAX) {
        // #5753 need to execute only required to promo update.
        if (!isPromoInProgress) {
          getOfflinePromo({ skippromo });
        } else {
          setPromoRetrigger(true);
          global?.logger?.info(
            `[7POS UI] - previous Offline promo inprogress...`
          );
        }
      }
      dispatch(cartActions.setPromoCallSkipFlag(0));
    } else {
      dispatch(cartActions.setFinalizePayStatus(false));
      global?.logger?.info(`[7POS UI] - Skip Offline promo call...`);
    }
  }, [items]);

  useEffect(() => {
    // Trigger promo offline promo call when user click back to home screen from payement screen.
    // Need to remove 7rewards promo in home screen.
    if (
      !isPaymentTriggered && // #6646 make sure no active payment inprogress
      isOfflinePromoTriggered &&
      !isTransactionAborted &&
      !location.pathname.includes('/CFDNotification') &&
      !location.pathname.includes('/payment') // execute only home screen
    ) {
      startLoading();
      // reset finalize button when user exit from payment screen.
      dispatch(cartActions.setFinalizePayStatus(false));
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setOfflinePromoTrigger(false));
      getOfflinePromo({ skippromo: 0 });
      stopLoading();
    }
  }, [isOfflinePromoTriggered]);

  const onfinalizePayClick = () => {
    const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;
    // #8820 blocking F&P click if Item query inprogress
    const isItemQueryInProgress =
      localStorage.getItem('isItemQueryInProgress') || false;
    if (!cartItems?.length) {
      Logger?.info(
        `[7POS UI] - finalizePayClick will not trigger due cart items length:${cartItems.length}`
      );
    } else if (!isSkipTaxPromoVerify && !isOnlyFuelInTheCart && !taxInfo) {
      dispatch(cartActions.setUpdateTaxFlag(true));
      Logger?.info(
        `[7POS UI] - finalizePayClick will not trigger due cart items length:${cartItems.length}`
      );
    } else if (isMemberTrigger) {
      global?.logger?.info(
        `[7POS UI] - onfinalizePayClick waiting for Member response`
      );
    } else if (isItemQueryInProgress) {
      global?.logger?.info(
        `7POS Application - onfinalizePayClick waiting for item response`
      );
    } else if (
      isPromoInProgress ||
      isPromoRetrigger ||
      UserActionScreenActive ||
      disableFinalizePay ||
      disableTransHoldFP
    ) {
      global?.logger?.info(`[7POS UI] - Waiting offline promo`);
      getOfflinePromo({ skippromo: 0 });
    } else {
      if (isTransHold && transactionId === transactionMemory.transactionId) {
        dispatch(
          cartActions.setTransRelease({
            config,
            storeDetails,
            terminalNumber: deviceInfo?.id,
            operator: user?.userId?.toString() || '',
          })
        );
      }
      // #7616 make sure promo items clear properly in cart trial before payment screen tirggered
      if (items && preCartItems && items !== preCartItems) {
        dispatch(cartActions.updateItems(items));
      }
      dispatch(cartActions.setFinalizePayStatus(true));
      dispatch(cfdActions.setUserActionScreenActive(true));
      dispatch(socketActions.reset());
      dispatch(cfdActions.IntiatedItemRedemption(false));
      dispatch(cfdActions.IntiatedSWP(false));
      dispatch(cfdActions.setUserRewardAction(''));
      dispatch(cfdActions.setRewardUserTrigger(false));
      dispatch(cartActions.setFinalizeClick(true));
    }
  };

  const finalizePayClick = async () => {
    try {
      startLoading();
      const { items } = store.getState().cart;
      const isValidAmount = tranFinalAmountValidation({
        isReturnOrVoid: isTransactionRefund || isTransactionVoid,
        finalTotalPrice,
        items,
        taxData,
      });
      if (!isValidAmount) {
        DisplayToastMsg('INVALID AMOUNT PLEASE REVIEW TRANSACTION');
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setFinalizePayStatus(false));
        dispatch(dailpadActions.resetKeypadValue());
        dispatch(cartActions.setFinalizeClick(false));
        return isValidAmount;
      }

      const finalizePayClickTime = `${moment
        .utc()
        .format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
      dispatch(cartActions.setfinalizePayClickTime(finalizePayClickTime));
      /* const transactionRequest = handlePayRequest({
        items,
        storeDetails,
        user,
        taxInfo,
        deviceInfo,
        member,
        transactionId,
        finalsubTotalPrice,
        finalTotalPrice,
        transactionStartTime,
        paymentDetails,
        isTransactionVoid,
        isTransactionRefund,
        runningTotal,
        loadCardMediaList,
        tranAgeVerifyInfo,
        paymentHistory,
        allPayments,
      });     
       await updateCacheHardTotals(
        JSON.stringify(transactionRequest),
        cartChangeTrial,
        localStorage.getItem(hardTotalsNames?.AltIDNewMembers)
      ); */
      // Hard totals update/get from library
      localStorage.removeItem('StoreSeqAndHardTotals');
      const summary = await getHardTotalSummaryAttributeValues('nrgt');
      global?.Logger?.debug(
        `[7POS UI] - getHardTotalSummaryAttributeValues ${JSON.stringify(
          summary
        )}`
      );
      dispatch(cartActions.setHardTotalSummary(summary));
      // cross check all offline promo call reset
      if (isPromoInProgress || isPromoRetrigger) {
        global?.Logger?.debug(`[7POS UI] - Waiting offline promo`);
      }
      if (AltIDEntryIntiate && !AltIDEntryReset) {
        dispatch(dailpadActions.resetKeypadValue());
        history.push({
          pathname: '/home/CFDNotification',
          state: 'AltID_Notify',
        });
        return;
      }
      // #5628 avoid to call promo for non member(instore promo already applied)
      // # 8657 added refund and void transaction to skip online promo call
      if (
        !isTransactionVoid &&
        !isTransactionRefund &&
        member &&
        !!member?.loyalty_id
      ) {
        let triggerLoyalty = false;
        if (isSkipTaxPromoVerify && isSpeedyStore) {
          // SCALE-1415 Fixing Lotto with Prepay
          const FuelItem = items?.find(item => item.isFuel);
          if (FuelItem && FuelItem.totalRetailPrice > 0) {
            triggerLoyalty = true;
          }
        }
        if (!isSkipTaxPromoVerify || triggerLoyalty) {
          localStorage.setItem('isMemberPromoTrigger', true);
          await getEligiblePromos({ finalTotalPrice });
          return;
        }
      }
      const displayForceFinalizeScreen =
        config?.storeConfig?.promptForceFinalizeAndPay;
      if (
        displayForceFinalizeScreen &&
        !member &&
        !isTransactionVoid &&
        !isTransactionRefund
      ) {
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setFinalizePayStatus(false));
        dispatch(dailpadActions.resetKeypadValue());
        history.push({
          pathname: '/home/forceFinalize',
        });
        return;
      }
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setFinalizePayStatus(false));
      dispatch(dailpadActions.resetKeypadValue());
      dispatch(cartActions.setFinalizeClick(false));
      history.push('/payment');
    } catch (error) {
      dispatch(cartActions.setFinalizeClick(false));
      dispatch(dailpadActions.resetKeypadValue());
      dispatch(cartActions.setFinalizePayStatus(false));
      dispatch(cfdActions.setUserActionScreenActive(false));
      global?.logger?.error(
        `[7POS UI] - finalizePayClick Failure ${JSON.stringify(error)}`
      );
    } finally {
      dispatch(cartActions.setFinalizeClick(false));
      localStorage.removeItem('isMemberPromoTrigger');
      stopLoading();
    }
  };

  useEffect(() => {
    if (isFinalizeClick) {
      finalizePayClick();
    }
  }, [isFinalizeClick]);

  const printRecepitData = async (type, transInfo) => {
    const receiptType = 'PRINT';
    // Removing Carwash Meta to remove carwash code from receipt
    const updatedItems = items.map(i => {
      if (i.isCarwash) {
        return {
          ...i,
          metaInfo: {},
        };
      }
      return i;
    });
    const paymentReqdata = paymentRecepitRequest({
      storeDetails,
      items: updatedItems,
      transInfo,
      paymentDetails,
      deviceInfo,
      user,
      transactionId,
      taxInfo,
      paymentHistory,
      paymentMediaList,
      transactionType: type,
      allPayments,
      member,
      basketPromo,
      isTransactionVoid,
      isTransactionRefund,
      config,
      loadCardMediaList,
      mediaAbortedPaymentList,
      isPrintChargereversalMessage,
      chargeReversalMediaPaymentList,
      fuelAttrs: getFuelReceiptAttts(),
    });
    try {
      paymentReqdata.receiptType = receiptType;
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
      global?.logger?.info(`[7POS UI] - Print receipt API successful`);
    } catch (error) {
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        global?.logger?.error(
          `[7POS UI] - Print receipt API Failure ${JSON.stringify(error)}`
        );
        DisplayToastMsg(errorMessage.message);
      } else DisplayToastMsg('Receipt could not be printed. Please try again');
    }
  };

  const onAbortTrans = () => {
    if (
      (cartItems.length === 0 && !isTransactionTriggered) ||
      // #6649 added card load status for F&P and abort
      (location.pathname !== '/home' && location.pathname !== '/home/group') ||
      disableFinalizePay ||
      disableTransHoldFP ||
      isPromoInProgress
    ) {
      global?.logger?.error(
        `[7POS UI] - Tax/Promo API inprogress so transaction abort not allowed at this moment (Item Length :${cartItems.length})(Finalize Button Status Status :${disableFinalizePay})`
      );
      DisplayToastMsg('Abort Transaction Not Allowed');
      return;
    }
    // make sure promo items clear properly in cart trial before abort transaction tirggered
    if (items && preCartItems && items !== preCartItems) {
      dispatch(cartActions.updateItems(items));
    }
    const isUserHavePermission = isValidUserFunction('aborttransaction');
    if (!isUserHavePermission) {
      history.push({
        pathname: '/home/functionSecurity',
        redirectionData: {
          pathname: '/home/abortConfirmation',
        },
        iFunctionName: 'aborttransaction',
      });
    } else {
      return history.push('/home/abortConfirmation');
    }
  };

  const storeSeqAndHardtotals = async () => {
    try {
      // Update tran sequence number once transaction complete
      let storedSeq = localStorage.getItem('StoreSeqAndHardTotals');
      storedSeq = storedSeq
        ? JSON.parse(storedSeq)
        : { transactionId: '', status: false, paymentTransactionId: '' };
      if (
        storedSeq.paymentTransactionId === paymentTransactionId &&
        storedSeq.status &&
        storedSeq.transactionId === transactionId
      ) {
        global?.Logger?.debug(
          `[7POS UI] - already Posted Hard totals storeSeqAndHardtotals(abort) and ${paymentTransactionId} `
        );
        return;
      }
      global?.logger?.info(
        `[7POS UI] - Posting Hard totals storeSeqAndHardtotals(abort) and ${paymentTransactionId} `
      );
      localStorage.setItem(
        'StoreSeqAndHardTotals',
        JSON.stringify({
          paymentTransactionId: paymentTransactionId.toString(),
          status: true,
          transactionId: transactionId.toString(),
        })
      );
      const {
        items,
        member,
        runningTotalTax,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        MembertransactionId,
        allPayments,
      } = store.getState().cart;
      localStorage.setItem('mediaInformation', JSON.stringify(allPayments));
      const { cashBack } = store.getState().socket;
      storeTranSeqNumber({
        transactionId,
        MembertransactionId,
        correlationID: paymentTransactionId,
      });
      finalizeHardTotals({
        items,
        member,
        runningTotalTax,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        cashBack,
      });
      await captureHardTotals();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store transaction seq and update Hartotals failed ${JSON.stringify(
          error
        )}`
      );
    }
  };

  // TODO: Refactor TriggerAbortTransaction function
  const TriggerAbortTransaction = async transInfo => {
    // #5177 cross check all offline promo call reset
    if (
      isPromoInProgress ||
      isPromoRetrigger ||
      (location.pathname !== '/home' && location.pathname !== '/home/group') // #6649 added card load status for F&P and abort
    ) {
      dispatch(cartActions.setTransactionAborted(false));
      Logger.info(`[7POS UI] - Waiting offline promo`);
      DisplayToastMsg('Abort Transaction Not Allowed');
      if (isPromoInProgress || isPromoRetrigger)
        getOfflinePromo({ skippromo: 0 });
      return;
    }
    if (cartItems.length === 0 && !isTransactionTriggered) return;
    dispatch(socketActions.reset());
    try {
      if (refundCache) {
        dispatch(cartActions.setTransactionAborted(false)); // Marking that the abort operation is rejected.
        return showToast({
          description: Messages.fuel_refund_abort_not_allowed,
          position: 'top-left',
        });
      }
      // #4347 added transaction start time check for abort transaction.
      let transStartTime = transactionStartTime;
      if (transactionStartTime === '') {
        transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
        dispatch(cartActions.setTransactionStartTime(transStartTime));
      }
      startLoading();
      let { creditAmount, creditTax, creditCount } = CreditItemRunningTotal(
        items,
        taxData,
        basketPromo
      );
      const {
        finalsubTotalPrice,
        finalTotalPrice,
        totalPromotionPrice,
        totalCouponPrice,
      } = getPriceDetails(
        cartItems,
        null,
        isTransactionVoid || isTransactionRefund
      );
      // For void transaction GT should be current total + voided item
      // #8258 coupon amount should not minus from GT
      let CurrentrunningTotal = runningTotal;
      if (isTransactionRefund || isTransactionVoid)
        CurrentrunningTotal =
          (Math.abs(finalsubTotalPrice) -
            Math.abs(totalPromotionPrice) +
            Math.abs(totalCouponPrice)) *
            100 +
          runningTotal;

      const isAbortTransaction = true;
      const abortRequest = handlePayRequest({
        items,
        storeDetails,
        user,
        taxInfo,
        deviceInfo,
        member,
        transactionId,
        finalsubTotalPrice,
        finalTotalPrice,
        transactionStartTime: transStartTime,
        paymentDetails,
        isTransactionVoid,
        isTransactionRefund,
        paymentTransactionId,
        tranAgeVerifyInfo,
        basketPromo,
        cartChangeTrial,
        runningTotal: CurrentrunningTotal,
        loadCardMediaList,
        isAbortTransaction,
        paymentHistory,
        allPayments,
        transactionComments,
      });
      // Adjust credit Item balance to running total and make Credit Item Bucket as zero
      let TotalrunningTotal = Number(CurrentrunningTotal) / 100 || 0;
      if (!isTransactionVoid && !isTransactionRefund)
        TotalrunningTotal = Math.abs(TotalrunningTotal + creditAmount);
      else {
        // eslint-disable-next-line no-lonely-if
        if (finalsubTotalPrice < 0)
          TotalrunningTotal = Math.abs(TotalrunningTotal + creditAmount);
        else TotalrunningTotal = Math.abs(TotalrunningTotal - creditAmount);
      }
      abortRequest.transactionHeaderInfo.transactionStatus = 'ABORTED';
      // For abort transaction no need add tax to running total
      abortRequest.transactionDetails.runningTotal = TotalrunningTotal;
      abortRequest.transactionDetails.paymentInformation = null;
      localStorage.removeItem('StoreSeqAndHardTotals');
      const summary = await getHardTotalSummaryAttributeValues('nrgt');
      global?.logger?.info(
        `[7POS UI] - getHardTotalSummaryAttributeValues ${JSON.stringify(
          summary
        )}`
      );
      dispatch(cartActions.setHardTotalSummary(summary));
      const hardTotalSummary = [];
      hardTotalSummary.push(summary);
      hardTotalSummary.push({
        name: 'runningTotal',
        count: 0,
        amount: parseFloat(
          (abortRequest?.transactionDetails?.runningTotal).toFixed(2)
        ),
      });
      abortRequest.transactionDetails.hardTotalSummary = hardTotalSummary;
      const request = JSON.stringify(abortRequest);
      /* await updateCacheHardTotals(request); */
      // updateCdbReport({ transactionRequest: request }); // CDB Update Abort Media

      localStorage.setItem('runningTotalTax', TotalrunningTotal.toString());
      // #7359 making running total also need to sync with runningTotalTax for abort transaction
      dispatch(cartActions.setrunningTotal(TotalrunningTotal));
      dispatch(cartActions.setrunningTotalTax(TotalrunningTotal));
      dispatch(cartActions.setCreditItemCount(0));
      dispatch(cartActions.setCreditItemAmount(0));
      dispatch(cartActions.setCreditItemTaxAmount(0));
      creditAmount = 0;
      creditTax = 0;
      creditCount = 0;
      if (creditAmount) {
        localStorage.setItem(
          hardTotalsNames?.Credit,
          JSON.stringify({
            count: creditCount.toString(),
            amount: creditAmount.toString(),
          })
        );
      }
      if (creditTax) {
        localStorage.setItem(hardTotalsNames?.CreditTax, creditTax.toString());
      }
      const abortTransRequest = {
        messageHeader: {
          timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
          messageType: 'PAYMENT',
          correlationId: paymentTransactionId,
          source: {
            sourceType: 'POS',
            sourceIdentifier: '1',
            version: process.env.REACT_APP_VERSION,
          },
          destination: {
            destinationType: 'PAYMENT',
            destinationIdentifier: '1',
          },
        },
        messageBody: {
          message: `${request}`,
        },
      };
      const cPayrequest = JSON.stringify(abortTransRequest);
      localStorage.setItem('finalPaymentRequest', cPayrequest);
      global?.logger?.info(
        `[7POS UI] - pay request(Abort)  ${JSON.stringify(abortTransRequest)}`
      );
      ws.socket?.send(
        '/app/pinpad/payment',
        {},
        JSON.stringify(abortTransRequest)
      );
      /*
      Validations are included in the promise. If failed, the call will not return a promise.
     */
      processUnlockPumpIfNeeded(false)?.catch(e => {
        Logger.error(`[Fuel] Prepay abort is failed: ${e.message}`);
      });
      clearCode({ showLoader: false })?.catch(e => {
        Logger.error(`[Carwash] Clear Code Failed: ${e.message}`);
      });
      // Reset Fuel Refund Cache
      // eslint-disable-next-line  no-extra-boolean-cast
      if (!!refundCache) resetRefundCache();

      // receipt should print with or without payment media
      getDVR().endTransaction(
        allPayments,
        cashBack,
        config,
        deviceInfo,
        items,
        loadCardMediaList,
        member,
        paymentDetails,
        transactionId,
        'Aborted',
        'abort',
        user
      );
      printRecepitData('abort', transInfo);
      const iTransactionMessage = {
        CMD: 'TransactionComplete',
        Status: 'Aborted',
        CFDRefreshTime: config?.storeConfig?.CFDRefreshTime,
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      // PMB Call
      submitPMB({ finalTotalPrice, isAbortTransaction: true });
      dispatch(cartActions.setTaxInfo({ tax: null }));
      setIsAbort(true);
      setTimeout(() => {
        storeSeqAndHardtotals();
        dispatch(cartActions.emptyCart());
        const { EODEOSDetails } = store.getState().cart;
        // #4996 added memory transaction check before intiate EOD/EOS
        if (EODEOSDetails?.IntiateEODEOS) {
          if (!transactionMemory?.items) {
            const payload = {
              ...EODEOSDetails,
              isCartItemsOnClear: true,
            };
            global?.logger?.info(
              `[7POS UI] - EOD/EOS are intialised ${JSON.stringify(payload)}`
            );
            dispatch(cartActions.setEODEOS(payload));
          } else {
            DisplayToastMsg(
              `${EODEOSDetails?.type} initiated, Please clear transaction from memory`
            );
            global?.logger?.info(
              `[7POS UI] - ${EODEOSDetails?.type} initiated, Please clear transaction from memory`
            );
          }
        }
        setIsAbort(false);
        stopLoading();
        dispatch(cartActions.setTransactionAborted(false));
        dispatch(cfdActions.setTransactionFinalize(false));
        localStorage.removeItem('isMemberTrigger');
        localStorage.removeItem('isMemberPromoTrigger');
        history.replace({
          pathname: '/home',
          state: { reset: true },
        });
      }, 100); // #7850 reduce timer from 5sec to 100ms
    } catch (error) {
      global.logger.error(
        `[7POS UI] - TriggerAbortTransaction Error from POS${JSON.stringify(
          error
        )}`
      );
      stopLoading();
    }
  };

  useEffect(() => {
    if (isTransactionAborted) {
      const transInfo = updateTransactionDetails();
      TriggerAbortTransaction(transInfo);
      setIntiateTransaction(false);
    }
  }, [isTransactionAborted]);

  useEffect(() => {
    if (triggerCouponValidation) {
      dispatch(cartActions.settriggerCouponValidation(false));
      history.push({
        pathname: '/home/GS1Coupon',
        state: 'Trigger',
      });
    }
  }, [triggerCouponValidation]);

  let h = isFuelScreen
    ? 395
    : isTransactionVoid || isTransactionRefund
    ? 320
    : 275;
  if (
    totalPromotionPrice !== '0.00' &&
    totalPromotionPrice !== 'NaN' &&
    totalPromotionPrice !== 0
  ) {
    h += 30;
  }
  const cartItemContainerClass = `calc(100vh - ${h}px)`;

  // Reset the PIPO on the new transaction initiation.
  const resetPreviousTransactionalData = () => {
    dispatch(cashFunctionActions.resetPIPOTransaction());
  };

  useEffect(() => {
    if (IntiateTransaction) {
      resetPreviousTransactionalData();
    }
  }, [IntiateTransaction]);

  const restInFuelCleanUp = async FuelItem => {
    // #9287 left with rest in fuel aborting the transaction
    if (items?.length <= 1) {
      dispatch(cartActions.setTransactionAborted(true));
      // New Toast Added as part of Code Review
      DisplayToastMsg(`Transaction Aborted due to Cart Changes.`);
    } else {
      // Removing the fuelLineItem from cart
      await processUnlockPumpIfNeeded()?.catch(e => {
        Logger.error(`[Fuel] Prepay auto void failed: ${e.message}`);
      });
      // New Toast Added as part of Code Review
      DisplayToastMsg(
        `Fuel Item Has Been Removed Due to Cart Changes. Please Use "Rest In Fuel" As Last Selection.`
      );
      dispatch(cartActions.removeFromCart(FuelItem));
    }
  };

  useEffect(() => {
    const isMemberPromoTrigger =
      localStorage.getItem('isMemberPromoTrigger') || false;
    const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;
    if (
      !isFinalizeClick &&
      !isPromoInProgress &&
      !isTransactionAborted &&
      !isMemberTrigger &&
      !isMemberPromoTrigger &&
      Math.abs(Number(finalTotalPrice)) > 0
    ) {
      const FuelItem = items?.find(item => item.isFuel);
      if (FuelItem) {
        const {
          metaInfo: { isRestInFuel, actualFuelAMount },
        } = FuelItem;
        if (isRestInFuel && Number(finalTotalPrice) !== actualFuelAMount) {
          restInFuelCleanUp(FuelItem);
        }
      }
    }
  }, [finalTotalPrice, isPromoInProgress]);

  const CartItemsMemo = useMemo(
    () =>
      ItemsMemo?.map(item => {
        const paramas = new URLSearchParams(location.search);
        const selectedItemId = Number(paramas.get('itemId')) || null;
        const isSelectedItemTaxExempt = () => {
          if (!location.pathname.toLowerCase().includes('taxexempt')) {
            return false;
          }
          return (
            selectedTaxExemptItems?.findIndex(
              i =>
                (i.itemId === item.itemSeq && i.itemId === item.itemId) ||
                (i.itemId !== item.itemSeq && i.itemSeq === item.itemSeq)
            ) > -1
          );
        };
        const isTaxExempt = isSelectedItemTaxExempt();
        const fDiscounts = item.isFuel && fuelDiscounts;
        const updatedFuelDiscounts = getUpadtedFuelDiscounts(
          fDiscounts,
          updatedDiscounts
        );
        const itemColour =
          (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
          (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
            item?.CardLoadFlag === LOAD_FLG_INVALID)
            ? '#ec2526'
            : isTaxExempt
            ? 'rgb(16, 127, 98)'
            : 'black';
        return (
          <CartItem
            key={`key-${item.itemId}-${item.name}-${item.itemSeq}`}
            item={item}
            isSelectedItemTaxExempt={isTaxExempt}
            selectedItemId={selectedItemId}
            storeDetails={storeDetails}
            isTransactionVoid={isTransactionVoid}
            isTransactionRefund={isTransactionRefund}
            incItemQuantity={incItemQuantity}
            decItemQuantity={decItemQuantity}
            clearCode={clearCode}
            processUnlockPumpIfNeeded={processUnlockPumpIfNeeded}
            onRemoveCoupon={onRemoveCoupon}
            onDeleteItem={onDeleteItem}
            openPriceOverride={openPriceOverride}
            getTaxIndicator={getTaxIndicator}
            itemsuffix={getItemSuffix(item)}
            getDiscountsTaxPrefix={getDiscountTaxPrefix}
            cardLoadfeePrefix={getCardLoadPrefix(item)}
            showCustomDailpad={showCustomDailpad}
            itemColour={itemColour}
            selectedItem={selectedItem}
            MaxallowedItemQty={MaxallowedItemQty}
            onCartItemClick={onCartItemClick}
            pathname={location.pathname}
            isSpeedyStore={isSpeedyStore}
            fuelPrepaidAmount={fuelPrepaidAmount}
            updatedFuelDiscounts={updatedFuelDiscounts}
          />
        );
      }),
    [
      ItemsMemo,
      isTransactionRefund,
      isTransactionVoid,
      location,
      selectedTaxExemptItems,
      selectedItem,
      MaxallowedItemQty,
      fuelDiscounts,
    ]
  );

  // Show the completed PIPO Transaction.
  if (pipoTransaction?.isCompleted) {
    return <PIPOTransaction autoDismiss />;
  }
  if (isSafeDrop && safeDropType) {
    return renderSafeCart();
  }

  return (
    <>
      {ItemsMemo?.length > 0 ||
      isTransactionTriggered ||
      cartItems?.length > 0 ||
      member ||
      itemQuantity > 1 ||
      balanceActive ? (
        <Flex
          direction="column"
          justifyContent="space-between"
          className={Styles.cartContainer}
          height={isFuelScreen ? 'calc(100vh - 177px)' : 'calc(100vh - 80px)'}
        >
          <Box h={cartItemContainerClass}>
            {member && <Member member={member} isSpeedyStore={isSpeedyStore} />}
            <CartHeader transactionId={transactionId} />
            {cartItems.length === 0 &&
              (isTransactionVoid || isTransactionRefund) && (
                <VoidTransactionText
                  type={isTransactionRefund ? 'REFUND' : 'VOID'}
                />
              )}
            {itemQuantity > 1 && <ItemQty itemQuantity={itemQuantity} />}
            {ItemsMemo.length > 0 && (
              <Box
                className={
                  member
                    ? `${Styles.cartItemsWithMember}`
                    : `${Styles.cartItems}`
                }
              >
                <CartItems items={CartItemsMemo} />
                <Text ref={itemEndRef} />
              </Box>
            )}
          </Box>
          {(ItemsMemo.length > 0 ||
            cartItems.length > 0 ||
            isTransactionTriggered) && (
            <Box className={cartItems.length > 6 ? Styles.border : ''}>
              {(isTransactionVoid || isTransactionRefund) && (
                <VoidTransactionText
                  type={isTransactionRefund ? 'REFUND' : 'VOID'}
                />
              )}
              {showTransHoldText && (
                <TransactionHoldText isTransHold={isTransHold} />
              )}
              {cartItems.length > 0 && isMediaAborted && <MediaAbortedText />}
              {(cartItems.length > 0 ||
                (isTransactionTriggered && cartItems.length > 0)) && (
                <CartSummary
                  finalsubTotalPrice={finalsubTotalPrice}
                  taxData={salesTaxValue}
                  allPayments={allPayments}
                  totalPromotionPrice={totalPromotionPrice}
                  isReturnVoid={isTransactionVoid || isTransactionRefund}
                  finalTotalPrice={finalTotalPrice}
                />
              )}
              <Flex mx={4} justifyContent="center">
                {!isAbort ? (
                  <Button
                    className="btn primaryButton"
                    size="lg"
                    width="100%"
                    isDisabled={
                      cartItems.length === 0 ||
                      // #6649 added card load status for F&P and abort
                      (location.pathname !== '/home' &&
                        location.pathname !== '/home/group') ||
                      disableFinalizePay ||
                      disableTransHoldFP ||
                      isPromoInProgress ||
                      isPromoRetrigger
                    }
                    _hover={{ bg: 'primary' }}
                    onClick={() => {
                      onfinalizePayClick();
                    }}
                  >
                    <Text
                      // color="rgb(255, 255, 255)"
                      fontSize="18px"
                      fontWeight="bold"
                      textAlign="center"
                      fontFamily="Roboto-Bold"
                    >
                      FINALIZE & PAY
                    </Text>
                  </Button>
                ) : (
                  <Text marginTop="20px">**** TRANSACTION ABORTED ****</Text>
                )}
              </Flex>
              <Flex m={5} justifyContent="center">
                {!isAbort ? (
                  <Text
                    className="text primaryText"
                    fontSize="14px"
                    fontWeight="500"
                    textAlign="center"
                    fontFamily="Roboto-Medium"
                    onClick={() => {
                      keyPressSound
                        ?.play?.()
                        .catch(e => console.log('Sound error', e));
                      onAbortTrans();
                    }}
                  >
                    ABORT TRANSACTION
                  </Text>
                ) : (
                  <Text>---- TRANSACTION COMPLETE ----</Text>
                )}
              </Flex>
            </Box>
          )}
        </Flex>
      ) : (
        ''
      )}
      {(!items || cartItems.length === 0) &&
      !member &&
      !isSafeDrop &&
      !itemQuantity > 0 && // #9251 added check to skip empty card render
        !(isTransactionVoid || isTransactionRefund) && (
          <>
            <Flex
              justifyContent="center"
              alignItems="center"
              height={
                isFuelScreen ? 'calc(100vh - 177px)' : 'calc(100vh - 80px)'
              }
            >
              <EmptyCart />
            </Flex>
          </>
        )}
    </>
  );
};
export default memo(Cart);
