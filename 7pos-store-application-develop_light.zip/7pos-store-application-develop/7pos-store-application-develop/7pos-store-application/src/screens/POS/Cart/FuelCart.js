import React from 'react';

import Cart from './Cart';
import FuelCartPumpStatus from './FuelCartPumpStatus';

const FuelCart = ({ selectedPump, crindDenialsReason }) => (
  <>
    <Cart isFuelScreen />
    {(selectedPump > 0 || crindDenialsReason) && (
      <FuelCartPumpStatus
        pumpNumber={selectedPump}
        crindDenialsReason={crindDenialsReason}
      />
    )}
  </>
);

export default FuelCart;
