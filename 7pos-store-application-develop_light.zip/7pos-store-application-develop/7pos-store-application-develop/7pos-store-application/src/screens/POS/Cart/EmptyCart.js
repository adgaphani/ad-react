import React, { useContext } from 'react';
import { Flex, Stack, Box, Text, Button } from '@chakra-ui/react';
import Add_circle from '../../../Icons/Add_circle.svg';
import Styles from './cart.module.css';
import { AppContext } from '../../../AppContext';

const EmptyCart = ({
  onAbortTrans,
  isTransactionVoid,
  isTransactionRefund,
  isAbort,
}) => {
  const { keyPressSound } = useContext(AppContext);

  const abortClick = () => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    onAbortTrans();
  };

  return (
    <Flex
      direction="column"
      p={2}
      justifyContent="center"
      alignItems="center"
      textAlign="center"
      className={
        !(isTransactionRefund || isTransactionVoid)
          ? Styles.cartContainer
          : Styles.cartContainerAbort
      }
    >
      <Stack
        style={{ flex: 1 }}
        justifyContent="center"
        alignItems="center"
        textAlign="center"
      >
        <Box>
          <img src={Add_circle} alt="iconCircle" />
        </Box>
        <Text
          color="rgb(44, 47, 53)"
          fontSize="12px"
          fontWeight="900"
          fontFamily="Roboto-Bold"
        >
          Add an Item
        </Text>
        <Text
          color="rgb(91, 97, 107)"
          fontSize="12px"
          fontWeight="normal"
          fontFamily="Roboto-Regular"
        >
          Tap an item to add to the transaction
        </Text>
      </Stack>
      {(isTransactionRefund || isTransactionVoid) && (
        <>
          <Flex mx={4} justifyContent="center">
            {!isAbort ? (
              <Button
                className="btn primaryButton"
                size="lg"
                width={300}
                isDisabled
                _hover={{ bg: 'primary' }}
              >
                <Text
                  color="rgb(255, 255, 255)"
                  fontSize="18px"
                  fontWeight="bold"
                  textAlign="center"
                  fontFamily="Roboto-Bold"
                >
                  FINALIZE & PAY
                </Text>
              </Button>
            ) : (
              <Text marginTop="20px">**** TRANSACTION ABORTED ****</Text>
            )}
          </Flex>
          <Flex m={5} justifyContent="center">
            {!isAbort ? (
              <Text
                color="rgb(16, 127, 98)"
                fontSize="14px"
                fontWeight="500"
                textAlign="center"
                fontFamily="Roboto-Medium"
                onClick={abortClick}
              >
                ABORT TRANSACTION
              </Text>
            ) : (
              <Text>---- TRANSACTION COMPLETE ----</Text>
            )}
          </Flex>
        </>
      )}
    </Flex>
  );
};

export default EmptyCart;
