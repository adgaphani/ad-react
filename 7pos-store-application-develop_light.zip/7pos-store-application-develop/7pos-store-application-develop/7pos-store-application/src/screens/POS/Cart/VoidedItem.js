import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';

export default function VoidedItem({ item }) {
  const items = [];
  for (let i = 0; i < item.quantity; i += 1) {
    items.push(
      <Box key={`${item.name}_${i}`}>
        <Flex margin="15px" justifyContent="space-between" flexDirection="row">
          <Text>1 {item.name}</Text>
          <Text>{parseFloat(item?.retailPrice).toFixed(2) / 100}</Text>
        </Flex>
      </Box>
    );
  }
  return (
    // <Box>
    //   <Flex margin={"15px"} justifyContent="space-between" flexDirection="row">
    //     <Text>1 {item.name}</Text>
    //     <Text>{parseFloat(item?.retailPrice / 100).toFixed(2)}</Text>
    //   </Flex>
    // </Box>
    items
  );
}
