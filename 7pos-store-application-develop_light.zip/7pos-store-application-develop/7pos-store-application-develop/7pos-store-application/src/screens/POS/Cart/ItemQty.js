import React, { memo } from 'react';
import { Flex, Text } from '@chakra-ui/react';

const ItemQty = ({ itemQuantity }) => (
  <Flex
    flexDirection="column"
    justifyContent="center"
    textAlign="center"
    background="rgb(233, 245, 248)"
    borderBottom="1px solid rgb(227, 227, 227)"
  >
    <Text fontFamily="Roboto-Medium" fontSize="20px" width="100%" my={3}>
      <span>Select PLU/Scan Item &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
      <span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {` Qty: ${itemQuantity}`}
      </span>
    </Text>
  </Flex>
);

export default memo(ItemQty);
