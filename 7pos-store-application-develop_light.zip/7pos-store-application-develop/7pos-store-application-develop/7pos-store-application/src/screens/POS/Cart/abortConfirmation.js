/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/prop-types */
import { Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Button } from '../../../components/Common/Buttons';
import Icon_twarning from '../../../Icons/warning_yellow.svg';
import { setShowNotifications } from '../../../slices/notifications.slice';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';

const abortConfirmation = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  useEffect(() => {
    dispatch(cartActions.setFinalizePayStatus(true));
    dispatch(cfdActions.setUserActionScreenActive(true));
    dispatch(setShowNotifications(false));
    dispatch(cartActions.setTransactionAborted(false));
    Logger.info(`[7POS UI] - Notification for the Abort transaction`);
    return () => {};
  }, []);

  const handleAbortCancel = () => {
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(setShowNotifications(true));
    Logger.info(`[7POS UI] - SA click exit from Abort notification`);
    dispatch(cartActions.setTransactionAborted(false));
    return history.push('/home');
  };

  const handleAbortContinue = () => {
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cartActions.setTransactionAborted(true));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(setShowNotifications(true));
    dispatch(cartActions.setCancelPaymentForMCLoyalty(true));
    Logger.info(`[7POS UI] - SA Intiate the Abort notification`);
    return history.push('/home');
  };

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="calc(100vh - 80px)"
      flexDirection="column"
    >
      <img src={Icon_twarning} height="48px" width="54px" />
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Regular"
        fontSize="18px"
        fontWeight="normal"
        textAlign="center"
        mx="5rem"
        my="1rem"
      >
        You are about to ABORT this transaction!
      </Text>
      <Flex direction="row" mt="2.5rem">
        <Button
          className="btn secondaryButton"
          borderRadius="3px"
          height="50px"
          width="140px"
          mr="1rem"
          onClick={handleAbortCancel}
        >
          <Text>Cancel</Text>
        </Button>
        <Button
          className="btn primaryButton"
          // border="1px solid rgb(77, 184, 86)"
          height="50px"
          width="140px"
          mr={3}
          _hover={{ bg: 'primary' }}
          onClick={handleAbortContinue}
        >
          <Text>Continue</Text>
        </Button>
      </Flex>
    </Flex>
  );
};

export default abortConfirmation;
