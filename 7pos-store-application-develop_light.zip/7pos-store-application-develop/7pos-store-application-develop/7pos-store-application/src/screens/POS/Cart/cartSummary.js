import React from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import { getTaxAssesments, getTotalBtlDeposit } from '../../../Utils/appUtils';
// import store from '../../../store';

const CartSummary = ({
  finalsubTotalPrice,
  taxData,
  allPayments,
  totalPromotionPrice,
  isReturnVoid,
  finalTotalPrice,
}) => {
  const { cartItems, taxInfo, isCanada } = useSelector(state => ({
    cartItems: state.cart.cartItems,
    taxInfo: state.cart.taxInfo,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
  }));

  const isUsCash = p => p?.label?.toLowerCase().includes('us cash');
  const getLabel = p => {
    if (isUsCash(p)) return 'US Cash';
    if (p?.label === 'Big Bucks') return 'Big Buck';
    if (p?.label !== undefined) return p?.label;
    return `${p?.receiptDetails?.cardName} ${
      p?.receiptDetails?.cardName?.toLowerCase().includes('debit') ||
      p?.receiptDetails?.cardName?.toLowerCase().includes('credit')
        ? 'Card'
        : ''
    }`;
  };

  return (
    <>
      {!!getTotalBtlDeposit(cartItems) && (
        <Flex justifyContent="space-between" my={2} mx={4} color="#5B616B">
          <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
            Total Btl Dep-N
          </Text>
          <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
            {parseFloat(getTotalBtlDeposit(cartItems)).toFixed(2)}
          </Text>
        </Flex>
      )}
      <Flex justifyContent="space-between" my={2} mx={4} color="#5B616B">
        <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
          Subtotal
        </Text>
        <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
          {parseFloat(finalsubTotalPrice).toFixed(2)}
        </Text>
      </Flex>

      {!isCanada &&
        taxData &&
        Object.keys(taxData).map((key, index) => (
          <Flex
            justifyContent="space-between"
            my={2}
            mx={4}
            color="#5B616B"
            key={index.toString()}
          >
            <Text
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              {key}
            </Text>
            <Text
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              {taxData[key] || '0.00'}
            </Text>
          </Flex>
        ))}
      {isCanada &&
        getTaxAssesments(taxInfo).map((item, index) => (
          <Flex
            key={index}
            justifyContent="space-between"
            my={2}
            mx={4}
            color="#5B616B"
          >
            <Text
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              {item.description} on {item.displayTaxableAmount}
            </Text>
            <Text
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              {item.displayTaxAmountCurrency}
            </Text>
          </Flex>
        ))}
      {allPayments && allPayments.length > 0 ? (
        <>
          {allPayments.map(p => (
            <>
              <Text
                mx={4}
                fontSize="15px"
                fontWeight="normal"
                fontFamily="Roboto-Regular"
              >
                {isUsCash(p) ? p?.label : ''}
              </Text>
              <Flex
                justifyContent="space-between"
                my={2}
                mx={4}
                color="#5B616B"
              >
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  {getLabel(p)}
                </Text>
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  {parseFloat(p.payment?.amount).toFixed(2)}
                </Text>
              </Flex>
            </>
          ))}
        </>
      ) : (
        ''
      )}
      {totalPromotionPrice !== '0.00' &&
        totalPromotionPrice !== 'NaN' &&
        totalPromotionPrice !== 0 && (
          <Flex justifyContent="space-between" my={2} mx={4}>
            <Text
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
              color="#5B616B"
            >
              Discount(s)
            </Text>
            <Text
              color="#EC2526"
              fontSize="15px"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              {isReturnVoid
                ? `${parseFloat(Math.abs(totalPromotionPrice)).toFixed(2)}`
                : `-${parseFloat(Math.abs(totalPromotionPrice)).toFixed(2)}`}
            </Text>
          </Flex>
        )}
      <Flex
        justifyContent="space-between"
        my={2}
        mx={4}
        color="rgb(44, 47, 53)"
      >
        <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
          Total
        </Text>
        <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
          {Number(finalTotalPrice) > 0 || Number(finalTotalPrice) === 0
            ? `$${parseFloat(finalTotalPrice).toFixed(2)}`
            : `-$${parseFloat(Math.abs(Number(finalTotalPrice))).toFixed(2)}`}
        </Text>
      </Flex>
    </>
  );
};

CartSummary.defaultTypes = {
  finalsubTotalPrice: 0,
  taxData: [],
  allPayments: [],
  totalPromotionPrice: 0,
  isReturnVoid: false,
  finalTotalPrice: 0,
};

export default CartSummary;
