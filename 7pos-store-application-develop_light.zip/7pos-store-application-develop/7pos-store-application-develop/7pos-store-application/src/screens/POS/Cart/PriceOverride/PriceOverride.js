/* eslint-disable jsx-a11y/label-has-for */
/* eslint-disable jsx-a11y/label-has-associated-control */

import { Box, Flex, Heading, Input, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Button } from '../../../../components/Common/Buttons';
import CustomDailPad from '../../../../components/Common/DailPad/CustomDailPad/CustomDailPad';
import Icon_confirm from '../../../../Icons/Icon_confirm.svg';
import Styles from './PriceOverride.module.css';
import { cfdActions } from '../../../../slices/cfd.slice';
import { overridePrice } from '../../../../slices/cart.slice';

const PriceOverride = () => {
  const dispatch = useDispatch();
  const location = useLocation();

  const history = useHistory();
  const [newPrice, setNewPrice] = useState('');
  const [isAppliedNewPrice, setAppliedNewPrice] = useState(false);
  // const [isFocussed, setFocus] = useState(true);
  const [isPriceInvalid, setPriceInvalidity] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const item = location?.state?.item;
  const params = new URLSearchParams(location.search);
  const { isTransactionVoid, isTransactionRefund } = useSelector(state => ({
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
  }));

  useEffect(() => {
    // #8636 added HALO and LALO check
    if (item?.lowAmountLockout >= 0 && item?.highAmountLockout > 0)
      setErrorMessage(
        `${
          Number(newPrice) === 0
            ? 'cannot be $0.00 or lower'
            : `between ${
                item?.lowAmountLockout > 0 ? item?.lowAmountLockout : 0.01
              } and ${item?.highAmountLockout}`
        }`
      );
    else
      setErrorMessage(
        `${
          Number(newPrice) === 0
            ? 'cannot be $0.00 or lower'
            : 'cannot exceed $99.99'
        }`
      );
    return () => {};
  }, [newPrice]);

  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(true));
  }, []);

  if (!(item && params.get('itemId'))) {
    dispatch(cfdActions.setUserActionScreenActive(false));
    history.push('/home');
    return;
  }

  const updatePrice = () => {
    if (!newPrice) return;
    const price = Number(newPrice);
    let isInValid = false;
    if (item.storeCoupon && item.storeCoupon[0]) {
      item.storeCoupon.map(coupondata => {
        if (price < Math.abs(coupondata.amount)) {
          isInValid = true;
        }
        return coupondata;
      });
    }
    if (!isInValid) {
      if (!isPriceInvalid && price > 0) {
        dispatch(overridePrice({ item, price: price * 100 }));
        setAppliedNewPrice(true);
      }
    } else {
      setPriceInvalidity(true);
      setErrorMessage('should not be less than coupon amt');
    }
  };

  const handlePriceChange = price => {
    const [priceWhole, priceDecimal] = price.split('.');
    let formattedPrice = price.slice(0, price.length);
    if (priceWhole !== undefined && priceDecimal !== undefined) {
      formattedPrice = `${priceWhole}.${priceDecimal.slice(0, 2)}`;
    }
    setNewPrice(formattedPrice);
    const newPrice = Number(formattedPrice);
    const isPriceEmpty = price.length === 0;
    if (!isPriceEmpty) {
      const currentPrice = parseFloat(item?.retailPrice).toFixed(2) / 100;
      const priceDifference = newPrice - currentPrice;
      // #8636 added HALO and LALO check
      if (
        newPrice > 0 &&
        item?.lowAmountLockout >= 0 && // #9024 added to zero check as well few items have zero LALO
        item?.highAmountLockout > 0
      ) {
        if (
          newPrice <= 0 ||
          newPrice < item?.lowAmountLockout ||
          newPrice > item?.highAmountLockout
        ) {
          setPriceInvalidity(true);
          return;
        }
      } else if (priceDifference >= 100 || newPrice <= 0) {
        setPriceInvalidity(true);
        return;
      }
      setPriceInvalidity(false);
    }
  };

  const onExit = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    history.push('/home');
  };

  return (
    <Box bg="#ffffff" p={4} shadow="md" height="100%">
      <Flex flexDirection="column" justifyContent="space-between" height="94%">
        {isAppliedNewPrice ? (
          <Flex
            flexDirection="column"
            aliginItems="center"
            justifyContent="space-between"
            mt="100px"
            mx="177px"
            height="206px"
          >
            <Heading
              color="rgb(50, 53, 61)"
              justifyContent="center"
              fontSize="28px"
              fontWeight="bold"
              textAlign="center"
            >
              New Price Applied!
            </Heading>
            <Flex justifyContent="center">
              <img
                src={Icon_confirm}
                height="80px"
                width="80px"
                alt="success"
              />
            </Flex>
            <Text
              color="rgb(29, 137, 107)"
              fontSize="24px"
              fontWeight="500"
              textAlign="center"
            >
              $
              {((isTransactionVoid || isTransactionRefund) &&
                !item?.negativeSalesFlag) ||
              (!isTransactionVoid &&
                !isTransactionRefund &&
                item?.negativeSalesFlag)
                ? -newPrice
                : newPrice}{' '}
              is the new price
            </Text>
          </Flex>
        ) : (
          <Flex flexDirection="column">
            <Heading
              textAlign="center"
              justifyContent="center"
              color="rgb(44, 47, 53)"
              fontSize={30}
            >
              Price Override
            </Heading>
            <Box w="75%" m="1em auto">
              <Flex alignItems="center" pt={10}>
                <Text className={Styles.item}>
                  {item.name}: ${parseFloat(item?.retailPrice).toFixed(2) / 100}
                </Text>
              </Flex>
              <Flex
                className="floating-label"
                alignItems="center"
                mt={6}
                mb={2}
              >
                <Input
                  // placeholder={isFocussed ? "" : 'Enter New Price $'}
                  placeholder=" "
                  size="lg"
                  autoFocus
                  mr={4}
                  className={`${Styles.inputField} floating-input ${
                    isPriceInvalid
                      ? Styles.borderColorOnError
                      : Styles.borderColorOnFocus
                  }`}
                  value={newPrice}
                  // onChange={(e) => setNewPrice(e.target.value)}
                  focusBorderColor="primary"
                  // onFocus={() => setFocus(!isFocussed)}
                />
                {/* {isFocussed && <label>Enter New Price $</label>} */}
                <label
                  className={
                    isPriceInvalid
                      ? Styles.labelColorOnError
                      : Styles.labelColorOnFocus
                  }
                >
                  Enter New Price $
                </label>
              </Flex>
              {isPriceInvalid && (
                <label className={Styles.errorMessage}>
                  Price {errorMessage}.
                </label>
              )}
            </Box>
            {/* <Flex alignItems="center" my={4} m="1em auto">
              <Button className={Styles.doneButton} onClick={updatePrice}>
                <Text color="#5b616b">DONE</Text>
              </Button>
            </Flex> */}
          </Flex>
        )}{' '}
        {!isAppliedNewPrice && (
          <CustomDailPad
            dailPadValue={newPrice}
            setDailPadValue={handlePriceChange}
            onEnter={updatePrice}
          />
        )}
        <Button
          alignSelf="flex-end"
          className={Styles.exitButton}
          onClick={onExit}
          mb={15}
          mr={15}
        >
          <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
            EXIT
          </Text>
        </Button>
      </Flex>
    </Box>
  );
};

export default PriceOverride;
