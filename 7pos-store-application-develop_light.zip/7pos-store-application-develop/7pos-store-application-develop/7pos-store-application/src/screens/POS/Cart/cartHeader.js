import React from 'react';
import { Flex, Text } from '@chakra-ui/react';

const CartHeader = ({ transactionId }) => (
  <Flex
    borderBottom="1px solid rgb(211, 211, 211)"
    height="39px"
    alignItems="center"
  >
    <Flex
      ml={4}
      flexDirection="row"
      justifyContent="flex-start"
      alignItems="baseline"
    >
      <Text
        color="rgb(44, 47, 53)"
        fontSize="20px"
        fontFamily="Roboto-Medium"
        fontWeight="500"
        mr={1}
      >
        Transaction{' '}
      </Text>{' '}
      <Text
        fontSize="16px"
        fontFamily="Roboto-Regular"
        fontWeight="regular"
        color="rgb(44, 47, 53)"
        alignItems="center"
      >
        #{transactionId}
      </Text>
    </Flex>
  </Flex>
);

CartHeader.defaultTypes = {
  transactionId: '',
};

export default CartHeader;
