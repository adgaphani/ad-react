import React from 'react';
import { useLocation } from 'react-router-dom';

import { Flex, Box, Text, Image } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import Styles from './FuelCart.module.css';
import { PumpImageMapper } from '../../../components/Fuel/FuelPumps/helpers/fuel/PumpImageMapper';
import { FuelPumpDescription } from '../../../components/Fuel/FuelPumps/helpers/FuelPumpStatus';
import FuelStyles from '../../../components/Fuel/FuelPumps/helpers/fuel/FuelScreenPump.module.css';
import PumpStyles from '../../../components/Fuel/FuelPumps/helpers/fuel/PumpNumberDisplay.module.css';

const FuelCartPumpStatus = ({ pumpNumber, crindDenialsReason }) => {
  const location = useLocation();
  const { pumpState } = useSelector(state => {
    const cPump = state.fuel.fuelPumps.find(
      pump => pump.pumpNumber === pumpNumber
    );
    console.log('CPUMP', cPump);
    return {
      selectedPump: cPump,
      pumpState: cPump?.currentState?.fuelState,
    };
  });
  if (location?.state?.isCrindDenialScreen && crindDenialsReason) {
    return (
      <Box
        className={`${FuelStyles.wrapper} ${Styles.wrapper} ${FuelStyles.D}`}
      >
        <Flex height="100%" alignItems="center">
          <Text className={`${PumpStyles.text}`} fontSize="14px">
            {crindDenialsReason}
          </Text>
        </Flex>
      </Box>
    );
  }

  return (
    <Box
      className={`${FuelStyles.wrapper} ${Styles.wrapper} ${FuelStyles[pumpState]}`}
    >
      <Flex height="100%" alignItems="center">
        <Text className={`${PumpStyles.text} ${Styles.content}`}>
          {pumpNumber}
        </Text>
        <Image
          className={`${PumpStyles.image} ${Styles.content} ${PumpStyles.small} ${Styles.image}`}
          src={PumpImageMapper[pumpState]}
        />
        <Text className={`${PumpStyles.text} ${Styles.content}`}>
          {FuelPumpDescription[pumpState]}
        </Text>
      </Flex>
    </Box>
  );
};

export default FuelCartPumpStatus;
