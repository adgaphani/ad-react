import React from 'react';

export const CartItems = ({ items }) => <>{items}</>;
