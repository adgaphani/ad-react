/* eslint-disable max-lines */
/* eslint-disable no-use-before-define */
/* eslint-disable import/order */
import { Box, Flex, Text } from '@chakra-ui/react';
import {
  useFuel,
  useSoundToast,
  useCart,
  useHardTotals,
  useEBTBagFee,
  useCharityRoundOff,
} from '../../../../hooks';
import React, { useContext, useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import CashBackText from './paymentSummary/cashBackText';
import {
  EBTSNAP,
  EBTCB,
  LOAD_REQUEST_INPROGRESS,
  WSTopics,
  SIGNATURE_CAPTURE,
} from '../../../../constants';
import Member from '../../Cart/Member';
import PaymentSummary from './paymentSummary/paymentSummary';
import PaymentTransactionItem from './paymentTransactionItem';
import { SendMessageToCFD } from '../../../../Communication';
import Styles from './paymentTransaction.module.css';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { cartActions } from '../../../../slices/cart.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import {
  currencyFixed,
  CreditItemRunningTotal,
  getTaxDetails,
  getScreenTaxDetails,
  getTaxAssesments,
  captureHardTotals,
  finalizeHardTotals,
  storeTranSeqNumber,
  finalizeAndPayClickTimeTrack,
} from '../../../../Utils/appUtils';
import { getLineTax, remapTaxObject } from '../../../../Utils/cartUtils';
import {
  processReceiptTransDetails,
  getTransPriceDetails,
  getTransactionBalanceDue,
} from '../../../../Utils/Payments/paymentTransactionUtils';
import {
  handlePayRequest,
  getBalanceDue,
  transactionTimeTrack,
  createTaxObject,
} from '../../../../Utils/paymentUtils';
import moment from 'moment';
import { processTax } from '../../../../Utils/tax';
import { unFormatCurrency } from '../../../../Utils/format';
import { PIPOTransaction } from '../PainInOut/PIPOTransaction';
import { isLottery, isOnlyLotteryInCart } from '../../../../Utils/lotteryUtils';
import { fetchTax } from '../../../../api/cart/fetchTax';
import { AppContext } from '../../../../AppContext';
import store from '../../../../store';
import * as coinDispenser from '../../../../hardware/coin_dispenser';
import { getDVR } from '../../../../hardware/dvr';
import { TransactionTypes } from '../../../../TransactionTypes';
import { FuelUtils } from '../../../../Utils';
import { fuelActions } from '../../../../slices/fuel.slice';

const PaymentTransaction = () => {
  const history = useHistory();
  const { refreshHardTotals } = useHardTotals();
  const [iTransactionTaxAmount, setTransactionTaxAmount] = useState(0);
  const [iTransactionTaxableAmount, setTransactionTaxableAmount] = useState(0);
  const [isRoundUpRemoved, setRoundUpRemoved] = useState(false);
  const [isEBTBagFeeRemoved, setEBTBagFeeRemoved] = useState(false);
  const [isTriggeredEBTPayment, setTriggeredEBTPayment] = useState(false);
  const [isMaxGallonTriggered, setIsMaxGallonTriggered] = useState(false);
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const { fuelPrices, fuelPrepaidAmount } = useFuel();
  const { nonFuelItems } = useCart();
  const {
    getRoundOffCharityItem,
    AddOrRemovalRoundOffCharity,
  } = useCharityRoundOff();
  const { AddOrRemovalEBTBagFeeItem } = useEBTBagFee();
  const {
    items,
    taxInfo,
    transactionId,
    member,
    paymentDetails,
    basketPromo,
    cashBack,
    storeDetails,
    arbitration,
    user,
    deviceInfo,
    pumpNumber,
    amount,
    pumpType,
    transactionStartTime,
    isTransactionVoid,
    paymentHistory,
    paymentMediaList,
    allPayments,
    isTransactionRefund,
    paymentTransactionId,
    enteredCash,
    CardDeclinedAmount,
    // tranItemSeqNumber,
    cartChangeTrial,
    runningTotal,
    pipoTransaction,
    loadCardMediaList,
    NotifyItemScanStatus,
    loadAdjustedTax,
    hardTotal,
    CashPaymentInfo,
    tenderSequenceNumber,
    approvedTenderedCount,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    ebtPaymentTendered,
    tranAgeVerifyInfo,
    lookupCallProgress,
    statusCode,
    taxDeductionAmount,
    isAgePrefetch,
    transactionComments,
    isCanada,
    mediaAbortedPaymentList,
    isFuelPPCancel,
    pinpadPayStartTime,
    RoundUpCharityStatus,
    CashAmountToBeApplied,
    totalCreditAmount,
    totalCreditTax,
    totalCreditCount,
    MembertransactionId,
    finalizePayClickTime,
    isSigCaptureRequired,
    calculatedPrepaidAmount,
    fuelLoyaltyDiscounts,
    isSpeedyStore,
    stateCode,
    config,
  } = useSelector(state => ({
    items: state.cart.cartItems,
    taxInfo: state.cart.taxInfo,
    transactionId: state.cart.transactionId,
    member: state.cart.member,
    paymentDetails: state.cart.paymentDetails,
    basketPromo: state.cart.basketPromo,
    cashBack: state.socket.cashBack,
    storeDetails: state.main.storeDetails,
    arbitration: state.cart.arbitration,
    user: state.auth.user,
    deviceInfo: state.main.deviceInfo,
    pumpNumber: state.cart.fuel[0]?.pumpNumber || null,
    amount: state.cart.fuel[0]?.amount || '',
    pumpType: state.cart.fuel[0]?.pumpType || '',
    transactionStartTime: state.cart.transactionStartTime,
    isTransactionVoid: state.cart.isTransactionVoid,
    paymentHistory: state.cart.paymentHistory,
    paymentMediaList: state.cart.paymentMediaList,
    allPayments: state.cart.allPayments,
    isTransactionRefund: state.cart.isTransactionRefund,
    paymentTransactionId: state.cart.paymentTransactionId,
    enteredCash: state.cart.enteredCash,
    CardDeclinedAmount: state.cart.CardDeclinedAmount,
    // tranItemSeqNumber: state.cart.tranItemSeqNumber,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    pipoTransaction: state.cashFunctions.pipoTransaction,
    loadCardMediaList: state.cart.loadCardMediaList,
    NotifyItemScanStatus: state.cart.NotifyItemScanStatus,
    loadAdjustedTax: state.cart.loadAdjustedTax,
    hardTotal: state.cart.hardTotalSummary,
    CashPaymentInfo: state.cart.CashPaymentInfo,
    tenderSequenceNumber: state.cart.tenderSequenceNumber,
    approvedTenderedCount: state.cart.approvedTenderedCount,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    ebtPaymentTendered: state.cart.ebtPaymentTendered,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    lookupCallProgress: state.cart.lookupCallProgress,
    statusCode: state.cart.statusCode,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    isAgePrefetch: state.main.storeDetails?.address?.country === 'CA',
    transactionComments: state.cart.transactionComments,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    isFuelPPCancel: state.cart.isFuelPPCancel,
    pinpadPayStartTime: state.cart.pinpadPayStartTime,
    RoundUpCharityStatus: state.cart.RoundUpCharityStatus,
    CashAmountToBeApplied: state.cart.CashAmountToBeApplied,
    totalCreditAmount: state.cart.totalCreditAmount,
    totalCreditTax: state.cart.totalCreditTax,
    totalCreditCount: state.cart.totalCreditCount,
    MembertransactionId: state.cart.MembertransactionId,
    finalizePayClickTime: state.cart.finalizePayClickTime,
    isSigCaptureRequired: state.cart.isSigCaptureRequired,
    calculatedPrepaidAmount: state.cart.calculatedPrepaidAmount,
    fuelLoyaltyDiscounts: state.cart.calculatedFuelDiscounts?.loyaltyDiscounts,
    isSpeedyStore: state.main.isSpeedyStore,
    stateCode: state.main.storeDetails?.address?.state,
    config: state.main.configuration,
  }));

  const cardStatus = useSelector(state => state.socket.cardStatus);
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);
  const hardTotalRef = useRef(hardTotal);
  const location = useLocation();

  const DisplayToastMsg = (MSG, msgType) => {
    toast({
      description: MSG,
      status: msgType,
      duration: 3000,
      position: 'top-left',
    });
  };

  if (pipoTransaction) {
    return <PIPOTransaction />;
  }

  let isSkipTaxPromoVerify = false;
  if (items?.length > 0) {
    isSkipTaxPromoVerify = items?.every(
      item =>
        item.isFuel === true ||
        item.isCarwash === true ||
        item.isMoneyOrder === true ||
        isLottery(item)
    );
  }

  useEffect(() => {
    if (isFuelPPCancel) {
      setTransactionTaxAmount(0);
    }
  }, [isFuelPPCancel]);

  const [isTaxAdjustTriggered, setTaxAdjustTriggered] = useState(false);

  useEffect(() => {
    if (isTaxAdjustTriggered) {
      processDistributedTax({
        ebtSnap: false,
      }).then(taxInfo => {
        setTaxAdjustTriggered(false);
        iNotifyTransactionDetailsCFD(taxInfo);
      });
    }
  }, [isTaxAdjustTriggered]);

  const processIsTaxAppliedCreditItem = type => {
    let isTaxAppliedForCreditItem = false;
    let creditTaxAmount = 0;
    const creditItems = items.filter(item => item.negativeSalesFlag);
    const sortedCreditItem = creditItems.sort(function fn(a, b) {
      return a?.retailPrice - b?.retailPrice;
    });
    sortedCreditItem?.map(item => {
      const itemTaxAmount = getLineTax(item, taxInfo);
      if (!isTaxAppliedForCreditItem && Math.abs(itemTaxAmount) !== 0) {
        creditTaxAmount += itemTaxAmount;
        if (Math.abs(creditTaxAmount) >= Math.abs(iTransactionTaxAmount))
          isTaxAppliedForCreditItem = true;
        if (type === 'nonMember')
          dispatch(cartActions.setSelectedTaxExemptItems(item));
      }
      return item;
    });
    return isTaxAppliedForCreditItem;
  };

  useEffect(() => {
    if (
      items?.findIndex(i => i.negativeSalesFlag) > -1 &&
      ((iTransactionTaxAmount < 0 &&
        !isTransactionRefund &&
        !isTransactionVoid) ||
        (iTransactionTaxAmount > 0 &&
          (isTransactionRefund || isTransactionVoid))) // Added refund case as well for handling credit tax
    ) {
      // let isTaxAppliedForCreditItem = false;
      // let creditTaxAmount = 0;
      // const creditItems = items.filter(item => item.negativeSalesFlag);
      // const sortedCreditItem = creditItems.sort(function fn(a, b) {
      //   return a?.retailPrice - b?.retailPrice;
      // });
      // sortedCreditItem?.map(item => {
      //   const itemTaxAmount = getLineTax(item, taxInfo);
      //   if (!isTaxAppliedForCreditItem && Math.abs(itemTaxAmount) !== 0) {
      //     creditTaxAmount += itemTaxAmount;
      //     if (Math.abs(creditTaxAmount) >= Math.abs(iTransactionTaxAmount))
      //       isTaxAppliedForCreditItem = true;
      //     dispatch(cartActions.setSelectedTaxExemptItems(item));
      //   }
      //   return item;
      // });
      const isTaxAppliedForCreditItem = processIsTaxAppliedCreditItem(
        'nonMember'
      );
      if (isTaxAppliedForCreditItem) {
        dispatch(cartActions.taxExemptConfirm({ isAutoTaxOverride: true }));
        setTaxAdjustTriggered(true);
      }
    }
  }, [iTransactionTaxAmount]);

  const taxData = taxInfo;
  const tranDetails = getTransPriceDetails({
    items,
    basketPromo,
    taxData,
    isTransactionRefund,
    isTransactionVoid,
  }); // Transction Journal values
  let {
    subTotalPrice,
    finalsubTotalPrice,
    totalPrice,
    totalPromotionPrice,
    totalPromotionPriceAmt,
  } = tranDetails;
  let finalTotalPrice = currencyFixed(totalPrice);

  const balanceInfo = getTransactionBalanceDue({
    paymentHistory,
    paymentMediaList,
    finalTotalPrice,
    enteredCash,
    cashBack,
    allPayments,
  });
  let { totalChangeForCash, balanceDue } = balanceInfo;

  const iNotifyTransactionDetailsCFD = taxData => {
    const items = store.getState()?.cart.items;
    const tranDetails = getTransPriceDetails({
      items,
      basketPromo,
      taxData,
      isTransactionRefund,
      isTransactionVoid,
    });

    ({ subTotalPrice } = tranDetails);
    ({ finalsubTotalPrice } = tranDetails);
    ({ totalPrice } = tranDetails);
    ({ totalPromotionPrice } = tranDetails);
    ({ totalPromotionPriceAmt } = tranDetails);
    finalTotalPrice = currencyFixed(totalPrice);
    // #7363 corrected total Due field value
    dispatch(cartActions.setTranTotalDue(Number(finalTotalPrice)));
    dispatch(cartActions.setTranDiscountAmt(Number(totalPromotionPrice)));
    dispatch(cartActions.setTranSubTotal(Number(finalsubTotalPrice)));

    // #6959 update transaction details for any change in tax
    const balanceInfo = getTransactionBalanceDue({
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
      enteredCash,
      cashBack,
      allPayments,
    });
    ({ totalChangeForCash } = balanceInfo);
    ({ balanceDue } = balanceInfo);
    console.log('Final Total Price:', finalTotalPrice);

    // updated tax information to CFD
    const itotalDetails = {
      finalsubTotalPrice,
      finalTotalPrice,
      totalPromotionPrice,
      Cash: enteredCash > 0 ? enteredCash : undefined,
      Change: enteredCash > 0 ? changeAmount : undefined,
      taxDeductionAmount,
    };

    let Items = items;
    if (isAgePrefetch) {
      if (tranAgeVerifyInfo?.some(data => data?.birthDate || data?.dateBirth))
        Items = [
          {
            name: 'Age Verify',
            quantity: '',
            preAgeVerify: true,
            retailPrice: 0,
            itemTaxes: { taxId: [] },
          },
        ].concat(Items);
    }

    const taxAssessments = createTaxObject(
      taxData,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      isTransactionRefund || isTransactionVoid
    );
    const salesTaxValue = getScreenTaxDetails(
      taxAssessments,
      taxData,
      isTransactionRefund || isTransactionVoid,
      taxableBeforeEBTExempt,
      taxBeforeEBTExempt,
      stateCode
    );
    let TaxDetails = Object.keys(salesTaxValue).map(key => ({
      amount: Number(salesTaxValue[key]),
      description: key,
    }));
    if (isCanada) {
      TaxDetails = getTaxAssesments(taxData).map(item => ({
        description: `${item.description} on ${item.displayTaxableAmount}`,
        amount: Number(item.taxAmount).toFixed(2),
      }));
    }
    const iTransactionMessage = {
      CMD: 'FinalizeTransaction',
      Items,
      TaxInfo: taxData,
      MemberInfo: member,
      basketpromo: basketPromo,
      TotalDetails: itotalDetails,
      TaxDetails,
    };
    SendMessageToCFD(iTransactionMessage);
  };

  const changeAmount =
    isTransactionVoid || isTransactionRefund
      ? '0.00'
      : parseFloat(totalChangeForCash).toFixed(2);

  const totalDue = Number(finalTotalPrice);

  const updateTransactionDetails = (taxEBTExempt = 0, taxableEBTExempt = 0) => {
    const { discountVal, totalDueVal } = processReceiptTransDetails({
      isTransactionRefund,
      isTransactionVoid,
      totalPromotionPrice,
      taxData,
      totalDue,
      taxBeforeEBTExempt: taxEBTExempt,
    });
    try {
      let itransDetails =
        Number(totalPromotionPrice) > 0
          ? {
              SUBTOTAL: finalsubTotalPrice,
              'DISCOUNT(S)': discountVal,
            }
          : {
              SUBTOTAL: finalsubTotalPrice,
            };
      let TransDetails = itransDetails;
      const taxAssessments = createTaxObject(
        taxInfo,
        taxEBTExempt,
        taxableEBTExempt,
        isTransactionRefund || isTransactionVoid
      );
      TransDetails = getTaxDetails(
        taxAssessments,
        taxInfo,
        itransDetails,
        isTransactionRefund || isTransactionVoid,
        taxableEBTExempt,
        taxEBTExempt,
        stateCode
      );
      itransDetails = TransDetails;
      itransDetails['TOTAL DUE'] = totalDueVal;
      // Transaction level change need add only for cash media and cashback will be footer level #3152
      if (
        !isNaN(changeAmount) &&
        Number(changeAmount) > 0 &&
        !cashBack &&
        Number(cashBack) <= 0
      ) {
        itransDetails = {
          ...itransDetails,
          CHANGE: Number(isNaN(changeAmount))
            ? Number('0.00')
            : Number(changeAmount).toFixed(2),
        };
      }
      dispatch(cartActions.setTransDetails(itransDetails));
      getDVR().handleTransactionSummary(
        cashBack,
        isTransactionRefund,
        isTransactionVoid,
        itransDetails,
        items
      );

      const isFuelCompletion = (() => {
        const fuelCartItems = items?.filter(i => i.isFuel);
        if (fuelCartItems?.length > 0) {
          const fuelItem = fuelCartItems[0];
          const {
            metaInfo: { transactionType },
          } = fuelItem;

          return transactionType === TransactionTypes.preAuthCompletion;
        }
        return false;
      })();

      coinDispenser.processSummary(
        cashBack,
        isTransactionRefund ||
          isTransactionVoid ||
          isFuelPPCancel ||
          isFuelCompletion,
        itransDetails,
        items
      );
    } catch (e) {
      global?.logger?.error(
        `[7POS UI] - paymentTransaction(tran details):${JSON.stringify(e)}`
      );
    }
  };

  useEffect(() => {
    updateTransactionDetails(taxBeforeEBTExempt, taxableBeforeEBTExempt);
    return () => {};
  }, [
    subTotalPrice,
    finalTotalPrice,
    taxData,
    enteredCash,
    changeAmount,
    cashBack,
  ]);

  //  const itemDiscount = itemPromo;
  const finalResult = items
    ?.filter(item => item.totalPromoDiscount && item.totalPromoDiscount > 0)
    .reduce((total, item) => total + item.totalPromoDiscount, 0);
  const itemDiscount =
    unFormatCurrency(finalResult) > 0 ? unFormatCurrency(finalResult) : 0;

  const processDistributedTax = async ({ ebtSnap, ebtTenderedAmount }) => {
    let calculatedTax = taxInfo;
    showLoader(true);
    try {
      if (!loadAdjustedTax) {
        localStorage.setItem('finalTaxCallTriggered', true);
        calculatedTax = await processTax({
          items,
          storeProfile: storeDetails,
          basketDiscount: basketPromoDiscount?.amount,
          itemDiscount,
          arbitration,
          isReturnOrVoid: isTransactionRefund || isTransactionVoid,
          ebtSnap,
          paymentTransactionId,
          taxData,
          ebtTenderedAmount,
          config,
        }).then(res => {
          Logger?.debug(
            `[7POS UI] - fetchTax successful : ${JSON.stringfy(res)}`
          );
          const taxResp = JSON.parse(res.data.data);
          if (taxResp !== undefined && taxResp !== null) {
            const { totalTaxAmount, totalTaxableAmount } = taxResp;
            setTransactionTaxAmount(Number(totalTaxAmount));
            setTransactionTaxableAmount(Number(totalTaxableAmount));
            if (ebtSnap && Math.abs(ebtTenderedAmount) > 0) {
              let taxBeforeEBT = localStorage.getItem('taxInfoBeforeEBT');
              try {
                if (taxBeforeEBT) {
                  taxBeforeEBT = JSON.parse(taxBeforeEBT);
                  taxBeforeEBT = taxBeforeEBT.taxInfo;
                  const { totalTaxAmount: TaxAmount } = taxBeforeEBT;
                  const DeductionAmount =
                    Number(TaxAmount) - Number(totalTaxAmount);
                  dispatch(cartActions.setTaxDeductionAmount(DeductionAmount));
                  updateTransactionDetails(
                    taxBeforeEBTExempt,
                    taxableBeforeEBTExempt
                  );
                }
              } catch (error) {
                taxBeforeEBT = null;
              }
            }
            // Updated tax bucket itself when distributed tax calculated refer so many places.
            dispatch(
              cartActions.setTaxInfo({
                tax: taxResp,
              })
            );
            let totalPrice =
              Number(finalsubTotalPrice) +
              Number(totalTaxAmount) +
              (isNaN(totalPromotionPriceAmt) ? 0 : totalPromotionPriceAmt);
            totalPrice = parseFloat(totalPrice).toFixed(2);
            finalTotalPrice = currencyFixed(totalPrice);
          }
          showLoader(false);
          return taxResp;
        });
      }
    } catch (error) {
      global?.logger?.error(`[7POS UI] - fetch tax details Error`);
    } finally {
      localStorage.removeItem('finalTaxCallTriggered');
      showLoader(false);
    }
    return calculatedTax;
  };

  useEffect(() => {
    // Removed items state check and make sure run only once even user multi media
    // run only for finalize and pay not fot card lookup.
    // Added below check to skip below block execute during noSale
    if (location.pathname.includes('/cashDrawer')) return;
    dispatch(cartActions.setFinalizeClick(false));
    if (lookupCallProgress !== LOAD_REQUEST_INPROGRESS) {
      try {
        showLoader(true);
        dispatch(cartActions.setLastTenderInfo(''));
        dispatch(cfdActions.setTransactionFinalize(true));
        dispatch(cfdActions.IntiatedItemRedemption(false));
        dispatch(cfdActions.IntiatedSWP(false));
        dispatch(cartActions.setEmailForReceipt(''));
        finalizeAndPayClickTimeTrack(
          paymentTransactionId,
          finalizePayClickTime,
          member
        );
        getRoundOffCharityItem();
        // #5628 call tax only for member(might have addtional promo applied)
        const isTaxAppliedForCreditItem = processIsTaxAppliedCreditItem(
          'member'
        );
        if (
          !isTaxAppliedForCreditItem &&
          items?.length &&
          !isSkipTaxPromoVerify &&
          (member || taxData === undefined || taxData === null)
        ) {
          setTaxAdjustTriggered(true);
        } else if (taxData !== undefined && taxData !== null) {
          // #5939 added null check
          // #5645 non member transaction updating transaction total tax amount
          const { totalTaxAmount, totalTaxableAmount } = taxData;
          setTransactionTaxAmount(Number(totalTaxAmount));
          setTransactionTaxableAmount(Number(totalTaxableAmount));
        }
        if (!hardTotal?.name && !hardTotal?.amount) {
          global?.logger?.info(`[7POS UI] - retry to get hardtotals.`);
          const updateHardTotalsIfNeeded = async () => {
            try {
              await refreshHardTotals();
            } catch (error) {
              global?.logger?.error(
                `[7POS UI] - failed to get hardtotals. ${JSON.stringify(error)}`
              );
            } finally {
              Logger.info(
                `UpdatedHardTotals: ${JSON.stringify(
                  hardTotalRef.current ?? {}
                )}`
              );
            }
          };
          updateHardTotalsIfNeeded();
        }
      } catch (error) {
        showLoader(false);
        global.logger.error(
          `[7POS UI] - payment screen landing error ${JSON.stringify(error)}`
        );
      } finally {
        showLoader(false);
      }
    }
    // reset notification render
    dispatch(setShowNotifications(true));
    return () => {};
  }, []);

  /**
   * Saving hardTotal object as ref to access from useEffects seamlessly.
   */
  useEffect(() => {
    hardTotalRef.current = hardTotal;
  }, [hardTotal]);

  useEffect(() => {
    if (ebtPaymentTendered) {
      // #7088 added EBT bag fee and round off charity remove status as well.
      if (
        items?.length &&
        (isEBTBagFeeRemoved ||
          isRoundUpRemoved ||
          (!isSkipTaxPromoVerify && Math.abs(Number(taxDeductionAmount)) > 0))
      ) {
        let isEbtSnapPresent = false;
        let isMediaAbort = [];
        let ebtTenderedAmount = 0;
        allPayments
          ?.filter(pml => pml?.paymentMediaType === 'EBTSNAP')
          ?.map(pml => {
            if (mediaAbortedPaymentList[0]) {
              isMediaAbort = mediaAbortedPaymentList?.filter(
                payment =>
                  payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
              );
              if (!isMediaAbort[0]) {
                ebtTenderedAmount = pml?.payment?.amount;
                isEbtSnapPresent = true;
              }
            } else {
              ebtTenderedAmount = pml?.payment?.amount;
              isEbtSnapPresent = true;
            }
            return pml;
          });
        if (!isEbtSnapPresent) {
          updateTransactionDetails();
          dispatch(cartActions.setTaxBeforeEBTExempt(0));
          dispatch(cartActions.setTaxDeductionAmount(0));
          dispatch(cartActions.setTaxableBeforeEBTExempt(0));
          localStorage.removeItem('taxInfoBeforeEBT');
          // Clean up EBT eligiable items
          const isRoundUpAdded =
            AddOrRemovalRoundOffCharity({
              iRemoveIntiate: false,
              isRoundUpRemoved,
            }) || false;
          if (isRoundUpAdded) {
            DisplayToastMsg('RoundUp charity item added', 'success');
            Logger.info(
              'RoundUp charity item added back to transaction for EBT tender decline.'
            );
          }

          const isEBTBagFeeUpAdded =
            AddOrRemovalEBTBagFeeItem({
              iRemoveIntiate: false,
              isEBTBagFeeRemoved,
            }) || false;
          if (isEBTBagFeeUpAdded) {
            DisplayToastMsg('Bag fee added', 'success');
            Logger.info(
              'RoundUp charity item added back to transaction for EBT tender decline.'
            );
          }
          setRoundUpRemoved(false);
          setEBTBagFeeRemoved(false);
          setTaxAdjustTriggered(true);
        } else {
          processDistributedTax({ ebtSnap: true, ebtTenderedAmount });
        }
      }
      dispatch(cartActions.setEBTPaymentIntiateStatus(false));
      dispatch(cartActions.setEbtPaymentTendered(false));
    }
    return () => {};
  }, [ebtPaymentTendered]);

  useEffect(() => {
    if (lookupCallProgress !== LOAD_REQUEST_INPROGRESS) {
      const taxData = store?.getState()?.cart.taxInfo;
      const { creditAmount, creditTax, creditCount } = CreditItemRunningTotal(
        items,
        taxData,
        basketPromo
      );
      dispatch(cartActions.setCreditItemCount(creditCount));
      dispatch(cartActions.setCreditItemAmount(creditAmount));
      dispatch(cartActions.setCreditItemTaxAmount(creditTax));
    }
    // #9288 updating cart summary details
    iNotifyTransactionDetailsCFD(taxData);
  }, [taxInfo, RoundUpCharityStatus, items]);

  const handlePay = ({
    taxData = taxInfo,
    isFinalCall = false,
    isFinalPayment = null,
  }) => {
    const newtaxInfo = taxData;
    const totalPrice =
      Number(finalsubTotalPrice) +
      Number(taxData?.totalTaxAmount ?? 0) +
      Number(totalPromotionPriceAmt);
    const UfinalTotalPrice = parseFloat(parseFloat(totalPrice).toFixed(2));
    const paymentTransId = paymentTransactionId;
    const payRequest = handlePayRequest({
      items:
        cardStatus === EBTSNAP || cardStatus === EBTCB
          ? items.filter(item => !item.isRoundUpCharityItem)
          : items,
      storeDetails,
      user,
      taxInfo: newtaxInfo,
      deviceInfo,
      member,
      transactionId,
      finalsubTotalPrice,
      finalTotalPrice: UfinalTotalPrice,
      totalPrice,
      transactionStartTime,
      pumpNumber,
      amount,
      pumpType,
      paymentDetails,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId: paymentTransId,
      tranAgeVerifyInfo,
      basketPromo,
      cartChangeTrial,
      runningTotal,
      // #8362 retrive data from state directly
      taxBeforeEBTExempt:
        cardStatus === EBTSNAP || cardStatus === EBTCB
          ? store?.getState()?.cart.taxBeforeEBTExempt
          : 0,
      taxableBeforeEBTExempt:
        cardStatus === EBTSNAP || cardStatus === EBTCB
          ? store?.getState()?.cart.taxableBeforeEBTExempt
          : 0,
      loadCardMediaList,
      isFinalCall,
      paymentHistory,
      fuelPrices,
      allPayments,
      transactionComments,
      isSigCaptureRequired,
      cardStatus,
      fuelLoyaltyDiscounts,
    });
    dispatch(
      cartActions.setrunningTotalTax(payRequest.transactionDetails.runningTotal)
    );
    // TAPI card load store call not payment request
    if (isFinalCall) {
      // update only card load decline payment info
      if (isFinalPayment) {
        global?.logger?.info(`[7POS UI] - readjust payment.`);
        payRequest.transactionDetails.paymentInformation = isFinalPayment;
      }
    } else {
      global?.logger?.info(`[7POS UI] - ebt card payment.`);
      const alreadyPaidAmount = allPayments?.reduce(
        (sum, ap) => sum + parseFloat(ap?.payment?.amount) || 0,
        0
      );
      const { balanceDue } = getBalanceDue({
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
        enteredCash,
        allPayments,
      });
      let lottoItemAmount = 0;
      lottoItemAmount = items
        ?.filter(
          item =>
            (Number(item.departmentId) === 61 ||
              Number(item.departmentId) === 63) &&
            !item.negativeSalesFlag
        )
        .reduce(
          (sum, item) =>
            sum +
            Math.abs(parseFloat(item?.overridedPrice || item?.retailPrice)) *
              item.quantity,
          0
        );
      lottoItemAmount /= 100;
      let creditItemAmount = items
        ?.filter(item => item.negativeSalesFlag)
        .reduce(
          (sum, item) =>
            sum +
            Math.abs(parseFloat(item?.overridedPrice || item?.retailPrice)) *
              item.quantity,
          0
        );
      creditItemAmount /= 100;
      let amt =
        isTransactionVoid || isTransactionRefund ? finalTotalPrice : balanceDue;
      const balanceDueAmount =
        isTransactionVoid || isTransactionRefund ? finalTotalPrice : balanceDue;
      // #3438 - 3464 In void/refund we should not add lotto win amount because there is no split tender.
      if (!isTransactionVoid && !isTransactionRefund) {
        amt = creditItemAmount > 0 ? balanceDue + creditItemAmount : balanceDue;
        amt = lottoItemAmount > 0 ? amt + lottoItemAmount : amt;
      }
      const paymentInformation = {
        tenderSequenceNumber,
        amount: parseFloat(parseFloat(amt + CashAmountToBeApplied).toFixed(2)),
        balanceDue: balanceDueAmount,
        approvedTenderedCount,
        tenderedAmount: parseFloat(parseFloat(alreadyPaidAmount).toFixed(2)),
        lastCashMediaAmount: parseFloat(
          parseFloat(CashAmountToBeApplied).toFixed(2)
        ),
      };
      payRequest.transactionDetails.paymentInformation = paymentInformation;
    }
    // adjust credit item amount applicable only for sale
    let TotalrunningTotal = payRequest.transactionDetails.runningTotal;
    if (
      Math.abs(totalCreditAmount) > 0 &&
      !isTransactionRefund &&
      !isTransactionVoid
    ) {
      TotalrunningTotal += totalCreditAmount + totalCreditTax;
    } else if (!isTransactionRefund && !isTransactionVoid) {
      // #6969 recalculate Credit Item Amount if any case Credit item present and amount reported as zero
      const { creditAmount, creditTax, creditCount } = CreditItemRunningTotal(
        items,
        taxData,
        basketPromo
      );
      dispatch(cartActions.setCreditItemCount(creditCount));
      dispatch(cartActions.setCreditItemAmount(creditAmount));
      dispatch(cartActions.setCreditItemTaxAmount(creditTax));
      TotalrunningTotal += creditAmount + creditTax;
    }
    const hardTotalSummary = [];
    hardTotalSummary.push(hardTotalRef.current);
    hardTotalSummary.push({
      name: 'runningTotal',
      count: 0,
      amount: parseFloat(TotalrunningTotal.toFixed(2)),
    });
    payRequest.transactionDetails.hardTotalSummary = hardTotalSummary;
    const req = JSON.stringify(payRequest);
    const paymentRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: !isFinalCall ? 'EBT_PAYMENT' : 'TRANSACTION',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: !isFinalCall ? 'PINPAD' : 'PAYMENT',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${req}`,
      },
    };
    const payReq = JSON.stringify(paymentRequest);
    localStorage.setItem('finalPaymentRequest', payReq);
    global?.logger?.info(
      `[7POS UI] - pay request(EBT/cardLoad)  ${JSON.stringify(paymentRequest)}`
    );
    dispatch(cartActions.setPaymentTriggerStatus(true));
    if (!isFinalCall) {
      dispatch(cartActions.setPaymentMethod('PINPAD'));
      ws.socket?.send(
        '/app/pinpad/payment',
        {},
        JSON.stringify(paymentRequest)
      );
    } else {
      global?.logger?.info(
        `[7POS UI] - sending TAPI data ${JSON.stringify(paymentRequest)}.`
      );
      ws.socket?.send(
        '/app/transaction/data',
        {},
        JSON.stringify(paymentRequest)
      );
      const storeId = storeDetails?.storeId;
      // Add timer to update payment information
      setTimeout(() => {
        transactionTimeTrack(
          storeId,
          paymentTransactionId,
          transactionStartTime,
          pinpadPayStartTime
        );
        // #4593 Open cash drawer after card load status received from PAPI
        if (CashPaymentInfo[0]) openCashDrawer();
        storeSeqAndHardtotals();
        // Singature Capture check for card load
        if (isSigCaptureRequired) {
          const iTransactionMessage = {
            CMD: 'SignatureCapture',
          };
          SendMessageToCFD(iTransactionMessage);
          dispatch(socketActions.setCardStatus(SIGNATURE_CAPTURE));
          return;
        }
        // updateCdbReport(); // card scenarios
        history.replace('/payment/success');
      }, 100);
    }
  };

  const storeSeqAndHardtotals = async () => {
    try {
      // #4761 State not yet reflect before call this function.
      const {
        runningTotalTax,
        taxInfo,
        runningTotal,
        allPayments,
      } = store.getState().cart;
      localStorage.setItem('mediaInformation', JSON.stringify(allPayments));
      let adjustedRunningTotal = runningTotalTax;
      // #7238 always need to check abs value(refund due case end with negative running total)
      if (runningTotalTax === 0 && Math.abs(runningTotal) > 0) {
        adjustedRunningTotal = Number(runningTotal / 100);
        if (
          taxInfo &&
          taxInfo?.totalTaxAmount > 0 &&
          !isTransactionRefund &&
          !isTransactionVoid
        ) {
          const iTaxAmount = Number(taxInfo?.totalTaxAmount) || 0;
          adjustedRunningTotal += iTaxAmount;
        }
        dispatch(cartActions.setrunningTotalTax(adjustedRunningTotal));
      }
      // Update tran sequence number once transaction complete
      let storedSeq = localStorage.getItem('StoreSeqAndHardTotals');
      storedSeq = storedSeq
        ? JSON.parse(storedSeq)
        : { transactionId: '', status: false, paymentTransactionId: '' };
      if (
        storedSeq.paymentTransactionId === paymentTransactionId &&
        storedSeq.status &&
        storedSeq.transactionId === transactionId
      ) {
        global?.Logger?.debug(
          `[7POS UI] - already Posted Hard totals storeSeqAndHardtotals(Card load) and ${paymentTransactionId} `
        );
        return;
      }
      global?.logger?.info(
        `[7POS UI] - Posting Hard totals storeSeqAndHardtotals(Card load) and ${paymentTransactionId} `
      );
      localStorage.setItem(
        'StoreSeqAndHardTotals',
        JSON.stringify({
          paymentTransactionId: paymentTransactionId.toString(),
          status: true,
          transactionId: transactionId.toString(),
        })
      );
      storeTranSeqNumber({
        transactionId,
        MembertransactionId,
        correlationID: paymentTransactionId,
      });
      finalizeHardTotals({
        items,
        member,
        runningTotalTax: adjustedRunningTotal,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        cashBack,
      });
      await captureHardTotals();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store transaction seq and update Hartotals failed ${JSON.stringify(
          error
        )}`
      );
    }
  };

  const openCashDrawer = () => {
    ws.socket?.send(WSTopics.cashdrawer.open);
    global?.logger?.info(`[7POS UI] -  Sent cash drawer open event(card load)`);
  };

  const EBTPaymentRequest = ({ isEBTCard, taxInfo }) => {
    let isEbtSnapPresent = false;
    let isMediaAbort = [];
    allPayments
      ?.filter(pml => pml?.paymentMediaType === 'EBTSNAP')
      ?.map(pml => {
        if (mediaAbortedPaymentList[0]) {
          isMediaAbort = mediaAbortedPaymentList?.filter(
            payment =>
              payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
          );
          if (!isMediaAbort[0]) {
            isEbtSnapPresent = true;
          }
        } else {
          isEbtSnapPresent = true;
        }
        return pml;
      });
    if (
      isEbtSnapPresent ||
      isOnlyLotteryInCart(items) ||
      !nonFuelItems.length
    ) {
      handlePay({ taxData: taxInfo });
      return;
    }
    let TransactionTaxAmount = iTransactionTaxAmount;
    let TransactionTaxableAmount = iTransactionTaxableAmount;
    if (taxInfo !== undefined && taxInfo !== null) {
      const { totalTaxAmount, totalTaxableAmount } = taxInfo;
      TransactionTaxableAmount = totalTaxableAmount;
      TransactionTaxAmount = totalTaxAmount;
      setTransactionTaxAmount(Number(TransactionTaxAmount));
      setTransactionTaxableAmount(Number(TransactionTaxableAmount));
    }
    if (isTransactionVoid || isTransactionRefund) {
      dispatch(cartActions.setTaxBeforeEBTExempt(TransactionTaxAmount));
      dispatch(cartActions.setTaxableBeforeEBTExempt(TransactionTaxableAmount));
      dispatch(
        cartActions.setTaxDeductionAmount(Math.abs(TransactionTaxAmount))
      );
    }
    localStorage.setItem('taxInfoBeforeEBT', JSON.stringify({ taxInfo }));
    // tax recalculate only for valid EBT
    processDistributedTax({
      ebtSnap: isEBTCard,
    }).then(taxInfo => {
      // console.log(iTransactionTaxAmount, taxInfo.totalTaxAmount);
      const taxDeductionAmount =
        Number(TransactionTaxAmount) - Number(taxInfo?.totalTaxAmount);
      if (
        !(isTransactionRefund || isTransactionVoid) &&
        Math.abs(taxDeductionAmount) > 0
      ) {
        dispatch(cartActions.setTaxDeductionAmount(taxDeductionAmount));
        dispatch(cartActions.setTaxBeforeEBTExempt(TransactionTaxAmount));
        dispatch(
          cartActions.setTaxableBeforeEBTExempt(TransactionTaxableAmount)
        );
      }
      updateTransactionDetails(TransactionTaxAmount, TransactionTaxableAmount);
      handlePay({ taxData: taxInfo });
    });
  };

  useEffect(() => {
    if (isTriggeredEBTPayment) {
      processDistributedTax({
        ebtSnap: false,
      }).then(taxInfo => {
        iNotifyTransactionDetailsCFD(taxInfo);
        const isEBTCard = cardStatus === EBTSNAP || false;
        EBTPaymentRequest({ isEBTCard, taxInfo });
      });
      setTriggeredEBTPayment(false);
    }
  }, [isTriggeredEBTPayment]);

  useEffect(() => {
    if (cardStatus === EBTSNAP || cardStatus === EBTCB) {
      if (statusCode === 278) return; // Split payment decline with EBTSnap as second media
      let isEBTCard = cardStatus === EBTSNAP || cardStatus === EBTCB;
      if (!isEBTCard) return;
      let iRoundUpRemoved = false;
      let iEBTBagFeeRemoved = false;
      dispatch(cartActions.setEBTPaymentIntiateStatus(true));
      // #5932 Remove charity item whenever use EBT tender
      if (cardStatus === EBTSNAP || cardStatus === EBTCB) {
        Logger.info(
          'Checking any round up item/EBT bag fee present in the transaction'
        );
        iRoundUpRemoved = AddOrRemovalRoundOffCharity({ iRemoveIntiate: true });
        iEBTBagFeeRemoved = AddOrRemovalEBTBagFeeItem({
          iRemoveIntiate: true,
        });
      }
      if (iRoundUpRemoved || iEBTBagFeeRemoved) {
        if (iRoundUpRemoved) {
          setRoundUpRemoved(true);
          DisplayToastMsg('RoundUp charity item removed', 'success');
          Logger.info(
            'RoundUp charity item removed from the transaction for EBT tender.'
          );
        }
        if (iEBTBagFeeRemoved) {
          setEBTBagFeeRemoved(true);
          DisplayToastMsg('Bag fee waived for EBT', 'success');
          Logger.info(
            'Bag fee waived for EBT from the transaction for EBT tender.'
          );
        }
        setTriggeredEBTPayment(true);
      } else {
        isEBTCard = cardStatus === EBTSNAP || false;
        EBTPaymentRequest({ isEBTCard, taxInfo });
      }
    }
    return () => {};
  }, [cardStatus]);

  let basketPromoDiscount = [];
  if (basketPromo?.length > 0) {
    const promodiscount = basketPromo?.slice(-1);
    basketPromoDiscount = promodiscount
      ? {
          amount: (promodiscount[0]?.item_discount).toFixed(2) / 100,
          name: promodiscount[0]?.name,
        }
      : {};
  }

  useEffect(() => {
    if (NotifyItemScanStatus) {
      DisplayToastMsg(NotifyItemScanStatus, 'error');
      dispatch(cartActions.setNotifyScanStatus(''));
    }
  }, [NotifyItemScanStatus]);

  const [sendFinalCardRequest, setFinalCartRequest] = useState(false);

  const reAdjustTax = async taxRequest => {
    try {
      global?.logger?.info(
        `[7POS UI] - fetchTax Request from reAdjustTax:${JSON.stringify(
          taxRequest
        )}`
      );
      showLoader(true);
      const resulttax = await fetchTax(taxRequest, paymentTransactionId);
      if (resulttax !== 'error' && resulttax?.data) {
        // const taxResult = resulttax.data;
        // const taxInfoData = JSON.parse(taxResult?.data);
        const taxInfoData = JSON.parse(resulttax?.data?.data);

        const { totalTaxAmount, totalTaxableAmount } = taxInfoData;
        setTransactionTaxAmount(Number(totalTaxAmount));
        setTransactionTaxableAmount(Number(totalTaxableAmount));
        dispatch(
          cartActions.setTaxInfo({
            tax: taxInfoData,
          })
        );
        setFinalCartRequest(true);
        global?.logger?.info(`[7POS UI] - fetchTax successful  readjust tax`);
      }
    } catch (error) {
      const declineCardLoadList = loadCardMediaList.filter(
        i => i.cardResult.status === 'DECLINED' || i.cardResult.statusCode !== 0
      );
      if (taxData !== null && declineCardLoadList && declineCardLoadList[0]) {
        const taxInfoData = remapTaxObject({
          items,
          taxData,
          declineCardLoadList,
        });
        const { totalTaxAmount, totalTaxableAmount } = taxInfoData;
        setTransactionTaxAmount(Number(totalTaxAmount));
        setTransactionTaxableAmount(Number(totalTaxableAmount));
        dispatch(
          cartActions.setTaxInfo({
            tax: taxInfoData,
          })
        );
      }
      setFinalCartRequest(true);
      global?.logger?.error(`[7POS UI] - fetch tax details Error reAdjust Tax`);
    } finally {
      showLoader(false);
    }
  };

  useEffect(() => {
    if (sendFinalCardRequest) {
      let newCashPayment = null;
      if (CashPaymentInfo[0]) {
        global?.logger?.info(
          `[7POS UI] - readjusting payment information for card load decline:${CardDeclinedAmount}.`
        );
        const iAdjustedAmount = !isTransactionVoid
          ? parseFloat(CashPaymentInfo[0].amount - CardDeclinedAmount).toFixed(
              2
            )
          : parseFloat(
              CardDeclinedAmount + Number(CashPaymentInfo[0].amount)
            ).toFixed(2);
        CashPaymentInfo.map(CashPayment => {
          if (Math.abs(Number(CardDeclinedAmount)) > 0) {
            newCashPayment = CashPaymentInfo;
            newCashPayment = {
              ...CashPayment,
              balanceDue: 0,
              mediaStatus:
                Number(iAdjustedAmount) !== 0 ? 'APPROVED' : 'DECLINED',
              amount: !isTransactionVoid
                ? parseFloat(CashPayment.amount - CardDeclinedAmount).toFixed(2)
                : parseFloat(
                    CardDeclinedAmount + Number(CashPayment.amount)
                  ).toFixed(2),
              changeAmount:
                !isTransactionVoid && CashPayment.amount > 0 // #6438 handling Win > Card load and decline case.
                  ? parseFloat(
                      CardDeclinedAmount +
                        Number(
                          isNaN(CashPayment?.changeAmount)
                            ? 0
                            : CashPayment?.changeAmount
                        )
                    ).toFixed(2)
                  : undefined,
              paidAmount: !isTransactionVoid
                ? CashPayment.paidAmount > 0 // #6438 handling Win > Card load and decline case.
                  ? CashPayment.paidAmount
                  : CashPayment.paidAmount - CardDeclinedAmount
                : parseFloat(
                    CardDeclinedAmount + Number(CashPayment.paidAmount)
                  ).toFixed(2),
            };
          }
          return CashPayment;
        });
      }
      handlePay({
        taxData: taxInfo,
        isFinalCall: sendFinalCardRequest,
        isFinalPayment: newCashPayment,
      });
      setFinalCartRequest(false);
    }
  }, [sendFinalCardRequest]);

  useEffect(() => {
    // Card load failed case readjust tax again after removed declined card load item
    if (loadAdjustedTax) {
      if (Math.abs(Number(CardDeclinedAmount)) > 0) {
        global?.logger?.info(
          `[7POS UI] - readjusting tax after card load decline.`
        );
        reAdjustTax(loadAdjustedTax);
      } else {
        // Card load approved case no need calcluate tax again
        global?.logger?.info(`[7POS UI] - sending final request to TAPI.`);
        setFinalCartRequest(true);
      }
      dispatch(cartActions.setLoadAdjustedTax(''));
    }
  }, [loadAdjustedTax]);

  const getItems = () => {
    if (isAgePrefetch) {
      if (tranAgeVerifyInfo?.some(data => data?.birthDate || data?.dateBirth))
        return [
          {
            retailPrice: 0,
            name: 'Age Verify',
            quantity: '',
            agePrefetch: true,
          },
        ].concat(items || []);
    }
    return items;
  };

  useEffect(() => {
    // #1822 1819 Gallaon limit and restin fuel contradict
    if (
      !isNaN(calculatedPrepaidAmount) &&
      calculatedPrepaidAmount &&
      fuelPrepaidAmount &&
      calculatedPrepaidAmount < fuelPrepaidAmount
    ) {
      DisplayToastMsg(
        'Gallon Limit exceeded, Total due is being reduced',
        'error'
      );
      setIsMaxGallonTriggered(true);
      const FuelItem = items.find(item => item.isFuel);
      const newFuelItem = FuelUtils.getUpdatedPrepayCartItem({
        newPrepayItemAmount: calculatedPrepaidAmount,
        ...FuelItem,
      });
      dispatch(cartActions.removeFromCart(FuelItem)); // Removing the fuelLineItem from cart As MAX Gallon limit reachd
      // Added isMaxGallonFlow to byPass finalizePayClick condition in Cart.slice addToCart reducer
      dispatch(
        cartActions.addToCart({
          ...newFuelItem,
          isMaxGallonFlow: true,
        })
      ); // Adding fuelLineItem to Cart
      dispatch(
        fuelActions.updatePrepayPumpDetails(calculatedPrepaidAmount?.toString())
      );
      iNotifyTransactionDetailsCFD(taxInfo);
    } else if (!isMaxGallonTriggered) {
      // #8793 verify final total price changes to accomnadate rest in fuel
      if (!Number(finalTotalPrice) > 0) return;
      const FuelItem = items?.find(item => item.isFuel);
      if (FuelItem) {
        const {
          metaInfo: { isRestInFuel, actualFuelAMount, prepayAmount },
        } = FuelItem;
        if (
          isRestInFuel &&
          Number(finalTotalPrice) !== actualFuelAMount &&
          Number(finalTotalPrice) <= actualFuelAMount
        ) {
          const newPrepayItemAmount = parseFloat(
            parseFloat(
              (prepayAmount + actualFuelAMount - Number(finalTotalPrice)) * 100
            ).toFixed(2)
          );
          const newFuelItem = FuelUtils.getUpdatedPrepayCartItem({
            newPrepayItemAmount,
            ...FuelItem,
          });
          dispatch(cartActions.removeFromCart(FuelItem)); // Removing the fuelLineItem from cart As MAX Gallon limit reachd
          dispatch(cartActions.addToCart({ ...newFuelItem })); // Adding fuelLineItem to Cart
          dispatch(
            fuelActions.updatePrepayPumpDetails(newPrepayItemAmount?.toString())
          );
        }
      }
    }
  }, [fuelPrepaidAmount, calculatedPrepaidAmount, items, finalTotalPrice]);

  return (
    <Flex
      direction="column"
      justifyContent="space-between"
      className={Styles.paymentContainer}
    >
      <Box className={Styles.paymentItemContainer}>
        {member && <Member member={member} isSpeedyStore={isSpeedyStore} />}
        <Flex
          borderBottom="1px solid rgb(211, 211, 211)"
          height="39px"
          alignItems="center"
        >
          <Flex
            ml={4}
            flexDirection="row"
            justifyContent="flex-start"
            alignItems="baseline"
          >
            <Text
              color="rgb(44, 47, 53)"
              fontSize="20px"
              fontFamily="Roboto-Medium"
              fontWeight="500"
              mr={1}
            >
              Transaction{' '}
            </Text>{' '}
            <Text
              fontSize="16px"
              fontFamily="Roboto-Regular"
              fontWeight="regular"
              color="rgb(44, 47, 53)"
              alignItems="center"
            >
              #{transactionId}
            </Text>
          </Flex>
        </Flex>
        <Box
          className={
            member
              ? `${Styles.paymentItemsWithMember}`
              : `${Styles.paymentItems}`
          }
        >
          {getItems().map((item, keyindex) => (
            <PaymentTransactionItem
              key={keyindex}
              item={item}
              taxData={taxInfo}
            />
          ))}
          {basketPromo?.length > 0 && (
            <Flex
              flexDirection="row"
              alignItems="center"
              pl={3}
              alignSelf="center"
              py={2}
              fontSize="14px"
              color="rgb(91, 97, 107)"
              fontWeight="normal"
              fontFamily="Roboto-Regular"
            >
              <Text color="#ec2526">-${basketPromoDiscount?.amount}</Text>
              <Text ml={2}>{basketPromoDiscount?.name}</Text>
            </Flex>
          )}
          {cashBack && <CashBackText eventData={cashBack} />}
        </Box>
      </Box>
      <PaymentSummary
        cashBack={cashBack}
        paymentDetails={paymentDetails}
        taxData={taxData}
        subTotal={finalsubTotalPrice}
        discount={totalPromotionPrice}
        total={finalTotalPrice}
        balanceDue={balanceDue}
        isTransactionVoid={isTransactionVoid}
        isTransactionRefund={isTransactionRefund}
        paymentMediaList={paymentMediaList}
        paymentHistory={paymentHistory}
        allPayments={allPayments}
        totalChangeForCash={totalChangeForCash}
      />
    </Flex>
  );
};

export default PaymentTransaction;
