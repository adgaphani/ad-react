/* eslint-disable react/prop-types */
import React from 'react';
import { Text, Flex } from '@chakra-ui/react';

function PaymentDetailValue({
  label,
  value,
  variant,
  comment,
  valueColor = 'rgb(44, 47, 53)',
}) {
  const isUsCash = () => comment?.toLowerCase().includes('us cash');
  const getLabel = () => {
    if (isUsCash()) return 'US Cash';
    if (comment === 'Big Bucks') return 'Big Buck';
    if (comment !== undefined) return comment;
    return label;
  };
  return (
    <>
      <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
        {isUsCash() ? comment : ''}
      </Text>
      {variant === 'bold' ? (
        <Flex justifyContent="space-between" mb={2} color="rgb(44, 47, 53)">
          <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
            {label}
          </Text>
          <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
            {value}
          </Text>
        </Flex>
      ) : (
        <Flex justifyContent="space-between" mb={2} color="rgb(44, 47, 53)">
          <Text fontSize="15px" fontWeight="normal" fontFamily="Roboto-Regular">
            {getLabel()}
          </Text>
          <Text
            fontSize="15px"
            fontWeight="normal"
            color={valueColor}
            fontFamily="Roboto-Regular"
          >
            {value}
          </Text>
        </Flex>
      )}
    </>
  );
}

export default PaymentDetailValue;
