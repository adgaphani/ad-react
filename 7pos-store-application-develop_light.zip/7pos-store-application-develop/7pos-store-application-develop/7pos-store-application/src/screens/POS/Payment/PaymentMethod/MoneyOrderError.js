/* eslint-disable react/prop-types */
import React from 'react';
import { useSelector } from 'react-redux';
import { Flex, Box, Text } from '@chakra-ui/react';
import { Button } from '../../../../components/Common/Buttons';
import warrningSymbol from '../../../../Icons/Icon_twarning.svg';
import Styles from './MoneyOrderError.module.css';
import {
  MO_FLG_PRINTING,
  MO_FLG_INVALID,
  MO_FLG_PRINTED,
} from '../../../../constants';

const MoMPrintError = ({ onAccept, onCancel }) => {
  let MoneyOrderAmt = 0;
  const { items } = useSelector(state => ({ items: state.cart.cartItems }));
  const isMoneyPrintItem = items.filter(
    item =>
      item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_PRINTING
  );
  const isMoneyInValiDCount = items.filter(
    item =>
      item.isMoneyOrder === true &&
      (item.MoneyOrderFlag === MO_FLG_INVALID ||
        item.MoneyOrderFlag === MO_FLG_PRINTED)
  );
  const iFailedMOCount = isMoneyInValiDCount?.length + 1 || 1;

  if (isMoneyPrintItem && isMoneyPrintItem[0]) {
    MoneyOrderAmt =
      parseFloat(isMoneyPrintItem[0]?.retailPrice).toFixed(2) / 100;
  }
  return (
    <Box justifyContent="space-between" h="calc(100vh - 275px)" py="0.5rem">
      <Flex
        h="100%"
        flexDirection="column"
        justifyContent="space-between"
        bg="rgb(255, 255, 255)"
        mr="0.5rem"
      >
        <Flex
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          height="100%"
          width="100%"
          bg="rgb(255,255,255)"
        >
          <Box textAlign="center">
            <img
              src={warrningSymbol}
              alt="Error_Node"
              height="40px"
              width="40px"
            />
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Medium"
              fontSize="24px"
              fontWeight="bold"
              mt=".75rem"
            >
              Money Order machine communication error
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="18px"
              fontWeight="normal"
              mt=".75rem"
            >
              There is a possible problem with Money Order
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="18px"
              fontWeight="normal"
              mt=".75rem"
            >
              {' '}
              {iFailedMOCount} for ${MoneyOrderAmt}
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="18px"
              fontWeight="normal"
              mt=".75rem"
            >
              Serial #000000000000
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="18px"
              fontWeight="normal"
              mt=".75rem"
            >
              Did this Money Order print correctly?
            </Text>
            <Flex
              flexDirection="row"
              justifyContent="space-between"
              textAlign="center"
              height="80px"
              fontWeight="bold"
              mt="3%"
              pb={4}
            >
              <Button
                ml="20%"
                onClick={onCancel}
                bg="#107f62"
                color="#ffffff"
                _hover={{ bg: '#107f62' }}
                className={Styles.SaveBtn}
              >
                NO
              </Button>
              <Button mr="18%" className={Styles.PayFullBtn} onClick={onAccept}>
                YES
              </Button>
            </Flex>
          </Box>
        </Flex>
      </Flex>
    </Box>
  );
};

export default MoMPrintError;
