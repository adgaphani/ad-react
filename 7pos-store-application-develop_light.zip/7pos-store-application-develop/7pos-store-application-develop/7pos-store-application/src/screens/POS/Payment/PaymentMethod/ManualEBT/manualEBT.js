import React, { useContext, useEffect } from 'react';
import { Flex, Text, Box } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import ExitButton from '../../../../../components/POS/ExitButton';
import pinpad_touch from '../../../../../Icons/pinpad_touch.png';
import { WebSocketContext } from '../../../../../components/Common/WebSocket/WebSocketProvider';
import { appIntegrationRequest } from '../../../../../Utils/appUtils';
import { cartActions } from '../../../../../slices/cart.slice';
import { socketActions } from '../../../../../slices/socket.slice';
import { setShowNotifications } from '../../../../../slices/notifications.slice';

const ManualEBT = () => {
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);
  const paymentTransactionId = useSelector(
    state => state.cart.paymentTransactionId
  );
  const isShowNotifications = useSelector(
    state => state.notifications.isShowNotifications
  );
  const history = useHistory();

  const goBack = () => {
    dispatch(cartActions.setPaymentExit(true));
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    // Added exit to payment screen some scenario not covered in pinpad event
    dispatch(socketActions.setCardStatus(null)); // #7355 reset card status as well
    dispatch(setShowNotifications(true));
    history.push({
      pathname: '/payment',
    });
  };

  useEffect(() => {
    if (isShowNotifications) dispatch(setShowNotifications(false));
  }, [isShowNotifications]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="calc(100vh - 128px)"
      background="rgb(255,255,255)"
    >
      <Flex
        flexDirection="column"
        alignItems="center"
        height="100%"
        justifyContent="center"
      >
        <img src={pinpad_touch} alt="pinpadImg" />
        <Text
          mb={2}
          color="rgb(44, 47, 53)"
          fontSize="24px"
          fontFamily="Roboto-bold"
          fontWeight="bold"
          textAlign="center"
        >
          Ask Customer to
        </Text>
        <Text
          color="rgb(29, 137, 107)"
          fontFamily="Roboto-bold"
          fontWeight="bold"
          textAlign="center"
          fontSize="24px"
        >
          Enter EBT Card into PINPAD
        </Text>
      </Flex>
      <Box display="block" textAlign="right" p="1rem" w="100%">
        <ExitButton onClick={goBack} />
      </Box>
    </Flex>
  );
};

export default ManualEBT;
