/* eslint-disable import/no-unresolved */
import { Flex, Text } from '@chakra-ui/react';
import moment from 'moment';
import React, { useContext, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { Button } from '../../../../../components/Common/Buttons';
import { WebSocketContext } from '../../../../../components/Common/WebSocket/WebSocketProvider';
import { handlePayRequest } from '../../../../../Utils/paymentUtils';
import { socketActions } from '../../../../../slices/socket.slice';
import { cartActions } from '../../../../../slices/cart.slice';
import { AppContext } from '../../../../../AppContext';
import Icon_twarning from '../../../../../Icons/Icon_twarning.svg';

const MediaAbort = () => {
  const {
    paymentDetails,
    isTransactionVoid,
    isTransactionRefund,
    paymentHistory,
    paymentTransactionId,
    basketPromo,
    cartChangeTrial,
    runningTotal,
    loadCardMediaList,
    tranAgeVerifyInfo,
    tenderSequenceNumber,
    mediaAbortedPaymentList,
    allPayments,
    items,
    transactionComments,
  } = useSelector(state => ({
    paymentDetails: state.cart.paymentDetails,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    paymentHistory: state.cart.paymentHistory,
    paymentTransactionId: state.cart.paymentTransactionId,
    basketPromo: state.cart.basketPromo,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    loadCardMediaList: state.cart.loadCardMediaList,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    tenderSequenceNumber: state.cart.tenderSequenceNumber,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    allPayments: state.cart.allPayments,
    items: state.cart.cartItems,
    transactionComments: state.cart.transactionComments,
  }));
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);
  // const [isCbShowReversal, setIsCbShowReversal] = useState(false);

  const [isMediaAborttriggered, setMediaAborttriggered] = useState(false);
  const {
    storeDetails,
    user,
    taxInfo,
    deviceInfo,
    member,
    transactionId,
    finalsubTotalPrice,
    finalTotalPrice,
    transactionStartTime,
    showChargeReversal,
    showEbtCbReversal,
    cbAmount,
  } = location.state;

  const processCashList = ({ cashPaymentsList }) => {
    const cashPayList = [];
    const initialCashPayObj = {
      mediaStatus: 'APPROVED',
      tenderType: 'SALE',
      paymentMediaNumber: 1,
      // paidAmount: 0,
    };
    cashPaymentsList.forEach(cashPayment => {
      cashPayList.push({
        ...initialCashPayObj,
        ...{
          tenderSequenceNumber: cashPayment?.tenderSequenceNumber
            ? cashPayment?.tenderSequenceNumber
            : tenderSequenceNumber,
          amount: `-${parseFloat(cashPayment?.payment?.amount.toFixed(2))}`,
          paidAmount: `-${parseFloat(cashPayment?.payment?.amount.toFixed(2))}`,
          balanceDue: `-${parseFloat(cashPayment?.payment?.amount.toFixed(2))}`,
          tenderType: 'VOID',
        },
      });
      dispatch(cartActions.setIsCashTransactionAborted(true));
      const tSeqNum = cashPayment?.tenderSequenceNumber
        ? cashPayment?.tenderSequenceNumber
        : tenderSequenceNumber;
      dispatch(
        cartActions.setEnteredCash({
          eCash: cashPayment?.payment?.amount * -100,
          tSeqNum,
          label: 'Cash',
          paymentMediaNumber: 1, // Payment Media Number is required for CDB
        })
      );
      dispatch(
        cartActions.setMediaAbortedPaymentList({
          tenderSequenceNumber: tSeqNum,
        })
      );
      dispatch(
        cartActions.setTransactionComments(
          `CHARGE OF ${cashPayment?.payment?.amount} WAS MEDIA ABORTED`
        )
      );
    });
    return cashPayList;
  };

  const processMediaAbort = mediaAbortRequest => {
    const abortedTenders = mediaAbortedPaymentList?.map(
      mapl => mapl.tenderSequenceNumber
    );
    const paymentMediaList = allPayments
      .filter(
        p =>
          abortedTenders?.indexOf(p.tenderSequenceNumber) === -1 &&
          p.paymentMediaType !== 'CASH'
      )
      .map(p => ({
        originalPayment: {
          ...p.payment,
        },
        paymentEntryType: p.paymentEntryType,
        promptDetails: p.promptDetails,
        tenderSequenceNumber: p.tenderSequenceNumber,
      }));
    const isCashPaymentsAvailable = allPayments.some(
      ph => ph.paymentMediaType === 'CASH'
    );
    if (isCashPaymentsAvailable) {
      const cashPayList = allPayments.filter(
        ph =>
          ph.paymentMediaType === 'CASH' &&
          ph.transactionStatus !== 'CASH_ABORTED'
      );
      let cashPaymentsList = cashPayList;
      const mediaAbortedCashList = allPayments.filter(
        ph => ph.transactionStatus === 'CASH_ABORTED'
      );
      if (mediaAbortedCashList.length && mediaAbortedCashList.length > 0) {
        const abortedTenders = mediaAbortedCashList.map(
          macl => macl.tenderSequenceNumber
        );
        const cpList = cashPayList.filter(
          p => abortedTenders.indexOf(p.tenderSequenceNumber) === -1
        );
        cashPaymentsList = cpList;
      }
      mediaAbortRequest.transactionDetails.paymentInformation = {
        paymentEntryType: allPayments[0]?.paymentEntryType || 'MAGSTRIPE',
        paymentMediaList,
        cashPaymentsList: processCashList({
          cashPaymentsList,
        }),
      };
    } else {
      mediaAbortRequest.transactionDetails.paymentInformation = {
        paymentEntryType: allPayments[0]?.paymentEntryType || 'MAGSTRIPE',
        paymentMediaList,
      };
    }
    mediaAbortRequest.transactionHeaderInfo.transactionStatus = 'MEDIA_ABORT';
    if (showChargeReversal) {
      mediaAbortRequest.transactionHeaderInfo.transactionStatus = 'ABORTED';
      mediaAbortRequest.transactionDetails.paymentInformation = null;
    }
    return mediaAbortRequest;
  };
  const onCancel = () => {
    setTimeout(() => {
      if (showChargeReversal)
        dispatch(
          cartActions.updateLineItemTotalFinal({ isResetLineItemTotal: false })
        );
      dispatch(cartActions.setStatusCode(null));
      dispatch(socketActions.setCardStatus(null));
      dispatch(cartActions.setPaymentTriggerStatus(false));
      dispatch(cartActions.setIsMediaAbortTriggered(false));
      history.replace('/payment');
    }, 0);
  };

  const onAbortTrans = async () => {
    dispatch(cartActions.setTransactionAborted(true));
    return history.push('/home');
  };

  const onAbortMedia = () => {
    if (showChargeReversal) {
      if (showEbtCbReversal) {
        history.push({
          pathname: '/payment/ebtCbChargeReversalFail',
          search: `?status=ebtCbChargeRev`,
          state: { cbAmount },
        });
        return;
      }
      global?.logger?.info(`[7POS UI] - Charge reversal Yes selected`);
      dispatch(cartActions.setStatusCode(null));
      dispatch(socketActions.setCardStatus(null));
      dispatch(cartActions.setPrintChargeReversalMsg(true));
      onAbortTrans();
      return;
    }
    dispatch(
      cartActions.updateLineItemTotalFinal({ isResetLineItemTotal: true })
    );
    dispatch(cartActions.setIsMediaAborted(true));
    dispatch(cartActions.setIsMediaAbortTriggered(true));
    setMediaAborttriggered(true);
  };

  const AllMediaAbort = () => {
    let mediaAbortRequest = handlePayRequest({
      items,
      storeDetails,
      user,
      taxInfo,
      deviceInfo,
      member,
      transactionId,
      finalsubTotalPrice,
      finalTotalPrice,
      transactionStartTime,
      paymentDetails,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId,
      tranAgeVerifyInfo,
      basketPromo,
      cartChangeTrial,
      runningTotal,
      loadCardMediaList,
      paymentHistory,
      isMediaAbortReq: true,
      allPayments,
      transactionComments,
    });
    mediaAbortRequest = processMediaAbort(mediaAbortRequest);
    const request = JSON.stringify(mediaAbortRequest);
    const mediaAbortReq = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'PAYMENT',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PAYMENT',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${request}`,
      },
    };
    ws.socket?.send('/app/pinpad/payment', {}, JSON.stringify(mediaAbortReq));
    global?.logger?.info(`[7POS UI] - Media abort Request sent`);
    if (
      mediaAbortRequest?.transactionDetails?.paymentInformation
        ?.paymentMediaList?.length > 0
    ) {
      showLoader(true);
    }
  };

  useEffect(() => {
    dispatch(cartActions.setPaymentTriggerStatus(true));
  }, []);

  useEffect(() => {
    if (isMediaAborttriggered) {
      setMediaAborttriggered(false);
      AllMediaAbort();
    }
  }, [isMediaAborttriggered]);

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="calc(100vh - 128px)"
      flexDirection="column"
    >
      <>
        <img
          src={Icon_twarning}
          alt="Warning_Icon"
          height="48px"
          width="54px"
        />
        <>
          {' '}
          {showChargeReversal ? ( // TODO: Need to add Correct status code
            <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
              <Text fontSize="18px" fontWeight="bold">
                Charge Reversal Failed.
              </Text>
              <Text fontSize="18px">
                Press &quot;YES&quot; to abort the transaction or &quot;NO&quot;
                to return
              </Text>
              <Text fontSize="18px">to the media screen.</Text>
            </Flex>
          ) : (
            <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
              <Text fontSize="18px" fontWeight="bold">
                Select New Media.
              </Text>
              <Text fontSize="18px" fontWeight="bold" mb="0.5rem">
                Media has been Tendered in the Sale
              </Text>
              <Text fontSize="18px">
                Press &quot;YES&quot; to cancel all media and return to main
              </Text>
              <Text fontSize="18px">
                sales screen.Press &quot;NO&quot; to return to media screen.
              </Text>
            </Flex>
          )}
        </>
        <Flex direction="row" mt={2}>
          <Button
            className="btn primaryButton"
            borderRadius="3px"
            height="50px"
            width="140px"
            mr={3}
            _hover={{ bg: '#107f62' }}
            onClick={onAbortMedia}
          >
            <Text>YES</Text>
          </Button>
          <Button
            className="btn secondaryButton"
            height="50px"
            width="140px"
            onClick={onCancel}
          >
            <Text>NO</Text>
          </Button>
        </Flex>
      </>
    </Flex>
  );
};

export default MediaAbort;
