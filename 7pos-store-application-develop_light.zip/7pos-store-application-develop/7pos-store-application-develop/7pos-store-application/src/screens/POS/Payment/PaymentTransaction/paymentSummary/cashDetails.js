/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
import React, { useState } from 'react';
import { Box } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import {
  currencyFixed,
  getScreenTaxDetails,
  getTaxAssesments,
  getTotalBtlDeposit,
} from '../../../../../Utils/appUtils';
import { isOnlyLotteryInCart } from '../../../../../Utils/lotteryUtils';
import { createTaxObject } from '../../../../../Utils/paymentUtils';
import PaymentDetailValue from './paymentDetailValue';
import TransactionComplete from './transactionComplete';
import { SendMessageToCFD } from '../../../../../Communication';
import VoidTransactionText from '../../../Cart/VoidTransactionText';
import MediaAbortedText from '../../../Cart/MediaAbortedText';

const CashDetails = props => {
  const {
    isTransactionVoid,
    isTransactionRefund,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    taxInfo,
    items,
    allPayments,
    taxDeductionAmount,
    isCanada,
    cartItems,
    stateCode,
  } = useSelector(state => ({
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    taxInfo: state.cart.taxInfo,
    items: state.cart.cartItems,
    allPayments: state.cart.allPayments,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    cartItems: state.cart.cartItems,
    stateCode: state.main.storeDetails?.address?.state,
  }));
  const location = useLocation();
  const [ChangeIdentified, setChangeIdentified] = useState(false);

  let exemptedAmount = Math.abs(
    Number(props.taxExempted) - Number(props.taxData?.totalTaxAmount || 0)
  );
  exemptedAmount = exemptedAmount.toFixed(2);
  const isOnlyLottery = isOnlyLotteryInCart(items);
  const canShowBalanceDue = () =>
    Number(props.balanceDue) !== 0 &&
    (location.pathname !== '/payment/success' ||
      location.pathname !== '/payment/emailReceipt');
  const getChange = () => {
    const cash =
      props?.enteredCash ||
      props.allPayments.reduce((acc, pay) => {
        if (pay.paymentMediaType === 'CASH') {
          acc += pay.payment.amount;
        }
        return acc;
      }, 0);
    if (cash > 0 || isOnlyLottery) {
      const alreadyPaidAmount = allPayments?.reduce(
        (sum, ap) => sum + parseFloat(ap?.payment?.amount) || 0,
        0
      );
      const isChangeWithSplitPay =
        (Number(alreadyPaidAmount) > 0 &&
          Number(props.totalChangeForCash) > 0) ||
        false;
      if (
        !isTransactionVoid &&
        !isTransactionRefund &&
        cash < Number(props.total) &&
        !isChangeWithSplitPay
      )
        return `$0.00`;
      return `$${currencyFixed(props.totalChangeForCash) || '0.00'}`;
    }
    return `$0.00`;
  };
  const processData = () => {
    const changeAmount = getChange();
    let totalValue = parseFloat(props.total).toFixed(2);

    const taxAssessments = createTaxObject(
      taxInfo,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      isTransactionRefund || isTransactionVoid
    );
    const salesTaxValue = getScreenTaxDetails(
      taxAssessments,
      taxInfo,
      isTransactionRefund || isTransactionVoid,
      taxableBeforeEBTExempt,
      taxBeforeEBTExempt,
      stateCode
    );
    /* let salesTaxValue = props.taxData?.totalTaxAmount || '0.00';
    salesTaxValue = parseFloat(salesTaxValue).toFixed(2); */

    // Always tax and total due will be negative in void and refund transaction.
    if (
      Number(exemptedAmount) !== 0 &&
      props.taxExempted !== null &&
      props.taxExempted !== 0
    ) {
      if (isTransactionRefund || isTransactionVoid) {
        totalValue = Number(totalValue) - Number(exemptedAmount);
        // salesTaxValue = Number(salesTaxValue) - Number(exemptedAmount);
      } else {
        totalValue = Number(totalValue) + Number(exemptedAmount);
        // salesTaxValue = Number(salesTaxValue) + Number(exemptedAmount);
      }
    }

    if (!ChangeIdentified) {
      setChangeIdentified(true);
      const itotalDetails = {
        finalsubTotalPrice: props.subTotal,
        finalTotalPrice: props.balanceDue,
        totalPromotionPrice: props.discount,
        totalDue: props.total,
        Cash: totalValue,
        Change: changeAmount,
        taxDeductionAmount,
        PaymentMediaList: props.allPayments,
      };
      let TaxDetails = Object.keys(salesTaxValue).map(key => ({
        amount: Number(salesTaxValue[key]),
        description: key,
      }));

      if (isCanada) {
        TaxDetails = getTaxAssesments(taxInfo).map(item => ({
          description: `${item.description} on ${item.displayTaxableAmount}`,
          amount: Number(item.taxAmount).toFixed(2),
        }));
      }
      const iTransactionMessage = {
        CMD: 'UpdateTransaction',
        TaxInfo: props.taxData,
        TaxDetails,
        TotalDetails: itotalDetails,
        MemberInfo: props.member,
        TransactionType: isTransactionVoid
          ? 'Void'
          : isTransactionRefund
          ? 'Refund'
          : 'Sale',
      };
      SendMessageToCFD(iTransactionMessage);
    }
    return {
      totalValue,
      salesTaxValue,
      changeAmount,
    };
  };
  // eslint-disable-next-line no-unused-vars
  const { totalValue, salesTaxValue, changeAmount } = processData();
  const discount =
    `${
      isTransactionVoid || isTransactionRefund
        ? currencyFixed(props.discount)
        : `-${currencyFixed(props.discount)}`
    }` || '0.00';
  return (
    <Box px={4}>
      {(props.isTransactionVoid || props.isTransactionRefund) && (
        <VoidTransactionText type={isTransactionRefund ? 'REFUND' : 'VOID'} />
      )}
      {props.isMediaAborted && <MediaAbortedText />}
      {!!getTotalBtlDeposit(cartItems) && (
        <PaymentDetailValue
          label="Total Btl Dep-N"
          value={parseFloat(getTotalBtlDeposit(cartItems)).toFixed(2)}
        />
      )}
      <PaymentDetailValue
        label="Subtotal"
        value={currencyFixed(props.subTotal) || '0.00'}
      />
      {props.discount ? (
        <PaymentDetailValue
          label="Discount(s)"
          valueColor="#ec2526"
          value={discount}
        />
      ) : (
        ''
      )}

      {!isCanada &&
        Object.keys(salesTaxValue).map((key, index) => (
          <PaymentDetailValue
            key={index}
            label={key}
            value={salesTaxValue[key]}
          />
        ))}

      {isCanada &&
        getTaxAssesments(taxInfo).map((item, index) => (
          <PaymentDetailValue
            key={index}
            label={`${item.description} on ${item.displayTaxableAmount}`}
            value={item.displayTaxAmountCurrency}
          />
        ))}

      <PaymentDetailValue
        label={`${
          props.isTransactionVoid ||
          props.isTransactionRefund ||
          props.total < 0 // Displays Refund if Negative Amount
            ? 'Refund'
            : 'Total'
        } Due`}
        value={`${currencyFixed(totalValue) || '0.00'}`}
      />
      {/* {Number(exemptedAmount) !== 0 &&
        props.taxExempted !== null &&
        props.taxExempted !== 0 && (
          // RISPIN:2726 Tax deduction should always +ve for void/sale
          <PaymentDetailValue
            label="Tax Deduction"
            value={`${Math.abs(currencyFixed(exemptedAmount)) || '0.00'}`}
          />
        )} */}
      {taxDeductionAmount && Number(taxDeductionAmount) > 0 ? (
        <PaymentDetailValue
          label="Tax Deduction"
          value={parseFloat(taxDeductionAmount).toFixed(2)}
        />
      ) : (
        ''
      )}
      {props.allPayments.length > 0 && (
        <>
          {props.allPayments.map((p, index) => (
            <PaymentDetailValue
              key={index}
              comment={p?.label}
              label={`${p?.receiptDetails?.cardName} ${
                p?.receiptDetails?.cardName.toLowerCase().includes('debit') ||
                p?.receiptDetails?.cardName.toLowerCase().includes('credit')
                  ? 'Card'
                  : ''
              }`}
              value={p?.payment?.amount?.toFixed(2)}
            />
          ))}
        </>
      )}
      {canShowBalanceDue() && (
        <PaymentDetailValue
          label="Balance Due"
          variant="bold"
          value={`$${currencyFixed(props.balanceDue)}`}
        />
      )}
      {Number(props.balanceDue) === 0 && (
        <>
          {changeAmount !== 'NaN' &&
          changeAmount !== '$0.00' &&
          changeAmount !== '0.00' ? (
            <PaymentDetailValue
              label="Change"
              variant="bold"
              value={changeAmount}
            />
          ) : (
            <PaymentDetailValue
              label="Balance Due"
              variant="bold"
              value="$0.00"
            />
          )}
          <TransactionComplete />
        </>
      )}
    </Box>
  );
};

export default CashDetails;
