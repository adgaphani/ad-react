import React from 'react';
import { Flex, Image, Text } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { PIPOExitButton } from '../../../../components/POS/OtherFunctions/PaidInOut/ExitButton';
import Styles from './PIPOAmountError.module.css';
import WarningIcon from '../../../../Icons/Warning_Icon.svg';

export const PIPOAmountError = () => {
  const history = useHistory();
  const { pipoTransaction = {} } = useSelector(state => ({
    pipoTransaction: state.cashFunctions.pipoTransaction,
  }));
  const { displayLabel } = pipoTransaction;
  const goBack = () => {
    history.replace('/payment');
  };
  return (
    <Flex className={Styles.wrapper}>
      <Flex className={Styles.errorWrapper}>
        <Image className={Styles.image} src={WarningIcon} />
        <Text className={Styles.errorText}>
          {`${displayLabel} Amount Expected`}
        </Text>
      </Flex>
      <PIPOExitButton onExit={goBack} />
    </Flex>
  );
};
