import React from 'react';
import { Flex, Box, Grid } from '@chakra-ui/react';
// import ExitButton from '../../../../components/POS/ExitButton';
import Keypad from '../../../../components/Common/DailPad/Keypad/Keypad';
import PaymentMethodTypes from './paymentMethodTypes';

export const PMethods = ({
  goBack,
  enteredCashAmount,
  onCashPayment,
  handlePay,
  onManualEbt,
  tenderSequenceNumber,
  disableOtherMedia,
}) => (
  <Flex flexDirection="column" justifyContent="space-between" height="100%">
    <Flex flexDirection="column">
      <Grid templateColumns="50% 50%">
        <Box pr="0.5rem">
          <Keypad onEnter={enteredCashAmount} />
        </Box>
        <Box bg="rgb(255, 255, 255)" p={0}>
          <PaymentMethodTypes
            onCashPayment={onCashPayment}
            enteredCashAmount={enteredCashAmount}
            handlePay={handlePay}
            onManualEbt={onManualEbt}
            tenderSequenceNumber={tenderSequenceNumber}
            goBack={goBack}
            disableOtherMedia={disableOtherMedia}
          />
        </Box>
      </Grid>
    </Flex>
  </Flex>
);
