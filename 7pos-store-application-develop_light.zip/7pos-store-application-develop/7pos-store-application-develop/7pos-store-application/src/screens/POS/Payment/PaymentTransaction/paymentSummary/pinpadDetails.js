import { Box } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { SendMessageToCFD } from '../../../../../Communication';
import VoidTransactionText from '../../../Cart/VoidTransactionText';
import MediaAbortedText from '../../../Cart/MediaAbortedText';
import {
  currencyFixed,
  getScreenTaxDetails,
  getTaxAssesments,
  getTotalBtlDeposit,
} from '../../../../../Utils/appUtils';
import { createTaxObject } from '../../../../../Utils/paymentUtils';
import CashBackText from './cashBackText';
import PaymentDetailValue from './paymentDetailValue';
import TransactionComplete from './transactionComplete';

const PinpadDetails = props => {
  const {
    subTotal,
    total,
    discount,
    paymentDetails,
    cashBack,
    allPayments,
    taxData,
    isTransactionRefund,
    isTransactionVoid,
    balanceDue,
    statusCode,
    taxExempted,
    member,
    // eslint-disable-next-line no-unused-vars
    enteredCash,
    CardDeclinedAmount,
    isMediaAborted,
  } = props;
  const [SendCardDetails, setSendCardDetails] = useState(false);

  const {
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    taxInfo,
    taxDeductionAmount,
    isCanada,
    cartItems,
    stateCode,
  } = useSelector(state => ({
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    taxInfo: state.cart.taxInfo,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    cartItems: state.cart.cartItems,
    stateCode: state.main.storeDetails?.address?.state,
  }));

  const cashBackAmount = parseFloat(cashBack).toFixed(2);
  const exemptedAmount = Math.abs(
    Number(taxExempted) - Number(taxData?.totalTaxAmount || 0)
  );
  let totalVal = parseFloat(total).toFixed(2);

  const taxAssessments = createTaxObject(
    taxInfo,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    isTransactionRefund || isTransactionVoid
  );
  const salesTaxValue = getScreenTaxDetails(
    taxAssessments,
    taxInfo,
    isTransactionRefund || isTransactionVoid,
    taxableBeforeEBTExempt,
    taxBeforeEBTExempt,
    stateCode
  );
  /* let salesTaxValue = taxData?.totalTaxAmount || '0.00';
  salesTaxValue = parseFloat(salesTaxValue).toFixed(2); */

  // Always tax and total due will be negative in void and refund transaction.
  if (
    Number(exemptedAmount) !== 0 &&
    taxExempted !== null &&
    taxExempted !== 0
  ) {
    if (isTransactionRefund || isTransactionVoid) {
      totalVal = Number(totalVal) - Number(exemptedAmount);
      // salesTaxValue = Number(salesTaxValue) - Number(exemptedAmount);
    } else {
      totalVal = Number(totalVal) + Number(exemptedAmount);
      // salesTaxValue = Number(salesTaxValue) + Number(exemptedAmount);
    }
  }

  useEffect(() => {
    if (!SendCardDetails) {
      setSendCardDetails(true);
      const itotalDetails = {
        finalsubTotalPrice: subTotal,
        finalTotalPrice: totalVal,
        totalPromotionPrice: discount,
        totalDue: total,
        CashBack: cashBack,
        PaymentMediaList: allPayments,
        taxDeductionAmount,
      };
      let TaxDetails = Object.keys(salesTaxValue).map(key => ({
        amount: Number(salesTaxValue[key]),
        description: key,
      }));

      if (isCanada) {
        TaxDetails = getTaxAssesments(taxInfo).map(item => ({
          description: `${item.description} on ${item.displayTaxableAmount}`,
          amount: Number(item.taxAmount).toFixed(2),
        }));
      }
      const iTransactionMessage = {
        CMD: 'UpdateTransaction',
        TaxInfo: taxData,
        TaxDetails,
        TotalDetails: itotalDetails,
        MemberInfo: member,
        TransactionType: isTransactionVoid
          ? 'Void'
          : isTransactionRefund
          ? 'Refund'
          : 'Sale',
      };
      SendMessageToCFD(iTransactionMessage);
    }
  }, []);

  return (
    <Box p={4}>
      {(isTransactionVoid || isTransactionRefund) && (
        <VoidTransactionText type={isTransactionRefund ? 'REFUND' : 'VOID'} />
      )}
      {isMediaAborted && <MediaAbortedText />}
      {!!getTotalBtlDeposit(cartItems) && (
        <PaymentDetailValue
          label="Total Btl Dep-N"
          value={parseFloat(getTotalBtlDeposit(cartItems)).toFixed(2)}
        />
      )}
      <PaymentDetailValue label="Subtotal" value={currencyFixed(subTotal)} />
      {discount ? (
        <PaymentDetailValue
          label="Discount(s)"
          valueColor="#ec2526"
          value={
            `${
              isTransactionVoid || isTransactionRefund
                ? currencyFixed(discount)
                : `-${currencyFixed(discount)}`
            }` || '0.00'
          }
        />
      ) : (
        ''
      )}
      {!isCanada &&
        Object.keys(salesTaxValue).map((key, index) => (
          <PaymentDetailValue
            key={index}
            label={key}
            value={salesTaxValue[key]}
          />
        ))}

      {isCanada &&
        getTaxAssesments(taxInfo).map((item, index) => (
          <PaymentDetailValue
            key={index}
            label={`${item.description} on ${item.displayTaxableAmount}`}
            value={Number(item.taxAmount).toFixed(2)}
          />
        ))}

      {(isTransactionVoid || isTransactionRefund) && (
        <PaymentDetailValue
          label="Refund Due"
          value={`${currencyFixed(totalVal) || '0.00'}`}
        />
      )}
      {!isTransactionRefund && !isTransactionVoid && (
        <PaymentDetailValue
          label="Total Due"
          value={`${currencyFixed(totalVal) || '0.00'}`}
        />
      )}
      {/* {Number(exemptedAmount) !== 0 &&
        taxExempted !== null &&
        taxExempted !== 0 && (
          // RISPIN:2726 Tax deduction should always +ve for void/sale
          <PaymentDetailValue
            label="Tax Deduction"
            value={`${Math.abs(currencyFixed(exemptedAmount)) || '0.00'}`}
          />
        )} */}
      {taxDeductionAmount && Number(taxDeductionAmount) > 0 ? (
        <PaymentDetailValue
          label="Tax Deduction"
          value={parseFloat(taxDeductionAmount).toFixed(2)}
        />
      ) : (
        ''
      )}
      {allPayments.length > 0 && (
        <>
          {allPayments.map((p, index) => (
            <PaymentDetailValue
              key={index}
              comment={p?.label}
              label={`${p?.receiptDetails?.cardName} ${
                p?.receiptDetails?.cardName.toLowerCase().includes('debit') ||
                p?.receiptDetails?.cardName.toLowerCase().includes('credit')
                  ? 'Card'
                  : ''
              }`}
              value={p.payment.amount.toFixed(2)}
            />
          ))}
        </>
      )}
      {paymentDetails && (
        <Box>
          {!isTransactionVoid &&
            !isTransactionRefund &&
            (cashBack ? (
              <CashBackText dence eventData={cashBackAmount} />
            ) : (
              <PaymentDetailValue
                label="Balance Due"
                variant="bold"
                value={`$${currencyFixed(balanceDue) || '$0.00'}`}
              />
            ))}
          {statusCode !== 12 &&
          paymentDetails.paymentMedia?.status === 'APPROVED' ? (
            <TransactionComplete />
          ) : (
            ''
          )}
        </Box>
      )}
      {!paymentDetails && Math.abs(Number(CardDeclinedAmount)) > 0 && (
        <TransactionComplete />
      )}
    </Box>
  );
};

PinpadDetails.defaultProps = {
  paymentDetails: {},
  subTotal: 0,
  total: 0,
  discount: 0,
  cashBack: 0,
  allPayments: [],
  taxData: {},
  isTransactionRefund: false,
  isTransactionVoid: false,
  balanceDue: '',
  statusCode: 0,
  taxExempted: 0,
  member: [],
  enteredCash: 0,
  CardDeclinedAmount: 0,
};

PinpadDetails.propTypes = {
  paymentDetails: PropTypes.object,
  subTotal: PropTypes.number,
  total: PropTypes.number,
  discount: PropTypes.number,
  cashBack: PropTypes.number,
  allPayments: PropTypes.array,
  taxData: PropTypes.object,
  isTransactionRefund: PropTypes.bool,
  isTransactionVoid: PropTypes.bool,
  balanceDue: PropTypes.string,
  statusCode: PropTypes.number,
  taxExempted: PropTypes.number,
  member: PropTypes.object,
  enteredCash: PropTypes.number,
  CardDeclinedAmount: PropTypes.number,
};

export default PinpadDetails;
