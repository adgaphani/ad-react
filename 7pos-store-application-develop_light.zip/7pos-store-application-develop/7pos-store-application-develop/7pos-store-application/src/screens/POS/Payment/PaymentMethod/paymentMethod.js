/* eslint-disable max-lines */
/* eslint-disable prefer-const */
import { Box, Flex, Grid, Text } from '@chakra-ui/react';
import moment from 'moment';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
// import { updateCacheHardTotals } from '7pos-hardtotals';
import {
  useCart,
  useCartCleanup,
  useFuel,
  useHardTotals,
  useSharedFuelRequest,
  useCharityRoundOff,
  useSoundToast,
  usePromoUtils,
} from '../../../../hooks';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { SendMessageToCFD } from '../../../../Communication';
import {
  CARD_READ,
  DECLINE,
  DECLINED_ORIGINALCARD_NOTFOUND,
  DECLINED_ORIGINALSALE_NOTFOUND,
  INVALID_EBT_ACCOUNT,
  PROMPT_REFERENCE_NUMBER,
  WAITING_FOR_CARD,
  TIMEOUT,
  MO_FLG_INSALE,
  MO_FLG_PRINTING,
  MO_FLG_PRINTED,
  MO_FLG_INVALID,
  WAITING_FOR_EBT_MANUAL_ENTRY,
  EBTCB,
  EBTSNAP,
  BALANCE_INQUIRY,
  DECLINED_INVALID_PAYMENT_REQUEST,
  WSTopics,
  TransactionStates,
  LOAD_FLG_INVALID,
  LOAD_REQUEST_INPROGRESS,
  CARD_LOAD_BASE_INDEX,
  CASHBACK_RESTRICTION,
  SKIP_PROMO,
  SIGNATURE_CAPTURE,
  LOCAL_CHARGE,
  DRIVE_OFF,
  ITEM_TYPE,
} from '../../../../constants';
import { fetchEmailReceipt } from '../../../../api/payment';
import { cartActions } from '../../../../slices/cart.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import {
  requestMoneyOrderLock,
  releaseMoneyOrderLock,
} from '../../../../Utils/moneyOrderUtils';
import { socketActions } from '../../../../slices/socket.slice';
import {
  handlePayRequest,
  getBalanceDue,
  getLineItemTotalTax,
} from '../../../../Utils/paymentUtils';
import EBTCBNoReturn from './EBTCBNoReturn';
import OriginalRefNumber from './OriginalRefNumber';
import PartialApproval from './partialApproval/partialApproval';
import InsuffcientAmount from './InsufficentAmount/InsufficentAmount';
import Styles from './paymentMethod.module.css';
import Processing from './Processing';
import WaitingForCard from './WaitingForCard';
import CardLoadSwipeWait from './CardLoadSwipeWait';
import ManualEBT from './ManualEBT/manualEBT';
import {
  getLineTax,
  tranFinalAmountValidation,
} from '../../../../Utils/cartUtils';
import {
  currencyFixed,
  appIntegrationRequest,
  captureHardTotals,
  CreditItemRunningTotal,
  finalizeHardTotals,
  storeTranSeqNumber,
  blockCashDrawerToOpen,
} from '../../../../Utils/appUtils';
import {
  processHandleCancel,
  processCashAmount,
} from '../../../../Utils/Payments/paymentMethodUtils';
import {
  verifyMoneyOrderItemStatus,
  verifyMOMInTransaction,
  IsValidCashPayment,
} from './MoneyOrderPrint';
import MoMPrintError from './MoneyOrderError';
import { cfdActions } from '../../../../slices/cfd.slice';
import {
  lookupRequest,
  isCardLoadsLimitCrossed,
} from '../../../../Utils/cardLoadUtils';
import { cashFunctionActions } from '../../../../slices/cashFunctions.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import { CashUtil } from '../../../../Utils/CashUtil';
import { AppContext } from '../../../../AppContext';
import MediaHalo from './MediaHalo';
import { PMethods } from './PMethods';
// import { TransactionTypes } from '../../../../TransactionTypes';
import EbtCbCashBackScreen from './EbtCbCashBackScreen';
import { getTransPriceDetails } from '../../../../Utils/Payments/paymentTransactionUtils';
import store from '../../../../store';
import SignatureCapture from './SignatureCapture/SignatureCapture';
// import { MasterCardPrompt } from '../../../../components/Common/Loyalty/MasterCardPrompt';
import { getDVR } from '../../../../hardware/dvr';
import { processTaxRequest } from '../../../../Utils/tax';

const MO_TIMER_RESET = 0;
const MO_TIMER_TRIGGER = 1;
const MO_TIMER_CLEAR = 2;

const ROUNDOFF_CHARITY_RESET = 0;
const ROUNDOFF_CHARITY_INTIATED = 1;
const ROUNDOFF_CHARITY_COMPLETED = 2;

const PaymentMethod = () => {
  const toast = useSoundToast();
  const history = useHistory();
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);
  const { showLoader, showToast, startLoading } = useContext(AppContext);
  const { isFuelTransactionInProgress, isCarwashInProgress } = useCart();
  const { isRoundOffCharityApplicable } = useCharityRoundOff();
  const { fuelPrices } = useFuel();
  const { refreshHardTotals } = useHardTotals();
  const { processPrepayApprovalIfNeeded } = useSharedFuelRequest();
  const location = useLocation();
  const [showPartialApproval, setShowPartialApproval] = useState(false);
  const [iMediaErrorMsg, setiMediaErrorMsg] = useState('');
  const [isMoneyOrderProgress, setMoneyOrderProgressStatus] = useState(0);
  const [isMoneyOrderError, setMoneyOrderEror] = useState(false);
  const [MoneyOrderTimeOut, setMoneyOrderTimeOut] = useState(null);
  const [isRoundUpTriggered, setRoundUpTriggered] = useState(false);
  const [isRoundUpProgress, setRoundUpProgress] = useState(
    ROUNDOFF_CHARITY_RESET
  );
  const [charityRedirection, setCharityRedirection] = useState('');
  const [isRoundUpAmount, setisRoundUpAmount] = useState(0);
  const [isMediaHALOError, setMediaHALOError] = useState(false);
  const {
    user,
    socketStatus,
    storeDetails,
    deviceInfo,
    items,
    transactionId,
    member,
    pumpNumber,
    amount,
    pumpType,
    basketPromo,
    paymentDetails,
    isTransactionVoid,
    statusCode,
    tenderSequenceNumber,
    paymentHistory,
    paymentMediaList,
    originalSaleDeclinedCount,
    isTransactionRefund,
    paymentTransactionId,
    enteredCash,
    MoneyOrderPrinterStatus,
    MoneyOrderDetails,
    tranAgeVerifyInfo,
    declinedPayments,
    cartChangeTrial,
    keypad,
    digitalWalletToken,
    hardTotal,
    RoundUpCharityStatus,
    tranItemSeqNumber,
    runningTotal,
    loadConfirm,
    loadSttn,
    loadBarcodeData,
    prepaidAccNumberValue,
    pipoTransaction,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    config,
    approvedTenderedCount,
    declineMessage,
    loadCardMediaList,
    CardLoadStatus,
    loadNotificationStatus,
    loadPromptRequest,
    loadAmount,
    cashBack,
    CashPaymentInfo,
    allPayments,
    currencyConversion,
    InSufficentCardDetails,
    CashAmountToBeApplied,
    transactionComments,
    isCanada,
    pinpadPayStartTime,
    isPaymentTriggered,
    totalCreditAmount,
    totalCreditTax,
    totalCreditCount,
    MembertransactionId,
    isEBTPayment,
    mediaAbortedPaymentList,
    isRoundOffDept,
    isSigCaptureRequired,
    isTAPITransCompleted,
    mediaConfig,
    isOtherMediaScreenActive,
    channel,
    fuelLoyalty,
    isMasterCardLoyaltyPayment,
    autoTriggerCardPayment,
    fuelLoyaltyDiscounts,
    arbitration,
    processPaymentAsMCLoyalty,
    itemQuantity,
  } = useSelector(
    state => ({
      user: state.auth.user,
      socketStatus: state.socket.status,
      storeDetails: state.main.storeDetails,
      deviceInfo: state.main.deviceInfo,
      items: state.cart.cartItems,
      transactionId: state.cart.transactionId,
      member: state.cart.member,
      pumpNumber: state.cart.fuel[0]?.pumpNumber || null,
      amount: state.cart.fuel[0]?.amount || '',
      pumpType: state.cart.fuel[0]?.pumpType || '',
      basketPromo: state.cart.basketPromo,
      paymentDetails: state.cart.paymentDetails,
      isTransactionVoid: state.cart.isTransactionVoid,
      statusCode: state.cart.statusCode,
      tenderSequenceNumber: state.cart.tenderSequenceNumber,
      partialPaymentBalnceAmt: state.cart.partialPaymentBalnceAmt,
      paymentHistory: state.cart.paymentHistory,
      paymentMediaList: state.cart.paymentMediaList,
      originalSaleDeclinedCount: state.socket.originalSaleDeclinedCount,
      isTransactionRefund: state.cart.isTransactionRefund,
      paymentTransactionId: state.cart.paymentTransactionId,
      enteredCash: state.cart.enteredCash,
      MoneyOrderPrinterStatus: state.cart.MoneyOrderPrinterStatus,
      MoneyOrderDetails: state.cart.MoneyOrderDetails,
      tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
      declinedPayments: state.cart.declinedPayments,
      cartChangeTrial: state.cart.cartChangeTrial,
      keypad: state.dailpad.keypad,
      digitalWalletToken: state.cart.digitalWalletToken,
      hardTotal: state.cart.hardTotalSummary,
      RoundUpCharityStatus: state.cart.RoundUpCharityStatus,
      tranItemSeqNumber: state.cart.tranItemSeqNumber,
      runningTotal: state.cart.runningTotal,
      loadConfirm: state.cart.loadConfirm,
      loadSttn: state.cart.loadSttn,
      loadBarcodeData: state.cart.loadBarcodeData,
      prepaidAccNumberValue: state.cart.prepaidAccNumberValue,
      pipoTransaction: state.cashFunctions.pipoTransaction,
      taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
      taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
      config: state.main.configuration,
      approvedTenderedCount: state.cart.approvedTenderedCount,
      declineMessage: state.cart.declineMessage,
      loadCardMediaList: state.cart.loadCardMediaList,
      CardLoadStatus: state.cart.CardLoadStatus,
      loadNotificationStatus: state.cart.loadNotificationStatus,
      loadPromptRequest: state.cart.loadPromptRequest,
      loadAmount: state.cart.loadAmount,
      cashBack: state.socket.cashBack,
      CashPaymentInfo: state.cart.CashPaymentInfo,
      allPayments: state.cart.allPayments,
      currencyConversion: state.main.currencyConversion,
      InSufficentCardDetails: state.cart.InSufficentCardDetails,
      CashAmountToBeApplied: state.cart.CashAmountToBeApplied,
      transactionComments: state.cart.transactionComments,
      isCanada: state.main.storeDetails?.address?.country === 'CA',
      pinpadPayStartTime: state.cart.pinpadPayStartTime,
      isPaymentTriggered: state.cart.isPaymentTriggered,
      totalCreditAmount: state.cart.totalCreditAmount,
      totalCreditTax: state.cart.totalCreditTax,
      totalCreditCount: state.cart.totalCreditCount,
      MembertransactionId: state.cart.MembertransactionId,
      isEBTPayment: state.cart.isEBTPayment,
      mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
      isRoundOffDept: state.cart.isRoundOffDept,
      isSigCaptureRequired: state.cart.isSigCaptureRequired,
      isTAPITransCompleted: state.cart.isTAPITransCompleted,
      mediaConfig: state.main.mediaConfig,
      isOtherMediaScreenActive: state.cart.isOtherMediaScreenActive,
      channel: state.main.channel,
      fuelLoyalty: state.cart.fuelLoyalty,
      loyaltyMasterCardStatusCode: state.cart.loyaltyMasterCardStatusCode,
      isMasterCardLoyaltyPayment: state.cart.isMasterCardLoyaltyPayment,
      autoTriggerCardPayment: state.cart.autoTriggerCardPayment,
      fuelLoyaltyDiscounts:
        state.cart.calculatedFuelDiscounts?.loyaltyDiscounts,
      arbitration: state.cart.arbitration,
      processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
      itemQuantity: state.cart.itemQuantity,
    }),
    shallowEqual
  );
  const { cancelFuelRewardInTransaction } = usePromoUtils();

  let paymentTransId;
  let {
    tranTotalDue: finalTotalPrice,
    tranSubTotal: finalsubTotalPrice,
  } = store.getState().cart;
  const { taxInfo } = store.getState().cart;

  // #7450/#7425 recalculate final total price before tender.
  const finalizeTransactionTotal = () => {
    const tranDetails = getTransPriceDetails({
      items,
      basketPromo,
      taxData: taxInfo,
      isTransactionRefund,
      isTransactionVoid,
    });
    ({ finalsubTotalPrice } = tranDetails);
    const { totalPrice } = tranDetails;
    finalTotalPrice = currencyFixed(totalPrice);
    console.log('Final Total:', finalTotalPrice);
    dispatch(cartActions.setTranTotalDue(Number(finalTotalPrice)));
    dispatch(cartActions.setTranSubTotal(Number(finalsubTotalPrice)));
  };

  const hardTotalRef = useRef(hardTotal);
  const transactionStartTime = useSelector(
    state => state.cart.transactionStartTime
  );
  const cardStatus = useSelector(state => state.socket.cardStatus);
  const paymentMethod = useSelector(state => state.cart.paymentMethod);
  const fleetPromptValues = useSelector(state => state.cart.fleetPromptValues);
  const { creditTaxOverrideCleanup } = useCartCleanup();

  const currencyRoundoff = (amount, currencyConversion) =>
    Number(
      (
        Math.round(Number(amount).toFixed(2) * currencyConversion * 1000) / 1000
      ).toFixed(2)
    );

  const DisplayToastMsg = (MSG, msgType = 'error') => {
    toast({
      description: MSG,
      status: msgType,
      duration: 3000,
      position: 'top-left',
    });
  };

  const displayErrorToast = msg => {
    toast({
      position: 'top-left',
      status: 'error',
      duration: 3000,
      render: () => (
        <Flex
          color="white"
          bg="#ec2526"
          justifyContent="flex-start"
          alignItems="center"
        >
          <Text pl="12px" fontFamily="Roboto-medium">
            {msg}
          </Text>
        </Flex>
      ),
    });
  };

  const showPrintFailure = (error, position = 'top') => {
    toast({
      description: error,
      status: 'error',
      duration: 5000,
      position,
    });
  };

  const resetPIPOTransaction = () => {
    // #2574 reset part of empty card
    // dispatch(cartActions.resetTransactionId());
    // #2574 updating transeq for PIPO empty cart will no
    dispatch(cartActions.emptyCart());
    // dispatch(cashFunctionActions.resetPIPOTransaction());
    dispatch(
      dailpadActions.setKeypadValue({
        value: '',
      })
    );
    // RISPIN-2497: Home is checking status variable from search to trigger no noSale.
    // Passing here to block the no sale call.
    history.push({
      pathname: '/home',
      search: `?status=noSale`,
    });
  };

  const initiatePrintIfNeeded = async () => {
    if (!pipoTransaction?.initiatePrint) {
      return;
    }
    const printPayload = CashUtil.paymentPrintRequest({
      storeDetails,
      user,
      transactionId,
      config,
      cashTransaction: pipoTransaction,
    });
    try {
      await fetchEmailReceipt(printPayload, paymentTransactionId, channel);
    } catch (e) {
      global.logger.error(`[7POS UI] - fetchEmailReceipt error`);
      if (e?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(e?.response?.data));
        showPrintFailure(errorMessage.message);
      } else {
        showPrintFailure('Receipt could not be printed. Please try again');
      }
    } finally {
      showLoader(false);
      resetPIPOTransaction();
    }
  };

  useEffect(() => {
    initiatePrintIfNeeded();
  }, [pipoTransaction?.initiatePrint]);

  if (transactionStartTime === '') {
    const transStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
    dispatch(cartActions.setTransactionStartTime(transStartTime));
  }

  const isRestirctionItempresent = () => {
    let isRestirctionItemPresent = false;
    if (
      items?.every(
        item =>
          item?.restrictedMediaTypes &&
          !item.restrictedMediaTypes.includes('LC')
      )
    ) {
      return isRestirctionItemPresent;
    }
    if (
      allPayments?.length === 0 &&
      items?.some(
        item =>
          item?.restrictedMediaTypes && item.restrictedMediaTypes.includes('LC')
      )
    ) {
      isRestirctionItemPresent = true;
      return isRestirctionItemPresent;
    }
    if (allPayments?.length > 0) {
      const tenderedAmount =
        allPayments?.length > 0
          ? allPayments?.reduce(
              (sum, ap) => sum + parseFloat(ap?.payment?.amount) || 0,
              0
            )
          : 0;
      // #7485 restricted LC items for paid items
      let paidItemsAmount = items
        ?.filter(
          item =>
            !item?.negativeSalesFlag &&
            !item?.restrictedMediaTypes?.includes('LC')
        )
        .reduce((sum, item) => {
          let lineItemAmount = getLineItemTotalTax({
            items,
            item,
            basketPromo,
            isTransactionRefund,
            isTransactionVoid,
            taxInfo,
          });
          if (
            item?.moneyOrderFeeOverride !== 'Y' &&
            item?.isMoneyOrder === true &&
            item?.MoneyOrderFlag !== MO_FLG_INVALID
          ) {
            lineItemAmount += Number(item?.moneyOrderFee / 100);
          }
          if (item?.lineItemTotalFinal === 0) {
            return parseFloat(parseFloat(sum + lineItemAmount).toFixed(2));
            // eslint-disable-next-line no-else-return
          } else {
            // eslint-disable-next-line no-lonely-if
            if (
              !item?.lineItemTotalFinal ||
              item?.lineItemTotalFinal === lineItemAmount
            )
              lineItemAmount = 0;
            else if (
              item?.lineItemTotalFinal !== 0 &&
              item?.lineItemTotalFinal !== lineItemAmount
            )
              lineItemAmount -= item?.lineItemTotalFinal;
          }
          return parseFloat(parseFloat(sum + lineItemAmount).toFixed(2));
        }, 0);
      // #7485 updating MO amount paidItemsAmount in case of only cash tendered
      if (paidItemsAmount === 0) {
        const isMoneyItem = items.filter(
          item =>
            item.isMoneyOrder === true && item.MoneyOrderFlag !== MO_FLG_INVALID
        );
        let iMoneyOrderPrice = 0;
        if (isMoneyItem[0]) {
          iMoneyOrderPrice = isMoneyItem?.reduce((sum, item) => {
            let price = 0;
            if (item.moneyOrderFeeOverride !== 'Y')
              price = parseFloat(
                Number(item?.retailPrice) + Number(item.moneyOrderFee)
              ).toFixed(2);
            else price = parseFloat(Number(item?.retailPrice)).toFixed(2);
            return sum + price * item.quantity;
          }, 0);
          iMoneyOrderPrice = parseFloat(
            parseFloat(iMoneyOrderPrice).toFixed(2) / 100
          );
        }
        paidItemsAmount = iMoneyOrderPrice;
      }

      const restirictedItemsAmount = items
        ?.filter(
          item =>
            item?.restrictedMediaTypes &&
            item.restrictedMediaTypes.includes('LC') &&
            (!item?.lineItemTotalFinal ||
              Math.abs(item?.lineItemTotalFinal) > 0)
        )
        .reduce((sum, item) => {
          const lineItemAmount = getLineItemTotalTax({
            items,
            item,
            basketPromo,
            isTransactionRefund,
            isTransactionVoid,
            taxInfo,
          });
          return parseFloat(parseFloat(sum + lineItemAmount).toFixed(2));
        }, 0);

      let remainingCashAmount = parseFloat(
        parseFloat(tenderedAmount - paidItemsAmount).toFixed(2)
      );
      let leftRestirctedItemAmount = parseFloat(
        parseFloat(
          Math.abs(remainingCashAmount) - Math.abs(restirictedItemsAmount)
        ).toFixed(2)
      );
      Logger.info(
        `7POS - Local Charge Details tenderedAmount:${tenderedAmount},
        remainingCashAmount:${remainingCashAmount}, paidItemsAmount:${paidItemsAmount},
        restirictedItemsAmount:${restirictedItemsAmount},leftRestirctedItemAmount:${leftRestirctedItemAmount}`
      );
      if (leftRestirctedItemAmount < 0) isRestirctionItemPresent = true;
    }
    return isRestirctionItemPresent;
  };

  const validateTranAmount = (MediaType, isFuelPPCancel = false) => {
    // Added this for Skipping validation for fuel Prepay Cancel
    if (isFuelPPCancel) return true;
    let iMediaHalo = 9999.99;
    let iMediaLalo = 0;
    const alreadyPaidAmount = allPayments?.reduce(
      (sum, ap) => sum + parseFloat(ap?.payment?.amount) || 0,
      0
    );

    if (Math.abs(alreadyPaidAmount) > 0) {
      // #5968/5969 checking balance due before tender
      const { balanceDue } = getBalanceDue({
        allPayments,
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
      });
      if (!balanceDue || Number(balanceDue) === 0) {
        DisplayToastMsg('INVALID TENDER PLEASE REVIEW TRANSACTION');
        Logger.info(
          `INVALID TENDER PLEASE REVIEW TRANSACTION MediaType:${MediaType} and Total Transaction Amount:${finalTotalPrice}`
        );
        return false;
      }
    }
    // Consider already paid amount as well for media validation
    const iMediaAmount = Math.abs(
      Math.abs(finalTotalPrice) - Math.abs(alreadyPaidAmount)
    );
    config?.storeMediaconfig?.map(media => {
      if (
        media?.type === MediaType &&
        media?.haloAmount &&
        media?.haloAmount > 0
      ) {
        iMediaHalo = media?.haloAmount || 9999.99;
      }
      if (
        media?.type === MediaType &&
        media?.laloAmount &&
        media?.laloAmount >= 0
      ) {
        iMediaLalo = media?.laloAmount || 0;
      }
      return media;
    });
    // Added Media halo check for manual cash enter as well.
    if (
      Number(iMediaAmount) > iMediaHalo ||
      (MediaType !== 'EB' &&
        MediaType !== 'CR' &&
        Number(keypad.value) / 100 > 0 &&
        Number(keypad.value) / 100 > iMediaHalo)
    ) {
      setMediaHALOError(true);
      setiMediaErrorMsg('Amount Tendered is too Big for Media');
      Logger.info(
        `Amount Tendered is too Big for Media MediaType:${MediaType} MediaHALO:${iMediaHalo} Entered Amount:${Number(
          keypad.value
        ) / 100} and Total Transaction Amount:${finalTotalPrice}`
      );
      return false;
    }
    if (
      !isFuelPPCancel &&
      (Number(iMediaAmount) < iMediaLalo ||
        (MediaType !== 'EB' &&
          MediaType !== 'CR' &&
          Number(keypad.value) / 100 > 0 &&
          Number(keypad.value) / 100 < iMediaLalo))
    ) {
      setMediaHALOError(true);
      setiMediaErrorMsg('Amount Tendered is too small for Media');
      Logger.info(
        `Amount Tendered is too small for Media MediaType:${MediaType} MediaLALO:${iMediaLalo} Entered Amount:${Number(
          keypad.value
        ) / 100} and Total Transaction Amount:${finalTotalPrice} `
      );
      return false;
    }
    // validating final total price
    if (MediaType !== 'CS') {
      if (isTransactionVoid || isTransactionRefund) {
        if (finalTotalPrice > 0) {
          setMediaHALOError(true);
          setiMediaErrorMsg('Amount Tendered is too small for Media');
          Logger.info(
            `Amount Tendered is too small for Media MediaType:${MediaType} and Total Transaction Amount:${finalTotalPrice}`
          );
          return false;
        }
      } else if (
        !isTransactionVoid &&
        !isTransactionRefund &&
        !isFuelPPCancel
      ) {
        if (finalTotalPrice < 0) {
          setMediaHALOError(true);
          setiMediaErrorMsg('Amount Tendered is too small for Media');
          Logger.info(
            `Amount Tendered is too small for Media MediaType:${MediaType} and Total Transaction Amount:${finalTotalPrice}`
          );
          return false;
        }
      }
    }
    if (MediaType === 'CS') {
      const isValidAmount = tranFinalAmountValidation({
        isReturnOrVoid: isTransactionRefund || isTransactionVoid,
        finalTotalPrice,
        items,
        taxData: taxInfo,
      });
      if (!isValidAmount) {
        DisplayToastMsg('INVALID TENDER PLEASE REVIEW TRANSACTION');
        Logger.info(
          `INVALID TENDER PLEASE REVIEW TRANSACTION MediaType:${MediaType} and Total Transaction Amount:${finalTotalPrice}`
        );
      }
      return isValidAmount;
    }
    return true;
  };

  // TODO: Refactor Handle Pay function
  const handlePay = async (config = {}) => {
    finalizeTransactionTotal();
    const { type, isFuelPPCancel = false, isMCLoyaltyPayment } = config;
    // #8260 payment triggered before final tax response
    const finalTaxCallTriggered =
      localStorage.getItem('finalTaxCallTriggered') || false;
    if (
      (isPaymentTriggered || finalTaxCallTriggered) &&
      type !== 'digitalWallet' &&
      type !== 'cancel'
    ) {
      DisplayToastMsg(
        !finalTaxCallTriggered
          ? 'Please wait. Waiting for payment response'
          : 'Please wait. Waiting for tax response'
      );
      global?.logger?.info(
        !finalTaxCallTriggered
          ? `7POS - handlePay payment(${isPaymentTriggered}) already intiated please wait.`
          : `7POS - handlePay payment waiting for tax respone(${finalTaxCallTriggered}).`
      );
      return;
    }

    if (pinpadPayStartTime === '') {
      const pPayStartTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}`;
      dispatch(cartActions.setPinpadPayStartTime(pPayStartTime));
    }
    const MediaType = type === 'manualEbt' ? 'EB' : 'CR';

    if (!validateTranAmount(MediaType, isFuelPPCancel)) return;
    if (pipoTransaction) {
      displayErrorToast('Invalid media selection');
      dispatch(cashFunctionActions.setMediaError());
      return;
    }

    if (
      !isTransactionVoid &&
      !isTransactionRefund &&
      !isFuelPPCancel &&
      items.length > 0
    ) {
      const isCardNotAllowed = verifyMoneyOrderItemStatus({
        items,
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
        enteredCash,
      });
      if (isCardNotAllowed) {
        DisplayToastMsg('Money Order can only be paid for in cash');
        return;
      }
    }

    if (
      type !== 'manualEbt' &&
      !isRoundUpTriggered &&
      approvedTenderedCount === 0
    ) {
      const {
        isRoundUpRequired,
        iRoundOffCharityAmt,
      } = isRoundOffCharityApplicable({
        paymentMedia: 'CARD',
        finalTotalPrice: Number(finalTotalPrice),
      });
      if (isRoundUpRequired) {
        setRoundUpTriggered(true);
        setRoundUpProgress(ROUNDOFF_CHARITY_INTIATED); // 1 means Round up intitated
        setisRoundUpAmount(iRoundOffCharityAmt);
        return;
      }
    }
    if (!isRoundUpTriggered) {
      const iTransactionMessage = {
        CMD: 'PinpadMessage',
        Status: 'DisplayCFDMessage',
      };
      SendMessageToCFD(iTransactionMessage);
    } else {
      setTimeout(() => {
        const iTransactionMessage = {
          CMD: 'PinpadMessage',
          Status: 'DisplayCFDMessage',
        };
        SendMessageToCFD(iTransactionMessage);
      }, 1000);
    }

    if (type === 'manualEbt') history.push('payment/manualEBT');
    paymentTransId = paymentTransactionId;
    dispatch(cartActions.setPaymentTransactionId(paymentTransId));
    const { balanceDue } = getBalanceDue({
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
      enteredCash,
      allPayments,
    });
    let lottoItemAmount = 0;
    lottoItemAmount = items
      ?.filter(
        item =>
          (Number(item.departmentId) === 61 ||
            Number(item.departmentId) === 63) &&
          !item.negativeSalesFlag
      )
      .reduce(
        (sum, item) =>
          sum +
          Math.abs(parseFloat(item?.overridedPrice || item?.retailPrice)) *
            item.quantity,
        0
      );
    lottoItemAmount /= 100;
    let creditItemAmount = items
      ?.filter(item => item.negativeSalesFlag)
      .reduce(
        (sum, item) =>
          sum +
          Math.abs(parseFloat(item?.overridedPrice || item?.retailPrice)) *
            item.quantity,
        0
      );
    creditItemAmount /= 100;
    let amt =
      isTransactionVoid || isTransactionRefund ? finalTotalPrice : balanceDue;
    const balanceDueAmount = amt;
    // #3438 - 3464 In void/refund we should not lotto win amount because there is no split tender.
    if (!isTransactionVoid && !isTransactionRefund) {
      amt = creditItemAmount > 0 ? amt + creditItemAmount : amt;
      amt = lottoItemAmount > 0 ? amt + lottoItemAmount : amt;
    }
    dispatch(cartActions.setBalanceDue(balanceDue));
    const alreadyPaidAmount = allPayments?.reduce(
      (sum, ap) => sum + parseFloat(ap?.payment?.amount) || 0,
      0
    );
    const paymentInformation = {
      tenderSequenceNumber,
      amount: parseFloat(parseFloat(amt + CashAmountToBeApplied).toFixed(2)),
      balanceDue: balanceDueAmount, // TODO: BD changes
      approvedTenderedCount,
      tenderedAmount: parseFloat(parseFloat(alreadyPaidAmount).toFixed(2)),
      lastCashMediaAmount: parseFloat(
        parseFloat(CashAmountToBeApplied).toFixed(2)
      ),
    };
    if (type === 'digitalWallet') {
      paymentInformation.paymentEntryType = 'SCANNED';
      let dwTok = `${digitalWalletToken}?`;
      // eslint-disable-next-line
      paymentInformation.digitalWalletToken = dwTok;
      paymentInformation.paymentData = JSON.stringify({
        digitalWalletToken: dwTok,
      });
      //   paymentInformation.paymentData = `{
      //     "digitalWalletToken": `${digitalWalletToken}?`}`;
    }
    // TODO: Need to handle part of 5th Media
    if (approvedTenderedCount > 5) {
      // Show toaster once PAPI changes done
    }
    let payRequest = handlePayRequest({
      items,
      storeDetails,
      user,
      taxInfo,
      deviceInfo,
      member,
      transactionId,
      finalsubTotalPrice,
      finalTotalPrice,
      transactionStartTime,
      pumpNumber,
      amount,
      pumpType,
      paymentDetails,
      paymentInformation,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId: paymentTransId,
      tranAgeVerifyInfo,
      basketPromo,
      cartChangeTrial,
      runningTotal,
      loadCardMediaList,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      paymentHistory,
      mediaNumber: 0, // For Non Cash Transaction we will not know the media number until user swipes the card.
      fuelPrices, // For non-cash fuel transactions, we need to send fuel prices as part of the transaction
      isFuelPPCancel,
      allPayments,
      transactionComments,
      fuelLoyaltyDiscounts,
    });
    dispatch(
      cartActions.setrunningTotalTax(payRequest.transactionDetails.runningTotal)
    );
    if (type === 'cancel') {
      dispatch(
        cartActions.setRealTimePaymentVoidSeq(
          paymentDetails?.paymentMedia?.tenderSequenceNumber || 0
        )
      );
      payRequest = processHandleCancel(payRequest, paymentDetails);
      // TODO: review and remove next line, this is breaking Partila Approval flow
      // payRequest.transactionHeaderInfo.transactionStatus = 'ABORT';
      // For abort transaction no need add tax to running total
      payRequest.transactionDetails.runningTotal = Number(runningTotal) / 100;
    }
    // adjust credit item amount applicable only for sale
    let TotalrunningTotal = payRequest.transactionDetails.runningTotal;
    if (
      Math.abs(totalCreditAmount) > 0 &&
      !isTransactionRefund &&
      !isTransactionVoid
    ) {
      TotalrunningTotal += totalCreditAmount + totalCreditTax;
    } else if (!isTransactionRefund && !isTransactionVoid) {
      // #6969 recalculate Credit Item Amount if any case Credit item present and amount reported as zero
      const { creditAmount, creditTax, creditCount } = CreditItemRunningTotal(
        items,
        taxInfo,
        basketPromo
      );
      dispatch(cartActions.setCreditItemCount(creditCount));
      dispatch(cartActions.setCreditItemAmount(creditAmount));
      dispatch(cartActions.setCreditItemTaxAmount(creditTax));
      TotalrunningTotal += creditAmount + creditTax;
    }
    const hardTotalSummary = [];
    hardTotalSummary.push(hardTotalRef.current);
    hardTotalSummary.push({
      name: 'runningTotal',
      count: 0,
      amount: parseFloat(TotalrunningTotal.toFixed(2)),
    });
    payRequest.transactionDetails.hardTotalSummary = hardTotalSummary;

    let destType = 'PINPAD';
    let messageType = isTransactionVoid
      ? 'VOID'
      : isTransactionRefund
      ? 'REFUND'
      : 'PAYMENT';
    if (type === 'manualEbt') {
      messageType = isTransactionVoid
        ? 'MANUAL_EBT_VOID'
        : isTransactionRefund
        ? 'MANUAL_EBT_REFUND'
        : 'MANUAL_EBT';
    }
    if (type === 'digitalWallet') {
      messageType = 'DIGITAL_WALLET';
      destType = 'PAYMENT';
    }

    const req = JSON.stringify(payRequest);
    /* if (
      payRequest.transactionHeaderInfo.transactionType ===
      TransactionTypes.preAuthCancel
    ) {
      await updateCacheHardTotals(req, cartChangeTrial);
    } */
    const paymentRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType,
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: destType,
          destinationIdentifier: '1',
        },
        ...(isMCLoyaltyPayment && {
          messageType: isTransactionRefund ? 'REFUND' : 'LOYALTY_PAYMENT',
        }),
      },
      messageBody: {
        message: `${req}`,
      },
    };
    dispatch(cartActions.setStatusCode(null));
    setShowPartialApproval(false);
    dispatch(cartActions.setTransactionStartTime(transactionStartTime));
    if (type === 'manualEbt') {
      dispatch(cartActions.setPaymentMethod('MANUAL_EBT'));
    } else if (type === 'digitalWallet') {
      dispatch(cartActions.setPaymentMethod('DIGITAL_WALLET'));
    } else {
      dispatch(cartActions.setPaymentMethod('PINPAD'));
    }
    global?.logger?.info(
      `[7POS UI] - pay request(Card Payment)  ${JSON.stringify(paymentRequest)}`
    );

    const cPayrequest = JSON.stringify(paymentRequest);
    localStorage.setItem('finalPaymentRequest', cPayrequest);
    dispatch(cartActions.setPaymentTriggerStatus(true));
    if (type === 'digitalWallet') {
      ws.socket?.send('/app/payment', {}, cPayrequest);
    } else {
      ws.socket?.send('/app/pinpad/payment', {}, cPayrequest);
    }
    showLoader(true);
  };

  const handleCardPreauthCancel = () => {
    // Starting the Spinner, Will be stopped in APP.JS once gets response from MW
    startLoading();
    // dispatch(cartActions.setFuelPPCancel(true));
    handlePay({ isFuelPPCancel: true });
  };

  const onManualEbt = () => {
    // https://digital-711.atlassian.net/browse/RISPIN-3455
    if (isFuelTransactionInProgress || isCarwashInProgress) {
      return showToast({
        description: Messages.invalid_ebt_media_for_fuel,
        status: 'error',
        position: 'top-left',
      });
    }
    handlePay({ type: 'manualEbt' });
  };

  const handlePIPOCashPayment = async (
    transactionAmount,
    targetTransactionState
  ) => {
    try {
      // operation is APPROVED or ABORTED
      if (!ws.socket || socketStatus !== 'CONNECTED') {
        return;
      }
      showLoader(true);

      const dvr = getDVR();
      dvr.startTransaction(
        config,
        transactionId,
        storeDetails,
        deviceInfo?.id,
        pipoTransaction.transactionTime,
        pipoTransaction.transactionType,
        user?.userId?.toString() || ''
      );
      (cartChangeTrial || []).forEach(cartChangePayload =>
        dvr.handleCartChange(cartChangePayload)
      );

      const cashRequest = CashUtil.getCashRequest({
        storeDetails,
        user,
        deviceInfo,
        transactionId,
        paymentTransactionId,
        amount: transactionAmount,
        cashTransaction: pipoTransaction,
        targetTransactionState,
      });
      global?.logger?.info('PIPORequest', JSON.stringify(cashRequest));
      const correlationId = paymentTransactionId;
      const cashRequestPayload = CashUtil.cashTransactionPayload(
        'PAYMENT',
        cashRequest,
        correlationId
      );
      // Added cache call to intiate/increment transaction seq in hardtotals(#RISPIN2755)
      // await updateCacheHardTotals(JSON.stringify(cashRequest));

      dvr.endPIPOTransaction(
        allPayments,
        transactionAmount,
        cashBack,
        config,
        deviceInfo,
        items,
        member,
        paymentDetails,
        targetTransactionState,
        transactionId,
        user
      );
      const cRequest = JSON.stringify(cashRequestPayload);
      localStorage.setItem('finalPaymentRequest', cRequest);
      if (targetTransactionState === 'APPROVED') {
        // eslint-disable-next-line no-use-before-define
        openCashDrawer();
      }
      ws.socket?.send(
        WSTopics.cashPayment,
        {},
        JSON.stringify(cashRequestPayload)
      );
    } catch (error) {
      global.logger.error(
        `[7POS UI] - handlePIPOCashPayment ${JSON.stringify(error)}`
      );
    }
  };

  const currentAmount = () =>
    parseFloat((Number(keypad?.value || 0) / 100).toString()).toFixed(2);

  const goBack = () => {
    if (isOtherMediaScreenActive) {
      Logger.info(`7POS - Exit from Other media payment screen.`);
      dispatch(cartActions.setOtherMediaScreenStatus(false));
      return;
    }
    // #7362 POS should not allow to exit from Payment screen when MO sale tendered
    const isMoneyPrintedItem = items.filter(
      item =>
        item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_PRINTED
    );
    if (
      isMoneyPrintedItem &&
      isMoneyPrintedItem[0] &&
      allPayments?.length > 0
    ) {
      DisplayToastMsg('MO printed - Media abort not allowed');
      Logger.info(`7POS - MO Sale already tendered media abort not allowed.`);
      return;
    }

    // #5311 SA should not allowed to exit from payment screen
    if (isPaymentTriggered) {
      DisplayToastMsg('Please wait. Waiting for payment response');
      Logger.info(
        `7POS - Waiting for payment response can't exit from payment screen.`
      );
      return;
    }
    global?.logger?.info(`7POS - Exit from payment screen`);

    creditTaxOverrideCleanup();
    dispatch(cartActions.setrunningTotalTax(0));
    dispatch(cartActions.setLoadConfirm(false));
    dispatch(cartActions.setPaymentTriggerStatus(false));

    if (paymentMethod === 'PARTIAL_PAYMENT' || paymentHistory.length) {
      const { balanceDue } = getBalanceDue({
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
        allPayments,
      });
      if (balanceDue === finalTotalPrice) {
        global?.logger?.info(
          `7POS - Redirect to home screen from payment screen`
        );
        history.push('/home');
        return;
      }
      global?.logger?.info(
        `7POS - Media abort Intiated due to exit from payment screen`
      );
      dispatch(dailpadActions.setKeypadValue({ value: '' }));
      history.push({
        pathname: '/payment/mediaAbort',
        state: {
          storeDetails,
          user,
          taxInfo,
          deviceInfo,
          member,
          transactionId,
          finalsubTotalPrice,
          finalTotalPrice,
          transactionStartTime,
        },
      });
    } else if (pipoTransaction) {
      global?.logger?.info(`7POS - handling PI/PO exit from payment screen`);
      dispatch(dailpadActions.setKeypadValue({ value: '' }));
      dispatch(
        cashFunctionActions.registerTargetPIPOTransaction({
          status: TransactionStates.aborted,
          transactionId,
        })
      );
      handlePIPOCashPayment(currentAmount(), TransactionStates.aborted);
      // dispatch(cashFunctionActions.cancelPIPOTransaction());
    } else {
      global?.logger?.info(
        `7POS - Redirect to home screen from payment screen`
      );
      if (fuelLoyalty) {
        dispatch(cartActions.setFuelLoyalty({}));
        SendMessageToCFD({ CMD: 'fuelLoyalty', data: {} });
      }
      dispatch(dailpadActions.setKeypadValue({ value: '' }));
      // ADDED TO DISPLAY EOD INTIATED TOAST
      dispatch(cartActions.setPaymentMethod(null));
      history.push('/home');
    }
  };

  const openCashDrawer = () => {
    const isBlockCashDrawerToOpen =
      blockCashDrawerToOpen(finalTotalPrice) || false;
    // 6788 and 6793 defect fixes
    if (isBlockCashDrawerToOpen && !pipoTransaction) {
      dispatch(socketActions.setCashDrawerStatus(null));
      return;
    }
    ws.socket?.send(WSTopics.cashdrawer.open);
    global?.logger?.info(`[7POS UI] -  Sent cash drawer open event(payment)`);
  };

  const { balanceDue: balanceDueAmount } = getBalanceDue({
    paymentHistory,
    paymentMediaList,
    finalTotalPrice,
    enteredCash,
    allPayments,
  });

  const getCashLabel = cashType => {
    if (!cashType) return 'Cash';
    const { otherMediaInfo = [] } = store.getState().cart;
    return cashType === 'otMedia' && otherMediaInfo !== null
      ? `${otherMediaInfo?.label}`
      : cashType === 'usd'
      ? `US Cash ${Number(currentAmount()).toFixed(2)} @ ${Number(
          currencyConversion
        ).toFixed(2)}:1 =`
      : 'Big Bucks';
  };

  const getMediaNumber = ({
    isBBucks,
    isUsCash,
    isDriveOffMedia,
    isLocalChargeMedia,
  } = {}) => {
    const { otherMediaInfo = [] } = store.getState().cart;
    if (isBBucks) return 8;
    if (isUsCash) return 15;
    if (isDriveOffMedia) {
      if (
        otherMediaInfo !== null &&
        otherMediaInfo?.storeMediaId &&
        (otherMediaInfo?.storeMediaTypeCode === 'DO' ||
          otherMediaInfo?.name?.toLowerCase() === 'driveoff')
      )
        return otherMediaInfo?.storeMediaId;
      return 5;
    }
    if (isLocalChargeMedia) {
      if (
        otherMediaInfo !== null &&
        otherMediaInfo?.storeMediaId &&
        (otherMediaInfo?.storeMediaTypeCode === 'LC' ||
          otherMediaInfo?.name?.toLowerCase() === 'localcharge')
      )
        return otherMediaInfo?.storeMediaId;
      return 6;
    }
    return 1;
  };

  const cashTransaction = async ({
    isUsCash,
    label,
    isBBucks,
    isDriveOffMedia,
    isLocalChargeMedia,
    prevAllPayments,
  }) => {
    const { allPayments = [] } = store.getState().cart;
    paymentTransId = paymentTransactionId;
    dispatch(cartActions.setPaymentTransactionId(paymentTransId));
    let cashAmount = enteredCash || 0;
    // #9148 Corrected the cash amount for negative Sale
    if (keypad?.value)
      cashAmount =
        Number(finalTotalPrice) < 0
          ? -Number(keypad.value) / 100
          : Number(keypad.value) / 100;
    const { balanceDue } = getBalanceDue({
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
      enteredCash: currencyRoundoff(
        cashAmount,
        isUsCash ? currencyConversion : 1
      ),
      allPayments,
    });

    const { balanceDue: prevBalanceDue } = getBalanceDue({
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
      enteredCash: currencyRoundoff(
        cashAmount,
        isUsCash ? currencyConversion : 1
      ),
      allPayments: prevAllPayments,
    });

    cashAmount = processCashAmount(
      paymentHistory,
      enteredCash,
      cashAmount,
      prevBalanceDue,
      finalTotalPrice,
      isTransactionRefund || isTransactionVoid
    );

    const CardLoadItem = items.filter(
      i =>
        i.itemTypeID === ITEM_TYPE.CARD_LOAD &&
        i?.CardLoadFlag !== LOAD_FLG_INVALID
    );
    const cashVal =
      isUsCash && isCanada
        ? cashAmount <
          Number(
            (
              Number(finalTotalPrice) / (isUsCash ? currencyConversion : 1)
            ).toFixed(2)
          )
        : cashAmount < Number(finalTotalPrice);
    if (
      CardLoadItem?.length > 0 &&
      cashVal &&
      !isTransactionRefund &&
      !isTransactionVoid
    ) {
      DisplayToastMsg('Cash must be equal or greater than transaction amount');
      return false;
    }
    const cashPaymentRequest = handlePayRequest({
      items,
      storeDetails,
      user,
      taxInfo,
      deviceInfo,
      member,
      transactionId,
      finalsubTotalPrice,
      finalTotalPrice,
      transactionStartTime,
      pumpNumber,
      amount,
      pumpType,
      paymentDetails,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId: paymentTransId,
      tranAgeVerifyInfo,
      basketPromo,
      cartChangeTrial,
      runningTotal,
      loadCardMediaList,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      paymentHistory,
      currencyConversion,
      mediaNumber: 1,
      allPayments,
      transactionComments,
      fuelLoyaltyDiscounts,
    });
    dispatch(cartActions.setTransactionStartTime(transactionStartTime));
    dispatch(
      cartActions.setrunningTotalTax(
        cashPaymentRequest.transactionDetails.runningTotal
      )
    );
    const tenderType = isTransactionVoid
      ? 'VOID'
      : isTransactionRefund
      ? 'REFUND'
      : 'SALE';
    cashPaymentRequest.transactionHeaderInfo.transactionStatus = null;
    cashPaymentRequest.transactionDetails.paymentInformation.mediaStatus =
      'APPROVED';
    cashPaymentRequest.transactionDetails.paymentInformation.tenderType = tenderType;
    cashPaymentRequest.transactionDetails.paymentInformation.paymentMediaNumber = getMediaNumber(
      { isBBucks, isUsCash, isDriveOffMedia, isLocalChargeMedia }
    );
    if (isBBucks || isUsCash || isDriveOffMedia || isLocalChargeMedia) {
      if (isUsCash) {
        cashPaymentRequest.transactionDetails.paymentInformation.exchangeRate = currencyConversion;
        cashPaymentRequest.transactionDetails.paymentInformation.description =
          'US CASH';
      } else if (isBBucks) {
        cashPaymentRequest.transactionDetails.paymentInformation.description =
          'BIG BUCK';
      } else if (isDriveOffMedia || isLocalChargeMedia) {
        const { otherMediaInfo = [] } = store.getState().cart;
        cashPaymentRequest.transactionDetails.paymentInformation.description =
          otherMediaInfo?.label;
      }
      cashPaymentRequest.transactionDetails.paymentInformation.foreignAmount = +Number(
        cashAmount
      ).toFixed(2);
    }
    cashPaymentRequest.transactionDetails.paymentInformation.tenderSequenceNumber = tenderSequenceNumber;

    // TODO:Still  Need to be revisited
    let paymentAmount = cashAmount;
    let bDue = balanceDue;
    if (isUsCash) {
      paymentAmount = currencyRoundoff(
        cashAmount,
        isUsCash ? currencyConversion : 1
      );
      bDue = currencyRoundoff(balanceDue, isUsCash ? currencyConversion : 1);
    }
    cashPaymentRequest.transactionDetails.paymentInformation.amount = paymentAmount;
    cashPaymentRequest.transactionDetails.paymentInformation.balanceDue = bDue;
    cashPaymentRequest.transactionDetails.paymentInformation.paidAmount = +Number(
      cashAmount
    ).toFixed(2);
    cashPaymentRequest.transactionDetails.paymentInformation.approvedTenderedCount =
      Number(approvedTenderedCount) + 1;

    if (
      (!isTransactionRefund && !isTransactionVoid) ||
      ((isTransactionRefund || isTransactionVoid) &&
        Number(finalTotalPrice) > 0)
    ) {
      let { changeAmount: change } = getBalanceDue({
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
        allPayments,
        enteredCash: currencyRoundoff(
          cashAmount,
          isUsCash ? currencyConversion : 1
        ),
      });
      change = Number(change || 0);
      // #3195 adjust amount field depending on change amount.
      if (Number(change) < 0) {
        dispatch(cartActions.setBalanceDue('0.00'));
        if (
          Number(finalTotalPrice) < 0 &&
          Number(finalTotalPrice) === Number(cashAmount)
        ) {
          cashPaymentRequest.transactionDetails.paymentInformation.amount = paymentAmount;
          cashPaymentRequest.transactionDetails.paymentInformation.changeAmount = 0;
        } else {
          const currentAmount =
            prevBalanceDue > 0 ? Math.abs(prevBalanceDue) : finalTotalPrice;
          cashPaymentRequest.transactionDetails.paymentInformation.amount = Number(
            currentAmount // RISPIN 4054 amount adjusted as per the requirement
          ).toFixed(2);
          // TODO NEED TO VERIFY THE MIXED SCENARIO
          cashPaymentRequest.transactionDetails.paymentInformation.changeAmount = Math.abs(
            Number(change)
          ).toFixed(2);
        }
      } else dispatch(cartActions.setBalanceDue(change || '0.00'));
    }
    dispatch(
      cartActions.setCashPaymentInfo({
        ...cashPaymentRequest.transactionDetails.paymentInformation,
        isUsCash,
        enteredCashAmount: enteredCash,
        label,
        isBBucks,
      })
    );
    // adjust credit item amount applicable only for sale
    let TotalrunningTotal =
      cashPaymentRequest?.transactionDetails?.runningTotal;
    if (
      Math.abs(totalCreditAmount) > 0 &&
      !isTransactionRefund &&
      !isTransactionVoid
    ) {
      TotalrunningTotal += totalCreditAmount + totalCreditTax;
    } else if (!isTransactionRefund && !isTransactionVoid) {
      // #6969 recalculate Credit Item Amount if any case Credit item present and amount reported as zero
      const { creditAmount, creditTax, creditCount } = CreditItemRunningTotal(
        items,
        taxInfo,
        basketPromo
      );
      dispatch(cartActions.setCreditItemCount(creditCount));
      dispatch(cartActions.setCreditItemAmount(creditAmount));
      dispatch(cartActions.setCreditItemTaxAmount(creditTax));
      TotalrunningTotal += creditAmount + creditTax;
    }
    const hardTotalSummary = [];
    hardTotalSummary.push(hardTotalRef.current);
    hardTotalSummary.push({
      name: 'runningTotal',
      count: 0,
      amount: parseFloat(TotalrunningTotal.toFixed(2)),
    });
    cashPaymentRequest.transactionDetails.hardTotalSummary = hardTotalSummary;

    const request = JSON.stringify(cashPaymentRequest);
    // global?.logger?.info(`Cash Payment request: ${request}`);
    /*  if (
      cashPaymentRequest?.transactionHeaderInfo?.transactionType ===
        TransactionTypes?.preAuthCancel ||
      location.state?.isPromoCarwash // #6874 added cache call for promo car wash as well.
    ) {
      await updateCacheHardTotals(request, cartChangeTrial);
    } */

    const cashRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: isTransactionVoid
          ? 'VOID'
          : isTransactionRefund
          ? 'REFUND'
          : 'PAYMENT',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PAYMENT',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${request}`,
      },
    };
    // #8708 updating tender sequence after cash post to MW
    dispatch(cartActions.setTenderSequenceNumber(tenderSequenceNumber + 1));
    dispatch(cartActions.setapprovedTenderedCount(approvedTenderedCount + 1));
    global?.logger?.info(
      `[7POS UI] - pay request(Cash payment)  ${JSON.stringify(cashRequest)}`
    );
    dispatch(dailpadActions.resetDailpadState());
    const cRequest = JSON.stringify(cashRequest);
    localStorage.setItem('finalPaymentRequest', cRequest);
    dispatch(cartActions.setPaymentTriggerStatus(true));
    ws.socket?.send('/app/payment', {}, cRequest);
    showLoader(true);
    getDVR().setDrawerStatus('CD_OPEN_OK', user);
    // reset
    dispatch(cartActions.setEnteredCash(null));
    dispatch(cartActions.setLastTenderInfo('CASHTENDER'));
  };

  // #8167 prepay auth failed secanrio handling
  const [isPrepayCashTendered, setPrepayCashTendered] = useState(null);
  useEffect(() => {
    if (isPrepayCashTendered) {
      setPrepayCashTendered(false);
      cashTransaction(
        isPrepayCashTendered
          ? { ...isPrepayCashTendered, prevAllPayments: allPayments }
          : {}
      );
      setShowPartialApproval(null);
    }
  }, [isPrepayCashTendered]);

  const TriggerCashPayment = async (data = {}) => {
    // Send PreAuth Approval to DEX
    // Success -> Proceed
    // Failure ->
    //                  Add void prepay item to cart
    //                  Remove prepay cache
    //                  On Tapping the cash again, Process the transaction as regular sale and pay back the user in cash.
    try {
      // Default mediaNumber will be 1.
      const prepayRequestPromise = processPrepayApprovalIfNeeded();
      if (prepayRequestPromise) {
        await prepayRequestPromise.catch(async e => {
          setPrepayCashTendered(data);
          DisplayToastMsg(Messages.prepay_not_accepted);

          // SCALE-1567 - PREAUTH_CANCEL scenario - timeout - error
          let errorType = 'error';
          if (e.message === Messages.request_failed) errorType = 'error';
          if (e.message === Messages.request_timeout) errorType = 'timeout';

          await cancelFuelRewardInTransaction(errorType);

          throw e;
        });
        showToast({
          description: Messages.prepay_accepted,
          status: 'success',
          position: 'top-left',
        });
        setPrepayCashTendered(data);
      } else {
        cashTransaction(data ? { ...data, prevAllPayments: allPayments } : {});
      }
    } catch (error) {
      global.logger.error(
        `[7POS UI] - TriggerCashPayment prepayRequestPromise ${JSON.stringify(
          error
        )}`
      );
    }
  };

  // # make finalPaymentRequest dependncy for prepay transaction
  let finalPaymentRequest = localStorage.getItem('finalPaymentRequest');
  useEffect(() => {
    finalPaymentRequest = localStorage.getItem('finalPaymentRequest');
    if (
      finalPaymentRequest &&
      Number(balanceDueAmount) === 0 &&
      paymentHistory?.length > 0
    ) {
      let finalPaidCashPaymentsList = []; // Cash with Split and Media abort should open Cash Drawer
      const isCashPay = paymentHistory.some(
        ph =>
          ph.paymentMedia.paymentMediaType === 'CASH' &&
          ph.paymentMedia.paymentMediaNumber !== LOCAL_CHARGE &&
          ph.paymentMedia.paymentMediaNumber !== DRIVE_OFF
      ); // #6223 added exception list for LC and DO
      // if non cash payment tendered return from here
      if (!isCashPay) return;
      const CardLoadItem = items.filter(
        i => i.itemTypeID === ITEM_TYPE.CARD_LOAD
      );
      // #4593 cash drawer should open after card load status received from PAPI
      if (!CardLoadItem[0]) {
        const isCashPayWithMediaAbort = paymentHistory.some(
          ph => ph.paymentMedia.transactionStatus === 'CASH_ABORTED'
        );
        const cashList = paymentHistory.filter(
          ph =>
            ph.paymentMedia.paymentMediaType === 'CASH' &&
            ph.paymentMedia.paymentMediaNumber !== LOCAL_CHARGE &&
            ph.paymentMedia.paymentMediaNumber !== DRIVE_OFF
        );
        const mediaAbortedCashList = paymentHistory.filter(
          ph => ph.paymentMedia.transactionStatus === 'CASH_ABORTED'
        );
        if (mediaAbortedCashList?.length && mediaAbortedCashList?.length > 0) {
          const abortedTenders = mediaAbortedCashList.map(
            macl => macl.paymentMedia.tenderSequenceNumber
          );
          finalPaidCashPaymentsList = cashList.filter(
            p =>
              abortedTenders.indexOf(p.paymentMedia.tenderSequenceNumber) === -1
          );
        }
        if (
          (isCashPay && !isCashPayWithMediaAbort) ||
          (isCashPay &&
            isCashPayWithMediaAbort &&
            finalPaidCashPaymentsList?.length > 0)
        ) {
          openCashDrawer();
        }
      } // card load check
    } // mandatory field check
    return () => {};
  }, [balanceDueAmount, paymentHistory, finalPaymentRequest]);

  const onMedaiHaloExit = () => {
    setMediaHALOError(false);
    setiMediaErrorMsg('');
    dispatch(cartActions.setCancelPaymentForMCLoyalty(true));
    history.replace('/payment');
  };

  const onCashPayment = (cashType = '', skipInputValidation) => {
    finalizeTransactionTotal();
    // #8260 payment triggered before final tax response
    const finalTaxCallTriggered =
      localStorage.getItem('finalTaxCallTriggered') || false;
    if (isPaymentTriggered || finalTaxCallTriggered) {
      DisplayToastMsg(
        !finalTaxCallTriggered
          ? 'Please wait. Waiting for payment response'
          : 'Please wait. Waiting for tax response'
      );
      global?.logger?.info(
        !finalTaxCallTriggered
          ? `7POS - onCashPayment payment(${isPaymentTriggered}) already intiated please wait.`
          : `7POS - onCashPayment payment waiting for tax respone(${finalTaxCallTriggered}).`
      );
      return;
    }
    const { balanceDue } = getBalanceDue({
      allPayments,
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
    });
    // #3213 added toast message when user try input zero dollar amount
    // #8374 For Cash Media amount input is mandatory
    if (keypad?.value) {
      const ienteredCash =
        Number(finalTotalPrice) < 0
          ? -Number(keypad.value) / 100
          : Number(keypad.value) / 100;
      if (ienteredCash === 0) {
        DisplayToastMsg('Problem. Amount is too small');
        return;
      }
    } else {
      // eslint-disable-next-line no-lonely-if
      if (
        !skipInputValidation &&
        Number(finalTotalPrice) !== 0 &&
        Number(finalTotalPrice) > 0
      ) {
        DisplayToastMsg('Cash Amount Expected');
        return;
      }
    }
    const { otherMediaInfo = [] } = store.getState().cart;
    // moving up Media amount validation
    const MediaType =
      cashType === 'otMedia' && otherMediaInfo !== null
        ? otherMediaInfo?.storeMediaTypeCode || 'CS'
        : 'CS';
    if (!validateTranAmount(MediaType)) return;

    const nonFuelItem = items.filter(i => !i.isFuel)?.length;
    const isDriveOffMedia =
      (cashType === 'otMedia' &&
        otherMediaInfo !== null &&
        (otherMediaInfo?.storeMediaTypeCode === 'DO' ||
          otherMediaInfo?.name?.toLowerCase() === 'driveoff')) ||
      false;
    const isLocalChargeMedia =
      (cashType === 'otMedia' &&
        otherMediaInfo !== null &&
        (otherMediaInfo?.storeMediaTypeCode === 'LC' ||
          otherMediaInfo?.name?.toLowerCase() === 'localcharge')) ||
      false;
    if (isDriveOffMedia && nonFuelItem > 0) {
      DisplayToastMsg('INVALID ITEM IN SALE FOR DRIVE OFF MEDIA');
      return;
    }
    if (cashType === 'usd' && currentAmount() <= 0) {
      showPrintFailure('Must enter amount for foreign media', 'top-left');
      return;
    }
    if (cashType === 'bbucks' && currentAmount() > balanceDue) {
      showPrintFailure('CHANGE NOT ALLOWED ON "BIG BUCK" MEDIA', 'top-left');
      return;
    }
    if (pipoTransaction && (isLocalChargeMedia || isDriveOffMedia)) {
      DisplayToastMsg('Selected Media Not Allowed');
      dispatch(cashFunctionActions.setMediaError());
      dispatch(cartActions.setOtherMediaScreenStatus(false));
      return;
    }
    if (pipoTransaction) {
      dispatch(cashFunctionActions.resetMediaError());
      if (!keypad?.value) {
        history.push('payment/pipoAmountError');
        return;
      }
      dispatch(cashFunctionActions.setPIPOAmount(keypad?.value));
      dispatch(
        cashFunctionActions.registerTargetPIPOTransaction({
          status: TransactionStates.approved,
          transactionId,
        })
      );
      handlePIPOCashPayment(currentAmount(), TransactionStates.approved);
      return;
    }

    const mediaAbortedCash =
      paymentHistory
        .filter(ph => ph.paymentMedia.paymentMediaType === 'CASH')
        .map(ph => ph.paymentMedia.transactionStatus !== 'CASH_ABORTED') || [];
    if (mediaAbortedCash?.length > 0) {
      dispatch(cartActions.setEnteredCash(null));
    }
    const ienteredCash =
      (isTransactionRefund || isTransactionVoid) && Number(finalTotalPrice) < 0
        ? -Number(keypad.value) / 100
        : Number(keypad.value) / 100;
    const CardLoadItem = items.filter(
      i =>
        i.itemTypeID === ITEM_TYPE.CARD_LOAD &&
        i?.CardLoadFlag !== LOAD_FLG_INVALID
    );
    const cashVal =
      cashType === 'usd' && isCanada
        ? ienteredCash <
          Number(
            (
              Number(finalTotalPrice) /
              (cashType === 'usd' ? currencyConversion : 1)
            ).toFixed(2)
          )
        : ienteredCash < balanceDue;

    if (currentAmount() > balanceDue && isLocalChargeMedia) {
      DisplayToastMsg(`Change not allowed on ${getCashLabel(cashType)} media`);
      dispatch(cartActions.setEnteredCash(null));
      dispatch(dailpadActions.resetDailpadState());
      return;
    }

    const showToaster = cashVal && !isTransactionRefund && !isTransactionVoid;
    const isReturnTrans =
      (isTransactionRefund || isTransactionVoid) &&
      Number(finalTotalPrice) < 0 &&
      Number(keypad.value) &&
      (Math.abs(ienteredCash) < Math.abs(Number(finalTotalPrice)) ||
        Math.abs(ienteredCash) > Math.abs(Number(finalTotalPrice)));

    // #7672 added MO invalid check for amount validation
    const isMoneyPrintedItem = items.filter(
      item =>
        item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_INVALID
    );

    const isErrorInCash =
      Number(keypad.value) &&
      !isMoneyPrintedItem[0] &&
      !isTransactionRefund &&
      !isTransactionVoid &&
      Number(finalTotalPrice) <= 0 &&
      (Math.abs(ienteredCash) < Math.abs(Number(finalTotalPrice)) ||
        Math.abs(ienteredCash) > Math.abs(Number(finalTotalPrice)));

    if (CardLoadItem?.length > 0 && isLocalChargeMedia) {
      DisplayToastMsg('Declined Invalid tender for this transaction');
      dispatch(cartActions.setEnteredCash(null));
      dispatch(dailpadActions.resetDailpadState());
      return;
    }
    if (
      ((CardLoadItem?.length > 0 || isLocalChargeMedia) &&
        ienteredCash > 0 &&
        showToaster) ||
      isReturnTrans ||
      isErrorInCash
    ) {
      const msg =
        isLocalChargeMedia && currentAmount() !== balanceDue
          ? 'Local charge media must close sale'
          : isReturnTrans || isErrorInCash
          ? 'Cash must be equal to transaction amount'
          : 'Cash must be equal or greater than transaction amount';
      DisplayToastMsg(msg);
      dispatch(cartActions.setEnteredCash(null));
      dispatch(dailpadActions.resetDailpadState());
      return;
    }

    if (isLocalChargeMedia) {
      const isAvailable = isRestirctionItempresent(items);
      if (isAvailable) {
        DisplayToastMsg(
          'INELIGIBLE ITEMS IN SALE MANUAL CREDIT CANNOT COMPLETE THE TRANSACTION'
        );
        dispatch(cartActions.setEnteredCash(null));
        dispatch(dailpadActions.resetDailpadState());
        return;
      }
    }

    dispatch(socketActions.setCardStatus(null));
    if (isTransactionRefund || isTransactionVoid) {
      const cashAmount = ienteredCash || balanceDue || finalTotalPrice;
      dispatch(
        cartActions.setEnteredCash({
          eCash:
            currencyRoundoff(
              cashAmount,
              cashType === 'usd' ? currencyConversion : 1
            ) * 100,
          label: getCashLabel(cashType),
          paymentMediaNumber: getMediaNumber({
            isBBucks: cashType === 'bbucks',
            isUsCash: cashType === 'usd',
            isDriveOffMedia,
            isLocalChargeMedia,
          }),
        })
      );
      TriggerCashPayment({
        isUsCash: cashType === 'usd',
        label: getCashLabel(cashType),
        isBBucks: cashType === 'bbucks',
        isDriveOffMedia,
        isLocalChargeMedia,
      });
    } else {
      if (ienteredCash > 0) {
        const isCashNotValid = IsValidCashPayment(
          items,
          ienteredCash,
          Number(finalTotalPrice)
        );
        if (isCashNotValid) {
          DisplayToastMsg('Problem. Cash must be equal or greater than MO');
          return;
        }
      }
      if (
        !isRoundUpTriggered &&
        !isDriveOffMedia &&
        !isLocalChargeMedia &&
        approvedTenderedCount === 0 &&
        Number(finalTotalPrice) > 0
      ) {
        const {
          isRoundUpRequired,
          iRoundOffCharityAmt,
        } = isRoundOffCharityApplicable({
          // #5954 added usd cash check for Canada store
          ienteredCash:
            currencyRoundoff(
              ienteredCash,
              cashType === 'usd' ? currencyConversion : 1
            ) || 0,
          paymentMedia: 'CASH',
          finalTotalPrice: Number(finalTotalPrice),
        });
        if (isRoundUpRequired) {
          // #5950 passing cash type as well to trigger cash payment
          setCharityRedirection(cashType || 'CASH');
          setRoundUpTriggered(true);
          setRoundUpProgress(ROUNDOFF_CHARITY_INTIATED); // 1 means Round up intitated
          setisRoundUpAmount(iRoundOffCharityAmt);
          return;
        }
      }
      const { MOMIntialieResuest, isMoneyPrintItem } = verifyMOMInTransaction(
        items,
        deviceInfo,
        user,
        paymentTransactionId
      );
      // update cash payment information when all MO printed or without MO
      if (isMoneyPrintItem && isMoneyPrintItem.length === 0) {
        if (keypad?.value) {
          let eCash = currencyRoundoff(
            Number(keypad.value) / 100,
            cashType === 'usd' ? currencyConversion : 1
          );
          eCash *= 100;
          const cashEntered =
            Number(finalTotalPrice) < 0
              ? -Number(eCash) / 100
              : Number(eCash) / 100;
          // Always check entered cash lessthan fifth media balance amount display error
          if (approvedTenderedCount >= 4 && balanceDue > cashEntered) {
            history.push('payment/fifthMediaError');
            return;
          }
          // all cash payments with keypad value set from here
          dispatch(
            cartActions.setEnteredCash({
              eCash: cashEntered * 100,
              label: getCashLabel(cashType),
              paymentMediaNumber: getMediaNumber({
                isBBucks: cashType === 'bbucks',
                isUsCash: cashType === 'usd',
                isDriveOffMedia,
                isLocalChargeMedia,
              }),
            })
          );
        } else {
          const cashAmount = ienteredCash || balanceDue || finalTotalPrice;
          dispatch(
            cartActions.setEnteredCash({
              eCash:
                currencyRoundoff(
                  cashAmount,
                  cashType === 'usd' ? currencyConversion : 1
                ) * 100,
              label: getCashLabel(cashType),
              paymentMediaNumber: getMediaNumber({
                isBBucks: cashType === 'bbucks',
                isUsCash: cashType === 'usd',
                isDriveOffMedia,
                isLocalChargeMedia,
              }),
            })
          );
        }
        dispatch(cfdActions.setUserActionScreenActive(false));
        setMoneyOrderProgressStatus(MO_TIMER_RESET);
        // #9125 POS need to wait to new fuel price for MO declined.
        const isMoneyItem = items.filter(
          item =>
            item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_INVALID
        );
        const FuelItem = items?.find(item => item.isFuel);
        let cashTriggerTimeout = 0;
        if (isMoneyItem[0] && FuelItem) {
          if (FuelItem) {
            const {
              metaInfo: { isRestInFuel },
            } = FuelItem;
            if (isRestInFuel) cashTriggerTimeout = 1000;
          }
        }
        setTimeout(() => {
          TriggerCashPayment({
            isUsCash: cashType === 'usd',
            label: getCashLabel(cashType),
            isBBucks: cashType === 'bbucks',
            isDriveOffMedia,
            isLocalChargeMedia,
          });
        }, cashTriggerTimeout);
      } else {
        if (isLocalChargeMedia) {
          DisplayToastMsg('Money Order can only be paid for in cash');
          return;
        }

        const payload = {
          MOFlag: MO_FLG_PRINTING,
          MOCheckFlag: MO_FLG_INSALE,
          MOSeq: isMoneyPrintItem[0]?.itemSeq,
          serialNumber: '',
          MOErrorMsg: '',
        };
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        dispatch(cartActions.updateMoneyOrderFlags(payload));
        dispatch(cfdActions.setUserActionScreenActive(true));
        setMoneyOrderProgressStatus(MO_TIMER_TRIGGER);
        requestMoneyOrderLock(
          ws,
          deviceInfo?.id,
          storeDetails?.storeId,
          MOMIntialieResuest
        );
      }
    }
  };

  const processCashPayment = cashType => {
    const ienteredCash = Number(keypad.value) / 100;
    if (isFuelTransactionInProgress) {
      if (ienteredCash && ienteredCash < finalTotalPrice) {
        return DisplayToastMsg(Messages.cannot_fuel_split_tender);
      }
    }
    // RISPIN4577 Canada Void or refund should not accept with US cash
    if (
      (cashType === 'usd' || cashType === 'bbucks') &&
      (isTransactionVoid || isTransactionRefund)
    ) {
      return DisplayToastMsg('Invalid Media');
    }
    onCashPayment(cashType);
  };

  /**
   * Saving hardTotal object as ref to access from useEffects seamlessly.
   */
  useEffect(() => {
    hardTotalRef.current = hardTotal;
  }, [hardTotal]);

  // #5742 Will cross validate balance due and TAPI capture event before allowing to tender.
  useEffect(() => {
    if (
      isTAPITransCompleted &&
      allPayments?.length > 0 && // #5775 added payment check and total check as well.
      Math.abs(Number(finalTotalPrice)) > 0 &&
      !location.state?.preauthCancelFlow &&
      !location.state?.isPromoCarwash &&
      !isSigCaptureRequired
    ) {
      const { balanceDue } = getBalanceDue({
        allPayments,
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
      });
      if (
        (!balanceDue || Number(balanceDue) === 0) &&
        !location.pathname.includes('success') &&
        !location.pathname.includes('emailReceipt')
      ) {
        const isBlockCashDrawerToOpen =
          blockCashDrawerToOpen(finalTotalPrice) || false;
        if (isBlockCashDrawerToOpen)
          dispatch(socketActions.setCashDrawerStatus(null));
        if (!paymentMethod || paymentMethod === '')
          dispatch(cartActions.setPaymentMethod('CASH'));
        history.replace('/payment/success');
      }
    }
  }, [isTAPITransCompleted]);

  /**
   * To Handle PREAUTH_CANCEL Automatic flow seamlessly
   */
  useEffect(() => {
    // Explicitly processing PREAUTH_CANCEL flow.
    if (location.state?.preauthCancelFlow) {
      const updateHardTotalsIfNeeded = async () => {
        startLoading();
        try {
          await refreshHardTotals();
        } catch (e) {
          global.logger.error(
            `[7POS UI] - refreshHardTotals error ${JSON.stringify(e)}`
          );
        } finally {
          Logger.info(
            `[Fuel] UpdatedHardTotals: ${JSON.stringify(
              hardTotalRef.current ?? {}
            )}`
          );
          Logger.info(`[Fuel] Automatically Processing PREAUTH_CANCEL`);
          const { mediaNumber = 1, prepayAmount } =
            location.state?.metaInfo || {};
          dispatch(cartActions.setFuelPPCancel(true));
          mediaNumber === 1
            ? onCashPayment('', true)
            : handleCardPreauthCancel(prepayAmount);
        }
      };
      updateHardTotalsIfNeeded();
    } else if (location.state?.isPromoCarwash) {
      const refreshHT = async () => {
        await refreshHardTotals().catch(e => console.log(e));
        onCashPayment('', true);
      };
      refreshHT();
    }
  }, [location.state]);

  useEffect(() => {
    if (!isMasterCardLoyaltyPayment) return;
    SendMessageToCFD({
      CMD: 'MasterCardLoyalty',
      alert: true,
    });
  }, [isMasterCardLoyaltyPayment]);

  useEffect(() => {
    if (!autoTriggerCardPayment) return;
    handlePay({
      isMCLoyaltyPayment: true,
    });
    dispatch(cartActions.setAutoTriggerCardPayment(false));
    // handlePay({ isMCLoyaltyPayment: true });
  }, [autoTriggerCardPayment]);

  const updateMoneyOrderFlags = ({
    MOFlag,
    MOCheckFlag,
    serialNumber = '',
    MOErrorMsg = '',
  }) => {
    const isMoneyPrintItem = items.filter(
      item =>
        item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_PRINTING
    );
    if (isMoneyPrintItem && isMoneyPrintItem[0]?.itemSeq) {
      const payload = {
        MOFlag,
        MOCheckFlag,
        MOSeq: isMoneyPrintItem[0]?.itemSeq,
        serialNumber,
        MOErrorMsg,
      };
      dispatch(cartActions.updateMoneyOrderFlags(payload));
    }
  };

  const updateMOItemStatus = () => {
    dispatch(setShowNotifications(true));
    if (MoneyOrderDetails?.status === 'moneyOrderStatusGood') {
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
      updateMoneyOrderFlags({
        MOFlag: MO_FLG_PRINTED,
        MOCheckFlag: MO_FLG_PRINTING,
        serialNumber: MoneyOrderDetails?.serialNumber,
        MOErrorMsg: MoneyOrderDetails?.errorMessge,
      });
      setMoneyOrderProgressStatus(MO_TIMER_CLEAR);
    } else if (MoneyOrderDetails?.status === 'moneyOrderInUse') {
      DisplayToastMsg(MoneyOrderDetails?.errorMessge);
      // resend MO
      setTimeout(() => {
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        updateMoneyOrderFlags({
          MOFlag: MO_FLG_INSALE,
          MOCheckFlag: MO_FLG_PRINTING,
        });
        setMoneyOrderProgressStatus(MO_TIMER_CLEAR);
      }, 3000);
    } else {
      showToast({
        description: MoneyOrderDetails?.errorMessge,
        status: 'error',
        duration: 5000,
        position: 'top-left',
      });
      // remove from cart
      setMoneyOrderEror(true);
    }
  };

  const loadReqCall = () => {
    const { item, type = '' } = location?.state || {};
    if (loadAmount > 0) {
      const { isError, displayErrorMsg } = isCardLoadsLimitCrossed(
        items,
        config,
        loadAmount,
        isTransactionVoid,
        isFuelTransactionInProgress,
        Messages
      );
      if (isError) {
        dispatch(dailpadActions.resetDailpadState());
        DisplayToastMsg(displayErrorMsg);
        const cancelLoadFromPos = true;
        SendMessageToCFD({
          CMD: 'PrepaidLoadConfirm',
          cancelLoadFromPos,
        });
        dispatch(cartActions.setCardLoadReset());
        history.push('/home');
        return;
      }
    }
    const lookupReq = lookupRequest({
      item,
      type,
      amount: loadAmount * 100,
      loadBarcodeData,
      storeDetails,
      deviceInfo,
      location,
      prepaidAccNumberValue,
      digitalWalletToken: `${digitalWalletToken}?`,
      isTransactionVoid,
      loadSttn,
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/pinpad/cardLoad', {}, JSON.stringify(lookupReq));
    dispatch(cartActions.setLookUpCallProgress(LOAD_REQUEST_INPROGRESS));
    showLoader(true);
  };

  useEffect(() => {
    if (digitalWalletToken && !loadConfirm) {
      global?.logger?.info(
        'digitalWalletToken in useEffect',
        digitalWalletToken
      );
      handlePay({ type: 'digitalWallet' });
    }
  }, [digitalWalletToken]);

  useEffect(() => {
    // will remove/move after integration
    if (isMoneyOrderProgress === MO_TIMER_TRIGGER) {
      dispatch(setShowNotifications(false));
      setMoneyOrderTimeOut(
        setTimeout(() => {
          dispatch(cartActions.setMoneyOrderPrinterStatus(true));
          dispatch(cartActions.setPaymentTriggerStatus(true));
          dispatch(setShowNotifications(true));
          setMoneyOrderEror(true);
          DisplayToastMsg('MONEY ORDER MACHINE OFFLINE');
          releaseMoneyOrderLock(ws, deviceInfo?.id, storeDetails?.storeId);
          global?.logger?.info(
            'MO request timeout. POS sending relase lock to Store Coordinator'
          );
        }, 120000)
      );
    } else if (isMoneyOrderProgress === MO_TIMER_CLEAR) {
      clearTimeout(setMoneyOrderTimeOut);
      onCashPayment();
    }
    return () => {
      clearTimeout(setMoneyOrderTimeOut);
    };
  }, [isMoneyOrderProgress]);

  useEffect(() => {
    if (MoneyOrderPrinterStatus) {
      dispatch(cartActions.setMoneyOrderPrinterStatus(false));
      if (
        MoneyOrderDetails &&
        MoneyOrderDetails?.status &&
        !isMoneyOrderError
      ) {
        clearTimeout(MoneyOrderTimeOut);
        updateMOItemStatus();
      }
    }
  }, [MoneyOrderPrinterStatus]);

  const handleMOContinue = () => {
    dispatch(cartActions.setPaymentTriggerStatus(false));
    dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
    setMoneyOrderEror(false);
    updateMoneyOrderFlags({
      MOFlag: MO_FLG_PRINTED,
      MOCheckFlag: MO_FLG_PRINTING,
      serialNumber: '000000000000',
      MOErrorMsg: 'MO print status override by SA',
    });
    global?.logger?.info(
      `[7POS UI] - handleMOContinue ${JSON.stringify({
        MOFlag: MO_FLG_PRINTED,
        MOCheckFlag: MO_FLG_PRINTING,
        serialNumber: '000000000000',
        MOErrorMsg: 'MO print status override by SA',
      })} `
    );
    setMoneyOrderProgressStatus(MO_TIMER_CLEAR);
    history.replace('/payment');
  };
  const handleMOCancel = () => {
    dispatch(cartActions.setPaymentTriggerStatus(false));
    dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
    setMoneyOrderEror(false);
    updateMoneyOrderFlags({
      MOFlag: MO_FLG_INVALID,
      MOCheckFlag: MO_FLG_PRINTING,
      MOErrorMsg:
        MoneyOrderDetails?.errorMessge?.length > 0
          ? MoneyOrderDetails?.errorMessge
          : 'MONEY ORDER MACHINE OFFLINE',
    });
    global?.logger?.info(
      `[7POS UI] - handleMOCancel ${JSON.stringify({
        MOFlag: MO_FLG_INVALID,
        MOCheckFlag: MO_FLG_PRINTING,
        MOErrorMsg:
          MoneyOrderDetails?.errorMessge?.length > 0
            ? MoneyOrderDetails?.errorMessge
            : 'MONEY ORDER MACHINE OFFLINE',
      })} `
    );
    setMoneyOrderProgressStatus(MO_TIMER_CLEAR);
    history.replace('/payment');
  };

  useEffect(() => {
    if (
      loadNotificationStatus &&
      (CardLoadStatus === 'APPROVED' || CardLoadStatus === 'DECLINED')
    ) {
      global?.logger?.info(`[7POS UI] - Card load status ${CardLoadStatus} `);
      let taxRequest = localStorage.getItem('taxInfoRequest');
      try {
        // #5968 Added null check for Tax field before parse
        if (taxRequest && taxRequest !== null) {
          taxRequest = JSON.parse(taxRequest);
          taxRequest = taxRequest?.taxInfo;
        } else {
          // #7795 reconstruct tax request from cart
          let basketPromoDiscount = [];
          if (basketPromo?.length > 0) {
            const promodiscount = basketPromo?.slice(-1);
            basketPromoDiscount = promodiscount
              ? {
                  amount: (promodiscount[0]?.item_discount).toFixed(2) / 100,
                  name: promodiscount[0]?.name,
                }
              : {};
          }
          taxRequest = processTaxRequest({
            items,
            storeProfile: storeDetails,
            basketDiscount: basketPromoDiscount?.amount,
            arbitration,
            isReturnOrVoid: isTransactionRefund || isTransactionVoid,
            taxData: taxInfo,
            config,
          });
        }
      } catch (error) {
        global.logger.error(
          `[7POS UI] - getting tax information failed. ${JSON.stringify(error)}`
        );
        taxRequest = null;
      }
      let cardDiscountAmt = 0;
      let cardAmt = 0;
      if (CardLoadStatus === 'DECLINED') {
        loadCardMediaList
          .filter(
            i =>
              i.cardResult.status === 'DECLINED' ||
              i.cardResult.statusCode !== 0
          )
          .map(loadCardDetails => {
            const item = items.filter(
              i =>
                i.itemTypeID === ITEM_TYPE.CARD_LOAD &&
                (i.sttn === loadCardDetails?.cardDetails?.sttn ||
                  i.itemSeq === loadCardDetails?.loadRequestId)
            );
            if (item[0]) {
              const cardTax = getLineTax(item[0], taxInfo);
              let price = item[0]?.retailPrice;
              let LoadTaxIndicator = '';
              let LoadFeeTaxIndicator = '';
              if (item[0]?.feeDetails?.retailPrice) {
                const lineNumber = Number(
                  parseFloat(
                    `${item[0].tranItemSeqNumber * CARD_LOAD_BASE_INDEX +
                      item[0].tranItemSeqNumber}`
                  )
                );
                const cardTax = getLineTax(
                  item[0].feeDetails,
                  taxInfo,
                  lineNumber
                );
                price =
                  Number(price) +
                  Number(item[0].feeDetails.retailPrice * 100) +
                  cardTax * 100;
                LoadFeeTaxIndicator = Math.abs(cardTax) > 0 ? 'T' : '';
              }
              if (item[0]?.cardDiscounts) {
                const cardDiscount = item[0].cardDiscounts.reduce(
                  (sum, item) => {
                    const price = item.amount;
                    return sum + price;
                  },
                  0
                );
                cardDiscountAmt += cardDiscount * 100;
              }
              cardAmt += Number(price) + cardTax * 100;
              LoadTaxIndicator = Math.abs(cardTax) > 0 ? 'T' : '';

              if (taxRequest && taxRequest.inventory) {
                const taxItem = taxRequest.inventory.items;
                let index = taxItem.findIndex(
                  i => i.lineNumber === item[0].tranItemSeqNumber
                );
                if (index >= 0) taxItem.splice(index, 1);
                // Removing Fee line item as well from the tax request.
                if (item[0]?.feeDetails?.retailPrice) {
                  const lineNumber = Number(
                    parseFloat(
                      `${item[0].tranItemSeqNumber * CARD_LOAD_BASE_INDEX +
                        item[0].tranItemSeqNumber}`
                    )
                  );
                  index = taxItem.findIndex(i => i.lineNumber === lineNumber);
                  if (index >= 0) taxItem.splice(index, 1);
                }
                const inventoryData = taxRequest.inventory;
                const taxinventory = {
                  ...inventoryData,
                  items: taxItem,
                };
                taxRequest = {
                  ...taxRequest,
                  inventory: taxinventory,
                };
              }
              dispatch(
                cartActions.updateCardLoadFlags({
                  itemSeq: item[0].itemSeq,
                  LoadTaxIndicator,
                  LoadFeeTaxIndicator,
                })
              );
            }
            return loadCardDetails;
          });
      }
      dispatch(cartActions.setCardLoadNotificationStatus(false));
      // #7795 CardLoadStatus APPROVED case always flag need to set
      if (CardLoadStatus === 'APPROVED' && !taxRequest)
        dispatch(cartActions.setLoadAdjustedTax(true));
      dispatch(cartActions.setLoadAdjustedTax(taxRequest));
      dispatch(cartActions.setCardLoadStatus(''));

      if (Math.abs(cardAmt) > 0) {
        const CardLoadDeclined = Number(
          parseFloat(
            (Math.abs(cardAmt) - Math.abs(cardDiscountAmt)) / 100
          ).toFixed(2)
        );
        global?.logger?.info(
          `[7POS UI] - Card load intiate from cash and adjusting decline ${CardLoadDeclined} `
        );
        dispatch(cartActions.setCardDeclinedAmount(CardLoadDeclined * 100));

        let TranPaidAmount = 0;
        let paymentMediaNumber = 1;
        let label = 'Cash';
        if (CashPaymentInfo.length > 0)
          CashPaymentInfo.map(CashPayment => {
            TranPaidAmount = Number(CashPayment.paidAmount);
            paymentMediaNumber = Number(CashPayment.paymentMediaNumber);
            label = CashPayment.description;
            return CashPayment;
          });

        if (Math.abs(TranPaidAmount) > 0 && CardLoadDeclined > 0) {
          // #6438 handling Win > Card load and decline case.
          if (isTransactionVoid || TranPaidAmount < 0) {
            const cashAdjust = isTransactionVoid
              ? TranPaidAmount + CardLoadDeclined
              : TranPaidAmount - CardLoadDeclined;
            dispatch(
              cartActions.setEnteredCash({
                eCash: cashAdjust * 100,
                LoadDecline: true,
                paymentMediaNumber,
                label,
              })
            );
            global?.logger?.info(
              `[7POS UI] - Card load intiate from cash and adjusting cash ${cashAdjust} for void transaction`
            );
          }
        }
      }
    }
  }, [loadNotificationStatus]);

  const enteredCashAmount = e => {
    console.log(e);
    // eslint-disable-next-line no-useless-return
    return;
  };

  const handleContinue = () => {
    dispatch(setShowNotifications(true));
    setShowPartialApproval(true);
    dispatch(socketActions.setCardStatus(null));
    dispatch(cartActions.setStatusCode(null)); // TODO: Need proper testing
    dispatch(
      cartActions.updateLineItemTotalFinal({ isResetLineItemTotal: false })
    ); // Update lineItem Final amount.
    dispatch(cartActions.setPaymentTriggerStatus(false));
    history.replace('/payment');
  };
  const handleCancel = () => {
    dispatch(setShowNotifications(true));
    setShowPartialApproval(true);
    dispatch(socketActions.setCardStatus(null));
    handlePay({ type: 'cancel' });
    const paidAmt = paymentDetails?.paymentMedia?.payment?.amount?.toFixed(2);
    dispatch(
      cartActions.setTransactionComments(`CHARGE OF ${paidAmt} WAS DECLINED`)
    );
    dispatch(cartActions.setTransactionComments(`BY THE CUSTOMER`));
    showLoader(true);
    history.replace('/payment');
  };

  const handleInSuffceintCancel = () => {
    dispatch(setShowNotifications(true));
    const payload = JSON.stringify({
      amountChangeFlag: false,
      customerConfirmAmount: '',
    });
    const continueReq = appIntegrationRequest({
      type: 'insufficent_bal',
      payload,
    });
    ws.socket?.send('/app/payment/prompt', {}, JSON.stringify(continueReq));
    // need reset some other flag as well
    dispatch(cartActions.setDigitalWalletToken(null));
    dispatch(cartActions.setDigitalWalletStatus(false));
    dispatch(cartActions.setPaymentMethod(null));
    dispatch(socketActions.setCardStatus(null));
    dispatch(cartActions.setStatusCode(null));
    dispatch(cartActions.setInSufficentCardDetails({}));
    if (isEBTPayment) {
      let isEbtSnapPresent = false;
      let isMediaAbort = [];
      allPayments
        ?.filter(pml => pml?.paymentMediaType === 'EBTSNAP')
        ?.map(pml => {
          if (mediaAbortedPaymentList[0]) {
            isMediaAbort = mediaAbortedPaymentList?.filter(
              payment =>
                payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
            );
            if (!isMediaAbort[0]) {
              isEbtSnapPresent = true;
            }
          } else {
            isEbtSnapPresent = true;
          }
          return pml;
        });
      if (!isEbtSnapPresent) {
        dispatch(cartActions.setEbtPaymentTendered(true));
      }
      dispatch(cartActions.setEBTPaymentIntiateStatus(false));
    }
    dispatch(cartActions.setPaymentTriggerStatus(false));
    history.replace('/payment');
  };

  const handleInSuffceintContinue = () => {
    try {
      dispatch(setShowNotifications(true));
      const payload = JSON.stringify({
        amountChangeFlag: true,
        customerConfirmAmount: InSufficentCardDetails?.CardbalanceAmount || '',
        tenderSequenceNumber,
      });
      const continueReq = appIntegrationRequest({
        type: 'insufficent_bal',
        payload,
      });
      ws.socket?.send('/app/payment/prompt', {}, JSON.stringify(continueReq));
      dispatch(cartActions.setPaymentMethod(null));
      dispatch(socketActions.setCardStatus(null));
    } catch (error) {
      global.logger.error(
        `[7POS UI] - InSufficeint bal Error from POS ${JSON.stringify(error)}`
      );
    } finally {
      showLoader(true);
    }
  };

  // eslint-disable-next-line arrow-body-style
  const canShowPartialApproval = () => {
    return statusCode === 12 && !showPartialApproval;
  };

  // eslint-disable-next-line arrow-body-style
  const canShowInSuffceintAmount = () => {
    return statusCode === 11 && InSufficentCardDetails?.CardbalanceAmount;
  };

  const fleetPromptReq = () => {
    const fleetReq = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'FLEET_PROMPTS',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PINPAD',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: JSON.stringify(fleetPromptValues),
      },
    };
    ws.socket?.send('/app/payment/prompt', {}, JSON.stringify(fleetReq));
  };

  const storeSeqAndHardtotals = async () => {
    try {
      // #4761 State not yet reflect before call this function.
      const {
        runningTotalTax,
        taxInfo,
        runningTotal,
        allPayments,
      } = store.getState().cart;
      localStorage.setItem('mediaInformation', JSON.stringify(allPayments));
      let adjustedRunningTotal = runningTotalTax;
      // #7238 always need to check abs value(refund due case end with negative running total)
      if (runningTotalTax === 0 && Math.abs(runningTotal) > 0) {
        adjustedRunningTotal = Number(runningTotal / 100);
        if (
          taxInfo &&
          taxInfo?.totalTaxAmount > 0 &&
          !isTransactionRefund &&
          !isTransactionVoid
        ) {
          const iTaxAmount = Number(taxInfo?.totalTaxAmount) || 0;
          adjustedRunningTotal += iTaxAmount;
        }
        dispatch(cartActions.setrunningTotalTax(adjustedRunningTotal));
      }
      // Update tran sequence number once transaction complete
      let storedSeq = localStorage.getItem('StoreSeqAndHardTotals');
      storedSeq = storedSeq
        ? JSON.parse(storedSeq)
        : { transactionId: '', status: false, paymentTransactionId: '' };
      if (
        storedSeq.paymentTransactionId === paymentTransactionId &&
        storedSeq.status &&
        storedSeq.transactionId === transactionId
      ) {
        global?.Logger?.debug(
          `[7POS UI] - already Posted Hard totals storeSeqAndHardtotals(Cash payment) and ${paymentTransactionId} `
        );
        return;
      }
      global?.logger?.info(
        `[7POS UI] - Posting Hard totals storeSeqAndHardtotals(Cash payment) and ${paymentTransactionId} `
      );
      localStorage.setItem(
        'StoreSeqAndHardTotals',
        JSON.stringify({
          paymentTransactionId: paymentTransactionId.toString(),
          status: true,
          transactionId: transactionId.toString(),
        })
      );
      storeTranSeqNumber({
        transactionId,
        MembertransactionId,
        correlationID: paymentTransactionId,
      });
      finalizeHardTotals({
        items,
        member,
        runningTotalTax: adjustedRunningTotal,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        cashBack,
      });
      await captureHardTotals();
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store transaction seq and update Hartotals failed ${JSON.stringify(
          error
        )}`
      );
    }
  };

  useEffect(() => {
    // #7821/#7276 payment redirection should happen after tender ack from MW
    if (!isPaymentTriggered) return;
    let description = 'Card Declined';
    if (cashBack && cardStatus !== CASHBACK_RESTRICTION) {
      dispatch(socketActions.setCardStatus(null));
    }
    if (cardStatus === DECLINE) {
      if (!declineMessage) return;
      description = declineMessage || 'Declined'; // TODO: after MVP address this with proper approach
      if (
        (isTransactionRefund || isTransactionVoid) &&
        declinedPayments.filter(pItem => pItem.paymentMediaType === EBTSNAP)
          .length > 0
      ) {
        description = 'Cannot return items using an EBT/CB CARD';
      }
      toast({
        description,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
    } else if (cardStatus === DECLINED_INVALID_PAYMENT_REQUEST) {
      toast({
        description,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
    } else if (cardStatus === TIMEOUT) {
      if (paymentMethod === BALANCE_INQUIRY) {
        history.push('/home');
      }
      DisplayToastMsg('Pinpad Timeout');
    } else if (cardStatus === DECLINED_ORIGINALCARD_NOTFOUND) {
      history.replace('/home');
    } else if (
      cardStatus === DECLINED_ORIGINALSALE_NOTFOUND &&
      originalSaleDeclinedCount >= 2
    ) {
      history.replace('/home');
      dispatch(dailpadActions.resetDailpadState());
      dispatch(socketActions.resetOriginalSaleDeclinedCount());
    }

    const { balanceDue } = getBalanceDue({
      paymentHistory,
      paymentMediaList,
      finalTotalPrice,
      enteredCash,
      allPayments,
    });

    if (
      allPayments?.length > 0 &&
      (!balanceDue || Number(balanceDue) === 0) &&
      !location.pathname.includes('success') &&
      !location.pathname.includes('emailReceipt')
    ) {
      if (!pipoTransaction && !loadCardMediaList.length && !cashBack) {
        // Should not be redirected to success screen in case of PIPO transaction.
        dispatch(cartActions.setPaymentMethod('CASH'));
        const { balanceDue } = getBalanceDue({
          paymentHistory,
          paymentMediaList,
          finalTotalPrice,
          enteredCash,
          allPayments,
        });
        if (!balanceDue || Number(balanceDue) === 0) {
          if (isSigCaptureRequired) {
            storeSeqAndHardtotals();
            showLoader(false);
            dispatch(setShowNotifications(false));
            const iTransactionMessage = {
              CMD: 'SignatureCapture',
            };
            SendMessageToCFD(iTransactionMessage);
            dispatch(socketActions.setCardStatus(SIGNATURE_CAPTURE));
            return;
          }
        }
        showLoader(true);
        setTimeout(() => {
          storeSeqAndHardtotals();
          showLoader(false);
          history.replace('/payment/success');
        }, 100);
      } else {
        global?.logger?.info(
          'Payment Success redirection Screen Check: ',
          pipoTransaction,
          loadCardMediaList.length,
          cashBack
        );
      }
    }
  }, [cardStatus, declineMessage, isPaymentTriggered]);

  useEffect(() => {
    if (!fleetPromptValues || Object.keys(fleetPromptValues).length === 0) {
      return;
    }
    fleetPromptReq();
    // #5788 reset Fleet Prompt values after sent to MW
    dispatch(cartActions.setFleetPromptValues(null));
    return () => {};
  }, [fleetPromptValues]);

  useEffect(() => {
    if (!isPaymentTriggered) {
      // 6783 added payment check before process card load
      if ((isTransactionRefund || itemQuantity > 1) && digitalWalletToken) {
        const MSG =
          itemQuantity > 1
            ? 'Invalid scan for qty multiplier.'
            : 'Card Load Not Allowed';
        DisplayToastMsg(MSG);
        Logger.error(
          `7POS Application - Card Load Not Allowed for refund transaction ${isTransactionRefund} or Qty:${itemQuantity}`
        );
        dispatch(cartActions.setCardLoadReset());
        return;
      }
      if (loadPromptRequest > 0) return;
      if (!loadConfirm) return;
      if (!loadBarcodeData && !digitalWalletToken) return;
      if (
        (!loadBarcodeData && digitalWalletToken) ||
        (loadBarcodeData && !digitalWalletToken)
      ) {
        loadReqCall();
      }
    }
    return () => {};
  }, [loadConfirm, loadBarcodeData, digitalWalletToken]);

  useEffect(() => {
    if (statusCode === 278 || statusCode === 275) {
      history.push({
        pathname: '/payment/MediaRestriction',
        search: `?status=ebtMediaRist`,
        state: { statusCode },
      });
    }
    return () => {};
  }, [statusCode]);
  const showPaymentMethods =
    cardStatus !== PROMPT_REFERENCE_NUMBER &&
    cardStatus !== INVALID_EBT_ACCOUNT;
  // cardStatus !== EBTCB;

  const getComponentByCardStatus = () => {
    if (cardStatus === PROMPT_REFERENCE_NUMBER) return <OriginalRefNumber />;
    if (isTransactionVoid || isTransactionRefund) {
      // TODO: Card Status should check with void or return this is breaking EBT sale
      // if (cardStatus === INVALID_EBT_ACCOUNT || cardStatus === EBTCB) return <EBTCBNoReturn />;
      if (cardStatus === INVALID_EBT_ACCOUNT) return <EBTCBNoReturn />;
    }
    return null;
  };

  useEffect(() => {
    if (RoundUpCharityStatus) {
      if (RoundUpCharityStatus === 'YES') {
        // Add charity dept sale item
        if (isRoundOffDept !== null) {
          dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
          const DeptInfo = {
            ...isRoundOffDept,
            retailPrice: parseFloat(isRoundUpAmount).toFixed(2) / 100,
            // #6050 added below fields mandatory for PMB
            totalRetailPrice: parseFloat(isRoundUpAmount).toFixed(2),
            couponRemainQty: 1,
          };
          dispatch(cartActions.setisRoundOffDept(DeptInfo));
          dispatch(cartActions.addToCart(DeptInfo));
          dispatch(
            cartActions.addCartItems([
              {
                ...DeptInfo,
                retailPrice: DeptInfo.retailPrice * 100,
                tranItemSeqNumber: tranItemSeqNumber + 1,
              },
              ...items,
            ])
          );
          DisplayToastMsg('RoundUp charity item added', 'success');
        }
        history.replace('/payment');
      }
      global?.logger?.info(
        `[7POS UI] - RoundUp charity opted by user ${RoundUpCharityStatus}`
      );
      if (RoundUpCharityStatus === 'YES' || RoundUpCharityStatus === 'NO') {
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cartActions.setRoundUpCharityStatus(''));
        dispatch(setShowNotifications(true));
        setRoundUpProgress(ROUNDOFF_CHARITY_COMPLETED);
      }
    }
  }, [RoundUpCharityStatus]);

  useEffect(() => {
    if (isRoundUpProgress === ROUNDOFF_CHARITY_COMPLETED) {
      dispatch(setShowNotifications(true));
      setRoundUpProgress(ROUNDOFF_CHARITY_RESET);
      dispatch(cartActions.setPinpadProcessMsg('Processing Request...'));
      if (charityRedirection === 'CASH' || charityRedirection !== '') {
        onCashPayment(charityRedirection !== 'CASH' ? charityRedirection : '');
      } else {
        handlePay({
          isMCLoyaltyPayment: processPaymentAsMCLoyalty,
        });
      }
      setCharityRedirection('');
    }
  }, [isRoundUpProgress, processPaymentAsMCLoyalty]);

  useEffect(() => {
    setRoundUpTriggered(false);
    setCharityRedirection('');
    setRoundUpProgress(ROUNDOFF_CHARITY_RESET); // 1 means Round up intitated
    setisRoundUpAmount(0);
  }, []);

  const renderComponent = () => {
    if (isMasterCardLoyaltyPayment) {
      return (
        <Processing
          iMsg="Awaiting for Customer response"
          isSpeedWayRewdsText="Please allow the customer to make a selection at the CFD"
        />
        // <MasterCardPrompt
        //   onCancel={() => {
        //     dispatch(cartActions.setIsMasterCardLoyaltyPayment(false));
        //     dispatch(cartActions.setCancelPaymentForMCLoyalty(true));
        //     SendMessageToCFD({
        //       CMD: 'MasterCardLoyalty',
        //       alert: false,
        //     });
        //   }}
        //   onConfirm={() => {
        //     SendMessageToCFD({
        //       CMD: 'MasterCardLoyalty',
        //       alert: false,
        //     });
        //     dispatch(cartActions.setIsMasterCardLoyaltyPayment(false));
        //     handlePay({ isMCLoyaltyPayment: true });
        //   }}
        // />
      );
    }
    if (cardStatus === CASHBACK_RESTRICTION) {
      return (
        <Box className={Styles.WaitingForCardContainer}>
          <EbtCbCashBackScreen />
        </Box>
      );
    }
    if (isMediaHALOError) {
      return <MediaHalo onExit={onMedaiHaloExit} MSG={iMediaErrorMsg} />;
    }
    if (isMoneyOrderError) {
      return (
        <MoMPrintError onAccept={handleMOContinue} onCancel={handleMOCancel} />
      );
    }
    if (canShowPartialApproval()) {
      return (
        <Box className={Styles.WaitingForCardContainer}>
          <PartialApproval
            amount={finalTotalPrice}
            paymentDetails={paymentDetails}
            paymentHistory={paymentHistory}
            paymentMediaList={paymentMediaList}
            statusCode={statusCode}
            allPayments={allPayments}
            onContinue={handleContinue}
            onCancel={handleCancel}
          />
        </Box>
      );
    }
    if (canShowInSuffceintAmount()) {
      return (
        <Box className={Styles.WaitingForCardContainer}>
          <InsuffcientAmount
            handleInSuffceintContinue={handleInSuffceintContinue}
            handleInSuffceintCancel={handleInSuffceintCancel}
          />
        </Box>
      );
    }
    if (cardStatus === WAITING_FOR_EBT_MANUAL_ENTRY) {
      return (
        <Box className={Styles.WaitingForCardContainer}>
          <ManualEBT />
        </Box>
      );
    }
    if (
      isMoneyOrderProgress !== 0 ||
      cardStatus === CARD_READ ||
      cardStatus === EBTCB ||
      cardStatus === EBTSNAP || // Added PROMPT_REFERENCE_NUMBER as well for void transaction
      (digitalWalletToken !== null &&
        cardStatus !== PROMPT_REFERENCE_NUMBER &&
        isPaymentTriggered) ||
      isRoundUpProgress !== ROUNDOFF_CHARITY_RESET
    ) {
      return (
        <Box className={Styles.processingCard}>
          <Processing
            iMsg="Processing Request..."
            isRoundUp={isRoundUpProgress !== ROUNDOFF_CHARITY_RESET}
          />
        </Box>
      );
    }
    if (cardStatus === WAITING_FOR_CARD) {
      return (
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          height="100%"
        >
          <Flex flexDirection="column">
            <Box className={Styles.WaitingForCardContainer}>
              {loadConfirm ? <CardLoadSwipeWait /> : <WaitingForCard />}
            </Box>
          </Flex>
        </Flex>
      );
    }
    if (cardStatus === SIGNATURE_CAPTURE) {
      return <SignatureCapture />;
    }
    if (!showPaymentMethods) {
      return (
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          height="100%"
        >
          <Flex flexDirection="column">
            <Grid templateColumns="50% 50%">{getComponentByCardStatus()}</Grid>
          </Flex>
        </Flex>
      );
    }

    return (
      <PMethods
        goBack={goBack}
        tenderSequenceNumber={tenderSequenceNumber}
        enteredCashAmount={enteredCashAmount}
        onCashPayment={processCashPayment}
        handlePay={handlePay}
        onManualEbt={onManualEbt}
        disableOtherMedia={!mediaConfig?.groups}
      />
    );
  };
  return renderComponent();
};

export default PaymentMethod;
