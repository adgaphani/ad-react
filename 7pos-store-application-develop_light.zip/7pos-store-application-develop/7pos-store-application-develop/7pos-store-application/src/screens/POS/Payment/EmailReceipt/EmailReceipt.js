/* eslint-disable jsx-a11y/label-has-for */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable no-useless-escape */
/* eslint-disable no-else-return */
import React, { useState, useRef, useEffect, useContext } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { Flex, Box, Heading, Input, Text } from '@chakra-ui/react';
import { useSelector, useDispatch } from 'react-redux';
import { useSoundToast } from '../../../../hooks';
import { Button } from '../../../../components/Common';
import Styles from './emailReceipt.module.css';
import {
  paymentRecepitRequest,
  createTaxObject,
  fuelPreAuthCancelReceipt,
} from '../../../../Utils/paymentUtils';
import { fetchEmailReceipt } from '../../../../api/payment';
import Icon_conf from '../../../../Icons/Icon_conf.svg';
import AlphaNumericDailpad from '../../../../components/Common/DailPad/AlphaNumericDailpad/AlphaNumericDailpad';
import ExitButton from '../../../../components/POS/ExitButton';
import { cartActions } from '../../../../slices/cart.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import { SendMessageToCFD } from '../../../../Communication';
import { getMaskedEmail, getTaxDetails } from '../../../../Utils/appUtils';
import { AppContext } from '../../../../AppContext';

const EmailReceipt = () => {
  const location = useLocation();
  const history = useHistory();
  const toast = useSoundToast();
  const dispatch = useDispatch();
  const [emailFailureCount, setEmailFailureCount] = useState(0);
  const { showLoader } = useContext(AppContext);

  const {
    member,
    isTransactionVoid,
    taxInfo,
    isTransactionRefund,
    basketPromo,
    taxBeforeEBTExempt,
    config,
    EmailForReceipt,
    loadCardMediaList,
    isMediaAborted,
    taxableBeforeEBTExempt,
    paymentTransactionId,
    taxDeductionAmount,
    isFuelPPCancel,
    paymentMethod,
    mediaAbortedPaymentList,
    channel,
    calculatedFuelDiscounts,
    hostDiscountsforSelectedGrade,
    fuelSelectedGradeMeta,
    sigPrintVouchSelected,
    isCashCreditStore,
    selectedFuelCashGMeta,
    stateCode,
  } = useSelector(state => ({
    member: state.cart.member,
    isTransactionVoid: state.cart.isTransactionVoid,
    taxInfo: state.cart.taxInfo,
    isTransactionRefund: state.cart.isTransactionRefund,
    basketPromo: state.cart.basketPromo,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    config: state.main.configuration,
    EmailForReceipt: state.cart.EmailForReceipt,
    loadCardMediaList: state.cart.loadCardMediaList,
    isMediaAborted: state.cart.isMediaAborted,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    paymentTransactionId: state.cart.paymentTransactionId,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    isFuelPPCancel: state.cart.isFuelPPCancel,
    paymentMethod: state.cart.paymentMethod,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    channel: state.main.channel,
    calculatedFuelDiscounts: state.cart.calculatedFuelDiscounts,
    hostDiscountsforSelectedGrade: state.cart.hostDiscountsforSelectedGrade,
    fuelSelectedGradeMeta: {
      ...(state.cart.calculatedPrices?.find(price => price.selected) || {}),
    },
    sigPrintVouchSelected: state.cart.sigPrintVouchSelected,
    isCashCreditStore: state.main.isCashCreditStore,
    selectedFuelCashGMeta: {
      ...(state.cart.calculatedFuelCashPrices?.find(price => price.selected) ||
        {}),
    },
    stateCode: state.main.storeDetails?.address?.state,
  }));

  const getInitialInputs = () => {
    /* if (IS_DEV) {
      return { email: 'sriramreddy.keesara@7-11.com', isValid: true };
    } */
    if (member) {
      return { email: member.email, isValid: true };
    } else if (
      EmailForReceipt.length > 0 &&
      EmailForReceipt !== 'EMAILTRIGGER'
    ) {
      return { email: EmailForReceipt, isValid: true };
    }
    return { email: '', isValid: false };
  };

  const [inputs, setInputValues] = useState(getInitialInputs());
  const [isShowSucessMessage, setIsShow] = useState(false);
  const [isEmailLandingScreen, setEmailLandingStatus] = useState(false);
  const [isDailpadShowing, setIsDailpadShowing] = useState(true);
  const emailRef = useRef();
  const [isScreenTimeout, setScreenTimeOut] = useState(false);

  const getTransDetails = transInfo => {
    const transDetails = { ...transInfo };
    let TransDetails = transDetails;
    if (taxBeforeEBTExempt) {
      // RISPIN:2726 Tax deduction should always +ve for void/sale
      transDetails['TAX DEDUCTION'] = Math.abs(taxDeductionAmount);
      transDetails['TAX DEDUCTION'] = transDetails['TAX DEDUCTION']
        .toFixed(2)
        .toString();
      const taxAssessments = createTaxObject(
        taxInfo,
        taxBeforeEBTExempt,
        taxableBeforeEBTExempt,
        isTransactionRefund || isTransactionVoid
      );
      TransDetails = getTaxDetails(
        taxAssessments,
        taxInfo,
        transDetails,
        isTransactionRefund || isTransactionVoid,
        taxableBeforeEBTExempt,
        taxBeforeEBTExempt,
        stateCode
      );
    }
    global?.logger?.info(
      `[7POS UI] - getTransDetails details success ${JSON.stringify(
        transDetails
      )}`
    );
    return TransDetails;
  };
  const sendEmailRecepit = async () => {
    let paymentReqdata;
    if (isFuelPPCancel && paymentMethod !== 'CASH') {
      const tInfo = {
        SUBTOTAL: location?.state?.transInfo.SUBTOTAL,
        'TOTAL DUE': location?.state?.transInfo['TOTAL DUE'],
      };
      paymentReqdata = fuelPreAuthCancelReceipt({
        ...location.state,
        transInfo: getTransDetails(tInfo),
      });
    } else {
      const fuelSelectedGMeta =
        isCashCreditStore && paymentMethod === 'CASH'
          ? selectedFuelCashGMeta
          : fuelSelectedGradeMeta;
      paymentReqdata = paymentRecepitRequest({
        ...location.state,
        transInfo: getTransDetails(location.state?.transInfo),
        isTransactionVoid,
        isTransactionRefund,
        taxInfo: { ...taxInfo, taxAmount: taxBeforeEBTExempt },
        member,
        basketPromo,
        config,
        loadCardMediaList,
        isMediaAborted,
        mediaAbortedPaymentList,
        fuelDiscounts: calculatedFuelDiscounts,
        hostDiscountForSelectedGrade: hostDiscountsforSelectedGrade,
        fuelSelectedGradeMeta: Object.keys(fuelSelectedGMeta).length
          ? fuelSelectedGMeta
          : undefined,
        sigPrintVouchSelected,
      });
    }

    try {
      paymentReqdata.receiptType = 'EMAIL';
      paymentReqdata.subject = 'Receipt';
      paymentReqdata.to =
        EmailForReceipt.length > 0 ? EmailForReceipt : inputs.email;
      dispatch(cartActions.setEmailForReceipt(''));
      showLoader(true);
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
      global?.logger?.info(`[7POS UI] - Email receipt API successful`);
      setIsShow(true);
      const iTransactionMessage = {
        CMD: 'EmailReceipt',
        Status: 'Success',
      };
      SendMessageToCFD(iTransactionMessage);
    } catch (error) {
      if (emailFailureCount > 1) {
        global?.logger?.error(
          `[7POS UI] - Receipt not sent - Email input exceeded attempts`
        );
        toast({
          description: 'Receipt not sent - Email input exceeded attempts',
          status: 'error',
          duration: 5000,
          position: 'top-left',
        });
        const iTransactionMessage = {
          CMD: 'EmailReceipt',
          Status: 'Aborted',
          Email: inputs.email,
        };
        SendMessageToCFD(iTransactionMessage);
        history.replace({
          pathname: '/payment/success',
          state: { redirection: true, isEmailSent: false },
        });
      } else {
        const iTransactionMessage = {
          CMD: 'EmailReceipt',
          Status: 'Failed',
          Email: inputs.email,
        };
        SendMessageToCFD(iTransactionMessage);
        setEmailFailureCount(emailFailureCount + 1);
        toast({
          description: 'Receipt was not successfully sent',
          status: 'error',
          duration: 5000,
          position: 'top-left',
        });
        global?.logger?.error(`[7POS UI] - Receipt was not successfully sent`);
      }
    } finally {
      showLoader(false);
    }
  };

  const onExitEmailSuccess = () => {
    global?.logger?.info(`[7POS UI] - onExitEmailSuccess clicked`);
    setIsShow(false);
    if (isScreenTimeout) {
      global?.logger?.info(`[7POS UI] - onExitEmailSuccess clear timeout`);
      clearTimeout(isScreenTimeout);
    }
    setEmailLandingStatus(false);
    dispatch(cfdActions.setCurrentFleetPrompt(null));
    dispatch(cfdActions.setUserActionScreenActive(false));
    if (location.pathname !== '/payment/emailReceipt') return;
    history.replace({
      pathname: '/payment/success',
      state: { redirection: true, isEmailSent: true },
    });
  };

  useEffect(() => {
    const timer = isEmailLandingScreen ? 60000 : 5000;
    if (isEmailLandingScreen || isShowSucessMessage) {
      setScreenTimeOut(
        setTimeout(() => {
          global?.logger?.info(
            `[7POS UI] - Email screen ${location.pathname}, ${isEmailLandingScreen},${isShowSucessMessage} and timer ${timer} `
          );
          if (location.pathname !== '/payment/emailReceipt') return;
          onExitEmailSuccess();
        }, timer)
      );
    } else {
      global?.logger?.info(`[7POS UI] - onTimer useEffect clear timeout`);
      clearTimeout(isScreenTimeout);
    }
    return () => {
      clearTimeout(isScreenTimeout);
    };
  }, [isEmailLandingScreen, isShowSucessMessage]);

  const onExitFromEmailReceiptScreen = () => {
    global?.logger?.info(`[7POS UI] - onExitFromEmailReceiptScreen clicked`);
    setIsShow(false);
    clearTimeout(isScreenTimeout);
    setEmailLandingStatus(false);
    history.replace({
      pathname: '/payment/success',
      state: { redirection: true, isEmailSent: false },
    });
  };

  const [EmailText, setEmailText] = useState('Email Receipt');

  const handleKeyPress = text => {
    setEmailLandingStatus(false);
    if (isScreenTimeout) clearTimeout(isScreenTimeout);
    const prev = inputs.email || '';
    const regEx = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let email = prev;
    if (text === '') {
      email = email.slice(0, -1);
    } else {
      email += text;
    }
    const isValid = regEx.test(String(email));
    setEmailText('Email Receipt');
    setInputValues({ ...inputs, email, isValid });
  };

  const handleEnter = () => {
    if (inputs.isValid) {
      setEmailLandingStatus(false);
      if (isScreenTimeout) clearTimeout(isScreenTimeout);
      sendEmailRecepit();
    } else {
      setEmailText('Incorrect email. please try again.');
    }
  };
  const node = useRef();

  const toggleAlphaNumericDailpad = e => {
    if (node?.current?.contains(e.target)) {
      // inside click
      return;
    }
    // outside click
    setIsDailpadShowing(true);
  };

  useEffect(() => {
    const iTransactionMessage = {
      CMD: 'EmailReceipt',
      Status: 'Trigger',
    };
    SendMessageToCFD(iTransactionMessage);
    setEmailLandingStatus(true);
    dispatch(cfdActions.setUserActionScreenActive(true));
    document.addEventListener('mousedown', toggleAlphaNumericDailpad);
    return () => {
      document.removeEventListener('mousedown', toggleAlphaNumericDailpad);
    };
  }, []);

  useEffect(() => {
    if (EmailForReceipt.length > 0) {
      if (EmailForReceipt === 'NORECEIPT') {
        if (isScreenTimeout) clearTimeout(isScreenTimeout);
        setEmailLandingStatus(false);
        global?.logger?.info(`[7POS UI] - User choose No receipt from CFD`);
        history.replace({
          pathname: '/payment/success',
          state: { redirection: true, isEmailSent: false },
        });
      } else if (EmailForReceipt === 'EMAILTRIGGER') {
        dispatch(cartActions.setEmailForReceipt(''));
        global?.logger?.info(`[7POS UI] - User Started to enter email ID`);
      } else {
        if (isScreenTimeout) clearTimeout(isScreenTimeout);
        setEmailLandingStatus(false);
        global?.logger?.info(`[7POS UI] - User entered email ID`);
        setInputValues({
          ...inputs,
          email: EmailForReceipt,
          isValid: true,
        });
        sendEmailRecepit();
      }
    }
  }, [EmailForReceipt]);

  const onCopyData = async e => {
    e.preventDefault();
    return false;
  };

  return (
    <>
      <Box h="calc(100vh - 100px)" pt="0.5rem">
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          height="100%"
          bg="rgb(255,255,255)"
        >
          {!isShowSucessMessage && (
            <Flex flexDirection="column">
              <Heading
                textAlign="center"
                justifyContent="center"
                color={
                  EmailText !== 'Email Receipt'
                    ? 'rgb(236, 37, 38)'
                    : 'rgb(44, 47, 53)'
                }
                fontSize="24px"
                m={2}
              >
                {EmailText}
              </Heading>
              <Box ref={node}>
                <Flex
                  className="floating-label"
                  alignItems="center"
                  my={2}
                  w="80%"
                  mx="88px"
                >
                  <Input
                    placeholder=" "
                    type="email"
                    size="lg"
                    mr={4}
                    ref={emailRef}
                    isReadOnly
                    contentEditable={false}
                    _selected={false}
                    onCopy={onCopyData}
                    value={member ? getMaskedEmail(inputs.email) : inputs.email}
                    onFocus={() =>
                      !isDailpadShowing && setIsDailpadShowing(true)
                    }
                    className={`floating-input ${Styles.noselect}`}
                    focusBorderColor="#107f62"
                  />
                  <label>Email Address</label>
                </Flex>
                {isDailpadShowing && (
                  <AlphaNumericDailpad
                    style={{
                      position: 'fixed',
                      bottom: '160px',
                      maxWidth: '63.80%',
                    }}
                    onEnter={handleEnter}
                    onKeyPress={handleKeyPress}
                  />
                )}
              </Box>
            </Flex>
          )}
          {isShowSucessMessage && (
            <>
              <Flex
                flexDirection="column"
                aliginItems="center"
                justifyContent="space-between"
                mt="100px"
                mx="177px"
                height="200px"
              >
                <Flex
                  flexDirection="column"
                  alignItems="center"
                  justifyContent="center"
                  mt="10px"
                >
                  <Heading
                    color="rgb(67, 69, 80)"
                    justifyContent="center"
                    fontSize="24px"
                    fontFamily="Roboto-Bold"
                    fontWeight="bold"
                    textAlign="center"
                    my="30px"
                  >
                    Receipt Successfully Sent!
                  </Heading>
                  <img
                    src={Icon_conf}
                    height="60px"
                    width="60px"
                    alt="success"
                  />
                  <Text
                    mt="20px"
                    color="rgb(16, 127, 98)"
                    fontSize="18px"
                    fontWeight="bold"
                    alignItems="center"
                    justifyContent="center"
                  >
                    The receipt has been sent to
                  </Text>
                  <Text
                    color="rgb(16, 127, 98)"
                    fontSize="18px"
                    fontWeight="bold"
                    alignItems="center"
                    justifyContent="center"
                  >
                    the email address
                  </Text>
                </Flex>
              </Flex>
              <Box display="block" textAlign="right" p="2rem" w="100%">
                <ExitButton onClick={onExitEmailSuccess} />
              </Box>
            </>
          )}
          {/* !isDailpadShowing && */ !isShowSucessMessage && (
            <Button
              alignSelf="flex-end"
              onClick={onExitFromEmailReceiptScreen}
              className={Styles.exitButton}
              mb={50}
              mr={15}
            >
              <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
                EXIT
              </Text>
            </Button>
          )}
        </Flex>
      </Box>
    </>
  );
};

export default EmailReceipt;
