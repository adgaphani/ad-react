/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Box } from '@chakra-ui/react';
import {
  currencyFixed,
  getScreenTaxDetails,
  getTaxAssesments,
} from '../../../../../Utils/appUtils';
import { createTaxObject } from '../../../../../Utils/paymentUtils';
import PaymentDetailValue from './paymentDetailValue';
import { SendMessageToCFD } from '../../../../../Communication';

const PartialPayment = props => {
  const {
    isTransactionVoid,
    isTransactionRefund,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    taxDeductionAmount,
    taxInfo,
    isCanada,
    stateCode,
  } = useSelector(state => ({
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    taxInfo: state.cart.taxInfo,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    stateCode: state.main.storeDetails?.address?.state,
  }));

  const taxAssessments = createTaxObject(
    props?.taxData,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    isTransactionRefund || isTransactionVoid
  );
  const salesTaxValue = getScreenTaxDetails(
    taxAssessments,
    props?.taxData,
    isTransactionRefund || isTransactionVoid,
    taxableBeforeEBTExempt,
    taxBeforeEBTExempt,
    stateCode
  );
  useEffect(() => {
    if (!props.allPayments.length > 0) return;
    const itotalDetails = {
      finalsubTotalPrice: props.subTotal,
      finalTotalPrice: props.balanceDue,
      totalPromotionPrice: props.discount,
      totalDue: props.total,
      PaymentMediaList: props.allPayments,
      taxDeductionAmount,
      // TODO: Check Cashback flow partial payment
      //  CashBack: props.cashBack,
    };
    let TaxDetails = Object.keys(salesTaxValue).map(key => ({
      amount: Number(salesTaxValue[key]),
      description: key,
    }));
    if (isCanada) {
      TaxDetails = getTaxAssesments(taxInfo).map(item => ({
        description: `${item.description} on ${item.displayTaxableAmount}`,
        amount: Number(item.taxAmount).toFixed(2),
      }));
    }
    const iTransactionMessage = {
      CMD: 'UpdateTransaction',
      TaxInfo: props.taxData,
      TaxDetails,
      TotalDetails: itotalDetails,
      MemberInfo: props.member,
      TransactionType: isTransactionVoid
        ? 'Void'
        : isTransactionRefund
        ? 'Refund'
        : 'Sale',
    };
    SendMessageToCFD(iTransactionMessage);
    return () => {};
  }, [props]);

  return (
    <Box px={4}>
      {!!props?.totalBtlDeposit && (
        <PaymentDetailValue
          label="Total Btl Dep-N"
          value={parseFloat(props?.totalBtlDeposit).toFixed(2)}
        />
      )}
      <PaymentDetailValue
        label="Subtotal"
        value={currencyFixed(props.subTotal)}
      />
      {props.discount ? (
        <PaymentDetailValue
          label="Discount(s)"
          valueColor="#ec2526"
          value={
            `${
              isTransactionVoid || isTransactionRefund
                ? currencyFixed(props.discount)
                : `-${currencyFixed(props.discount)}`
            }` || '0.00'
          }
        />
      ) : (
        ''
      )}
      {!isCanada &&
        Object.keys(salesTaxValue).map((key, index) => (
          <PaymentDetailValue
            key={index}
            label={key}
            value={salesTaxValue[key]}
          />
        ))}

      {isCanada &&
        getTaxAssesments(taxInfo).map((item, index) => (
          <PaymentDetailValue
            key={index}
            label={`${item.description} on ${item.displayTaxableAmount}`}
            value={Number(item.taxAmount).toFixed(2)}
          />
        ))}
      {props.allPayments.length > 0 && (
        <>
          {props.allPayments.map((p, index) => (
            <PaymentDetailValue
              key={index}
              // label={p.paymentMediaType}
              label={`${p?.receiptDetails?.cardName} ${
                p?.receiptDetails?.cardName?.toLowerCase().includes('debit') ||
                p?.receiptDetails?.cardName?.toLowerCase().includes('credit')
                  ? 'Card'
                  : ''
              }`}
              value={p.payment.amount.toFixed(2)}
            />
          ))}
        </>
      )}
      <PaymentDetailValue
        label="Total Due"
        value={`${currencyFixed(props.total) || '0.00'}`}
      />
      <PaymentDetailValue
        label="Balance Due"
        variant="bold"
        value={`$${currencyFixed(props.balanceDue) || '$0.00'}`}
      />
    </Box>
  );
};

export default PartialPayment;
