import React from 'react';
import { Flex, Text, Box } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import ExitButton from '../../../../components/POS/ExitButton';
import Icon_twarning from '../../../../Icons/Icon_twarning.svg';

const FifthMediaError = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const goBack = () => {
    dispatch(dailpadActions.resetDailpadState());
    history.push('/payment');
  };
  return (
    <Box
      height="calc(100vh - 128px)"
      paddingTop="0.5rem"
      paddingBottom="0.5rem"
    >
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex
          alignItems="center"
          justifyContent="center"
          pl="0.5rem"
          bg="rgb(255, 255, 255)"
          height="100%"
          flexDirection="column"
        >
          <img
            src={Icon_twarning}
            alt="Warning_Icon"
            height="48px"
            width="54px"
          />
          <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
            <Text color="rgb(16, 127, 98)" fontSize="18px">
              5TH MEDIA MUST COMPLETE THE SALE.
            </Text>
            <Text color="rgb(16, 127, 98)" fontSize="18px">
              <b>MEDIA HAS INSUFFICIENT FUNDS.</b>
            </Text>
            <Text color="rgb(16, 127, 98)" fontSize="18px">
              SELECT ANOTHER FORM OF PAYMENT.
            </Text>
          </Flex>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={goBack} />
        </Box>
      </Flex>
    </Box>
  );
};

export default FifthMediaError;
