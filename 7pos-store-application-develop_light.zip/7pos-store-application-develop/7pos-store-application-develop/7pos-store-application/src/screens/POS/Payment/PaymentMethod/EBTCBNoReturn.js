import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useContext } from 'react';
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
// import { updateCacheHardTotals } from '7pos-hardtotals';
import { Button } from '../../../../components/Common/Buttons';
import { useSoundToast } from '../../../../hooks';
import Keypad from '../../../../components/Common/DailPad/Keypad/Keypad';
import Icon_Warning from '../../../../Icons/Icon_Warning.svg';
// import Notifications from '../../../../components/POS/Notifications/Notifications';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { cartActions } from '../../../../slices/cart.slice';
import { socketActions } from '../../../../slices/socket.slice';
import {
  handlePayRequest,
  paymentRecepitRequest,
} from '../../../../Utils/paymentUtils';
import { SendMessageToCFD } from '../../../../Communication';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { cfdActions } from '../../../../slices/cfd.slice';
import { fetchEmailReceipt } from '../../../../api/payment/fetchEmailReceipt';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import { getPriceDetails } from '../../../../Utils/cartUtils';
import { getDVR } from '../../../../hardware/dvr';
// import { print_failure_message } from '../../../../constants';

export default function EBTCBNoReturn() {
  const history = useHistory();
  const dispatch = useDispatch();
  // const [ws] = useContext(WebSocketContext);
  const {
    member,
    items,
    transactionId,
    cartItems,
    taxInfo,
    storeDetails,
    UserActionScreenActive,
    user,
    paymentDetails,
    deviceInfo,
    config,
    basketPromo,
    isTransactionVoid,
    paymentHistory,
    paymentMediaList,
    transInfo,
    allPayments,
    isTransactionRefund,
    paymentTransactionId,
    cartChangeTrial,
    runningTotal,
    loadCardMediaList,
    tranAgeVerifyInfo,
    mediaAbortedPaymentList,
    transactionComments,
    transactionStartTime,
    cashBack,
    channel,
  } = useSelector(state => ({
    member: state.cart.member,
    items: state.cart.items,
    transactionId: state.cart.transactionId,
    cartItems: state.cart.cartItems,
    taxInfo: state.cart.taxInfo,
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
    paymentDetails: state.cart.paymentDetails,
    deviceInfo: state.main.deviceInfo,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    config: state.main.configuration,
    basketPromo: state.cart.basketPromo,
    isTransactionVoid: state.cart.isTransactionVoid,
    paymentHistory: state.cart.paymentHistory,
    paymentMediaList: state.cart.paymentMediaList,
    transInfo: state.cart.transDetails,
    allPayments: state.cart.allPayments,
    isTransactionRefund: state.cart.isTransactionRefund,
    paymentTransactionId: state.cart.paymentTransactionId,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    loadCardMediaList: state.cart.loadCardMediaList,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    transactionComments: state.cart.transactionComments,
    transactionStartTime: state.cart.transactionStartTime,
    cashBack: state.socket.cashBack,
    channel: state.main.channel,
  }));
  const [ws] = useContext(WebSocketContext);
  const taxData = taxInfo;
  const toast = useSoundToast();
  // Promo changes
  const { finalsubTotalPrice, totalPrice, finalTotalPrice } = getPriceDetails(
    cartItems,
    taxData,
    isTransactionVoid || isTransactionRefund
  );

  useEffect(
    () =>
      function cleanup() {
        dispatch(dailpadActions.resetDailpadState());
      }
  );

  const printRecepitData = async type => {
    const paymentReqdata = paymentRecepitRequest({
      storeDetails,
      items,
      transInfo,
      paymentDetails,
      deviceInfo,
      user,
      transactionId,
      // paymentInfo: { paymentMethod, enteredCash }, //pending
      taxInfo,
      paymentHistory,
      paymentMediaList,
      transactionType: type,
      allPayments,
      member,
      basketPromo,
      isTransactionRefund,
      isTransactionVoid,
      config,
      loadCardMediaList,
      mediaAbortedPaymentList,
    });
    try {
      paymentReqdata.receiptType = 'PRINT';
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
    } catch (error) {
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        global?.logger?.error(`[7POS UI] - Print receipt API Failure`);
        toast({
          description: errorMessage.message,
          status: 'error',
          duration: 5000,
          position: 'top',
        });
      } else {
        toast({
          description: 'Receipt could not be printed. Please try again',
          status: 'error',
          duration: 5000,
          position: 'top',
        });
      }
    }
  };

  const onAbortTrans = async () => {
    if (UserActionScreenActive) return;
    if (cartItems.length === 0) return;
    dispatch(socketActions.reset());
    let startTime = transactionStartTime;
    if (transactionStartTime === '') {
      startTime = `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`;
      dispatch(cartActions.setTransactionStartTime(startTime));
    }

    const isAbortTransaction = true;
    const abortRequest = handlePayRequest({
      items,
      storeDetails,
      user,
      taxInfo,
      deviceInfo,
      member,
      transactionId,
      finalsubTotalPrice,
      finalTotalPrice,
      totalPrice,
      transactionStartTime: startTime,
      paymentDetails,
      isTransactionVoid,
      isTransactionRefund,
      paymentTransactionId,
      tranAgeVerifyInfo,
      basketPromo,
      cartChangeTrial,
      runningTotal,
      loadCardMediaList,
      isAbortTransaction,
      paymentHistory,
      allPayments,
      transactionComments,
    });
    abortRequest.transactionHeaderInfo.transactionStatus = 'ABORTED';
    // For abort transaction no need add tax to running total
    abortRequest.transactionDetails.runningTotal = Number(runningTotal) / 100;
    const request = JSON.stringify(abortRequest);
    /* await updateCacheHardTotals(request); */
    const abortTransRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'PAYMENT',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PAYMENT',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${request}`,
      },
    };
    global?.logger?.info(
      `[7POS UI] - pay request(EBTCB return)  ${JSON.stringify(
        abortTransRequest
      )}`
    );
    dispatch(cartActions.setPaymentTriggerStatus(true));
    ws.socket?.send(
      '/app/pinpad/payment',
      {},
      JSON.stringify(abortTransRequest)
    );
    if (allPayments && allPayments.length) {
      printRecepitData('abort');
      const abortTransRequestWithPayments = appIntegrationRequest({
        type: 'Abort',
        correlationId: paymentTransactionId,
      });
      ws.socket?.send(
        '/app/transaction',
        {},
        JSON.stringify(abortTransRequestWithPayments)
      );
    }
    getDVR().endTransaction(
      allPayments,
      cashBack,
      config,
      deviceInfo,
      items,
      loadCardMediaList,
      member,
      paymentDetails,
      transactionId,
      'Aborted',
      'abort',
      user
    );

    const iTransactionMessage = {
      CMD: 'TransactionComplete',
      Status: 'Aborted',
      CFDRefreshTime: config?.storeConfig?.CFDRefreshTime,
    };
    SendMessageToCFD(iTransactionMessage);
    dispatch(cfdActions.setAltIDUserReset(false));
    dispatch(cfdActions.setAltIDUserTrigger(false));

    // setIsAbort(true);
    setTimeout(() => {
      dispatch(cartActions.emptyCart());
      dispatch(socketActions.setCashBack(null));
      // setIsAbort(false);
      history.replace({ pathname: '/home', state: { reset: true } });
    }, 5000);
  };

  const onExit = () => {
    dispatch(dailpadActions.resetDailpadState());
    onAbortTrans();
    history.push('/home');
    // history.goBack();
  };

  return (
    <>
      {/* <Notifications /> */}
      <Box pr="0.5rem">
        <Keypad defaultValue="" onEnter={console.log} />
      </Box>
      <Box bg="rgb(255, 255, 255)" p={0}>
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          height="100%"
        >
          <Flex flexDirection="column">
            <Flex justifyContent="center" margin="15px">
              <img
                src={Icon_Warning}
                height="80px"
                width="80px"
                alt="success"
              />
            </Flex>
            <Text
              color="rgb(44, 47, 53)"
              fontSize="16px"
              fontFamily="Roboto-Medium"
              lineHeight="30px"
              textAlign="center"
              marginTop="15px"
            >
              Cannot return items using an <strong>EBT/CB card</strong>,
              transaction not allowed.
            </Text>
          </Flex>
          <Button
            alignSelf="flex-end"
            onClick={onExit}
            borderRadius="3px !important"
            width="90px"
            height="40px"
            background="rgb(255, 255, 255)"
            border="1px solid rgb(91, 97, 107)"
            mb={15}
            mr={15}
          >
            <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
              CANCEL
            </Text>
          </Button>
        </Flex>
      </Box>
    </>
  );
}
