import React, { useContext, useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Flex, Box, Text, Heading } from '@chakra-ui/react';
import Styles from './paymentMethodTypes.module.css';
import cash from '../../../../Icons/cash.svg';
import Icon_EBT from '../../../../Icons/Icon_EBT.svg';
import {
  MoExColorIcon,
  usFlagIcon,
  caFlagIcon,
  BBucksIcons,
} from '../../../../Icons';
import pinpad from '../../../../Icons/pinpad.svg';
import { AppContext } from '../../../../AppContext';
import { cartActions } from '../../../../slices/cart.slice';
import { useSoundToast, useSafe } from '../../../../hooks';
import ExitButton from '../../../../components/POS/ExitButton';

const PaymentMethodTypes = ({
  onCashPayment,
  handlePay,
  onManualEbt,
  isCashOnly = false,
  disableMoneyExchange,
  disableBBucks,
  disableOtherMedia,
  goBack,
  disableExitButton,
}) => {
  const dispatch = useDispatch();
  const { keyPressSound } = useContext(AppContext);
  const history = useHistory();
  const {
    storeDetails,
    pinpadResetInProgress,
    mediaConfig,
    isOtherMediaScreenActive,
    currencyConversion,
    isVault,
    items,
    disablePinpadForreset,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    pinpadResetInProgress: state.main.pinpadResetInProgress,
    mediaConfig: state.main.mediaConfig,
    isOtherMediaScreenActive: state.cart.isOtherMediaScreenActive,
    currencyConversion: state.main.currencyConversion,
    isVault: state.cart.safeDropType === 'vaultDrop',
    items: state.cart.items,
    disablePinpadForreset: state.main.disablePinpadForreset,
  }));
  const { SetVaultCurreny } = useSafe();
  const [disablePinPad, setDisablePinPad] = useState(null);
  const [disableManualEBT, setDisableManualEBT] = useState(false);
  const [disableCardPayment, setDisableCardOption] = useState(false);
  const [mediaHeading, setMediaheading] = useState('Payment Methods');
  const isCanadaStore = () => storeDetails?.address?.country === 'CA';
  const toast = useSoundToast();

  // #7801 added exchange rate validation before proceed tender
  const onErrorCashPayment = () => {
    toast({
      description: 'Invalid exchange rate',
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };

  const onUSCashPayment = () => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (isVault) SetVaultCurreny('USD');
    onCashPayment('usd');
  };

  const onBBucksPress = () => {
    if (disableBBucks) return;
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    onCashPayment('bbucks');
  };

  const onOtherMediaClick = () => {
    dispatch(cartActions.setOtherMediaScreenStatus(true));
    setMediaheading('Other Media Selection');
  };

  // #6321 reset screen heading
  const onClickExit = () => {
    if (isOtherMediaScreenActive) {
      setMediaheading('Payment Methods');
    }
    goBack();
  };

  const iButtonGap = mediaConfig?.groups?.length
    ? 50 / mediaConfig?.groups?.length
    : 10;
  const onOtheMediaPayment = MediaInfo => {
    dispatch(cartActions.setOtherMediaInfo({ ...MediaInfo }));
    onCashPayment('otMedia');
  };

  // #6321 reset heading on PIPO
  useEffect(() => {
    if (!isOtherMediaScreenActive) {
      setMediaheading('Payment Methods');
    }
  }, [isOtherMediaScreenActive]);

  // #5160 disable manual EBT if ebt not enable store
  useEffect(() => {
    if (
      storeDetails &&
      storeDetails?.ebtSetting &&
      (!storeDetails?.ebtSetting?.isEBTEnabled ||
        !storeDetails?.ebtSetting?.fnsNumber ||
        storeDetails?.ebtSetting?.fnsNumber === null)
    ) {
      setDisableManualEBT(true);
    }
  }, []);

  useEffect(() => {
    if (pinpadResetInProgress || disablePinpadForreset) {
      Logger.info(
        `PinPad will be disabled due to schedule pinpad reset ${pinpadResetInProgress} and ${disablePinpadForreset}`
      );
      if (!disablePinPad) setDisablePinPad(true);
    } else {
      setDisablePinPad(false);
    }
    return () => {};
  }, [pinpadResetInProgress, disablePinpadForreset]);

  // #7324 disable card payments
  useEffect(() => {
    const FuelItem = items?.find(item => item.isFuel);
    if (FuelItem) {
      const {
        metaInfo: { isRestInFuel },
      } = FuelItem;
      if (isRestInFuel) setDisableCardOption(true);
    }
  }, []);

  return (
    <Flex flexDirection="column" justifyContent="space-between" height="100%">
      <Flex justify="center" alignItems="center" direction="column">
        <Heading
          textAlign="center"
          justifyContent="center"
          mt="20px"
          mb="30px"
          color="rgb(44, 47, 53)"
          fontSize="24px"
          fontWeight="bold"
          fontFamily="Roboto-Bold"
        >
          {mediaHeading}
        </Heading>
        {!isOtherMediaScreenActive ? (
          <>
            <Flex justify="center" alignItems="center" direction="row">
              <Box
                className={`${Styles.paymentMethodButton} ${
                  isCanadaStore() ? Styles.canadaCash : ''
                }`}
                mb={isCanadaStore() ? '30px' : '10px'}
                onClick={() => {
                  keyPressSound
                    ?.play?.()
                    .catch(e => console.log('Sound error', e));
                  onCashPayment();
                }}
              >
                <Flex
                  justifyContent="center"
                  alignItems="center"
                  direction={isCanadaStore() ? 'column' : 'row'}
                >
                  <img src={isCanadaStore() ? caFlagIcon : cash} alt="cash" />
                  <Text
                    className={`${Styles.paymentMethodText} ${
                      isCanadaStore() ? Styles.canadaCashText : ''
                    }`}
                  >
                    Cash
                  </Text>
                </Flex>
              </Box>
              {isCanadaStore() && (
                <Box
                  className={`${Styles.paymentMethodButton} ${
                    isCanadaStore() ? Styles.canadaCash : ''
                  }`}
                  mb={isCanadaStore() ? '30px' : '10px'}
                  onClick={() => {
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                    if (!currencyConversion || Number(currencyConversion) <= 0)
                      onErrorCashPayment();
                    else onUSCashPayment();
                  }}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="column"
                  >
                    <img src={usFlagIcon} alt="cash" />
                    <Text
                      className={`${Styles.paymentMethodText} ${
                        isCanadaStore() ? Styles.canadaCashText : ''
                      }`}
                    >
                      Cash
                    </Text>
                  </Flex>
                </Box>
              )}
            </Flex>
            <Flex justify="center" alignItems="center" direction="row">
              <Box
                className={`${Styles.paymentMethodButton} ${
                  isCanadaStore() ? Styles.ePinpad : ''
                } ${
                  disablePinPad ||
                  isCashOnly ||
                  disableCardPayment ||
                  disablePinpadForreset
                    ? Styles.disabled
                    : ''
                }`}
                mb={isCanadaStore() ? '30px' : '10px'}
                onClick={() => {
                  if (disablePinPad || disablePinpadForreset) return;
                  keyPressSound
                    ?.play?.()
                    .catch(e => console.log('Sound error', e));
                  handlePay();
                }}
              >
                <Flex
                  justifyContent="center"
                  alignItems="center"
                  direction={isCanadaStore() ? 'column' : 'row'}
                >
                  <img src={pinpad} alt="pinpad" />
                  <Text className={Styles.paymentMethodText}>
                    Pinpad{isCanadaStore() ? '' : `/Wallet`}
                  </Text>
                </Flex>
              </Box>
              {isCanadaStore() && (
                <Box
                  className={`${Styles.paymentMethodButton} ${
                    Styles.canadaCash
                  } ${Styles.moExchange} ${
                    disableMoneyExchange ? Styles.disabled : ''
                  }`}
                  mb={isCanadaStore() ? '30px' : '10px'}
                  onClick={() => {
                    if (disableMoneyExchange) return;
                    history.push({
                      pathname: '/payment/currencyConverter',
                      search: `?itemId=${Date.now()}`,
                      route: '/payment',
                    });
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                  }}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="column"
                  >
                    <img src={MoExColorIcon} alt="Media Exchange" />
                    <Text
                      className={`${Styles.paymentMethodText} ${Styles.mediaExchangeText}`}
                    >
                      Media Exchange
                    </Text>
                  </Flex>
                </Box>
              )}
            </Flex>
            {!isCanadaStore() && (
              <>
                <Box
                  className={[
                    Styles.paymentMethodButton,
                    disablePinPad ||
                    isCashOnly ||
                    disableManualEBT ||
                    disableCardPayment ||
                    disablePinpadForreset
                      ? Styles.disabled
                      : '',
                  ].join(' ')}
                  mb={isCanadaStore() ? '30px' : '10px'}
                  onClick={() => {
                    if (disablePinPad || disablePinpadForreset) return;
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                    onManualEbt();
                  }}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="row"
                  >
                    <img src={Icon_EBT} alt="EBT" />
                    <Text className={Styles.paymentMethodText}>Manual EBT</Text>
                  </Flex>
                </Box>
                <Box
                  className={[
                    Styles.paymentMethodButton,
                    disableOtherMedia || disableCardPayment
                      ? Styles.disabled
                      : '',
                  ].join(' ')}
                  onClick={() => {
                    if (disableOtherMedia) return;
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                    onOtherMediaClick();
                  }}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="row"
                  >
                    <Text className={Styles.paymentMethodText}>
                      Other Media
                    </Text>
                  </Flex>
                </Box>
              </>
            )}

            {isCanadaStore() && (
              <Flex justify="center" alignItems="center" direction="row">
                <Box
                  className={`${Styles.paymentMethodButton} ${
                    Styles.canadaCash
                  }  ${Styles.eBucks} ${
                    disableBBucks || disableCardPayment ? Styles.disabled : ''
                  }`}
                  mb={isCanadaStore() ? '30px' : '10px'}
                  onClick={onBBucksPress}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="column"
                  >
                    <img src={BBucksIcons} alt="cash" />
                    <Text
                      className={`${Styles.paymentMethodText} ${Styles.canadaCashText} ${Styles.eBucksText}`}
                    >
                      B Bucks
                    </Text>
                  </Flex>
                </Box>

                <Box
                  className={`${Styles.paymentMethodButton} ${
                    Styles.canadaCash
                  }  ${Styles.otherMedia}  ${
                    disableOtherMedia ? Styles.disabled : ''
                  }`}
                  mb={isCanadaStore() ? '30px' : '10px'}
                  onClick={() => {
                    if (disableOtherMedia) return;
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                    onOtherMediaClick();
                  }}
                >
                  <Flex
                    justifyContent="center"
                    alignItems="center"
                    direction="column"
                  >
                    <Text className={Styles.paymentMethodText}>Other </Text>
                    <Text className={Styles.paymentMethodText}>Media</Text>
                  </Flex>
                </Box>
              </Flex>
            )}
          </>
        ) : (
          <>
            {mediaConfig &&
              mediaConfig?.groups?.map((item, keyindex) => (
                <Flex
                  justify="center"
                  alignItems="center"
                  direction="row"
                  key={keyindex}
                >
                  <Box
                    className={[Styles.otherMediaButton].join(' ')}
                    mb={`${iButtonGap}px`}
                    onClick={() => {
                      keyPressSound
                        ?.play?.()
                        .catch(e => console.log('Sound error', e));
                      onOtheMediaPayment(item);
                    }}
                  >
                    <Flex
                      justifyContent="center"
                      alignItems="center"
                      direction="row"
                    >
                      <Text className={`${Styles.paymentMethodText} `}>
                        {item?.label}
                      </Text>
                    </Flex>
                  </Box>
                </Flex>
              ))}
          </>
        )}
      </Flex>
      {!disableExitButton && (
        <Box display="block" textAlign="right" pr="1rem" pt="1rem">
          <ExitButton onClick={onClickExit} />
        </Box>
      )}
    </Flex>
  );
};

PaymentMethodTypes.defaultTypes = {
  onCashPayment: () => null,
  handlePay: () => null,
  onManualEbt: () => null,
};

export default PaymentMethodTypes;
