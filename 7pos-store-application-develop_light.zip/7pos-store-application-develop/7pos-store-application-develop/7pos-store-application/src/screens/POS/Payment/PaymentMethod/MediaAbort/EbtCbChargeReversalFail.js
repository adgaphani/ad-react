import { Flex, Text, Box, Button } from '@chakra-ui/react';
import React from 'react';
import { useLocation, useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import Icon_twarning from '../../../../../Icons/Icon_twarning.svg';
import { cartActions } from '../../../../../slices/cart.slice';

const helpDeskNumber = '1-800-987-0711';
// eslint-disable-next-line arrow-body-style
const EbtCbChargeReversalFail = () => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const { cbAmount } = location.state;
  const onAbortTrans = async () => {
    dispatch(cartActions.setPrintChargeReversalMsg(true));
    dispatch(cartActions.setTransactionAborted(true));
    return history.push('/home');
  };
  const onExit = () => {
    onAbortTrans();
  };
  return (
    <Flex
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="calc(100vh - 128px)"
      flexDirection="column"
      w="100%"
    >
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex
          alignItems="center"
          justifyContent="center"
          pl="0.5rem"
          bg="rgb(255, 255, 255)"
          height="100%"
          flexDirection="column"
        >
          <img
            src={Icon_twarning}
            alt="Warning_Icon"
            height="48px"
            width="54px"
          />
          <Flex
            direction="column"
            mt="1.5rem"
            mb="1rem"
            alignItems="center"
            fontSize="20px"
            fontWeight="900"
          >
            <Text>Unable to Reverse the Following Charges</Text>
            <Text>${cbAmount}</Text>
            <Text color="#107f62">Reprint Receipt and Give</Text>
            <Text color="#107f62">to Store Operator. Call</Text>
            <Text color="#107f62">RIS Help Desk {helpDeskNumber}</Text>
            <Text color="#107f62">to Report Reversal Failure</Text>
          </Flex>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <Button
            alignSelf="flex-end"
            onClick={onExit}
            width="90px"
            className="btn secondaryButton"
            height="40px"
            mt={15}
          >
            <Text
              fontSize="18px"
              fontFamily="Roboto-Bold"
              color="rgb(91, 97, 107)"
              fontWeight="bold"
            >
              Exit
            </Text>
          </Button>
        </Box>
      </Flex>
    </Flex>
  );
};

export default EbtCbChargeReversalFail;
