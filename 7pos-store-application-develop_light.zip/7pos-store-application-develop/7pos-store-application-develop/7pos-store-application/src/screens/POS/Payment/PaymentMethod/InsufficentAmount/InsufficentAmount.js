/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/prop-types */
import { Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '../../../../../components/Common/Buttons';
import { INSUFFICENT_PAYMENT_HEADING } from '../../../../../constants';
import Icon_twarning from '../../../../../Icons/Icon_twarning.svg';
import { setShowNotifications } from '../../../../../slices/notifications.slice';
import { cartActions } from '../../../../../slices/cart.slice';
import Styles from '../paymentMethod.module.css';

const InsuffcientAmount = ({
  handleInSuffceintContinue,
  handleInSuffceintCancel,
}) => {
  const dispatch = useDispatch();
  const { statusCode, InSufficentCardDetails } = useSelector(state => ({
    statusCode: state.cart.statusCode,
    InSufficentCardDetails: state.cart.InSufficentCardDetails,
  }));

  useEffect(() => {
    dispatch(setShowNotifications(false));
    dispatch(cartActions.setPaymentTriggerStatus(true));
    return () => {};
  }, []);

  useEffect(() => {
    if (statusCode !== 11 || !InSufficentCardDetails?.CardbalanceAmount) {
      global?.logger?.info(
        `[7POS UI] - InsuffcientAmount redirect to payment screen
         due to status code:${statusCode} or amount.`
      );
      dispatch(setShowNotifications(true));
      dispatch(cartActions.setStatusCode(null));
      dispatch(cartActions.setInSufficentCardDetails({}));
      history.replace('/payment');
    }
    return () => {};
  }, [statusCode, InSufficentCardDetails]);

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="100%"
      flexDirection="column"
    >
      <img src={Icon_twarning} height="48px" width="54px" />
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Bold"
        fontSize="24px"
        fontWeight="bold"
        textAlign="center"
        mt={6}
      >
        {INSUFFICENT_PAYMENT_HEADING}
        <span className={Styles.balanceAmount}>
          &nbsp;${InSufficentCardDetails?.CardbalanceAmount}
        </span>
      </Text>
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Regular"
        fontSize="18px"
        fontWeight="normal"
        textAlign="center"
        mx="5rem"
      >
        Additional ${InSufficentCardDetails?.RemainingAmount} must be tendered.
        Press YES to continue, or press NO to select another form of payment.
      </Text>
      <Flex direction="row" mt="2.5rem">
        <Button
          className="btn primaryButton"
          borderRadius="3px"
          height="50px"
          width="140px"
          mr="1rem"
          _hover={{ bg: '#107f62' }}
          onClick={handleInSuffceintContinue}
        >
          <Text>YES</Text>
        </Button>
        <Button
          className="btn secondaryButton"
          // border="1px solid rgb(77, 184, 86)"
          height="50px"
          width="140px"
          mr={3}
          onClick={handleInSuffceintCancel}
        >
          <Text>NO</Text>
        </Button>
      </Flex>
    </Flex>
  );
};

export default InsuffcientAmount;
