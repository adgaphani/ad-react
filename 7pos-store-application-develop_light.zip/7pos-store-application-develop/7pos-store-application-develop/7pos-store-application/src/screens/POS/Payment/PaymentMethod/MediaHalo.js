/* eslint-disable react/prop-types */
import React from 'react';
import { Flex, Box, Text, Heading } from '@chakra-ui/react';
import warrningSymbol from '../../../../Icons/Icon_twarning.svg';
import ExitButton from '../../../../components/POS/ExitButton';

function MediaHalo({ onExit, MSG }) {
  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="calc(100vh - 300px)"
      background="rgb(255,255,255)"
      boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
      my="0.6rem"
      ml="0.5rem"
      mr="0.6rem"
    >
      <Flex
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        mt="20%"
      >
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
        >
          <img src={warrningSymbol} alt="warning" />
        </Flex>
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
          mt="2%"
        >
          <Heading
            textAlign="center"
            justifyContent="center"
            style={{
              width: '400px',
              height: '64px',
              color: 'rgb(44, 47, 53)',
              fontSize: '20px',
              fontFamily: 'Roboto-Bold',
              fontWeight: 'bold',
              textAlign: 'center',
              lineHeight: '32px',
            }}
          >
            Select New Media
          </Heading>
          <Text
            color="#107f62"
            fontFamily="Roboto-Medium"
            fontSize="20px"
            fontWeight="bold"
          >
            {MSG}
          </Text>
        </Flex>
      </Flex>

      <Box display="block" textAlign="right" p="1rem" w="100%">
        <ExitButton onClick={onExit} />
      </Box>
    </Flex>
  );
}
export default MediaHalo;
