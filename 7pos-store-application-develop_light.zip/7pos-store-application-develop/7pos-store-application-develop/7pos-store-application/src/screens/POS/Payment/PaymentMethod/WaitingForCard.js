import React, { memo, useContext, useEffect } from 'react';
import { Flex, Text, Box } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import ExitButton from '../../../../components/POS/ExitButton';
import Carousal from '../../../../components/POS/Carousal/Carousal';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import Wallet_Icon from '../../../../Icons/Wallet_Icon.svg';
import SpeedwayWallet_icon from '../../../../Icons/SpeedwayWallet_icon.svg';
import Payment_Art from '../../../../Icons/Payment_Art.svg';
import SpeedyPayment_Art from '../../../../Icons/SpeedyPayment_Art.svg';
import { cartActions } from '../../../../slices/cart.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import { SendMessageToCFD } from '../../../../Communication';
import { AppContext } from '../../../../AppContext';

const images = [
  {
    image: `${process.env.PUBLIC_URL}/assets/images/insert.png`,
    name: 'InsertCard',
  },
  {
    image: `${process.env.PUBLIC_URL}/assets/images/swipe.png`,
    name: 'Swipe Card',
  },
  {
    image: `${process.env.PUBLIC_URL}/assets/images/tap.png`,
    name: 'Tap card',
  },
];

const WaitingForCard = () => {
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);
  const {
    // lookupCallProgress,
    paymentTransactionId,
    isCanada,
    iscannedBarcode,
    cardSwiped,
    isSpeedyStore,
  } = useSelector(state => ({
    // lookupCallProgress: state.cart.lookupCallProgress,
    paymentTransactionId: state.cart.paymentTransactionId,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    iscannedBarcode: state.cart.iscannedBarcode,
    cardSwiped: state.socket.cardStatus === 'CARD_READ',
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  const goBack = () => {
    dispatch(cartActions.setPaymentExit(true));
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    dispatch(socketActions.setCardStatus(null));
    showLoader(false);
    const iTransactionMessage = {
      CMD: 'PinpadMessage',
      Status: 'CancelCFDMessage',
    };
    SendMessageToCFD(iTransactionMessage);
    dispatch(setShowNotifications(true));
    showLoader(true);
  };

  useEffect(() => {
    // #6411 make sure notification bar disable on waiting for card swipe screen
    dispatch(setShowNotifications(false));
    showLoader(false);
  }, []);

  const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="100%"
      background="rgb(255,255,255)"
    >
      <Flex
        flexDirection="column"
        alignItems="center"
        height="100%"
        justifyContent="center"
      >
        <Text
          mb={10}
          color="rgb(44, 47, 53)"
          fontSize="24px"
          fontFamily="Roboto-bold"
          fontWeight="bold"
          textAlign="center"
        >
          Please ask Customer to
        </Text>
        <Flex justify="center" alignItems="center" direction="row">
          <Flex justify="center" alignItems="center" direction="column">
            <Text
              mb={10}
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
              fontSize="24px"
            >
              Tap, Swipe or Insert Card to Pay
            </Text>
            <Carousal images={images} />
          </Flex>
          {!isCanada && (
            <Flex justify="center" alignItems="center" direction="column">
              <Flex height="120px">
                <hr border="1px solid" color="#d3d3d3" width="0" />
              </Flex>
              <Text
                border={12}
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-bold"
                fontWeight="bold"
                textAlign="center"
                fontSize="24px"
              >
                or
              </Text>
              <Flex height="120px">
                <hr border="1px solid" color="#d3d3d3" width="0" />
              </Flex>
            </Flex>
          )}
          {!isCanada && (
            <Flex justify="center" alignItems="center" direction="column">
              <Text
                mb={10}
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-bold"
                fontWeight="bold"
                textAlign="center"
                fontSize="24px"
              >
                Scan {isSpeedyStore ? 'Speedway' : '7-Eleven'} Wallet Digital
                Barcode
              </Text>
              <img
                src={isSpeedyStore ? SpeedwayWallet_icon : Wallet_Icon}
                height="180px"
                width="120px"
                alt="Digital Wallet"
              />
            </Flex>
          )}
        </Flex>
        <Flex justify="center" alignItems="center" direction="column">
          <img
            src={isSpeedyStore ? SpeedyPayment_Art : Payment_Art}
            height="100px"
            width="600px"
            alt="Payment Art"
          />
        </Flex>
      </Flex>
      <Box display="block" textAlign="right" p="1rem" w="100%">
        <ExitButton
          onClick={goBack}
          isDisabled={iscannedBarcode || isMemberTrigger || cardSwiped}
        />
      </Box>
    </Flex>
  );
};

export default memo(WaitingForCard);
