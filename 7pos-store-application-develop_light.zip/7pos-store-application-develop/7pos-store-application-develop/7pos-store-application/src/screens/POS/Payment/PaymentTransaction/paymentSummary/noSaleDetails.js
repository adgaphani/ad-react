/* eslint-disable react/prop-types */
/* eslint-disable react/destructuring-assignment */
import React from 'react';
import { Box, Text } from '@chakra-ui/react';
import { currencyFixed } from '../../../../../Utils/appUtils';
import PaymentDetailValue from './paymentDetailValue';
import TransactionComplete from './transactionComplete';

const NoSaleDetails = props => (
  <Box p={4}>
    <Text
      color="rgb(127, 130, 143)"
      fontFamily="Roboto-Medium"
      fontSize="14px"
      fontWeight="500"
      textAlign="center"
      mb="1rem"
    >
      **** NO SALE ****
    </Text>
    {!!props?.totalBtlDeposit && (
      <PaymentDetailValue
        label="Total Btl Dep-N"
        value={parseFloat(props?.totalBtlDeposit).toFixed(2)}
      />
    )}
    <PaymentDetailValue
      label="Subtotal"
      value={currencyFixed(props.subTotal) || '0.00'}
    />
    <PaymentDetailValue
      label="Total"
      value={`$${currencyFixed(props.total) || '0.00'}`}
      variant="bold"
    />
    <TransactionComplete />
  </Box>
);

export default NoSaleDetails;
