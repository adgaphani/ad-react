import moment from 'moment';
import { fetchEmailReceipt } from '../../../../api/payment/fetchEmailReceipt';
import store from '../../../../store';

// const responseData = {
//   messageHeader: {
//     timeStamp: '2021.08.26 12:55:08 CDT',
//     messageType: 'PAYMENT_RESPONSE',
//     source: {
//       sourceType: 'Payment',
//       sourceIdentifier: '1',
//       version: '2020.11',
//     },
//     destination: { destinationType: 'POS', destinationIdentifier: '1' },
//   },
//   messageBody: {
//     message:
//       '{"paymentResponse":{"transactionId":"b4e3c5d0-0696-11ec-9b61-3d5341fe7163","paymentTenderId":"28399029523","transactionType":"SALE","paymentEntryType":"EMV_CONTACT","currency":"CAD","paymentMedia":{"tenderSequenceNumber":1,"payment":{"paymentTenderId":"28399029523","referenceNumber":"84536179274","messageTypeIndicator":null,"systemTraceAuditNumber":"000398","authCode":"O00593","amount":5.93,"shutOffAmount":null,"hostTransactionTime":"210826135458","hostReferenceNumber":"1551327121","signatureThreshold":null,"hostResponseCode":null},"status":"DECLINED","statusCode":266,"displayMessage":"DECLINED - CHIP DECLINE","promptDetails":{"payMethod":"DEBIT"},"paymentMediaNumber":13,"paymentMediaType":"Debit","companyId":"0047","cardId":1506,"reportMaskedPan":"450644******1933","terminalVerificationResult":"8000009000","issuerAuthenticationData":"11111111111111111111","paymentEntryType":"EMV_CONTACT","receiptDetails":{"cardName":"Debit","maskedPan":"************1933","statusCode":266,"statusMessage":"DECLINED","applicationName":"INTERAC","applicationId":"A0000002771010","cryptogram":"AAC 791792A35D0591F4","cardholderVerficationMethod":"OFFLINE_PIN","transactionStatusInformation":"7800","hostTransactionTime":"08/26/2021 13:54:58","recNumber":"000398","cardEntry":"CONTACT/CHIP READ","responseCode":"00/000","posSequenceNumber":"0010010380"}}},"captureSuccess":false,"paymentCallStatus":false,"tenderType":null}',
//   },
// };

export const getDate = () => new Date();
export const getCurrentTime = () =>
  moment(getDate()).format('MM/DD/YYYY h:mm A');

export const getDeclinedReceipts = async (
  responseData,
  paymentTransactionId,
  channel
) => {
  if (responseData?.messageHeader?.messageType !== 'PAYMENT_RESPONSE') return;
  try {
    const { message } = responseData?.messageBody || {};
    const data = JSON.parse(message);
    const { paymentResponse = {} } = data;
    const { paymentMedia } = paymentResponse;
    const {
      receiptDetails = {},
      payment = {},
      terminalVerificationResult,
      hostResponseMessage,
      status,
    } = paymentMedia || {};
    const { auth, main, cart } = store.getState();
    const operatorId = auth.user.userId;
    const {
      address: { streetAddress, city, zip, phone, country },
      storeId,
    } = main.storeDetails;
    const { transactionId: transSeqId } = cart;
    const isPaymentDeclined = status
      ? status?.includes('DECLINED')
      : receiptDetails?.statusMessage?.includes('DECLINED');
    if (country === 'US' || !isPaymentDeclined) return;
    const currentTime = getCurrentTime();
    //
    const {
      cardHolderName,
      cardExpiration,
      invoiceNumber,
      retrievalReferenceNumber,
      staNumber,
      applicationName,
      cryptogram,
      debitAccountType,
      tid,
      cardName,
      cardEntry,
      statusMessage,
      statusCode,
      maskedPan,
      recNumber,
      hostTransactionTime,
      responseCode,
      posSequenceNumber,
      transactionStatusInformation,
      applicationId,
    } = receiptDetails;

    const { amount, authCode, referenceNumber } = payment;
    const receiptData = [];
    const line1 = (col1, col2) => {
      if (col1 && col2) {
        receiptData.push({
          details: col2,
          description: col1,
        });
      }
      return false;
    };
    const line = (col1, val) => {
      if (val) {
        receiptData.push({
          description: col1,
        });
      }
      return false;
    };

    line1(cardName, cardEntry);

    line1(
      statusMessage,
      amount ? `CAD$${Number(amount || 0).toFixed(2)}` : null
    );

    line(cardHolderName);

    line(`CARD EXP: ${cardExpiration}`, cardExpiration);

    line(`INV#: ${invoiceNumber}`, invoiceNumber);

    line(`RREF#: ${retrievalReferenceNumber}`, retrievalReferenceNumber);

    line(`ACCT#: ${maskedPan}`, maskedPan);

    line(`STANUM: ${staNumber}`, staNumber);

    line(`APP NAME: ${applicationName}`, applicationName);

    line(`CRYPTO: ${cryptogram}`, cryptogram);

    line(`AUTH CODE: ${authCode}`, authCode);

    line(`REC#: ${recNumber}`, recNumber);

    line(
      `DECLINE DATETIME: ${hostTransactionTime || currentTime}`,
      hostTransactionTime || currentTime
    );
    if (receiptDetails) {
      line('TRANSACTION TYPE: PURCHASE', true);
    }

    line(`ACCT TYPE: ${debitAccountType}`, debitAccountType);

    // line(`${hostTransactionTime}`, hostTransactionTime);

    line(`STATUS MSG: ${statusMessage}`, statusMessage);

    line(`STATUS CODE: ${statusCode}`, typeof statusCode === 'number');

    line(`RESPONSE CODE: ${responseCode}`, responseCode);

    line(`REF#: ${referenceNumber}`, referenceNumber);

    line(`SEQ#: ${posSequenceNumber}`, posSequenceNumber);

    line(`TSI: ${transactionStatusInformation}`, transactionStatusInformation);

    line(`TVR: ${terminalVerificationResult}`, terminalVerificationResult);

    line(`TID: ${tid}`, tid);

    line(`AID#: ${applicationId}`, applicationId);

    line(`RESPONSE MESSAGE#: ${hostResponseMessage}`, hostResponseMessage);

    const finalResponse = {
      // to: 'koushikreddy.gunapati@7-11.com',
      // subject: 'email subject',
      // receiptType: 'EMAIL',
      receiptType: 'PRINT',
      header: {
        headerLines: [
          '7-ELEVEN',
          streetAddress,
          `${city} ${zip}`,
          `Ph:${phone}`,
          `STORE#:${storeId}`,
          'THANKS FOR SHOPPING',
          '7-ELEVEN',
          cart?.isTransactionRefund || cart?.isTransactionVoid ? '' : 'SALE',
        ],
      },
      paymentDetails: [
        {
          items: receiptData.filter(Boolean),
        },
      ],
      footer: {
        footerLines: [
          'CUSTOMER AGREES TO PAY THE ABOVE',
          'TOTAL AMOUNT ACCORDING TO THE CARD',
          'HOLDERS AGREEMENT',
          'CUSTOMER COPY',
          'Gift Cards and Prepaid Cards are not returnable or exchangeable, except where required by law',
        ],
        footer: [
          'TRY OUR DELI CENTRAL SANDWICHES AND DELICIOUS ENTREES',
          `T#${main.deviceInfo?.id} OP${operatorId} TRN${transSeqId} ${currentTime}`,
        ],
      },
    };
    await fetchEmailReceipt(finalResponse, paymentTransactionId, channel);
    return finalResponse;
  } catch (e) {
    return null;
  }
};
