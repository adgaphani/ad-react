import React, { useEffect } from 'react';
import { Flex, Text, Box } from '@chakra-ui/react';
import { useDispatch } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import ExitButton from '../../../../../components/POS/ExitButton';
import Icon_twarning from '../../../../../Icons/Icon_twarning.svg';
import { socketActions } from '../../../../../slices/socket.slice';
import { cartActions } from '../../../../../slices/cart.slice';
import { setShowNotifications } from '../../../../../slices/notifications.slice';

const MediaRestriction = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const statusCode = location?.state?.statusCode;

  const goBack = () => {
    dispatch(cartActions.setStatusCode(null));
    dispatch(socketActions.setCardStatus(null));
    dispatch(setShowNotifications(true));
    history.replace('/payment');
  };

  useEffect(() => {
    dispatch(setShowNotifications(false));
    if (statusCode === 278) {
      dispatch(cartActions.setEbtPaymentTendered(true));
      dispatch(socketActions.setCardStatus(null));
      dispatch(cartActions.setEBTPaymentIntiateStatus(false));
    }
    return () => {};
  }, []);

  return (
    <Box
      height="calc(100vh - 128px)"
      paddingTop="0.5rem"
      paddingBottom="0.5rem"
    >
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex
          alignItems="center"
          justifyContent="center"
          pl="0.5rem"
          bg="rgb(255, 255, 255)"
          height="100%"
          flexDirection="column"
        >
          <img
            src={Icon_twarning}
            alt="Warning_Icon"
            height="48px"
            width="54px"
          />
          {statusCode === 278 ? (
            <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
              <Text fontSize="18px" fontWeight="bold">
                Please ask customer to select new media.
              </Text>
              <Text fontSize="18px" fontWeight="bold" mb="0.5rem">
                EBT must use first.
              </Text>
              <Text fontSize="18px">
                if EBT is to be used, select &quot;EXIT&quot; at the media
                screen and
              </Text>
              <Text fontSize="18px">start payment with EBT.</Text>
            </Flex>
          ) : statusCode === 275 ? (
            <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
              <Text fontSize="18px" fontWeight="bold">
                Declined.
              </Text>
              <Text fontSize="18px" fontWeight="bold">
                Select new media
              </Text>
              <Text fontSize="18px">
                There are media ineligible items in the transaction and split
                tender
              </Text>
              <Text fontSize="18px">not allowed for void/return.</Text>
              <Text fontSize="18px">
                Remove media ineligible items and complete the transaction.
              </Text>
            </Flex>
          ) : (
            <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
              <Text fontSize="18px" fontWeight="bold">
                Select new media
              </Text>
              <Text fontSize="18px">
                Non foodstamp items in EBT void or return
              </Text>
            </Flex>
          )}
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={goBack} />
        </Box>
      </Flex>
    </Box>
  );
};

export default MediaRestriction;
