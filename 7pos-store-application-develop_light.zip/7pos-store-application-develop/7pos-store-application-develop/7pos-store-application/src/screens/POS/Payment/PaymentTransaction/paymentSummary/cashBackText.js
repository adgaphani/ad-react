/* eslint-disable react/prop-types */
import { Box, Flex, Text } from '@chakra-ui/react';
import React from 'react';

const CashBackText = ({ eventData, dence = false }) => (
  <>
    {!dence ? (
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        alignItems="center"
        px={4}
        pt={2}
        fontSize="16px"
        color="rgb(44, 47, 53)"
        lineHeight="20px"
      >
        <Flex flexDirection="row" alignItems="center">
          <Text fontFamily="Roboto-Medium" fontWeight="500">
            {' '}
            Cashback
          </Text>
        </Flex>
        <Box ml={2} />
        <Box ml={2}>
          <Text
            fontFamily="Roboto-Medium"
            fontWeight="500"
            width="52px"
            textAlign="left"
          >
            {eventData}
          </Text>
        </Box>
      </Flex>
    ) : (
      <Flex justifyContent="space-between" my={2}>
        <Flex flexDirection="row">
          <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
            Change
          </Text>
          <Text
            color="rgb(44, 47, 53)"
            fontSize="15px"
            fontWeight="normal"
            fontFamily="Roboto-regular"
            pl="4px"
          >
            (Cashback)
          </Text>
        </Flex>
        <Text fontSize="15px" fontWeight="bold" fontFamily="Roboto-Bold">
          ${eventData}
        </Text>
      </Flex>
    )}
  </>
);

export default CashBackText;
