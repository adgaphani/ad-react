import React from 'react';
import { Text, Flex } from '@chakra-ui/react';

const TransactionComplete = () => (
  <Flex flexDirection="row" justifyContent="center" alignItems="center" my={5}>
    <Text border="1px solid rgb(44, 47, 53)" height="1px" width="20px" pr={2} />
    <Text
      color="rgb(44, 47, 53)"
      fontSize="14px"
      fontFamily="Roboto-Medium"
      fontWeight="500"
    >
      TRANSACTION COMPLETE
    </Text>
    <Text border="1px solid rgb(44, 47, 53)" height="1px" width="20px" pl={2} />
  </Flex>
);

export default TransactionComplete;
