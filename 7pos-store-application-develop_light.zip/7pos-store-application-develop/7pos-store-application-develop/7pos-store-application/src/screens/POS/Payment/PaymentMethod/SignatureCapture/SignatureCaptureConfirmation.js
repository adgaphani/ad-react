import React from 'react';
import { useSelector } from 'react-redux';
import { Box, Flex, Text, Button } from '@chakra-ui/react';
import ExitButton from '../../../../../components/POS/ExitButton';

import Styles from './SignatureCapture.module.css';

const SignatureCaptureConfirmation = ({
  onAccept,
  reSign,
  printVoucher,
  goBack,
}) => {
  const capturedSignature = useSelector(state => state.cart.capturedSignature);

  return (
    <Box
      height="calc(100vh - 128px)"
      paddingTop="0.5rem"
      paddingBottom="0.5rem"
    >
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex className={Styles.container} pl="0.5rem">
          <Flex direction="column" alignItems="center" mb="20px">
            <Text mb="0.5rem" fontWeight="bold" fontSize="24px">
              <b>Please verify signature</b>
            </Text>
            <Text
              mb="0.5rem"
              fontWeight="bold"
              color="rgb(16, 127, 98)"
              fontSize="24px"
            >
              <b>compared with customer’s</b>
            </Text>
            <Text fontWeight="bold" color="rgb(16, 127, 98)" fontSize="24px">
              <b>signature</b>
            </Text>
          </Flex>
          <Box className={Styles.imgWrap}>
            <Text mt={2} className={Styles.cSignText}>
              CUSTOMER SIGNATURE
            </Text>
            <img height="93px" width="334px" src={capturedSignature} alt="" />
          </Box>
          <Flex className={Styles.btnWrap} py={2}>
            <Button className={Styles.btn} mr="20px" onClick={reSign}>
              <Text>RE-SIGN</Text>
            </Button>
            <Button className={Styles.btn} onClick={printVoucher}>
              <Text>PRINT VOUCHER</Text>
            </Button>
          </Flex>
          <Button
            width="336px"
            height="50px"
            bg="rgb(16, 127, 98)"
            color="#ffffff"
            onClick={onAccept}
          >
            <Text fontFamily="Roboto-Bold" fontWeight="bold">
              ACCEPT
            </Text>
          </Button>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={goBack} />
        </Box>
      </Flex>
    </Box>
  );
};

export default SignatureCaptureConfirmation;
