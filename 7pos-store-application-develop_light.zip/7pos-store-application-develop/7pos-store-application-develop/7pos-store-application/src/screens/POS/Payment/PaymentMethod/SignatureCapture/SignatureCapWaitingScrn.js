import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import ExitButton from '../../../../../components/POS/ExitButton';

const SignatureCapWaitingScrn = ({ goBack }) => (
  <Box height="calc(100vh - 128px)" paddingTop="0.5rem" paddingBottom="0.5rem">
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="100%"
      background="rgb(255,255,255)"
    >
      <Flex
        alignItems="center"
        justifyContent="center"
        pl="0.5rem"
        bg="rgb(255, 255, 255)"
        height="100%"
        flexDirection="column"
      >
        <Flex direction="column" alignItems="center">
          <Text mb="0.5rem" fontWeight="bold" fontSize="24px">
            <b>Waiting for customer to</b>
          </Text>
          <Text fontWeight="bold" color="rgb(16, 127, 98)" fontSize="24px">
            <b>Sign and Press Ok at the CFD</b>
          </Text>
        </Flex>
      </Flex>
      <Box display="block" textAlign="right" p="1rem" w="100%" onClick={goBack}>
        <ExitButton />
      </Box>
    </Flex>
  </Box>
);

export default SignatureCapWaitingScrn;
