import React, { memo, useContext, useEffect } from 'react';
import { Flex, Text, Box } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import posWedge from '@icons/launch_pos.svg';
import ExitButton from '../../../../components/POS/ExitButton';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import Wallet_Icon from '../../../../Icons/Wallet_Icon.svg';
import { cartActions } from '../../../../slices/cart.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import { SendMessageToCFD } from '../../../../Communication';
import { AppContext } from '../../../../AppContext';
import SpeedwayWallet_icon from '../../../../Icons/SpeedwayWallet_icon.svg';
import Carousal from '../../../../components/POS/Carousal/Carousal';

const CardLoadSwipeWait = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);

  const {
    isCanada,
    paymentTransactionId,
    isSpeedyStore,
    iscannedBarcode,
    cardSwiped,
  } = useSelector(state => ({
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    paymentTransactionId: state.cart.paymentTransactionId,
    isSpeedyStore: state.main.isSpeedyStore,
    iscannedBarcode: state.cart.iscannedBarcode,
    cardSwiped: state.socket.cardStatus === 'CARD_READ',
  }));

  const images = [
    {
      image: `${process.env.PUBLIC_URL}/assets/images/insert.png`,
      name: 'InsertCard',
    },
    {
      image: `${process.env.PUBLIC_URL}/assets/images/swipe.png`,
      name: 'Swipe Card',
    },
    {
      image: `${process.env.PUBLIC_URL}/assets/images/tap.png`,
      name: 'Tap card',
    },
  ];

  const resetCardLookUpFlags = () => {
    dispatch(dailpadActions.resetKeypadValue());
    dispatch(cartActions.setCardLoadReset());
  };

  const goBack = () => {
    dispatch(cartActions.setPaymentExit(true));
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    dispatch(socketActions.setCardStatus(null));
    showLoader(false);
    const cancelLoadFromPos = true;
    SendMessageToCFD({
      CMD: 'PrepaidLoadConfirm',
      cancelLoadFromPos,
    });
    resetCardLookUpFlags();
    history.replace('/home');
  };

  useEffect(() => {
    dispatch(setShowNotifications(false));
    showLoader(false);
  }, []);

  const getHeaderText = () => {
    let msg;
    if (isCanada) {
      msg = 'Please Swipe Card at the POS';
    } else {
      msg = 'Please Swipe Card at the POS or Scan Digital Barcode';
    }
    return msg;
  };

  const isMemberTrigger = localStorage.getItem('isMemberTrigger') || false;

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="100%"
      background="rgb(255,255,255)"
    >
      <Flex
        flexDirection="column"
        alignItems="center"
        height="100%"
        justifyContent="center"
      >
        <Text
          mb={10}
          color="rgb(44, 47, 53)"
          fontSize="24px"
          fontFamily="Roboto-bold"
          fontWeight="bold"
          textAlign="center"
        >
          {getHeaderText()}
        </Text>
        <Flex justify="center" alignItems="center" direction="row">
          <Flex justify="center" alignItems="center" direction="column">
            <Text
              mb={10}
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
              fontSize="24px"
            >
              Swipe Card
            </Text>
            {isSpeedyStore ? (
              <Carousal images={images} />
            ) : (
              <img
                src={posWedge}
                height="180px"
                width="200px"
                alt="POS Wedge"
              />
            )}
          </Flex>
          {!isCanada && (
            <Flex justify="center" alignItems="center" direction="column">
              <Flex height="120px">
                <hr border="1px solid" color="#d3d3d3" width="0" />
              </Flex>
              <Text
                border={12}
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-bold"
                fontWeight="bold"
                textAlign="center"
                fontSize="24px"
              >
                or
              </Text>
              <Flex height="120px">
                <hr border="1px solid" color="#d3d3d3" width="0" />
              </Flex>
            </Flex>
          )}
          {!isCanada && (
            <Flex justify="center" alignItems="center" direction="column">
              <Text
                mb={10}
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-bold"
                fontWeight="bold"
                textAlign="center"
                fontSize="24px"
              >
                Scan {isSpeedyStore ? 'Speedway' : '7-Eleven'} Wallet Digital
                Barcode
              </Text>
              <img
                src={isSpeedyStore ? SpeedwayWallet_icon : Wallet_Icon}
                height="180px"
                width="120px"
                alt="Digital Wallet"
              />
            </Flex>
          )}
        </Flex>
      </Flex>
      <Box display="block" textAlign="right" p="1rem" w="100%">
        <ExitButton
          onClick={goBack}
          isDisabled={iscannedBarcode || isMemberTrigger || cardSwiped}
        />
      </Box>
    </Flex>
  );
};

export default memo(CardLoadSwipeWait);
