import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import Styles from './paymentTransaction.module.css';
import { displayCurrency } from '../../../../Utils/appUtils';

const paymentTransactionSubItem = props => {
  const {
    itemName,
    itemAmount,
    itemColour = '',
    itemAmtColour = '',
    KeyIndex = 0,
    isRemoved = false,
    itemSuffix = '',
    type,
    flag,
    depositFee,
    isFuel,
  } = props;

  const isFees = () => type === 'BOTTLE_DEPOSIT' || type === 'ECO_FEE';

  const getItemAmtColour = () => {
    if (isFees()) {
      return 'rgb(16, 127, 98)';
    }
    return itemAmtColour;
  };

  const getItemAmount = () => {
    if (isFees()) {
      return `${displayCurrency({ price: depositFee })} ${flag}`;
    }
    return itemAmount;
  };

  return (
    <Flex
      key={KeyIndex}
      flexDirection="row"
      justifyContent="space-between"
      alignItems="center"
      px={4}
      pt={2}
      fontSize="16px"
      color="rgb(44, 47, 53)"
    >
      <Flex flexDirection="row" alignItems="center">
        <Text ml="14px" fontWeight="normal" color={itemColour}>
          {itemName}
        </Text>
      </Flex>
      {!isFuel && (
        <Box>
          <Text
            color={getItemAmtColour()}
            font-weight="normal"
            className={Styles.priceAlignment}
          >
            <span
              className={
                isRemoved
                  ? itemSuffix === ''
                    ? Styles.priceCouponAlignmentStrike
                    : Styles.pricePromoAlignmentStrike
                  : itemSuffix === ''
                  ? Styles.priceCouponAlignment
                  : Styles.pricePromoAlignment
              }
            >
              {getItemAmount()}
            </span>
          </Text>
        </Box>
      )}
    </Flex>
  );
};
paymentTransactionSubItem.defaultProps = {
  itemName: '',
  itemAmount: '',
  itemColour: '',
  itemAmtColour: '',
  KeyIndex: 0,
  isRemoved: false,
};

paymentTransactionSubItem.propTypes = {
  itemName: PropTypes.string,
  itemAmount: PropTypes.string,
  itemColour: PropTypes.string,
  itemAmtColour: PropTypes.string,
  KeyIndex: PropTypes.number,
  isRemoved: PropTypes.bool,
};
export default paymentTransactionSubItem;
