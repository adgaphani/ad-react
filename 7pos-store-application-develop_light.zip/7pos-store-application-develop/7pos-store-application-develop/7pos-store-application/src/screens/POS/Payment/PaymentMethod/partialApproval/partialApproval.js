/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable react/prop-types */
import { Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Button } from '../../../../../components/Common/Buttons';
import { PARTIAL_PAYMENT_HEADING } from '../../../../../constants';
import Icon_twarning from '../../../../../Icons/Icon_twarning.svg';
import { setShowNotifications } from '../../../../../slices/notifications.slice';
import { cartActions } from '../../../../../slices/cart.slice';
import { getBalanceDue } from '../../../../../Utils/paymentUtils';

const PartialApproval = ({
  amount,
  paymentDetails,
  paymentHistory,
  paymentMediaList,
  statusCode,
  onContinue,
  onCancel,
  allPayments,
}) => {
  const dispatch = useDispatch();
  const { balanceDue } = getBalanceDue({
    paymentHistory,
    paymentMediaList,
    finalTotalPrice: amount,
    allPayments,
  });
  const paidAmt = paymentDetails?.paymentMedia?.payment?.amount?.toFixed(2);

  useEffect(() => {
    dispatch(setShowNotifications(false));
    dispatch(cartActions.setPaymentTriggerStatus(true));
    return () => {};
  }, []);

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="100%"
      flexDirection="column"
    >
      <img src={Icon_twarning} height="48px" width="54px" />
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Bold"
        fontSize="24px"
        fontWeight="bold"
        textAlign="center"
        mt={6}
      >
        {PARTIAL_PAYMENT_HEADING}
      </Text>

      {statusCode === 12 && (
        <Flex direction="row" mt="0.5rem" mb="1rem">
          <Text color="rgb(44, 47, 53)" fontSize="18px">
            {' '}
            Card balance:
          </Text>
          <Text color="rgb(16, 127, 98)" fontSize="18px">
            ${paidAmt}
          </Text>
        </Flex>
      )}
      <Text
        color="rgb(44, 47, 53)"
        fontFamily="Roboto-Regular"
        fontSize="18px"
        fontWeight="normal"
        textAlign="center"
        mx="5rem"
      >
        Customer still needs to pay ${balanceDue}. Ask the customer if they
        would like to continue with the payment or cancel to use another form of
        payment.
      </Text>
      <Flex direction="row" mt="2.5rem">
        <Button
          className="btn secondaryButton"
          // border="1px solid rgb(77, 184, 86)"
          height="50px"
          width="140px"
          mr={3}
          onClick={onCancel}
        >
          <Text>CANCEL</Text>
        </Button>
        <Button
          className="btn primaryButton"
          borderRadius="3px"
          height="50px"
          width="140px"
          _hover={{ bg: '#107f62' }}
          onClick={onContinue}
        >
          <Text>CONTINUE</Text>
        </Button>
      </Flex>
    </Flex>
  );
};

export default PartialApproval;
