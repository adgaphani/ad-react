import React, { useState, useEffect, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { cartActions } from '../../../../../slices/cart.slice';
import { SendMessageToCFD } from '../../../../../Communication';
import { appIntegrationRequest } from '../../../../../Utils/appUtils';
import { WebSocketContext } from '../../../../../components/Common/WebSocket/WebSocketProvider';
import { AppContext } from '../../../../../AppContext';
import { WSTopics } from '../../../../../constants';
import SignatureCapWaitingScrn from './SignatureCapWaitingScrn';
import SignatureCaptureConfirmation from './SignatureCaptureConfirmation';

const SignatureCapture = () => {
  const {
    capturedSignature,
    paymentTransactionId,
    cashBack,
    cancelSignature,
  } = useSelector(state => ({
    capturedSignature: state.cart.capturedSignature,
    paymentTransactionId: state.cart.paymentTransactionId,
    cashBack: state.socket.cashBack,
    cancelSignature: state.cart.cancelSignature,
  }));
  const dispatch = useDispatch();
  const history = useHistory();
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);
  const [isSigCaptured, setIsSigCaptured] = useState(false);

  // Navigation to Payment Success screen
  const NavToSuccessScrn = () => {
    if (cashBack && Number(cashBack) > 0) {
      ws.socket.send(WSTopics.cashdrawer.open);
      global?.logger?.info(
        `[7POS UI] -  Sent cash drawer open event(handleApprove)`
      );
      setTimeout(() => {
        showLoader(false);
        history.replace('/payment/success');
      }, 500);
    } else {
      showLoader(false);
      history.replace('/payment/success');
    }
  };

  // SignatureCapture accept and navigate to success
  const onAccept = ({ type = '' }) => {
    try {
      const payload =
        type === 'PrintVoucher' || type === 'Exit'
          ? ''
          : capturedSignature?.toString();
      if (payload && payload !== '') {
        const signatureCapReq = appIntegrationRequest({
          type: 'Signature_Cap',
          correlationId: paymentTransactionId,
          payload,
        });
        ws.socket.send(
          '/app/transaction/signatureData',
          {},
          JSON.stringify(signatureCapReq)
        );
        global.logger.info(`[7POS UI] - signatureCapture request sent`);
      }
    } catch (error) {
      global.logger.error(
        `[7POS UI] - Error in signatureCapture accept ${JSON.stringify(error)}`
      );
    } finally {
      NavToSuccessScrn();
    }
  };

  // Resign retriggers signatureCapture on CFD
  const reSign = () => {
    dispatch(cartActions.setCapturedSignature(null));
    const iTransactionMessage = {
      CMD: 'SignatureCapture',
    };
    SendMessageToCFD(iTransactionMessage);
  };

  const printVoucher = () => {
    dispatch(cartActions.setSigPrintVouchSelected(true));
    onAccept({ type: 'PrintVoucher' });
  };

  const goBack = () => {
    dispatch(cartActions.setSigPrintVouchSelected(true));
    onAccept({ type: 'Exit' });
  };

  // isSigCaptured set to true once Customer submit the signature
  useEffect(() => {
    if (capturedSignature) {
      setIsSigCaptured(true);
    } else {
      setIsSigCaptured(false);
    }
    return () => {};
  }, [capturedSignature]);

  // Auto accept triggers if no action performs by SA
  useEffect(() => {
    if (!isSigCaptured) return;
    const signatureAcceptTimer = 15000;
    const autoAcceptTime = setTimeout(() => {
      onAccept({ type: '' });
    }, signatureAcceptTimer);
    return () => {
      clearTimeout(autoAcceptTime);
    };
  }, [isSigCaptured]);

  // Handling SignatureCapture cancel from CFD
  useEffect(() => {
    if (!cancelSignature) return;
    dispatch(cartActions.setCancelSignature(false));
    dispatch(cartActions.setSigPrintVouchSelected(true));
    onAccept({ type: 'PrintVoucher' });
    return () => {};
  }, [cancelSignature]);

  return !isSigCaptured ? (
    <SignatureCapWaitingScrn goBack={goBack} />
  ) : (
    <SignatureCaptureConfirmation
      onAccept={onAccept}
      reSign={reSign}
      printVoucher={printVoucher}
      goBack={goBack}
    />
  );
};

export default SignatureCapture;
