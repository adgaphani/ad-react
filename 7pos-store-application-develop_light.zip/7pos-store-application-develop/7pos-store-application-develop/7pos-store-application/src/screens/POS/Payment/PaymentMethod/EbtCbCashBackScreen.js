import { Flex, Text, Button } from '@chakra-ui/react';
import React, { useContext, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import Icon_twarning from '../../../../Icons/Icon_twarning.svg';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import { socketActions } from '../../../../slices/socket.slice';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { AppContext } from '../../../../AppContext';
import { cartActions } from '../../../../slices/cart.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';

const EbtCbCashBackScreen = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const [ws] = useContext(WebSocketContext);
  const { showLoader } = useContext(AppContext);
  const { isCashBackRestictionAmount } = useSelector(state => ({
    isCashBackRestictionAmount: state.cart.isCashBackRestictionAmount,
  }));
  const onOk = () => {
    dispatch(setShowNotifications(true));
    dispatch(socketActions.setCardStatus(null));
    dispatch(socketActions.setCashBack(null));
    dispatch(cartActions.setCashBackRestictionAmount(0));
    const payload = JSON.stringify({
      removeCashback: true,
    });
    // eslint-disable-next-line no-unused-vars
    const paymentOkReq = appIntegrationRequest({
      type: 'CB_Restriction',
      payload,
    });
    ws.socket?.send('/app/payment/prompt', {}, JSON.stringify(paymentOkReq));
    history.replace('/payment');
    showLoader(true);
  };
  const onCancel = () => {
    dispatch(setShowNotifications(true));
    dispatch(socketActions.setCardStatus(null));
    dispatch(socketActions.setCashBack(null));
    dispatch(cartActions.setCashBackRestictionAmount(0));
    const payload = JSON.stringify({
      removeCashback: false,
    });
    // eslint-disable-next-line no-unused-vars
    const paymentCancelReq = appIntegrationRequest({
      type: 'CB_Restriction',
      payload,
    });
    ws.socket?.send(
      '/app/payment/prompt',
      {},
      JSON.stringify(paymentCancelReq)
    );
    dispatch(cartActions.setPaymentTriggerStatus(false));
    history.replace('/payment');
  };

  useEffect(() => {
    dispatch(cartActions.setPaymentTriggerStatus(true));
    return () => {};
  }, []);

  return (
    <Flex
      alignItems="center"
      justifyContent="center"
      pl="0.5rem"
      bg="rgb(255, 255, 255)"
      height="calc(100vh - 128px)"
      flexDirection="column"
    >
      <img src={Icon_twarning} alt="Warning_Icon" height="48px" width="54px" />
      <Flex direction="column" mt="1.5rem" mb="1rem" alignItems="center">
        <Text fontSize="18px" fontWeight="bold">
          {`$${isCashBackRestictionAmount}`} is ineligble for EBT Cash Benefits
        </Text>
        <Text fontSize="18px" fontWeight="bold" mb="0.5rem">
          Ask Customer if they want to Cash Back
        </Text>
        <Text fontSize="18px">
          if <b>YES</b> press <b>CANCEL</b> to pay --- first, then re-render
          media
        </Text>
        <Text fontSize="18px">
          if <b>NO</b> press <b>OK</b>.
        </Text>
      </Flex>
      <Flex direction="row" mt={2}>
        <Button
          className="btn primaryButton"
          borderRadius="3px"
          height="50px"
          width="140px"
          mr={3}
          _hover={{ bg: '#107f62' }}
          onClick={onOk}
        >
          <Text>OK</Text>
        </Button>
        <Button
          className="btn secondaryButton"
          height="50px"
          width="140px"
          onClick={onCancel}
        >
          <Text>CANCEL</Text>
        </Button>
      </Flex>
    </Flex>
  );
};

export default EbtCbCashBackScreen;
