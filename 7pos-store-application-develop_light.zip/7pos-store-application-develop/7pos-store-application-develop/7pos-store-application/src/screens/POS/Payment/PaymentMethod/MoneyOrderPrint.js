import moment from 'moment';
import { getBalanceDue } from '../../../../Utils/paymentUtils';
import {
  MO_FLG_INSALE,
  MO_FLG_INVALID,
  MO_FLG_PRINTED,
} from '../../../../constants';

export const verifyMoneyOrderItemStatus = ({
  items,
  paymentHistory,
  paymentMediaList,
  finalTotalPrice,
  enteredCash,
}) => {
  let isPaymentNotValid = false;
  const isMoneyItem = items.filter(
    item => item.isMoneyOrder === true && item.MoneyOrderFlag !== MO_FLG_INVALID
  );
  if (isMoneyItem?.length) {
    const isMoneyOrderInCart = items?.every(item => item.isMoneyOrder === true);
    if (!isMoneyOrderInCart) {
      let iMoneyOrderPrice = isMoneyItem?.reduce((sum, item) => {
        let price = 0;
        if (item.moneyOrderFeeOverride !== 'Y') {
          price = parseFloat(
            Number(item?.retailPrice) + Number(item.moneyOrderFee)
          ).toFixed(2);
        } else price = parseFloat(Number(item?.retailPrice)).toFixed(2);
        return sum + price * item.quantity;
      }, 0);
      iMoneyOrderPrice = parseFloat(
        parseFloat(iMoneyOrderPrice).toFixed(2) / 100
      );
      const { balanceDue } = getBalanceDue({
        paymentHistory,
        paymentMediaList,
        finalTotalPrice,
        enteredCash,
      });
      const amount = finalTotalPrice - balanceDue;
      if (amount < iMoneyOrderPrice) {
        isPaymentNotValid = true;
      }
    } else isPaymentNotValid = true;
  }
  return isPaymentNotValid;
};

export const verifyMOMInTransaction = (
  items,
  deviceInfo,
  user,
  paymentTransactionId
) => {
  let MOMIntialieResuest = [];
  let MoneyOrdeCount = 1;
  const isMoneyPrintItem = items.filter(
    item => item.isMoneyOrder === true && item.MoneyOrderFlag === MO_FLG_INSALE
  );
  if (isMoneyPrintItem && isMoneyPrintItem[0]) {
    // MOMResuest = isMoneyItem.reduce((acc, imapItem) => {
    MOMIntialieResuest = JSON.stringify({
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'moneyOrderRequest',
        uniqueId: isMoneyPrintItem[0]?.itemSeq,
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: deviceInfo?.id,
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'MOM',
        },
      },
      messageBody: {
        message: {
          amount: isMoneyPrintItem[0]?.retailPrice.toString(),
          firstName: user?.firstName,
          lastName: user?.lastName,
          employeeNumber: user?.userId ? user?.userId.toString() : '',
          saleCount: MoneyOrdeCount.toString(),
          feeInidcator: 'N',
        },
      },
    });
    // eslint-disable-next-line no-plusplus
    MoneyOrdeCount++;
  }
  return { MOMIntialieResuest, isMoneyPrintItem };
};

export const IsValidCashPayment = (items, enteredCash, finalTotalPrice) => {
  let isPaymentNotValid = false;
  // #7449 ignore already printed or invalid MO sale during amount validation
  const isMoneyItem = items.filter(
    item =>
      item.isMoneyOrder === true &&
      item.MoneyOrderFlag !== MO_FLG_INVALID &&
      item.MoneyOrderFlag !== MO_FLG_PRINTED
  );
  if (isMoneyItem) {
    let iMoneyOrderPrice = isMoneyItem?.reduce((sum, item) => {
      let price = 0;
      if (item.moneyOrderFeeOverride !== 'Y')
        price = parseFloat(
          Number(item?.retailPrice) + Number(item.moneyOrderFee)
        ).toFixed(2);
      else price = parseFloat(Number(item?.retailPrice)).toFixed(2);
      return sum + price * item.quantity;
    }, 0);
    iMoneyOrderPrice = parseFloat(
      parseFloat(iMoneyOrderPrice).toFixed(2) / 100
    );
    if (enteredCash < iMoneyOrderPrice) {
      // #8048 added final total price validation to skip MO amount error
      if (finalTotalPrice >= enteredCash) isPaymentNotValid = true;
    }
  }
  return isPaymentNotValid;
};
