/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';
import { Box, Grid } from '@chakra-ui/react';
import {
  Route,
  Switch,
  useRouteMatch,
  useHistory,
  useLocation,
} from 'react-router-dom';

import { useDispatch } from 'react-redux';
import MenuBar from '../../../components/POS/MenuBar/menuBar';
import Styles from './payment.module.css';
import Header from '../../../components/POS/Header/Header';
import PaymentTransaction from './PaymentTransaction/paymentTransaction';
import PaymentMethod from './PaymentMethod/paymentMethod';
import PaymentConfrimation from './PaymentConfirmation/PaymentConfrimation';
import EmailReceipt from './EmailReceipt/EmailReceipt';
import Notifications from '../../../components/POS/Notifications/Notifications';
import { FuelPumps } from '../../../components/Fuel';
import MediaAbort from './PaymentMethod/MediaAbort/MediaAbort';
import CardLoadNotification from './PaymentMethod/CardLoadNotification';
import CashDrawer from '../../../components/POS/CashDrawer/CashDrawer';
import PartialApproval from './PaymentMethod/partialApproval/partialApproval';
import ManualEBT from './PaymentMethod/ManualEBT/manualEBT';
import { cartActions } from '../../../slices/cart.slice';
import Arrow_left from '../../../Icons/Arrow_left.svg';
import { PIPOAmountError } from './PainInOut/PIPOAmountError';
import FifthMediaError from './PaymentMethod/FifthMediaError';
import CurrencyConverter from '../../../components/POS/CurrencyConverter';
import MediaRestriction from './PaymentMethod/MediaAbort/MediaRestriction';
import EbtCbChargeReversalFail from './PaymentMethod/MediaAbort/EbtCbChargeReversalFail';
import { Discountprompt } from '../Coupons/DiscountPrompt';

function Payment() {
  const history = useHistory();
  const location = useLocation();
  const { path } = useRouteMatch();
  const dispatch = useDispatch();

  const goBack = () => {
    if (location.pathname === '/payment/success') {
      dispatch(cartActions.emptyCart());
      history.replace('/home');
    } else {
      // history.goBack();
    }
  };
  return (
    <Box backgroundColor="#F2F2F2">
      <FuelPumps />
      <Grid templateColumns="34% 66%">
        <Box
          w="100%"
          boxShadow="-2px 0px 6px 0px rgba(0, 0, 0, 0.2)"
          borderRight="1px solid rgb(233, 233, 233)"
          background="rgb(255, 255, 255)"
        >
          <PaymentTransaction />
        </Box>

        <Box background="#F2F2F2">
          <Header>
            <Box px={2}>
              {/* eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions */}
              <img src={Arrow_left} onClick={goBack} alt="" />
            </Box>
          </Header>
          <Notifications />
          <Box px={3} className={Styles.paymentMethodContainer}>
            <Switch>
              <Route path={`${path}/`} exact>
                <PaymentMethod />
              </Route>
              <Route path={`${path}/success`}>
                <PaymentConfrimation />
              </Route>
              <Route path={`${path}/emailReceipt`}>
                <EmailReceipt />
              </Route>
              <Route path={`${path}/cashDrawer`}>
                <CashDrawer />
              </Route>
              <Route path={`${path}/mediaAbort`}>
                <MediaAbort />
              </Route>
              <Route path={`${path}/loadnotification`}>
                <CardLoadNotification />
              </Route>
              <Route path={`${path}/partialApproval`}>
                <PartialApproval />
              </Route>
              <Route path={`${path}/manualEBT`}>
                <ManualEBT />
              </Route>
              <Route path={`${path}/currencyConverter`}>
                <CurrencyConverter />
              </Route>
              <Route path={`${path}/pipoAmountError`}>
                <PIPOAmountError />
              </Route>
              <Route path={`${path}/fifthMediaError`}>
                <FifthMediaError />
              </Route>
              <Route path={`${path}/MediaRestriction`}>
                <MediaRestriction />
              </Route>
              <Route path={`${path}/ebtCbChargeReversalFail`}>
                <EbtCbChargeReversalFail />
              </Route>
              <Route path={`${path}/discountPrompt`}>
                {/* //<EbtCbChargeReversalFail /> */}
                <Discountprompt />
              </Route>
            </Switch>
          </Box>
        </Box>
      </Grid>
      <MenuBar />
    </Box>
  );
}
export default Payment;
