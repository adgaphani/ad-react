import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Button } from '../../../../components/Common/Buttons';
import { useSoundToast } from '../../../../hooks';
import Keypad from '../../../../components/Common/DailPad/Keypad/Keypad';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { AppContext } from '../../../../AppContext';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
import { cartActions } from '../../../../slices/cart.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';
import { getPromptRefRequestPayload } from '../../../../Utils/paymentUtils';

const messagesMap = {
  DRIVER_NUMBER: {
    message: 'Enter DRIVER NUMBER# from the Original Receipt',
    placeholder: 'DRIVER NUMBER',
    fieldName: 'driverNumber',
  },
  FLEET_NUMBER: {
    message: 'Enter FLEET NUMBER# from the Original Receipt',
    placeholder: 'FLEET NUMBER',
    fieldName: 'fleetNumber',
  },
  MOBILE_NUMBER: {
    message: 'Enter MOBILE NUMBER# from the Original Receipt',
    placeholder: 'MOBILE NUMBER',
    fieldName: 'mobileNumber',
  },
  VEHICLE_ID: {
    message: 'Enter VEHICLE ID# from the Original Receipt',
    placeholder: 'VEHICLE ID',
    fieldName: 'vehicleId',
  },
  ODOMETER_VALUE: {
    message: 'Enter ODOMETER VALUE# from the Original Receipt',
    placeholder: 'ODOMETER VALUE',
    fieldName: 'odometerValue',
  },
  JOB_NUMBER: {
    message: 'Enter JOB NUMBER# from the Original Receipt',
    placeholder: 'JOB NUMBER',
    fieldName: 'jobNumber',
  },
  FLEET_ID: {
    message: 'Enter FLEET ID# from the Original Receipt',
    placeholder: 'FLEET ID',
    fieldName: 'fleetId',
  },
  DATA: {
    message: 'Enter DATA# from the Original Receipt',
    placeholder: 'DATA',
    fieldName: 'data',
  },
  DEPARTMENT: {
    message: 'Enter DEPARTMENT# from the Original Receipt',
    placeholder: 'DEPARTMENT',
    fieldName: 'department',
  },
};

export default function OriginalRefNumber() {
  const history = useHistory();
  const dispatch = useDispatch();
  const promptValues = useRef();
  const toast = useSoundToast();
  const fleetVoidPrompts = useSelector(state => state.cart.fleetVoidPrompts);
  const fleetVoidReason = useSelector(state => state.cart.fleetVoidReason);
  const paymentTransactionId = useSelector(
    state => state.cart.paymentTransactionId
  );
  const [currentScreen, setCurrentScreen] = useState('referenceNumber');
  const [message, setMessage] = useState(
    'Enter REFERENCE# from the Original Receipt'
  );
  const { showLoader } = useContext(AppContext);
  const [ws] = useContext(WebSocketContext);

  useEffect(() => {
    dispatch(setShowNotifications(true));
    const prompt = Object.values(messagesMap).find(
      cmsg => cmsg.fieldName === currentScreen
    );
    if (prompt) setMessage(prompt.message);
    return () => {
      dispatch(dailpadActions.resetDailpadState());
    };
  }, [currentScreen]);

  const onExit = () => {
    dispatch(cartActions.setPaymentExit(true));
    dispatch(cartActions.setPaymentTriggerStatus(false));
    dispatch(dailpadActions.resetDailpadState());
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    dispatch(socketActions.setCardStatus(null));
    // #7253 reset wallet information
    dispatch(cartActions.setDigitalWalletToken(null));
    dispatch(cartActions.setDigitalWalletStatus(false));
    history.push('/payment');
  };

  const sendDataToServer = () => {
    dispatch(cartActions.setStatusCode(null));
    const values = promptValues?.current;
    const payRequest = getPromptRefRequestPayload({
      values,
      correlationId: paymentTransactionId,
    });
    // const req = JSON.stringify(payRequest);
    dispatch(cartActions.setPaymentMethod('PINPAD'));
    dispatch(cartActions.setReferenceAttempts(0));
    dispatch(cartActions.setOriginalRefAttempt(true));
    ws.socket?.send('/app/payment/prompt', {}, JSON.stringify(payRequest));
    showLoader(true);
  };

  const onEnterValueHandler = value => {
    promptValues.current = promptValues.current || {};
    promptValues.current[currentScreen] = value;
    if (
      fleetVoidPrompts.length > 0 &&
      Object.keys(promptValues.current).length < fleetVoidPrompts.length + 1
    ) {
      const index = Object.keys(promptValues.current).length;
      const prompt = messagesMap[fleetVoidPrompts[index - 1]];
      setCurrentScreen(prompt.fieldName);
    } else {
      sendDataToServer();
    }
  };

  useEffect(() => {
    if (fleetVoidReason) {
      toast({
        description: 'Invalid input',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
    }
  }, [fleetVoidReason]);

  // if (originalSaleDeclinedCount >= 2 && cardStatus === DECLINED_ORIGINALSALE_NOTFOUND) {
  //   history.replace('/home');
  //   return;
  // }

  return (
    <>
      <Box pr="0.5rem">
        <Keypad defaultValue="" onEnter={onEnterValueHandler} disableDecimal />
      </Box>
      <Box bg="rgb(255, 255, 255)" p={0}>
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          height="100%"
        >
          <Flex flexDirection="column">
            <Text
              color="rgb(44, 47, 53)"
              fontSize="24px"
              fontFamily="Roboto-Medium"
              fontWeight="500"
              lineHeight="30px"
              textAlign="center"
              marginTop="15px"
            >
              {message}
            </Text>
          </Flex>
          <Button
            alignSelf="flex-end"
            onClick={onExit}
            borderRadius="3px !important"
            width="90px"
            height="40px"
            background="rgb(255, 255, 255)"
            border="1px solid rgb(91, 97, 107)"
            mb={15}
            mr={15}
          >
            <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
              EXIT
            </Text>
          </Button>
        </Flex>
      </Box>
    </>
  );
}
