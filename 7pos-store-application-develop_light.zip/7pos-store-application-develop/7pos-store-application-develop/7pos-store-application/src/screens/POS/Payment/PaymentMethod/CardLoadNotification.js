import React, { useEffect } from 'react';
import { Flex, Box, Text } from '@chakra-ui/react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import warrningSymbol from '../../../../Icons/warning_yellow.svg';
import ExitButton from '../../../../components/POS/ExitButton';
import { cartActions } from '../../../../slices/cart.slice';
import { setShowNotifications } from '../../../../slices/notifications.slice';

function LoadNotification() {
  const dispatch = useDispatch();
  const history = useHistory();

  const onLoadNotificationExit = () => {
    dispatch(cartActions.setCardLoadNotificationStatus(true));
    dispatch(setShowNotifications(true));
    history.replace('/payment');
  };

  useEffect(() => {
    dispatch(setShowNotifications(false));
  }, []);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="calc(100vh - 128px)"
      background="rgb(255,255,255)"
      boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
      my="0.6rem"
      ml="0.5rem"
      mr="0.6rem"
    >
      <Flex
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        mt="30%"
      >
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
        >
          <img src={warrningSymbol} alt="warning" height="48px" width="54px" />
        </Flex>
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
          mt="5%"
        >
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Bold"
            fontSize="24px"
            fontWeight="700"
            textAlign="center"
            mx="5rem"
            my="1rem"
          >
            1 or More loads failed and will be voided from the Transaction
          </Text>
        </Flex>
      </Flex>

      <Box display="block" textAlign="right" p="1rem" w="100%">
        <ExitButton onClick={onLoadNotificationExit} />
      </Box>
    </Flex>
  );
}
export default LoadNotification;
