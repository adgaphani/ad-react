/* eslint-disable react/prop-types */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Box } from '@chakra-ui/react';
import { SendMessageToCFD } from '../../../../../Communication';
import VoidTransactionText from '../../../Cart/VoidTransactionText';
import MediaAbortedText from '../../../Cart/MediaAbortedText';
import {
  currencyFixed,
  getScreenTaxDetails,
  getTaxAssesments,
  getTotalBtlDeposit,
} from '../../../../../Utils/appUtils';
import { cartActions } from '../../../../../slices/cart.slice';
import CashBackText from './cashBackText';
import CashDetails from './cashDetails';
import NoSaleDetails from './noSaleDetails';
import PartialPayment from './partialPayment';
import PaymentDetailValue from './paymentDetailValue';
import PinpadDetails from './pinpadDetails';
import TransactionComplete from './transactionComplete';
import {
  getBalanceDue,
  getChange,
  createTaxObject,
} from '../../../../../Utils/paymentUtils';
import * as coinDispenser from '../../../../../hardware/coin_dispenser';
import { getDVR } from '../../../../../hardware/dvr';

const PaymentSummary = props => {
  const {
    paymentDetails,
    cashBack,
    taxData,
    balanceDue,
    isTransactionVoid,
    paymentMediaList,
    paymentHistory,
    isTransactionRefund,
    totalChangeForCash,
    allPayments,
  } = props;
  const {
    paymentMethod,
    enteredCash,
    statusCode,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    member,
    CardDeclinedAmount,
    isMediaAborted,
    taxInfo,
    taxDeductionAmount,
    cartItems,
    isCanada,
    isFuelPPCancel,
    total,
    subTotal,
    discount,
    stateCode,
  } = useSelector(state => ({
    paymentMethod: state.cart.paymentMethod,
    enteredCash: state.cart.enteredCash,
    statusCode: state.cart.statusCode,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    member: state.cart.member,
    CardDeclinedAmount: state.cart.CardDeclinedAmount,
    isMediaAborted: state.cart.isMediaAborted,
    taxInfo: state.cart.taxInfo,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    cartItems: state.cart.cartItems,
    isCanada: state.main.storeDetails?.address?.country === 'CA',
    isFuelPPCancel: state.cart.isFuelPPCancel,
    total: state.cart.tranTotalDue,
    subTotal: state.cart.tranSubTotal,
    discount: state.cart.tranDiscountAmt,
    stateCode: state.main.storeDetails?.address?.state,
  }));

  const history = useHistory();
  const isPaymentSuccess = history.location.pathname.includes(
    'payment/success'
  );
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const status = params.get('status');
  const dispatch = useDispatch();
  const processData = () => {
    const taxAssessments = createTaxObject(
      taxInfo,
      taxBeforeEBTExempt,
      taxableBeforeEBTExempt,
      isTransactionRefund || isTransactionVoid
    );
    const salesTaxValue = getScreenTaxDetails(
      taxAssessments,
      taxInfo,
      isTransactionRefund || isTransactionVoid,
      taxableBeforeEBTExempt,
      taxBeforeEBTExempt,
      stateCode
    );

    const discountValue = `${currencyFixed(discount)}` || '0.00';
    const subTotalVal = cashBack
      ? Number(subTotal) + Math.abs(Number(cashBack))
      : subTotal;
    const totalDue = cashBack
      ? Number(total) + Math.abs(Number(cashBack))
      : total;
    const totalValue =
      enteredCash || isTransactionVoid || isTransactionRefund
        ? `${currencyFixed(total) || '0.00'}`
        : `${currencyFixed(total) || '0.00'}`;
    let balanceDueValue = balanceDue;
    if (paymentHistory.length > 0 || enteredCash) {
      ({ balanceDue: balanceDueValue } = getBalanceDue({
        paymentMediaList,
        paymentHistory,
        finalTotalPrice: total,
        allPayments,
      }));
      // RISPIN#3159 Add cashback only during payment.
      if (balanceDueValue > 0 && Math.abs(Number(cashBack)) > 0) {
        // console.log('balanceDueValue', balanceDueValue, cashBack);
        balanceDueValue += cashBack ? Math.abs(Number(cashBack)) : 0;
      }
    }
    balanceDueValue = parseFloat(balanceDueValue).toFixed(2);
    const changeAmount = getChange({
      enteredCash,
      allPayments,
      isTransactionVoid,
      isTransactionRefund,
      totalValue,
      isDollarSignReq: true,
      totalChangeForCash,
    });
    return {
      salesTaxValue,
      discountValue,
      totalDue,
      totalValue,
      balanceDueValue,
      changeAmount,
      subTotalVal,
    };
  };
  const {
    salesTaxValue,
    discountValue,
    totalDue,
    // totalValue,
    balanceDueValue,
    changeAmount,
    subTotalVal,
  } = processData();

  useEffect(() => {
    if (!allPayments.length > 0 && !cashBack) return;
    const change = balanceDueValue <= 0 ? changeAmount : '0.00';
    const itotalDetails = {
      finalsubTotalPrice: subTotalVal,
      finalTotalPrice: balanceDueValue,
      totalPromotionPrice: discount,
      totalDue,
      PaymentMediaList: allPayments.length > 0 ? allPayments : undefined,
      CashBack: cashBack,
      Cash: enteredCash,
      Change: cashBack && Number(cashBack) > 0 ? undefined : change, // #5781 Change applicable only non cash back
      taxDeductionAmount,
    };
    let TaxDetails = Object.keys(salesTaxValue).map(key => ({
      amount: Number(salesTaxValue[key]),
      description: key,
    }));

    if (isCanada) {
      TaxDetails = getTaxAssesments(taxInfo).map(item => ({
        description: `${item.description} on ${item.displayTaxableAmount}`,
        amount: Number(item.taxAmount).toFixed(2),
      }));
    }

    const iTransactionMessage = {
      CMD: 'UpdateTransaction',
      TaxInfo: taxData,
      TaxDetails,
      TotalDetails: itotalDetails,
      MemberInfo: member,
      TransactionType: isTransactionVoid
        ? 'Void'
        : isTransactionRefund
        ? 'Refund'
        : 'Sale',
    };
    SendMessageToCFD(iTransactionMessage);
    return () => {};
  });

  /*
  useEffect(() => {
    // RISPIN 4869 CFD not updating on cashback removal
    if (
      (window.location?.search?.includes(PIN_ENTRY_END) ||
        window.location?.search === '') &&
      !cashBack
    ) {
      // cfdDetails();
      return;
    }
    if (cashBack) {
      if (!allPayments.length > 0) return;
      // cfdDetails();
    }
    return () => {};
  }, [cashBack]); */

  // #6515 added total Due dependcy as well to update correct total due in case Member rewards
  useEffect(() => {
    if (changeAmount !== 0) {
      dispatch(cartActions.setBalanceDue(balanceDueValue));
      getDVR().setChangeAmount(changeAmount);
      coinDispenser.setChangeAmount(changeAmount);
    }
    return () => {};
  }, [balanceDueValue, changeAmount, totalDue]);

  /* useEffect(() => {
    const isCashOnly =
      allPayments.length > 0
        ? allPayments?.every(ap => ap.paymentMediaType === 'CASH')
        : false;
    if (isCashOnly) {
      // cfdDetails();
    }
    return () => {};
  }); */

  const getComponent = () => {
    if (
      paymentMethod === 'PINPAD' ||
      paymentMethod === 'MANUAL_EBT' ||
      paymentMethod === 'DIGITAL_WALLET'
    ) {
      return (
        <>
          <PinpadDetails
            balanceDue={balanceDueValue}
            enteredCash={enteredCash}
            taxData={taxData}
            total={totalDue}
            subTotal={subTotalVal}
            discount={discount}
            paymentDetails={paymentDetails}
            cashBack={cashBack}
            isTransactionVoid={isTransactionVoid}
            isTransactionRefund={isTransactionRefund}
            statusCode={statusCode}
            paymentHistory={paymentHistory}
            paymentMediaList={paymentMediaList}
            allPayments={allPayments}
            taxExempted={taxBeforeEBTExempt}
            member={member}
            CardDeclinedAmount={CardDeclinedAmount}
            isMediaAborted={isMediaAborted}
          />
        </>
      );
    }
    if (paymentMethod === 'CASH') {
      return (
        <>
          <CashDetails
            balanceDue={balanceDueValue}
            taxData={taxData}
            total={total}
            subTotal={subTotal}
            discount={discount}
            enteredCash={enteredCash}
            isTransactionVoid={isTransactionVoid}
            isTransactionRefund={isTransactionRefund}
            member={member}
            allPayments={allPayments}
            totalChangeForCash={totalChangeForCash}
            taxExempted={taxBeforeEBTExempt}
            isMediaAborted={isMediaAborted}
          />
        </>
      );
    }
  };

  return (
    <>
      {location.pathname === '/payment/success' ||
      location.pathname === '/payment/emailReceipt' ||
      ((location.pathname === '/payment' ||
        location.pathname === '/payment/cashDrawer') &&
        paymentMethod === 'CASH') ? (
        getComponent()
      ) : paymentMethod === 'PARTIAL_PAYMENT' ? (
        <PartialPayment
          balanceDue={balanceDue}
          taxData={taxData}
          total={totalDue}
          subTotal={subTotal}
          discount={discount}
          paymentDetails={paymentDetails}
          paymentHistory={paymentHistory}
          paymentMediaList={paymentMediaList}
          allPayments={allPayments}
          member={member}
          totalBtlDeposit={getTotalBtlDeposit(cartItems)}
        />
      ) : status === 'noSale' ? (
        <NoSaleDetails
          totalBtlDeposit={getTotalBtlDeposit(cartItems)}
          subTotal={subTotal}
          total={totalDue}
        />
      ) : (
        <Box
          px={4}
          pt={3}
          borderTop={status !== 'noSale' ? `2px solid rgb(192, 191, 191)` : ''}
        >
          {(isTransactionVoid || isTransactionRefund) && (
            <VoidTransactionText
              type={isTransactionRefund ? 'REFUND' : 'VOID'}
            />
          )}
          {isMediaAborted && <MediaAbortedText />}
          {!!getTotalBtlDeposit(cartItems) && (
            <PaymentDetailValue
              label="Total Btl Dep-N"
              value={parseFloat(getTotalBtlDeposit(cartItems)).toFixed(2)}
            />
          )}
          <PaymentDetailValue
            label="Subtotal"
            value={parseFloat(subTotalVal).toFixed(2)}
          />
          {status !== 'noSale' && !isCanada && (
            <>
              {Object.keys(salesTaxValue).map((key, index) => (
                <PaymentDetailValue
                  key={index}
                  label={key}
                  value={salesTaxValue[key]}
                />
              ))}
            </>
          )}
          {status !== 'noSale' && isCanada && (
            <>
              {isCanada &&
                getTaxAssesments(taxInfo).map((item, index) => (
                  <PaymentDetailValue
                    key={index}
                    label={`${item.description} on ${item.displayTaxableAmount}`}
                    value={Number(item.taxAmount).toFixed(2)}
                  />
                ))}
            </>
          )}
          {/* (isTransactionVoid || isTransactionRefund) && */ (isPaymentSuccess ||
            window.location.pathname.includes('currencyConverter')) && (
            <PaymentDetailValue
              label={
                (!isTransactionVoid &&
                  !isTransactionRefund &&
                  !isFuelPPCancel) ||
                window.location.pathname.includes('currencyConverter')
                  ? 'Total Due'
                  : 'Refund Due'
              }
              value={parseFloat(totalDue).toFixed(2)}
            />
          )}
          {/* TODO: Remove after EBT tests */}
          {taxDeductionAmount && Number(taxDeductionAmount) > 0 ? (
            <PaymentDetailValue
              label="Tax Deduction"
              value={parseFloat(taxDeductionAmount).toFixed(2)}
            />
          ) : (
            ''
          )}
          {/* (isTransactionVoid || isTransactionRefund) && isPaymentSuccess && (
            <PaymentDetailValue
              label="Total Due"
              value={parseFloat(totalDue).toFixed(2)}
            />
          ) */}
          {Number(Math.abs(discount)) > 0 && (
            <PaymentDetailValue
              label="Discount(s)"
              valueColor="#ec2526"
              value={
                isTransactionRefund || isTransactionVoid
                  ? discountValue
                  : `-${discountValue}`
              }
            />
          )}
          {/* (isTransactionVoid || isTransactionRefund) && !paymentDetails && (
            <PaymentDetailValue
              label="Refund Due"
              value={currencyFixed(totalDue)}
            />
          ) */}
          {!paymentDetails &&
            !window.location.pathname.includes('currencyConverter') && (
              <PaymentDetailValue
                label={
                  isTransactionVoid || isTransactionRefund
                    ? 'Refund Due'
                    : 'Total'
                }
                value={currencyFixed(totalDue)}
              />
            )}
          {(isTransactionVoid || isTransactionRefund) && isPaymentSuccess && (
            <PaymentDetailValue
              label="Change"
              variant="bold"
              value={`$${parseFloat(-totalDue).toFixed(2)}`}
            />
          )}
          {/* {enteredCash && (
            <>
              <PaymentDetailValue
                label="Cash"
                value={parseFloat(enteredCash).toFixed(2)}
              />
            </>
          )} */}
          <Box>
            {allPayments.length > 0 && (
              <>
                {allPayments.map((p, index) => (
                  <PaymentDetailValue
                    key={index}
                    comment={p?.label}
                    label={`${p?.receiptDetails?.cardName} ${
                      p?.receiptDetails?.cardName
                        ?.toLowerCase()
                        .includes('debit') ||
                      p?.receiptDetails?.cardName
                        ?.toLowerCase()
                        .includes('credit')
                        ? 'Card'
                        : ''
                    }`}
                    value={p.payment?.amount?.toFixed(2)}
                  />
                ))}
              </>
            )}
            {cashBack?.eventData ? (
              <CashBackText dence eventData={cashBack.eventData} />
            ) : (
              <>
                {paymentHistory.length > 0 && (
                  <PaymentDetailValue
                    label="Balance Due"
                    variant="bold"
                    value={`$${balanceDueValue}`}
                  />
                )}
              </>
            )}
            {paymentDetails && (
              <>
                {(statusCode !== 12 || statusCode !== 0) &&
                paymentDetails.paymentMedia?.status !== 'APPROVED' ? (
                  <TransactionComplete />
                ) : (
                  ''
                )}
              </>
            )}
            {!paymentDetails && Math.abs(Number(CardDeclinedAmount)) > 0 && (
              <TransactionComplete />
            )}
          </Box>
        </Box>
      )}
    </>
  );
};

export default PaymentSummary;
