/* eslint-disable no-use-before-define */
import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useContext, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Button } from '../../../../components/Common';
import {
  useCart,
  useFuelCache,
  useSoundToast,
  useFuel,
  useCarWash,
} from '../../../../hooks';
import { SendMessageToCFD } from '../../../../Communication';
import Icon_confirm from '../../../../Icons/Icon_confirm.svg';
import { cartActions } from '../../../../slices/cart.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import {
  paymentRecepitRequest,
  createTaxObject,
  fuelPreAuthCancelReceipt,
} from '../../../../Utils/paymentUtils';
import { getTaxDetails } from '../../../../Utils/appUtils';
import Styles from './PaymentConfirmation.module.css';
import { fetchEmailReceipt } from '../../../../api/payment';
import { AppContext } from '../../../../AppContext';
import store from '../../../../store';
import { getDVR } from '../../../../hardware/dvr';
import { usePMB } from '../../../../hooks/promo/usePMB';
import { ITEM_TYPE } from '../../../../constants';

const STOP_TIMER = 0;
const START_TIMER = 1;
const RESTART_TIMER = 2;
const EXIT_TIMER = 3;

const PaymentConfrimation = () => {
  const [timeoutCancel, setTimeoutCancel] = useState(false);
  const [timerStatus, setTimerStatus] = useState(0);
  const {
    futurePreauthCancelCache,
    clearFuturePreauthCancelCache,
  } = useFuelCache();
  const { clearCode, isCarwashInProgress } = useCarWash();

  const { addVoidFuelCartItem, setNewTransactionStartTime } = useCart();
  const { submitPMB } = usePMB();
  const {
    storeDetails,
    items,
    member,
    transInfo,
    paymentDetails,
    deviceInfo,
    user,
    cashBack,
    transactionId,
    paymentMethod,
    enteredCash,
    isTransactionVoid,
    taxInfo,
    paymentHistory,
    paymentMediaList,
    allPayments,
    isTransactionRefund,
    basketPromo,
    taxBeforeEBTExempt,
    taxableBeforeEBTExempt,
    config,
    EmailForReceipt,
    loadCardMediaList,
    EODEOSDetails,
    paymentTransactionId,
    taxDeductionAmount,
    isFuelPPCancel,
    mediaAbortedPaymentList,
    isTAPITransCompleted,
    canAutoPrintReceipt,
    transactionMemory,
    sigPrintVouchSelected,
    channel,
    calculatedFuelDiscounts,
    hostDiscountsforSelectedGrade,
    fuelSelectedGradeMeta,
    selectedFuelCashGMeta,
    isCashCreditStore,
    stateCode,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    items: state.cart.cartItems,
    member: state.cart.member,
    transInfo: state.cart.transDetails,
    paymentDetails: state.cart.paymentDetails,
    deviceInfo: state.main.deviceInfo,
    user: state.auth.user,
    cashBack: state.socket.cashBack,
    transactionId: state.cart.transactionId,
    paymentMethod: state.cart.paymentMethod,
    enteredCash: state.cart.enteredCash,
    isTransactionVoid: state.cart.isTransactionVoid,
    taxInfo: state.cart.taxInfo,
    paymentHistory: state.cart.paymentHistory,
    paymentMediaList: state.cart.paymentMediaList,
    allPayments: state.cart.allPayments,
    isTransactionRefund: state.cart.isTransactionRefund,
    basketPromo: state.cart.basketPromo,
    taxBeforeEBTExempt: state.cart.taxBeforeEBTExempt,
    taxableBeforeEBTExempt: state.cart.taxableBeforeEBTExempt,
    config: state.main.configuration,
    EmailForReceipt: state.cart.EmailForReceipt,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    loadCardMediaList: state.cart.loadCardMediaList,
    CashPaymentInfo: state.cart.CashPaymentInfo,
    EODEOSDetails: state.cart.EODEOSDetails,
    paymentTransactionId: state.cart.paymentTransactionId,
    taxDeductionAmount: state.cart.taxDeductionAmount,
    isFuelPPCancel: state.cart.isFuelPPCancel,
    mediaAbortedPaymentList: state.cart.mediaAbortedPaymentList,
    isTAPITransCompleted: state.cart.isTAPITransCompleted,
    canAutoPrintReceipt: state.cart.items?.filter(i => i.isCarwash)?.length,
    transactionMemory: state.cart.transactionMemory,
    sigPrintVouchSelected: state.cart.sigPrintVouchSelected,
    channel: state.main.channel,
    calculatedFuelDiscounts: state.cart.calculatedFuelDiscounts,
    hostDiscountsforSelectedGrade: state.cart.hostDiscountsforSelectedGrade,
    fuelSelectedGradeMeta: {
      ...(state.cart.calculatedPrices?.find(price => price.selected) || {}),
    },
    selectedFuelCashGMeta: {
      ...(state.cart.calculatedFuelCashPrices?.find(price => price.selected) ||
        {}),
    },
    isCashCreditStore: state.main.isCashCreditStore,
    stateCode: state.main.storeDetails?.address?.state,
  }));

  const cashDrawerStatus = useSelector(state => state.socket.cashDrawerStatus);
  const toast = useSoundToast();
  const { getFuelReceiptAttts } = useFuel();
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const [isReceiptSent, setReceiptSentStatus] = useState(false);
  const { showLoader, startLoading } = useContext(AppContext);

  const isEmailRedirection = location?.state?.redirection || false;
  const isEmailSent = location?.state?.isEmailSent || false;

  const DisplayToastMsg = (MSG, DisplayPosition = 'top', status) => {
    toast({
      description: MSG,
      status: status || 'error',
      duration: 3000,
      position: DisplayPosition,
    });
  };

  const noReceipt = () => {
    const { cashDrawerStatus } = store.getState().socket;
    if (
      // eslint-disable-next-line no-undef
      !isDev &&
      (cashDrawerStatus === 'CD_OPEN_OK' ||
        cashDrawerStatus === 'CD_IS_OPEN' ||
        cashDrawerStatus === 'CD_ALARM_ON')
    ) {
      DisplayToastMsg('Please close cash drawer');
      global?.logger?.error(
        `[7POS UI] - noReceipt cash drawer still open${cashDrawerStatus}`
      );
      return;
    }
    if (cashBack && Number(cashBack) > 0) {
      if (!cashDrawerStatus) {
        global?.logger?.error(
          `[7POS UI] - noReceipt() cashBack triggered and cash drawer :${cashDrawerStatus}`
        );
        return;
      }
    }
    if (
      !isReceiptSent &&
      items.length > 0 &&
      !isTransactionVoid &&
      !isTransactionRefund &&
      !isEmailSent
    ) {
      global?.logger?.info(
        `[7POS UI] - noReceipt() trigger NORECEIPT to store Transaction ${transactionId}`
      );
      sendPrintReceipt('NORECEIPT');
    }
    global?.Logger?.debug(
      `[7POS UI] - noReceipt() exit from paymentconfirmation`
    );
    setTimerStatus(EXIT_TIMER);
  };

  const onExit = () => {
    global?.logger?.info(`[7POS UI] - click exit from paymentConfirmation`);
    noReceipt();
  };

  const onEmailReceiptClick = (isCFD = false) => {
    global?.logger?.info(`[7POS UI] - onEmailReceiptClick() stop timer`);
    // clear timeout before redirection to email.
    clearTimeout(timeoutCancel);
    setTimerStatus(STOP_TIMER);
    if (isCFD)
      global?.logger?.info(`[7POS UI] - onEmailReceiptClick clicked from CFD`);
    history.push('/payment/emailReceipt', {
      storeDetails,
      items,
      transInfo,
      paymentDetails,
      deviceInfo,
      user,
      cashBack,
      transactionId,
      paymentInfo: { paymentMethod, enteredCash },
      paymentHistory,
      paymentMediaList,
      allPayments,
    });
  };

  const sendPrintReceipt = async (
    receiptType = 'PRINT',
    canNotifyCFD = true
  ) => {
    console.log('Calculated FUEL DISCOUNTS', calculatedFuelDiscounts);
    setReceiptSentStatus(true);
    if (receiptType !== 'SAVERECEIPT') {
      const iTransactionMessage = {
        CMD: 'EmailReceipt',
        Status: 'Aborted',
      };
      SendMessageToCFD(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - sendPrintReceipt() receipt type:${receiptType} ${transactionId}`
      );
    }
    const transDetails = { ...transInfo };
    let TransDetails = transDetails;
    const fuelAttrs = getFuelReceiptAttts();
    if (taxBeforeEBTExempt) {
      // RISPIN:2726 Tax deduction should always +ve for void/sale
      transDetails['TAX DEDUCTION'] = Math.abs(taxDeductionAmount);
      transDetails['TAX DEDUCTION'] = transDetails['TAX DEDUCTION']
        .toFixed(2)
        .toString();

      const taxAssessments = createTaxObject(
        taxInfo,
        taxBeforeEBTExempt,
        taxableBeforeEBTExempt,
        isTransactionRefund || isTransactionVoid
      );
      TransDetails = getTaxDetails(
        taxAssessments,
        taxInfo,
        transDetails,
        isTransactionRefund || isTransactionVoid,
        taxableBeforeEBTExempt,
        taxBeforeEBTExempt,
        stateCode
      );
    }
    let paymentReqdata;
    if (isFuelPPCancel && paymentMethod !== 'CASH') {
      paymentReqdata = fuelPreAuthCancelReceipt({
        storeDetails,
        items,
        paymentDetails,
        transInfo: {
          SUBTOTAL: transInfo.SUBTOTAL,
          'TOTAL DUE': transInfo['TOTAL DUE'],
        },
        deviceInfo,
        user,
        transactionId,
        config,
        fuelAttrs,
      });
    } else {
      const fuelSelectedGMeta =
        isCashCreditStore && paymentMethod === 'CASH'
          ? selectedFuelCashGMeta
          : fuelSelectedGradeMeta;
      paymentReqdata = paymentRecepitRequest({
        storeDetails,
        items,
        transInfo: TransDetails,
        paymentDetails,
        deviceInfo,
        user,
        cashBack,
        transactionId,
        paymentInfo: { paymentMethod, enteredCash },
        isTransactionVoid,
        taxInfo: { ...taxInfo, taxAmount: taxBeforeEBTExempt },
        paymentHistory,
        paymentMediaList,
        allPayments,
        isTransactionRefund,
        member,
        basketPromo,
        config,
        loadCardMediaList,
        mediaAbortedPaymentList,
        fuelAttrs,
        sigPrintVouchSelected,
        fuelDiscounts: calculatedFuelDiscounts,
        hostDiscountForSelectedGrade: hostDiscountsforSelectedGrade,
        fuelSelectedGradeMeta: Object.keys(fuelSelectedGMeta).length
          ? fuelSelectedGMeta
          : undefined,
      });
    }

    try {
      paymentReqdata.receiptType = receiptType;
      if (receiptType !== 'SAVERECEIPT') showLoader(true);
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
      /* if (receiptType === 'PRINT' && result?.data?.message) {
        DisplayToastMsg(result?.data?.message, 'top', 'success');
      } */
      global?.logger?.info(`[7POS UI] -  sendPrintReceipt() Success`);
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - sendPrintReceipt() Print receipt API Failure`
      );
      if (receiptType === 'PRINT') {
        if (error?.response?.data) {
          const errorMessage = JSON.parse(
            JSON.stringify(error?.response?.data)
          );
          DisplayToastMsg(errorMessage.message, 'top-left');
        } else {
          DisplayToastMsg(
            'Receipt could not be printed. Please try again',
            'top-left'
          );
        }
      }
    } finally {
      if (receiptType === 'PRINT' && canNotifyCFD) {
        const iTransactionMessage = {
          CMD: 'TransactionComplete',
          Status: 'Completed',
          CFDRefreshTime: config?.storeConfig?.CFDRefreshTime,
        };
        SendMessageToCFD(iTransactionMessage);
      }
      showLoader(false);
    }
  };

  const printRecepitData = async (canNotifyCFD = true) => {
    try {
      await sendPrintReceipt('PRINT', canNotifyCFD);
      global?.logger?.info(
        `[7POS UI] - Restart Timer for Home page redirection after print API call.`
      );
      setTimerStatus(RESTART_TIMER);
    } catch (error) {
      global?.logger?.error(`[7POS UI] - printRecepitData() error`);
    }
  };

  const navigateHome = () => {
    if (!location.pathname.includes('/payment/success')) return;
    setTimeoutCancel(
      setTimeout(() => {
        const { cashDrawerStatus } = store.getState().socket;
        if (!location.pathname.includes('/payment/success')) return;
        if (
          cashDrawerStatus === 'CD_OPEN_OK' ||
          cashDrawerStatus === 'CD_IS_OPEN' ||
          cashDrawerStatus === 'CD_ALARM_ON'
        ) {
          DisplayToastMsg('Please close cash drawer');
          global?.logger?.error(
            `[7POS UI] - navigateHome() cash drawer still open${cashDrawerStatus}`
          );
          return;
        }
        global?.Logger?.debug(
          `[7POS UI] - navigateHome() redirect to home screen after timeout.`
        );
        noReceipt();
      }, 20000)
    );
  };

  useEffect(() => {
    if (isEmailRedirection) {
      return;
    }
    submitPMB();
    return () => {};
  }, []);

  useEffect(() => {
    if (EmailForReceipt.length > 0) {
      if (EmailForReceipt === 'NORECEIPT') {
        noReceipt();
        dispatch(cartActions.setEmailForReceipt(''));
        global?.logger?.info(
          `[7POS UI] - NORECEIPT choosen from CFD ${transactionId}`
        );
      } else {
        global?.logger?.info(
          `[7POS UI] - Email choosen from CFD ${transactionId}`
        );
        onEmailReceiptClick();
      }
    }
  }, [EmailForReceipt]);

  useEffect(() => {
    if (timerStatus === STOP_TIMER && timeoutCancel) {
      global?.Logger?.debug(`[7POS UI] - Stop the timer.`);
      clearTimeout(timeoutCancel);
    } else if (timerStatus === RESTART_TIMER) {
      global?.Logger?.debug(`[7POS UI] - Restart the Timer.`);
      if (timeoutCancel) {
        clearTimeout(timeoutCancel);
      }
      setTimerStatus(START_TIMER);
    } else if (timerStatus === START_TIMER) {
      global?.Logger?.debug(`[7POS UI] - Start the timer.`);
      navigateHome();
    } else if (timerStatus === EXIT_TIMER) {
      if (timeoutCancel) {
        global?.Logger?.debug(`[7POS UI] - Exit the timer.`);
        clearTimeout(timeoutCancel);
      }
      if (
        location.pathname.includes('/payment/success') &&
        !location.pathname.includes('/home')
      ) {
        dispatch(cartActions.emptyCart());
        // #6555 clear number entry
        dispatch(dailpadActions.resetKeypadValue());
        // #4996 added memory transaction check before intiate EOD/EOS
        if (EODEOSDetails?.IntiateEODEOS) {
          if (!transactionMemory?.items) {
            const payload = {
              ...EODEOSDetails,
              isCartItemsOnClear: true,
            };
            global?.logger?.info(
              `[7POS UI] - EOD/EOS are intialised ${JSON.stringify(payload)}`
            );
            dispatch(cartActions.setEODEOS(payload));
          } else {
            DisplayToastMsg(
              `${EODEOSDetails?.type} initiated, Please clear transaction from memory`
            );
            global?.logger?.info(
              `[7POS UI] - ${EODEOSDetails?.type} initiated, Please clear transaction from memory`
            );
          }
        }
        dispatch(socketActions.setCashBack(null));
        dispatch(socketActions.setCashDrawerStatus(null));
        getDVR().setDrawerStatus(null, user);
        dispatch(cfdActions.setCurrentFleetPrompt(null));
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(cfdActions.resetSpeedyRewardSelections());
        global?.Logger?.debug(
          `[7POS UI] - Redirect to home screen:(${location.pathname} ${transactionId})`
        );
        const iTransactionMessage = {
          CMD: 'IntialState',
          COUNTRY: storeDetails?.address?.country,
        };
        SendMessageToCFD(iTransactionMessage);
        setReceiptSentStatus(false);
        history.replace('/home');
      }
    }
  }, [timerStatus]);

  useEffect(() => {
    // Below code should run only once per transaction and skip if come back from
    // Email screen.
    if (!isEmailRedirection) {
      showLoader(false);
      dispatch(cfdActions.setTransactionFinalize(false));
      // #8129 added card load auto print receipt condition
      const isCardLoadItem =
        items?.filter(item => item.itemTypeID === ITEM_TYPE.CARD_LOAD) || false;
      if (isTransactionVoid || isTransactionRefund || isCardLoadItem[0]) {
        global?.logger?.info(
          `[7POS UI] - auto print for void/return/card load transaction ${transactionId}`
        );
        // 1sec timer cause issue when user click exit button immediately landing confirmation screen.
        // anyway void/refund need auto print receipt no need add delay.
        // autoPrintReceipt();
        clearCode({ isConfirmScreen: true })?.catch(e => console.log(e));
        // Has Seperate hook which handles auto receipt print for carwash
        if (!canAutoPrintReceipt) {
          const iTransactionMessage = {
            CMD: 'TransactionComplete',
            Status: 'Completed',
            delayInMS: 0,
            CFDRefreshTime: config?.storeConfig?.CFDRefreshTime,
          };
          SendMessageToCFD(iTransactionMessage);
          printRecepitData(false);
        }
      } else {
        sendPrintReceipt('SAVERECEIPT');
      }
      getDVR().endTransaction(
        allPayments,
        cashBack,
        config,
        deviceInfo,
        items,
        loadCardMediaList,
        member,
        paymentDetails,
        transactionId,
        'Completed',
        '',
        user
      );
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
    }
    // #4655 for void/refund transaction POS will auto print receipt
    // so sending TransactionComplete to CFD after print receipt
    if (
      (EmailForReceipt !== 'NORECEIPT' &&
        !isTransactionVoid &&
        !isTransactionRefund) ||
      isEmailRedirection
    ) {
      const iTransactionMessage = {
        CMD: 'TransactionComplete',
        Status: 'Completed',
        CFDRefreshTime: config?.storeConfig?.CFDRefreshTime,
      };
      SendMessageToCFD(iTransactionMessage);
    }
    if (
      ((!isEmailRedirection && !isTransactionRefund && !isTransactionVoid) ||
        isEmailRedirection) &&
      cashDrawerStatus !== 'CD_ALARM_OFF' &&
      cashDrawerStatus !== 'CD_CLOSED'
    ) {
      if (EmailForReceipt !== 'NORECEIPT') {
        global?.Logger?.debug(
          `[7POS UI] - Restart Timer for Home page redirection.${transactionId}`
        );
        setTimerStatus(RESTART_TIMER);
      }
    }
  }, []);

  useEffect(() => {
    Logger.debug(
      '____***___futurePreauthCancelCache',
      futurePreauthCancelCache,
      'isTAPITransCompleted :-',
      isTAPITransCompleted
    );
    if (futurePreauthCancelCache) {
      startLoading();
    }
    if (futurePreauthCancelCache && isTAPITransCompleted) {
      dispatch(cartActions.emptyCart());
      const { mediaNumber, fuelAmount } = futurePreauthCancelCache;
      setNewTransactionStartTime();
      addVoidFuelCartItem(futurePreauthCancelCache);
      clearFuturePreauthCancelCache();
      history.replace('/payment', {
        preauthCancelFlow: true,
        metaInfo: {
          mediaNumber,
          prepayAmount: fuelAmount,
        },
      });
      Logger.info(`[Fuel] AUTO_PREAUTH_CANCEL : Proccessing autimatically `);
    }
  }, [futurePreauthCancelCache, isTAPITransCompleted]);

  // Automatically prints receipt for FUEL PRE_AUTH Cancel
  useEffect(() => {
    if (
      (isFuelPPCancel || canAutoPrintReceipt || sigPrintVouchSelected) &&
      !isEmailRedirection
    ) {
      // #8853 preserve sigPrintVouchSelected and update after auto print
      const isSigPrintVouchSelected = sigPrintVouchSelected;
      sendPrintReceipt();
      // Print Voucher clear after Receipt Print
      if (isSigPrintVouchSelected)
        dispatch(cartActions.setSigPrintVouchSelected(true));
    }
  }, []);

  // Testing cash drawer toaster issue
  useEffect(() => {
    if (
      cashDrawerStatus === 'CD_ALARM_OFF' ||
      cashDrawerStatus === 'CD_CLOSED'
    ) {
      if (EmailForReceipt !== 'NORECEIPT') {
        global?.Logger?.debug(
          `[7POS UI] - Restart Timer for Home page redirection, cash drawer close event.${transactionId}`
        );
        setTimerStatus(RESTART_TIMER);
      }
    }
    return () => {};
  }, [cashDrawerStatus]);

  return (
    <Box
      justifyContent="space-between"
      height="calc(100vh - 128px)"
      py="0.5rem"
    >
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        height="100%"
        bg="rgb(255,255,255)"
      >
        <Flex flexDirection="column" mx="142px" mt="5.5rem">
          <Box mb="1rem" textAlign="center">
            <img src={Icon_confirm} alt="Confirm" height="40px" width="40px" />
          </Box>
          <Text
            textAlign="center"
            justifyContent="center"
            color="rgb(44, 47, 53)"
            fontSize="24px"
            fontFamily="Roboto-Medium"
            fontWeight="500"
            mb={5}
          >
            Payment Confirmed!
          </Text>
          <Flex flexDirection="column" alignItems="center" my={5} />
          <Flex flexDirection="column" alignItems="center" my={2}>
            {!isCarwashInProgress && (
              <Button
                className={Styles.noReceiptButton}
                mb={5}
                onClick={noReceipt}
                width="100%"
              >
                <Text color="#fffff" fontWeight="bold">
                  NO RECEIPT
                </Text>
              </Button>
            )}
            <Button
              className={Styles.emailReceiptButton}
              onClick={onEmailReceiptClick}
              mb={5}
              width="100%"
            >
              <Text
                color="rgb(91, 97, 107)"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
              >
                EMAIL RECEIPT
              </Text>
            </Button>
            <Button
              className={Styles.emailReceiptButton}
              onClick={() => printRecepitData()}
              mb={5}
              width="100%"
            >
              <Text
                color="rgb(91, 97, 107)"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
              >
                PRINT RECEIPT
              </Text>
            </Button>
          </Flex>
        </Flex>
        <Button
          alignSelf="flex-end"
          mb={15}
          mr={15}
          className="btn secondaryButton"
          width="120px"
          onClick={onExit}
        >
          <Text
            fontSize="18px"
            fontFamily="Roboto-Bold"
            color="rgb(91, 97, 107, 0.9)"
            fontWeight="bold"
          >
            EXIT
          </Text>
        </Button>
      </Flex>
    </Box>
  );
};

export default PaymentConfrimation;
