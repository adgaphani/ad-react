import React, { useContext, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Flex, Text, Box } from '@chakra-ui/react';
import ExitButton from '../../../../components/POS/ExitButton';
import loader from '../../../../Icons/Icons_loader.svg';
import Warning_alert from '../../../../Icons/Warning_alert.png';
import { WebSocketContext } from '../../../../components/Common/WebSocket/WebSocketProvider';
import { appIntegrationRequest } from '../../../../Utils/appUtils';
/* eslint-disable react/prop-types */
import { cartActions } from '../../../../slices/cart.slice';
import { cfdActions } from '../../../../slices/cfd.slice';
import { balanceActions } from '../../../../slices/balance.slice';
import { socketActions } from '../../../../slices/socket.slice';
import { notificationsActions } from '../../../../slices/notifications.slice';
import { SendMessageToCFD } from '../../../../Communication';

function Processing({ iMsg, isRoundUp, isSpeedWayRewdsText }) {
  const {
    currentFleetPrompt,
    balanceInquiryActive,
    paymentTransactionId,
    pinpadProcessMsg,
    RoundUpCharityStatus,
  } = useSelector(state => ({
    currentFleetPrompt: state.cfd.CurrentFleetPrompt,
    balanceInquiryActive: state.balance.isActive,
    paymentTransactionId: state.cart.paymentTransactionId,
    pinpadProcessMsg: state.cart.pinpadProcessMsg,
    RoundUpCharityStatus: state.cart.RoundUpCharityStatus,
  }));
  const [ws] = useContext(WebSocketContext);
  const dispatch = useDispatch();
  const [processingMessage, setProcessingMessage] = useState(iMsg);
  const [roundUpCharity, setRoundUpCharity] = useState(isRoundUp);
  const [speedWayRewdsText, setSpeedWayRewdsText] = useState(
    isSpeedWayRewdsText
  );
  const onCancel = () => {
    dispatch(cartActions.setIsMasterCardLoyaltyPayment(false));
    dispatch(cartActions.setCancelPaymentForMCLoyalty(true));
    SendMessageToCFD({
      CMD: 'MasterCardLoyalty',
      alert: false,
    });
  };
  const goBack = () => {
    if (!isSpeedWayRewdsText) {
      setSpeedWayRewdsText('');
    }
    if (isRoundUp) {
      setRoundUpCharity(false);
      const iTransactionMessage = {
        CMD: 'RoundUpTrigger',
        status: 'Canceled',
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cartActions.setRoundUpCharityStatus('NO'));
      return;
    }
    dispatch(cartActions.setPaymentExit(true));
    if (balanceInquiryActive) {
      dispatch(balanceActions.setBalanceActive(false));
      dispatch(balanceActions.setBalanceInquiryTrigger(false));
    }
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
  };
  const cancel = () => {
    dispatch(cartActions.setPaymentExit(true));
    if (balanceInquiryActive) {
      dispatch(balanceActions.setBalanceActive(false));
      dispatch(balanceActions.setBalanceInquiryTrigger(false));
    }
    dispatch(cartActions.setFleetPromptValues(null));
    dispatch(cfdActions.setCurrentFleetPrompt(null));
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    if (currentFleetPrompt) {
      dispatch(socketActions.setCardStatus(null));
      const iTransactionMessage = {
        CMD: 'PinpadMessage',
        Status: 'CancelCFDMessage',
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cartActions.setPaymentTriggerStatus(false));
      dispatch(notificationsActions.setShowNotifications(true));
    }
  };

  useEffect(() => {
    // #7488 not reset processing message during round up charity flow
    if (pinpadProcessMsg && !isRoundUp) {
      setProcessingMessage(pinpadProcessMsg);
    }
    // @8118 Updating processing text depends on user action
    if (RoundUpCharityStatus !== '') {
      dispatch(cartActions.setPinpadProcessMsg('Processing Request...'));
      setRoundUpCharity(false);
    }
    return () => {};
  }, [pinpadProcessMsg, RoundUpCharityStatus]);

  return (
    <Flex
      flexDirection="column"
      justifyContent="space-between"
      h="100%"
      background="rgb(255,255,255)"
    >
      {!currentFleetPrompt && (
        <>
          <Flex
            alignItems="center"
            justifyContent="center"
            pl="0.5rem"
            bg="rgb(255, 255, 255)"
            height="100%"
            flexDirection="column"
          >
            {!roundUpCharity ? (
              <>
                <object type="image/svg+xml" data={loader} width="100px">
                  svg-animation
                </object>

                <Text
                  color=" rgb(44, 47, 53)"
                  fontFamily="Roboto-Bold"
                  fontSize="18px"
                  fontWeight="bold"
                  mt="2rem"
                >
                  {processingMessage}
                </Text>
                {speedWayRewdsText ? (
                  <Text fontSize={20}>{speedWayRewdsText}</Text>
                ) : (
                  ''
                )}
              </>
            ) : (
              <>
                <Box mb={15}>
                  <Text as="strong" fontSize={28}>
                    Awaiting customer action...
                  </Text>
                </Box>

                <Text fontSize={20}>
                  Please{' '}
                  <Text as="span" color="#107f62" fontWeight={600}>
                    allow the customer to donate to Charity
                  </Text>{' '}
                </Text>
                <Text fontSize={20}>
                  {' '}
                  or Press Skip Donation to finalize the transaction.
                </Text>
              </>
            )}
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            {isRoundUp || speedWayRewdsText ? (
              <ExitButton
                onClick={isRoundUp ? goBack : onCancel}
                label={isRoundUp ? 'SKIP DONATION' : 'EXIT'}
              /> // #7682 removed dots and rename buttton text
            ) : (
              <ExitButton onClick={goBack} isDisabled />
            )}
          </Box>
        </>
      )}
      {currentFleetPrompt?.placeholder && (
        <>
          <Flex
            flexDirection="column"
            alignItems="center"
            height="100%"
            justifyContent="center"
          >
            <Text
              mb={2}
              color="rgb(44, 47, 53)"
              fontSize="24px"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
            >
              Please Have Customer
            </Text>
            <Text
              color="rgb(29, 137, 107)"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
              fontSize="24px"
            >
              Enter the {currentFleetPrompt.placeholder} on the
            </Text>
            <Text
              color="rgb(29, 137, 107)"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
              fontSize="24px"
            >
              CFD Screen
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={cancel} />
          </Box>
        </>
      )}
      {currentFleetPrompt?.error && (
        <>
          <Flex
            flexDirection="column"
            alignItems="center"
            height="100%"
            justifyContent="center"
          >
            <img src={Warning_alert} height="48px" width="54px" alt="warning" />
            <Text
              mb={2}
              color="rgb(44, 47, 53)"
              fontSize="24px"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
            >
              Incorrect Input
            </Text>
            <Text
              color="rgb(29, 137, 107)"
              fontFamily="Roboto-bold"
              fontWeight="bold"
              textAlign="center"
              fontSize="24px"
            >
              Please have customer re-enter information
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={cancel} />
          </Box>
        </>
        // <Flex alignItems="center" justifyContent="center">
        //   {currentFleetPrompt.error}
        // </Flex>
      )}
    </Flex>
  );
}

export default Processing;
