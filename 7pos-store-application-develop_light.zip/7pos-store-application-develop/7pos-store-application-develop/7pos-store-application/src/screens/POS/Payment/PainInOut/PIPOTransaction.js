import React, { useEffect, useContext } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import Styles from './PIPOTransaction.module.css';
import { TransactionStates } from '../../../../constants';
import { CashUtil } from '../../../../Utils/CashUtil';
import { cashFunctionActions } from '../../../../slices/cashFunctions.slice';
import { AppContext } from '../../../../AppContext';

const Transaction = ({ id }) => (
  <Flex className={Styles.transWrapper}>
    <Text className={Styles.transactionText}>Transaction</Text>
    <Text className={Styles.transId}>{`#${id}`}</Text>
  </Flex>
);

const Activity = ({ name }) => (
  <Text className={Styles.activity}>
    {`****    ${name.toUpperCase()}    ****`}
  </Text>
);

const TransactionCancel = ({ name, status }) =>
  status === TransactionStates.aborted ? (
    <Activity name={`${name} CANCELLED`} />
  ) : null;

const TransactionStatus = ({ status }) => (
  <Text className={Styles.status}>
    {`----    TRANSACTION ${status.toUpperCase()}    ----`}
  </Text>
);

const ItemName = ({ name }) => <Text className={Styles.item}>{name}</Text>;

const Amount = ({ amount }) => {
  const amountString =
    amount < 0
      ? `-$${CashUtil.toFloatValue(Math.abs(amount))}`
      : `$${CashUtil.toFloatValue(amount)}`;
  return <Text className={Styles.item}>{amountString}</Text>;
};
const LineItem = ({ name, amount }) => (
  <Flex className={Styles.lineItemWrapper}>
    <ItemName name={name} />
    <Amount amount={parseFloat(amount).toFixed(2)} />
  </Flex>
);

const MediaError = ({ name }) => (
  <Flex className={Styles.errorContainer}>
    {/* eslint-disable-next-line react/no-unescaped-entities */}
    <Text className={Styles.errorTitle}>Please Select "Cash"</Text>
    <Text className={Styles.errorDescription}>
      {`Invalid Media for ${name}`}
    </Text>
  </Flex>
);

export const PIPOTransaction = ({ autoDismiss }) => {
  const { showLoader } = useContext(AppContext);
  const dispatch = useDispatch();
  const { pipoTransaction, transactionId } = useSelector(state => ({
    pipoTransaction: state.cashFunctions.pipoTransaction,
    transactionId: state.cart.transactionId,
  }));
  const displayTransactionId = pipoTransaction?.transactionId || transactionId;
  const isCompleted = pipoTransaction?.isCompleted;
  const {
    amount,
    reason: { shortDescription },
    displayLabel,
    transactionStatus: status,
    workflowStatus,
    mediaError = false,
    multiplicationFactor,
  } = pipoTransaction;

  // Displaying at max 5 secs in case if the user doesn't start any new transaction.
  useEffect(() => {
    let timer;
    if (autoDismiss && isCompleted) {
      global?.logger?.info(
        `Creating 5 sec timer to clear PIPO completed transaction.`
      );
      showLoader(true);
      timer = setTimeout(() => {
        global?.logger?.info(`[AutoReset] ___resetPIPOTransaction`);
        dispatch(cashFunctionActions.resetPIPOTransaction());
        showLoader(false);
      }, 5000);
    }
    return () => {
      clearTimeout(timer);
    };
  }, [isCompleted]);

  return (
    <Flex className={Styles.container}>
      <Transaction id={displayTransactionId} />
      {mediaError && <MediaError name={displayLabel} />}
      <Flex className={Styles.activityWrapper}>
        <Activity name={displayLabel} />
        {amount && status && (
          <LineItem
            name={shortDescription}
            amount={amount * multiplicationFactor}
          />
        )}
        {status && <TransactionCancel name={displayLabel} status={status} />}
        {workflowStatus && <TransactionStatus status="COMPLETED" />}
      </Flex>
    </Flex>
  );
};
