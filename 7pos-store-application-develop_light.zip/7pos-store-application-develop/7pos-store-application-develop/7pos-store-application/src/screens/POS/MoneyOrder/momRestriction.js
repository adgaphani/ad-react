import React, { useState } from 'react';
import { Flex, Box, Text } from '@chakra-ui/react';
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Button } from '../../../components/Common/Buttons';
import warrningSymbol from '../../../Icons/Icon_twarning.svg';
import warrningSymbol1 from '../../../Icons/Icon_Warning.svg';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import ExitButton from '../../../components/POS/ExitButton';
import Styles from './momRestriction.module.css';
import {
  momRestrictionMsg,
  momRestrictionNameMsg,
  momRestrictionNameHeadingMsg,
  momRestrictionDeclineHeadingMsg,
  momRestrictionDeclineMsg,
} from '../../../constants';

const MoMRestrictionStatus = () => {
  const user = useSelector(state => state.auth.user);
  const history = useHistory();
  const dispatch = useDispatch();
  const [userDisagreeName, setuserDisagreeName] = useState(false);

  const FirstName = user?.firstName ? user?.firstName : '';
  const LastName = user?.lastName ? user?.lastName : '';

  const onClickYesBtn = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setMoMAllowedStatus(true));
    history.push('/home/moneyorder');
  };

  const onClickNoBtn = () => {
    dispatch(dailpadActions.resetDailpadState());
    dispatch(cartActions.setMoMAllowedStatus(false));
    setuserDisagreeName(true);
  };

  const onExit = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(dailpadActions.resetDailpadState());
    setuserDisagreeName(false);
    history.push('/home');
  };

  return (
    <Box justifyContent="space-between" h="calc(100vh - 275px)" py="0.5rem">
      <Flex
        h="100%"
        flexDirection="column"
        justifyContent="space-between"
        bg="rgb(255, 255, 255)"
        mr="0.5rem"
      >
        <Flex
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          height="100%"
          width="100%"
          bg="rgb(255,255,255)"
        >
          {userDisagreeName ? (
            <>
              <Box textAlign="center">
                <img
                  src={warrningSymbol1}
                  alt="Error_Node"
                  height="40px"
                  width="40px"
                />
                <Text
                  color="rgb(44, 47, 53)"
                  fontFamily="Roboto-Medium"
                  fontSize="24px"
                  fontWeight="bold"
                  mt=".75rem"
                  dangerouslySetInnerHTML={{
                    __html: momRestrictionDeclineHeadingMsg,
                  }}
                />
                <Text
                  color="rgb(44, 47, 53)"
                  fontFamily="Roboto-Regular"
                  fontSize="18px"
                  fontWeight="normal"
                  mt=".75rem"
                  dangerouslySetInnerHTML={{ __html: momRestrictionDeclineMsg }}
                />
              </Box>
            </>
          ) : (
            <>
              {FirstName.length > 0 && LastName.length > 0 ? (
                <Box textAlign="center">
                  <img
                    src={warrningSymbol}
                    alt="Error_Node"
                    height="40px"
                    width="40px"
                  />
                  <Text
                    color="rgb(44, 47, 53)"
                    fontFamily="Roboto-Medium"
                    fontSize="24px"
                    fontWeight="bold"
                    mt=".75rem"
                  >
                    Please Verify Your Name
                  </Text>
                  <Text
                    color="#107f62"
                    fontFamily="Roboto-Medium"
                    fontSize="24px"
                    fontWeight="bold"
                    mt=".75rem"
                  >
                    {FirstName}
                  </Text>
                  <Text
                    color="rgb(44, 47, 53)"
                    fontFamily="Roboto-Regular"
                    fontSize="18px"
                    fontWeight="normal"
                    mt=".75rem"
                    dangerouslySetInnerHTML={{ __html: momRestrictionMsg }}
                  />
                  <Flex
                    flexDirection="row"
                    justifyContent="space-between"
                    textAlign="center"
                    height="80px"
                    fontWeight="bold"
                    mt="3%"
                    pb={4}
                  >
                    <Button
                      ml="20%"
                      onClick={onClickNoBtn}
                      className={Styles.PayFullBtn}
                    >
                      NO
                    </Button>
                    <Button
                      mr="18%"
                      className={Styles.SaveBtn}
                      bg="#107f62"
                      color="#ffffff"
                      _hover={{ bg: '#107f62' }}
                      onClick={onClickYesBtn}
                    >
                      YES
                    </Button>
                  </Flex>
                </Box>
              ) : (
                <>
                  <Box textAlign="center">
                    <img
                      src={warrningSymbol1}
                      alt="Error_Node"
                      height="40px"
                      width="40px"
                    />
                    <Text
                      color="rgb(44, 47, 53)"
                      fontFamily="Roboto-Medium"
                      fontSize="24px"
                      fontWeight="bold"
                      mt=".75rem"
                      dangerouslySetInnerHTML={{
                        __html: momRestrictionNameHeadingMsg,
                      }}
                    />
                    <Text
                      color="rgb(44, 47, 53)"
                      fontFamily="Roboto-Regular"
                      fontSize="18px"
                      fontWeight="normal"
                      mt=".75rem"
                      dangerouslySetInnerHTML={{
                        __html: momRestrictionNameMsg,
                      }}
                    />
                  </Box>
                </>
              )}
            </>
          )}
        </Flex>
        {(userDisagreeName ||
          FirstName.length <= 0 ||
          LastName.length <= 0) && (
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExit} />
          </Box>
        )}
      </Flex>
    </Box>
  );
};

export default MoMRestrictionStatus;
