/* eslint-disable react/prop-types */

import { Box, Flex, Grid, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { v1 as uuidv1 } from 'uuid';
import { useSoundToast } from '../../../hooks';
import {
  ITEM_TYPE,
  MONEYORDER_SALE_CONTENT,
  MO_FLG_INSALE,
  MO_FLG_INVALID,
  SKIP_PROMO,
} from '../../../constants';
import { cartActions } from '../../../slices/cart.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import ExitButton from '../../../components/POS/ExitButton';
import Keypad from '../../../components/Common/DailPad/Keypad/Keypad';
import { cfdActions } from '../../../slices/cfd.slice';
import { fetchDepartmentInfo } from '../../../api/app/fetchDepartmentInfo';

const MoneyOrderSale = () => {
  const {
    items,
    isTransactionRefund,
    isTransactionVoid,
    isMoMAllowed,
    config,
    paymentTransactionId,
  } = useSelector(state => ({
    items: state.cart.items,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    isMoMAllowed: state.cart.isMoMAllowed,
    config: state.main.configuration,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));
  const dispatch = useDispatch();
  const history = useHistory();
  const toast = useSoundToast();

  useEffect(() => {
    if (isTransactionVoid || isTransactionRefund) {
      toast({
        description: 'Cannot VOID or RETURN Money Order Sale.',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      dispatch(dailpadActions.resetDailpadState());
      history.push('/home');
    } else if (
      !isMoMAllowed &&
      config?.moneyOrderConfig?.isUserVerificationRequired
    ) {
      dispatch(cfdActions.setUserActionScreenActive(true));
      history.push('/home/momRestriction');
    }
  }, []);

  const onEnterValue = async MoneyOrderAmt => {
    // Add Money Order Item
    if (MoneyOrderAmt <= 0) return;
    let moneyOrderFeeAmt = 0;
    let overrideflag = 'N';
    let FeeName = 'Fee';

    const isMoneyItem = items.filter(item => item.isMoneyOrder === true);
    if (isMoneyItem?.length) {
      isMoneyItem.forEach(imapItem => {
        if (imapItem.moneyOrderFeeOverride === 'Y') overrideflag = 'Y';
      });
    }

    const MoneyOrterTotal = items
      ?.filter(
        item =>
          item.MoneyOrderFlag !== MO_FLG_INVALID && item.isMoneyOrder === true
      )
      .reduce((sum, item) => {
        let price = item?.overridedPrice || item?.retailPrice;
        if (
          item.isMoneyOrder &&
          item.moneyOrderFeeOverride !== 'Y' &&
          item.MoneyOrderFlag !== MO_FLG_INVALID
        ) {
          price = parseFloat(
            Number(price) + Number(item.moneyOrderFee)
          ).toFixed(2);
        }
        return sum + price * item.quantity;
      }, 0);

    // maxTransactionAmount will come in $ amount so changed the below comparison to make $ check
    if (
      Number(config?.moneyOrderConfig?.maxTransactionAmount) > 0 &&
      (MoneyOrterTotal + Number(MoneyOrderAmt)) / 100 >
        Number(config?.moneyOrderConfig?.maxTransactionAmount)
    ) {
      toast({
        description: `The MoneyOrder maximum transaction has been exceeded.`,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      Logger.error(
        `The MoneyOrder maximum transaction has been exceeded for MO. Max transaction Amt:${Number(
          config?.moneyOrderConfig?.maxTransactionAmount
        )} and MO:${(MoneyOrterTotal + Number(MoneyOrderAmt)) / 100}`
      );
      dispatch(dailpadActions.resetDailpadState());
      history.push('/home');
      return;
    }
    const FeeDept = config?.moneyOrderConfig?.feeCategoryCode || '340101';
    if (FeeDept && config?.moneyOrderFee?.length) {
      config?.moneyOrderFee.map(feeItem => {
        if (
          Number(feeItem.beginAmount) > 0 &&
          Number(feeItem.endAmount) > 0 &&
          Number(MoneyOrderAmt / 100) <= feeItem.endAmount &&
          Number(MoneyOrderAmt / 100) >= feeItem.beginAmount
        ) {
          moneyOrderFeeAmt = feeItem.feeAmount * 100;
          FeeName = feeItem.description || 'Fee';
        }
        return feeItem;
      });
    }
    try {
      let productCategoryId = Number(
        config?.moneyOrderConfig?.salesCategoryCode
      );
      if (isNaN(productCategoryId)) productCategoryId = 70;
      let deptResponse = await fetchDepartmentInfo(
        productCategoryId,
        paymentTransactionId
      );
      deptResponse = JSON.parse(deptResponse.data.data);
      deptResponse = deptResponse.length > 0 ? deptResponse[0] : {};
      global?.logger?.info(`[7POS UI] - fetch Department  Success`);
      const MaxallowedItemPrice =
        config?.storeConfig?.maxAllowedItemPrice !== undefined &&
        config?.storeConfig?.maxAllowedItemPrice !== null
          ? Number(config?.storeConfig?.maxAllowedItemPrice)
          : 0;
      if (
        deptResponse?.lowAmountLockout &&
        deptResponse?.lowAmountLockout > 0 &&
        Number(MoneyOrderAmt / 100) < deptResponse?.lowAmountLockout
      ) {
        toast({
          description: `Amount too small. Minimum is $${parseFloat(
            deptResponse?.lowAmountLockout
          ).toFixed(2)}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
        Logger.error(
          `Amount too small for MO. Minimum is $${parseFloat(
            deptResponse?.lowAmountLockout
          ).toFixed(2)}`
        );
      } else if (
        (deptResponse?.highAmountLockout &&
          deptResponse?.highAmountLockout > 0 &&
          Number(MoneyOrderAmt) / 100 > deptResponse.highAmountLockout) ||
        Number(MoneyOrderAmt) / 100 > 999999 ||
        (MaxallowedItemPrice !== 0 &&
          Number(MoneyOrderAmt) / 100 > MaxallowedItemPrice)
      ) {
        const Amount = parseFloat(
          deptResponse.highAmountLockout < MaxallowedItemPrice ||
            MaxallowedItemPrice === 0
            ? deptResponse.highAmountLockout
            : MaxallowedItemPrice
        ).toFixed(2);
        toast({
          description: `Amount too large. Maximum is $${Amount}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
        Logger.error(`Amount too large for MO. Maximum is $${Amount}`);
      } else {
        const cartItemObj = {
          isMoneyOrder: true,
          itemTypeID: ITEM_TYPE.DEPT,
          moneyOrderFee: moneyOrderFeeAmt,
          moneyOrderFeeDept: FeeDept,
          moneyOrderFeeOverride: overrideflag,
          moneyOrderFeeName: FeeName,
          MoneyOrderFlag: MO_FLG_INSALE,
          itemSeq: uuidv1(), // dont have item ID so make one unique identifier
          productCategoryId,
          name: deptResponse.description,
          retailPrice: parseFloat(MoneyOrderAmt).toFixed(2) / 100,
          quantity: 1,
          category_id: productCategoryId, // productCategoryId.toString(),
          departmentId: productCategoryId, // productCategoryId.toString(),
          category: { id: productCategoryId },
          connexxusCode: deptResponse.connexxusCode || null,
          PSAGroupInfo: deptResponse.psaGroup,
          isFoodStampAllowed: deptResponse.foodStampAllowed === 'Y' ? 1 : 0,
          updatedAt: Date.now(),
          negativeSalesFlag:
            deptResponse.negativeSalesFlag === 'Y' ||
            deptResponse.negativeSalesFlag === true ||
            false,
          manufacturerCouponAllowed: deptResponse.manufacturerCouponAllowed,
          otherCouponAllowed: deptResponse.otherCouponAllowed,
          storeCouponAllowed: deptResponse.storeCouponAllowed,
          itemTaxes: {
            exciseTaxAmount: null,
            isItemLevelTaxOverride: false,
            taxId: deptResponse?.taxId,
          },
          restrictedMediaTypes: deptResponse?.restrictedMediaTypes,
          highAmountLockout: deptResponse.highAmountLockout,
          lowAmountLockout: deptResponse.lowAmountLockout,
        };
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        dispatch(cartActions.addToCart(cartItemObj));
        // MO amount round off causing issue so picking directly entered amount(in cents)
        dispatch(
          cartActions.addCartItems([
            { ...cartItemObj, retailPrice: MoneyOrderAmt },
            ...items,
          ])
        );
      }
    } catch (error) {
      toast({
        description: `Department Not Found`,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.error(`[7POS UI] - fetchDepartmentInfo details Error`);
    }
    dispatch(dailpadActions.resetDailpadState());
    history.push('/home');
  };

  const onExit = () => {
    dispatch(dailpadActions.resetDailpadState());
    history.push('/home');
  };

  return (
    <Grid templateColumns="50% 50%" width="100%">
      <Box marginLeft="7px" pr="0.5rem">
        <Keypad onEnter={onEnterValue} />
      </Box>
      <Flex
        h="100%"
        flexDirection="column"
        justifyContent="space-between"
        bg="rgb(255, 255, 255)"
        mr="0.5rem"
      >
        <Flex flexDirection="column">
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Bold"
            fontSize="24px"
            fontWeight="bold"
            my="1.75rem"
            ml="2.5rem"
            dangerouslySetInnerHTML={{ __html: 'Enter Money Order<br>Amount' }}
          />
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Regular"
            fontSize="16px"
            fontWeight="normal"
            mx="2.5rem"
          >
            {MONEYORDER_SALE_CONTENT}
          </Text>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={onExit} />
        </Box>
      </Flex>
    </Grid>
  );
};

export default MoneyOrderSale;
