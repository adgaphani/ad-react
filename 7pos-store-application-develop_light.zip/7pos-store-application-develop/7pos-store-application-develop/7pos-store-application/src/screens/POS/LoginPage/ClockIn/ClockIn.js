/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */
/* eslint-disable jsx-a11y/label-has-for */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable no-use-before-define */
import {
  Box,
  Input,
  InputGroup,
  InputRightElement,
  Stack,
  Text,
} from '@chakra-ui/react';
import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { useSoundToast } from '../../../../hooks';
import { Button } from '../../../../components/Common/Buttons';
import { fetchClockinout } from '../../../../api/user/fetchClockinout';
import DailPad from '../../../../components/Common/DailPad/DailPad';
import { LOGIN_ERROR } from '../../../../constants';
import Icons_visibility from '../../../../Icons/Icons_visibility.svg';

import Icons_visibility_off from '../../../../Icons/Icons_visibility_off.svg';
import Styles from './ClockIn.module.css';
import InlineLoader from '../../../../components/Common/Loader/InlineLoader';

const USER_INPUT_LENGTH = 2;
const PASSWORD_INPUT_LENGHT = 6;
function ClockIn(props) {
  const [show, setShow] = useState(false);
  const handleClick = () => setShow(!show);

  const { paymentTransactionId } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
  }));
  const [currentField, setCurrentField] = useState('');
  const [values, setValues] = useState({ userId: '', password: null });
  const [isClockinError, setClockinError] = useState(false);
  const [charAt, setCharAt] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const toast = useSoundToast();

  const isClockinDisabled = !(
    values.userId.length >= 1 && values.password?.length >= 4
  );
  const userIdRef = useRef(null);
  const passwordRef = useRef(null);

  const validateMaxLength = (name, value) => {
    if (name === 'userId' && value.length <= USER_INPUT_LENGTH) {
      return true;
    }
    if (name === 'password' && value.length <= PASSWORD_INPUT_LENGHT) {
      return true;
    }
  };

  const updateCursorPosition = currentEl => () => {
    setCharAt(currentEl.current.selectionStart);
  };
  const onUpdateFieldValue = (cVal, wasBackSpace = false) => {
    if (validateMaxLength(currentField, cVal)) {
      setValues({
        ...values,
        [currentField]: cVal,
      });
    }
    setCharAt(wasBackSpace ? (charAt > 0 ? charAt - 1 : 0) : charAt + 1);
    changeFocus(currentField, cVal);
    resetLoginError();
  };

  const changeFocus = (name, value) => {
    if (userIdRef.current && passwordRef.current) {
      if (name === 'userId' && value.length === USER_INPUT_LENGTH) {
        userIdRef.current.blur();
        passwordRef.current.focus();
      }
    }
  };

  const resetLoginError = () => {
    if (isClockinError) setClockinError(false);
  };
  const handleChange = e => {
    onUpdateFieldValue(e.target.value);
  };

  const resetValues = () => {
    setValues({ userId: '', password: '' });
    setCurrentField('');
    setClockinError(false);
  };

  const handleSubmit = async e => {
    e.stopPropagation();
    e.preventDefault();
    const req = {
      userId: values.userId,
      password: values.password,
      clockInOutTimeStamp: `${moment.utc().format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`,
      updatedBy: '7POS',
    };
    if (
      req.userId &&
      req.userId !== '' &&
      req.password &&
      req.password !== ''
    ) {
      try {
        setIsLoading(true);
        const res = await fetchClockinout(req, paymentTransactionId);
        global?.logger?.info(`[7POS UI] -Fetch Clock in-out API Successful`);
        if (res.data.status === '200 OK') {
          const respMessage = JSON.parse(res.data.data);
          if (respMessage === 'Clock In Successful') {
            toast({
              description: 'You are clocked in. Sign in to get started!',
              status: 'success',
              duration: 3000,
              position: 'top',
            });
            resetValues();
            props.handleTabChange(0);
          } else {
            toast({
              description: 'You have clocked out successfully!',
              status: 'success',
              duration: 3000,
              position: 'top',
            });
            resetValues();
          }
        }
      } catch (error) {
        // #6385 not tracing full log
        global?.logger?.error(
          `[7POS UI] - Fetch Clock in-out API failed and status code :${JSON.stringify(
            error?.response?.status
          )}`
        );
        if (error) {
          const e = JSON.parse(JSON.stringify(error?.response?.data));
          if (e?.message !== 'success') {
            toast({
              status: 'error',
              duration: 3000,
              position: 'top',
              description: 'Clock In/Out Unsuccessful',
            });
          }
        }
        // setClockinError(true);
      } finally {
        setIsLoading(false);
      }
    } else {
      console.warn('Please enter credentials');
    }
  };

  useEffect(() => {
    resetValues();
    setCharAt(0);
  }, [props.tabIndex]);

  return (
    <form onSubmit={e => handleSubmit(e)}>
      <Stack spacing={5} py={3}>
        <Box className="floating-label" mb="13px" fontFamily="Robot-Regular">
          <Input
            type="text"
            name="userId"
            size="lg"
            fontFamily="Roboto-Regular"
            onFocus={() => setCurrentField('userId')}
            onChange={handleChange}
            onClick={updateCursorPosition(userIdRef)}
            focusBorderColor="#107f62"
            value={values.userId ? values.userId : ''}
            borderColor="#d3d3d3"
            placeholder=" "
            autoComplete="off"
            className={`floating-input ${
              currentField === 'userId' ? Styles.borderColorOnFocus : ''
            }`}
            ref={userIdRef}
          />
          <label
            className={
              currentField === 'userId' ? Styles.labelColorOnFocus : ''
            }
          >
            User ID
          </label>
        </Box>
        <InputGroup
          className={`floating-label ${Styles.noMargin}`}
          size="lg"
          borderColor="#d3d3d3"
        >
          <Input
            type={show ? 'text' : 'password'}
            name="password"
            placeholder=" "
            autoComplete="off"
            onFocus={() => setCurrentField('password')}
            onChange={handleChange}
            onClick={updateCursorPosition(passwordRef)}
            value={values.password ? values.password : ''}
            className={`floating-input ${
              isClockinError
                ? Styles.borderColorOnError
                : currentField === 'password'
                ? Styles.borderColorOnFocus
                : ''
            }`}
            focusBorderColor="#107f62"
            ref={passwordRef}
            pattern="\d*"
            maxLength={PASSWORD_INPUT_LENGHT}
            errorBorderColor="rgb(236, 37, 38)"
            isInvalid={isClockinError}
          />
          <InputRightElement width="4.5rem" onClick={handleClick}>
            {show ? (
              <img src={Icons_visibility} alt="visibility" />
            ) : (
              <img src={Icons_visibility_off} alt="visibilityOff" />
            )}
          </InputRightElement>
          <label
            className={
              isClockinError
                ? Styles.labelColorOnError
                : currentField === 'password'
                ? Styles.labelColorOnFocus
                : ''
            }
          >
            Password
          </label>
        </InputGroup>
        {isLoading && <InlineLoader className={Styles.loader} size="sm" />}
        {isClockinError && !isLoading && (
          <label className={Styles.clockinErrorMessage}>{LOGIN_ERROR}</label>
        )}
        {!isLoading && (
          <Button
            isDisabled={isClockinDisabled}
            type="submit"
            value="Submit"
            className={`btn primaryButton mb0 ${
              isClockinDisabled ? Styles.clockinDisabled : ''
            }`}
            size="lg"
            _hover={{ bg: '#107f62' }}
            mt={5}
          >
            <Text
              color={isClockinDisabled ? '#646a73' : 'rgb(255, 255, 255)'}
              fontSize="18px"
              fontFamily="Roboto-Bold"
              fontWeight="bold"
              textAlign="center"
            >
              CLOCK IN/OUT
            </Text>
          </Button>
        )}
        {currentField && !isLoading && (
          <DailPad
            currentValue={values[currentField] || ''}
            clearField={() => setCurrentField('')}
            onUpdateValue={onUpdateFieldValue}
            charAt={charAt}
            hideKey={['ENTER']}
          />
        )}
      </Stack>
    </form>
  );
}

export default ClockIn;
