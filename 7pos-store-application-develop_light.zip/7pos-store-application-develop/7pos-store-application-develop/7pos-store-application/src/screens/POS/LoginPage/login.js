import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Image,
  Box,
  Grid,
  Text,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Flex,
} from '@chakra-ui/react';
import { useLocation } from 'react-router-dom';
import speedyLogo from '@icons/speedway/speedy_logo.svg';
import sevenElevenLogo from '../../../Icons/sevenElevenLogo.svg';
import Styles from './login.module.css';
import Signin from '../../../components/POS/Signin/signin';
import ClockIn from './ClockIn/ClockIn';
import loader from '../../../Icons/Icons_loader.svg';
import { cartActions } from '../../../slices/cart.slice';
import ScreenSaver from './ScreenSaver';
import { useSoundToast } from '../../../hooks';
import store from '../../../store';
import { setShowToast } from '../../../hardware/ipc';
import { NoCompanyScreen } from '../../../components/Common/Registration/NoCompanyScreen';

function LoginPage() {
  const location = useLocation();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  setShowToast(toast);
  const {
    RegistrationInvoke,
    isScreenSaverActive,
    isAppLogin,
    EODEOSDetails,
    storeDetails,
    isDataSyncInProgress,
    isSpeedyStore,
    loadingStoreDetails,
    posSystemStatus,
  } = useSelector(state => ({
    RegistrationInvoke: state.auth.RegistrationInvoke,
    isScreenSaverActive: state.auth.isScreenSaverActive,
    isAppLogin: state.auth.isAppLogin,
    EODEOSDetails: state.cart.EODEOSDetails,
    storeDetails: state.main.storeDetails,
    isDataSyncInProgress: state.auth.isDataSyncInProgress,
    isSpeedyStore: state.main.isSpeedyStore,
    loadingStoreDetails: state.main.loadingStoreDetails,
    posSystemStatus: state.cart.posSystemStatus,
  }));
  const [isRegistrationTrigger, setRegistrationTrigger] = useState(false);
  // const [ScreenSaverTimeOut, setScreenSaverTimeOut] = useState(null);
  const [EODEOSNotifyTimeOut, setEODEOSNotifyTimeOut] = useState(null);

  const [index, setIndex] = useState(
    () => Number(location?.state?.logInTabIndex) || 0
  );

  const [displayMessage, setDisplayMessage] = useState([
    'Device Registration in progress',
    'Please wait...',
  ]);

  const handleTabChange = e => {
    setIndex(e);
  };

  useEffect(() => {
    if (RegistrationInvoke === 1) {
      global?.logger?.info(`POS device registration in progress...`);
      setRegistrationTrigger(true);
      // dispatchEvent(authActions.setRegistrationInvoke(2));
    } else if (RegistrationInvoke === 2) {
      global?.logger?.info(`POS device registration is completed.`);
      setRegistrationTrigger(false);
    }
  }, [RegistrationInvoke]);

  useEffect(() => {
    if (!isAppLogin && !isRegistrationTrigger) {
      // global?.logger?.info(
      //   `POS landing login page and timeout set for Screen Saver.`
      // );
      // comment out
      /* setScreenSaverTimeOut(
        setInterval(() => {
          dispatch(authActions.setScreenSaverActive(true));
        }, 60000 * 5)
      ); */
    } else if (isAppLogin) {
      /* if (ScreenSaverTimeOut) {
        global?.logger?.info(`Clear Screen Saver timeout...`);
        clearTimeout(ScreenSaverTimeOut);
      } */
      if (EODEOSNotifyTimeOut) {
        global?.Logger?.debug(
          `[7POS UI] : Clear EOD toast notification timeout @Login Screen`
        );
        clearTimeout(EODEOSNotifyTimeOut);
      }
    }
    return () => {
      // clearTimeout(setScreenSaverTimeOut);
      clearTimeout(EODEOSNotifyTimeOut);
    };
  }, [isAppLogin]);

  useEffect(() => {
    if (EODEOSDetails.IntiateEODEOS) {
      setEODEOSNotifyTimeOut(
        setInterval(() => {
          const { isAppLogin } = store.getState().auth;
          const { cartItems, transactionMemory } = store.getState().cart;
          const MSG = !transactionMemory?.items
            ? `${EODEOSDetails?.type} initiated, Please complete transaction`
            : `${EODEOSDetails?.type} initiated, Please clear transaction from memory`;
          if (cartItems.length > 0 && !isAppLogin) {
            toast({
              description: MSG,
              status: 'error',
              duration: 3000,
              position: 'top',
            });
            global.logger.info(`[7POS UI] - ${MSG}`);
          }
        }, 10000) // As per discussion #7795 reducethe timer from 30sec/10sec
      );
    } else if (EODEOSNotifyTimeOut) {
      clearTimeout(EODEOSNotifyTimeOut);
    }
    return () => {
      clearTimeout(EODEOSNotifyTimeOut);
    };
  }, [EODEOSDetails.IntiateEODEOS]);

  useEffect(() => {
    if (posSystemStatus && posSystemStatus?.length) {
      if (posSystemStatus === 'SoftwareInstallTriggered') {
        setDisplayMessage([
          'Software Update in progress',
          'Warning: Do not Reboot POS during install',
        ]);
        setTimeout(() => {
          dispatch(cartActions.setPOSSystemStatus('Idle'));
          setDisplayMessage([
            'Device Registration in progress',
            'Please wait...',
          ]);
          toast({
            description: 'POS Install Unsuccessful',
            status: 'error',
            duration: 3000,
            position: 'top',
          });
          Logger.error('POS Install Unsuccessful');
        }, 60000);
      }
    }
  }, [posSystemStatus]);

  const renderClockInOutTab = () => {
    const AVAILABLE_LETTER_CODE = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
    if (
      AVAILABLE_LETTER_CODE.includes(storeDetails?.letterCode) &&
      storeDetails?.address?.country === 'US'
    )
      return (
        <Tab
          backgroundColor="#fff"
          borderLeft="none"
          borderRight="none"
          borderTop="none"
          className={Styles.tablistButton}
          justifyContent="left"
        >
          <Text fontWeight="400" fontSize="20px">
            Clock In/Out
          </Text>
        </Tab>
      );
  };
  if (!storeDetails && loadingStoreDetails) {
    return <NoCompanyScreen />;
  }

  return (
    <>
      {isScreenSaverActive ? (
        <ScreenSaver width={1024} height={768} />
      ) : (
        <>
          <div className={Styles.login}>
            <Grid templateColumns="1fr 1fr">
              <Box height="100vh" bg="backgrounds.primary">
                <Image
                  mt="24%"
                  height="243px"
                  width="184px"
                  src={isSpeedyStore ? speedyLogo : sevenElevenLogo}
                  className={Styles.sevenEleven1}
                  alt="sevenElevenLogo"
                />
              </Box>
              {!isDataSyncInProgress &&
              posSystemStatus !== 'SoftwareInstallTriggered' ? (
                <Box
                  p={3}
                  mt="21%"
                  ml="12%"
                  mr="12%"
                  fontFamily="Roboto-Regular"
                >
                  <Tabs isFitted onChange={handleTabChange} index={index}>
                    <TabList className="tablist" mb={5}>
                      <Tab
                        backgroundColor="#fff"
                        borderLeft="none"
                        borderRight="none"
                        borderTop="none"
                        className={Styles.tablistButton}
                        justifyContent="left"
                      >
                        <Text fontWeight="400" fontSize="20px">
                          Log In
                        </Text>
                      </Tab>
                      {renderClockInOutTab()}
                    </TabList>

                    <TabPanels>
                      <TabPanel>
                        <Signin tabIndex={index} />
                      </TabPanel>
                      <TabPanel>
                        <ClockIn
                          tabIndex={index}
                          handleTabChange={handleTabChange}
                        />
                      </TabPanel>
                    </TabPanels>
                  </Tabs>
                </Box>
              ) : (
                <Flex
                  flexDirection="column"
                  justifyContent="space-between"
                  h="100%"
                  background="rgb(255,255,255)"
                >
                  <Flex
                    alignItems="center"
                    justifyContent="center"
                    pl="0.5rem"
                    bg="rgb(255, 255, 255)"
                    height="100%"
                    flexDirection="column"
                  >
                    <object type="image/svg+xml" data={loader} width="100px">
                      svg-animation
                    </object>
                    <Text
                      color=" rgb(44, 47, 53)"
                      fontFamily="Roboto-Bold"
                      fontSize="18px"
                      fontWeight="bold"
                      mt="2rem"
                    >
                      {displayMessage[0]}
                    </Text>
                    <Text
                      color=" rgb(44, 47, 53)"
                      fontFamily="Roboto-Bold"
                      fontSize="18px"
                      fontWeight="bold"
                      mt="2rem"
                    >
                      {displayMessage[1]}
                    </Text>
                  </Flex>
                </Flex>
              )}
            </Grid>
          </div>
        </>
      )}
    </>
  );
}
export default LoginPage;
