/* eslint-disable */
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { authActions } from '../../../slices/auth.slice';
import useInterval from '@use-it/interval';

function ScreenSaver(props) {
  const history = useHistory();
  const dispatch = useDispatch();
  const [x, setX] = useState(150);
  const [y, setY] = useState(150);

  const handleClick = () => {
    global?.logger?.info(
      `User intervention on screen, POS reset screen saver timer...`
    );
    dispatch(authActions.setScreenSaverActive(false));
    history.push('/');
  };

  /* useEffect(() => {
    setInterval(() => {
      const actionX = Math.random() * (props.width - 250);
      setX(actionX);
      const actionY = Math.random() * (props.height - 100);
      setY(actionY);
    }, 5000);
    return () => {};
  }, []); */

  const updateImageIndex = () => {
    const actionX = Math.random() * (props.width - 250);
    setX(actionX);
    const actionY = Math.random() * (props.height - 100);
    setY(actionY);
  };

  useInterval(() => {
    updateImageIndex();
  }, 5000);

  return (
    <div
      style={{
        border: '1px solid black',
        height: props.height - 20,
        position: 'relative',
        width: props.width - 20,
        backgroundColor: 'black',
      }}
      onClick={handleClick}
    >
      <div
        style={{
          color: 'white',
          textAlign: 'center',
          fontWeight: 600,
          fontSize: 18,
          fontFamily: 'Arial, Helvetica, sans-serif',
          backgroundColor: 'darkgreen',
          border: '5px solid darkred',
          padding: '12px 12px 12px 12px',
          width: '250px',
          top: 0,
          left: 0,
          transform: `translateX(${x}px) translateY(${y}px)`,
          transition: 'transform .5s',
        }}
      >
        Welcome to 7-11
      </div>
    </div>
  );
}
export default ScreenSaver;
