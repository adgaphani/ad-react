export const UPC_COPUN_ACCEPTED = 30; // M1 Coupon accepted
export const GS1_COPUN_ACCEPTED = 31;
// this status code to cashier intervention)
export const COPUN_ACCEPTED_NEEDAMOUNT = 80; // M1 coupon accepted SA need enter discount amount
export const COPUN_ACCEPTED_NEEDAMOUNT1 = 64;
export const COPUN_ACCEPTED_NEEDITEM = 78; // M1 coupon accepted SA need select discount item
export const COPUN_ACCEPTED_NEEDITEMAMOUNT = 52; // M1 coupon accepted SA need select discount item and enter the discount amount
export const COPUN_ACCEPTED_NEEDITEMAMOUNT1 = 63;
export const COPUN_ACCEPTED_NEEDISAINTERVENTION = 57; // M1 coupon accepted SA intervention
export const COPUN_REJECTED_NOTYETACTIVE = 45; // M1 coupon rejected - coupon start dat not yet active
export const COPUN_REJECTED_EXPIRED = 46; // M1 coupon rejected - coupon has expired
export const COPUN_REJECTED_NON711 = 44; // M1 coupon rejected - Non 7-Eleven coupon
export const COPUN_REJECTED_INVALID = 65; // M1 coupon rejected - Coupon save value is reserved
export const COPUN_REJECTED_INVALID1 = 42; // M1 coupon rejected - Promation not applicable to 7-11 - purcahse requriement code
export const COPUN_REJECTED_INVALID2 = 77; // M1 coupon rejected - Promation not applicable to 7-11 - based on save value code
export const COPUN_REJECTED_NOELEITEMS = 47; // M1 coupon rejected - Not enough qulified items include exclusion flag=GS1;
export const COPUN_REJECTED_NOELEITEMS1 = 48; // M1 coupon rejected - No Item Match to coupon company prefix=GS1;
export const COPUN_REJECTED_NOELEITEMS2 = 55; // M1 coupon rejected - Family code does not match to GTIN=GS1;
export const COPUN_REJECTED_NOELEITEMS3 = 58; // M1 coupon rejected - Alphanumeric cahracter encounter in ITEM GTIN =UPC & GS1;
export const COPUN_REJECTED_NOELEITEMS4 = 60; // M1 coupon rejected - All items are have exclusion flag set =GS1;
export const COPUN_REJECTED_NOELEITEMS5 = 68; // M1 coupon rejected - Family code does not match to GTIN=UPC;
export const COPUN_REJECTED_NOELEITEMS6 = 69; // M1 coupon rejected - All items are have exclusion flag set = UPC ;
export const COPUN_REJECTED_NOELEITEMS7 = 72; // M1 coupon rejected - Not enough qulified items based on save value code =UPC;
export const COPUN_REJECTED_NOELEITEMS8 = 79; // M1 coupon rejected - Unable to extract compny prefix from GTIN =UPC & GS1;
export const COPUN_REJECTED_NOELEITEMS9 = 67; // M1 coupon rejected - No Item Match to coupon company prefix=UPC;
export const COPUN_REJECTED_NOTFORMAT = 43; // M1 coupon rejected - Invalid Multiple flag =GS1;
export const COPUN_REJECTED_NOTFORMAT1 = 49; // M1 coupon rejected - Invalid Purchase requriment code=GS1;
export const COPUN_REJECTED_NOTFORMAT2 = 50; // M1 coupon rejected - Invalid APRC code =GS1;
export const COPUN_REJECTED_NOTFORMAT3 = 51; // M1 coupon rejected - Invalid Discount item code=GS1;
export const COPUN_REJECTED_NOTFORMAT4 = 53; // M1 coupon rejected - Invalid date structure coupon =GS1;
export const COPUN_REJECTED_NOTFORMAT5 = 54; // M1 coupon rejected - Item GTIN does not listed on family code table=GS1 & UPC;
export const COPUN_REJECTED_NOTFORMAT6 = 56; // M1 coupon rejected - No save value for cents off promotion =GS1;
export const COPUN_REJECTED_NOTFORMAT7 = 59; // M1 coupon rejected - Alphanumeric cahracter encounter in coupon=GS1 & UPC;
export const COPUN_REJECTED_NOTFORMAT8 = 61; // M1 coupon rejected - Unrecognized AI on coupon =GS1;
export const COPUN_REJECTED_NOTFORMAT9 = 62; // M1 coupon rejected - Coupon code length is not 12 digit=UPC;
export const COPUN_REJECTED_NOTFORMAT0 = 71; // M1 coupon rejected - Addtional barcode digit =GS1;
export const COPUN_REJECTED_NOTFORMAT01 = 73; // M1 coupon rejected - 992 family code with multiple qualifing items. special save value code= UPC;
export const COPUN_REJECTED_NOTFORMAT02 = 74; // M1 coupon rejected - Invalid save value code =GS1;
export const COPUN_REJECTED_NOTFORMAT03 = 76; // M1 coupon rejected - No item match found for predefined discounted group(GS1)

// M1 - findout exact error message from error code
export const CopuonErrorLookUpTable = [
  { Code: COPUN_REJECTED_NOTYETACTIVE, ErrMsg: 'COUPON START DATE NOT VALID' },
  { Code: COPUN_REJECTED_EXPIRED, ErrMsg: 'COUPON HAS EXPIRED' },
  { Code: COPUN_REJECTED_NON711, ErrMsg: 'NON 7-ELEVEN COUPON' },
  {
    Code: COPUN_REJECTED_INVALID,
    ErrMsg: 'Coupon Save Value is reserved for future use',
  },
  {
    Code: COPUN_REJECTED_INVALID1,
    ErrMsg:
      'Promotion not applicable to 7-11 – invalid purchase requirement code',
  },
  {
    Code: COPUN_REJECTED_INVALID2,
    ErrMsg: 'Promotion not applicable to 7-11 – invalid save value code',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS,
    ErrMsg: 'Not enough qualified items include exclusion flag(GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS1,
    ErrMsg: 'No Item Match to coupon company prefix(GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS2,
    ErrMsg: 'Family code does not match the GTIN(GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS3,
    ErrMsg: 'Alphanumeric character encountered in ITEM GTIN (UPC & GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS4,
    ErrMsg: 'All items have the exclusion flag set (UPC & GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS5,
    ErrMsg: 'Family code does not match the GTIN(UPC)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS6,
    ErrMsg: 'All items have the exclusion flag set ( UPC )',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS7,
    ErrMsg: 'Not enough qualified items based on save value code (UPC)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS8,
    ErrMsg: 'Unable to extract company prefix from GTIN (UPC & GS1)',
  },
  {
    Code: COPUN_REJECTED_NOELEITEMS9,
    ErrMsg: 'No Item Match to coupon company prefix(UPC)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT,
    ErrMsg: 'Invalid Do Not Multiply flag (GS1)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT1,
    ErrMsg: 'Invalid Purchase requirement code(GS1)',
  },
  { Code: COPUN_REJECTED_NOTFORMAT2, ErrMsg: 'Invalid APRC code (GS1)' },
  {
    Code: COPUN_REJECTED_NOTFORMAT3,
    ErrMsg: 'Invalid Discount item code(GS1)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT4,
    ErrMsg: 'Invalid date structure for coupon (GS1)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT5,
    ErrMsg: 'Item GTIN is not listed on the family code table(GS1 & UPC)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT6,
    ErrMsg: 'No save value for cents off promotion (GS1)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT7,
    ErrMsg: 'Alphanumeric character encountered in coupon(GS1 & UPC)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT8,
    ErrMsg: 'Unrecognized AI on coupon (GS1)',
  },
  {
    Code: COPUN_REJECTED_NOTFORMAT9,
    ErrMsg: 'Coupon code length is not 12 digit(UPC)',
  },
  { Code: COPUN_REJECTED_NOTFORMAT0, ErrMsg: 'Additional barcode digit (GS1)' },
  {
    Code: COPUN_REJECTED_NOTFORMAT01,
    ErrMsg:
      '992 family code with multiple qualifying items. special save value code( UPC)',
  },
  { Code: COPUN_REJECTED_NOTFORMAT02, ErrMsg: 'Invalid save value code (GS1)' },
  {
    Code: COPUN_REJECTED_NOTFORMAT03,
    ErrMsg: 'No item match found for predefined discounted group(GS1)',
  },
];
