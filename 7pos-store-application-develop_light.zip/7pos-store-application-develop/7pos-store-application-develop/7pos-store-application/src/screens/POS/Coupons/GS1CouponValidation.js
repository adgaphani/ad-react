/* eslint-disable no-lone-blocks */
import moment from 'moment';
import { fetchCuponDetails } from '../../../api/scanner/fetchCouponDetails';
import {
  UPC_COPUN_ACCEPTED,
  GS1_COPUN_ACCEPTED,
  COPUN_ACCEPTED_NEEDAMOUNT,
  COPUN_ACCEPTED_NEEDAMOUNT1,
  COPUN_ACCEPTED_NEEDITEM,
  COPUN_ACCEPTED_NEEDITEMAMOUNT,
  COPUN_ACCEPTED_NEEDITEMAMOUNT1,
  COPUN_ACCEPTED_NEEDISAINTERVENTION,
  COPUN_REJECTED_NOTYETACTIVE,
  COPUN_REJECTED_EXPIRED,
  COPUN_REJECTED_NON711,
  COPUN_REJECTED_INVALID,
  COPUN_REJECTED_INVALID1,
  COPUN_REJECTED_INVALID2,
  COPUN_REJECTED_NOELEITEMS,
  COPUN_REJECTED_NOELEITEMS1,
  COPUN_REJECTED_NOELEITEMS2,
  COPUN_REJECTED_NOELEITEMS3,
  COPUN_REJECTED_NOELEITEMS4,
  COPUN_REJECTED_NOELEITEMS5,
  COPUN_REJECTED_NOELEITEMS6,
  COPUN_REJECTED_NOELEITEMS7,
  COPUN_REJECTED_NOELEITEMS8,
  COPUN_REJECTED_NOELEITEMS9,
  COPUN_REJECTED_NOTFORMAT,
  COPUN_REJECTED_NOTFORMAT1,
  COPUN_REJECTED_NOTFORMAT2,
  COPUN_REJECTED_NOTFORMAT3,
  COPUN_REJECTED_NOTFORMAT4,
  COPUN_REJECTED_NOTFORMAT5,
  COPUN_REJECTED_NOTFORMAT6,
  COPUN_REJECTED_NOTFORMAT7,
  COPUN_REJECTED_NOTFORMAT8,
  COPUN_REJECTED_NOTFORMAT9,
  COPUN_REJECTED_NOTFORMAT0,
  COPUN_REJECTED_NOTFORMAT01,
  COPUN_REJECTED_NOTFORMAT02,
  COPUN_REJECTED_NOTFORMAT03,
} from './GS1CouponConstants';
import { ITEM_TYPE } from '../../../constants';

export const isCouponValidForTransaction = async (
  storeDetails,
  items,
  transactionId,
  GS1CouponBarcode,
  paymentTransactionId
) => {
  const iresult = 'error';
  let ErrorMsg = '';
  try {
    global?.logger?.info(`[7POS UI] - isCouponValidForTransaction ENTRY...`);
    // The data in the RequestDateTime It should be MM/dd/yyyy HH:mm:SS.sss instead of dd/MM/yyyy HH:mm:SS.sss
    const payload = {
      CouponInformation: {
        CouponCode: GS1CouponBarcode,
        RequestDateTime: moment.utc().format('MM/DD/YYYY HH:mm:ss.SSS a'),
      },
      RequestHeader: {
        Channel: 3,
        MessageFormatVersion: '1',
        POSTransSequence: transactionId,
        RequestDateTime: moment.utc().format('MM/DD/YYYY HH:mm:ss.SSS a'),
        StoreId: storeDetails?.storeId,
        TransSequence: transactionId,
      },
      ItemDetails: [],
    };
    // #4824 added department filter check as well
    payload.ItemDetails = items
      .filter(item => !item.isFuel)
      .filter(item => !item.isMoneyOrder)
      .filter(item => item.couponRemainQty > 0)
      .filter(item => !item.isCarwash)
      .filter(item => item.itemTypeID !== ITEM_TYPE.DEPT)
      .filter(item => item.itemTypeID !== ITEM_TYPE.CARD_LOAD)
      .map(item => {
        const departmentId =
          item?.category?.id ||
          (
            item?.PSAGroupInfo?.psaCode +
            item?.PSAGroupInfo?.catCode +
            item?.PSAGroupInfo?.subcatCode
          ).toString();

        let iItemAmount = 0;
        let itemStorediscountAmt = 0;
        let itempBrierlyDiscount = 0;
        let itempBrierlyDiscountQty = 0;
        if (item.arbitration) {
          item.arbitration.map(arbitdata => {
            if (arbitdata.source === 'brierley') {
              // eslint-disable-next-line operator-assignment
              itempBrierlyDiscount =
                itempBrierlyDiscount + arbitdata.itemDiscount;
              // eslint-disable-next-line no-plusplus
              itempBrierlyDiscountQty++;
            } else {
              itemStorediscountAmt += arbitdata.itemDiscount;
            }
            return arbitdata;
          });
        }
        if (item.quantity === itempBrierlyDiscountQty) iItemAmount = 0;
        else {
          if (item.totalOverridedPrice > 0) {
            iItemAmount =
              parseFloat(parseFloat(item.totalOverridedPrice)) -
              parseFloat(parseFloat(itemStorediscountAmt));
          } else {
            iItemAmount =
              parseFloat(parseFloat(item.totalRetailPrice)) -
              parseFloat(parseFloat(itemStorediscountAmt));
          }
          iItemAmount /= item.quantity;
        }
        return {
          Department: departmentId,
          ExclusionFlag: item.manufacturerCouponAllowed === 'Y' ? 'F' : 'T',
          Id: item.itemId.toString(),
          PLU: item.upc,
          Quantity: item.couponRemainQty,
          SalesPrice: iItemAmount > 0 ? iItemAmount : 0,
          Size: item.itemSizeIndex,
        };
      });

    global?.logger?.info(
      `[7POS UI] - fetchCuponDetails request ${JSON.stringify(payload)}`
    );
    /* eslint-disable prefer-const */
    let result = await fetchCuponDetails(payload, paymentTransactionId);
    global?.logger?.info(
      `[7POS UI] - fetchCuponDetails successful ${JSON.stringify(result)}`
    );
    /* result = {
      // mock up data for testing
      data: {
        ResponseHeader: {
          TransSequence: '01012698',
          POSTransSequence: '01012690',
          StoreId: 10017,
          RequestDateTime: '01/13/2021 04:46:29.618 PM',
          MessageFormatVersion: '1',
          ExecutionDuration: 116,
          Status: 0,
        },
        QualifiedItems: [,
        {
            PLU: '00012300200592',
            DiscountedFlag: 1,
          },
          {
            PLU: '00012300200592',
            DiscountedFlag: 0,
          },
          {
            PLU: '10070773125511',
            DiscountedFlag: 0,
          },
        ],
        CouponDetails: {
          Offer_Code: '150689',
          AdditionalPurchaseRequirement: null,
          SaveValueCode: null,
          SaveValue: '150',
          DiscountAmount: 150,
          StartDate: null,
          ExpirationDate: '250930',
          RetailerIdentifier: null,
          SerialNumber: '0011064615',
          DiscountedItem: null,
          StoreCoupon: null,
          DontMultiplyFlag: null,
          PrimaryPurchasePrefix: '0012300',
          PrimaryPurchaseRequirement: '2',
          PrimaryRequirementCode: '0',
          PrimaryPurchaseFamilyCode: '211',
          SecondPurchasePrefix: null,
          SecondPurchaseRequirement: null,
          SecondRequirementCode: null,
          SecondPurchaseFamilyCode: null,
          ThirdPurchasePrefix: null,
          ThirdPurchaseRequirement: null,
          ThirdRequirementCode: null,
          ThirdPurchaseFamilyCode: null,
          ManufacturerCouponFlag: 1,
          UPCACouponFlag: 0,
          CouponValueCode: null,
          StatusCode: 78,
        },
      },
    }; */
    if (
      result.data.CouponDetails.DiscountAmount > 0 &&
      (result.data?.CouponDetails?.StatusCode ===
        COPUN_ACCEPTED_NEEDITEMAMOUNT ||
        result.data?.CouponDetails?.StatusCode ===
          COPUN_ACCEPTED_NEEDITEMAMOUNT1 ||
        result.data?.CouponDetails?.StatusCode === COPUN_ACCEPTED_NEEDAMOUNT ||
        result.data?.CouponDetails?.StatusCode === COPUN_ACCEPTED_NEEDAMOUNT1)
    ) {
      result.data.CouponDetails.DiscountAmount = 0;
    } else if (
      result.data?.CouponDetails?.StatusCode === UPC_COPUN_ACCEPTED ||
      result.data?.CouponDetails?.StatusCode === GS1_COPUN_ACCEPTED ||
      result.data?.CouponDetails?.StatusCode ===
        COPUN_ACCEPTED_NEEDISAINTERVENTION
    ) {
      if (
        !result.data?.QualifiedItems &&
        result.data?.CouponDetails?.DiscountAmount === 0
      ) {
        result.data.CouponDetails.StatusCode = COPUN_ACCEPTED_NEEDITEMAMOUNT;
      } else if (result.data.CouponDetails.DiscountAmount === 0) {
        result.data.CouponDetails.StatusCode = COPUN_ACCEPTED_NEEDAMOUNT1;
      } else if (!result.data?.QualifiedItems) {
        result.data.CouponDetails.StatusCode = COPUN_ACCEPTED_NEEDITEM;
      }
    } else if (
      result.data?.CouponDetails?.StatusCode === COPUN_ACCEPTED_NEEDITEM
    ) {
      if (result.data.CouponDetails.DiscountAmount === 0) {
        result.data.CouponDetails.StatusCode = COPUN_ACCEPTED_NEEDITEMAMOUNT;
      }
    } else if (
      result.data?.CouponDetails?.StatusCode === COPUN_ACCEPTED_NEEDAMOUNT1 ||
      result.data?.CouponDetails?.StatusCode === COPUN_ACCEPTED_NEEDAMOUNT
    ) {
      if (!result.data.QualifiedItems) {
        result.data.CouponDetails.StatusCode = COPUN_ACCEPTED_NEEDITEMAMOUNT;
      }
    }
    switch (result?.data.CouponDetails?.StatusCode) {
      // Recieved success message -  coupon is accepted and discounted item is figured by ESL layer
      case COPUN_REJECTED_NOELEITEMS:
      case COPUN_REJECTED_NOELEITEMS1:
      case COPUN_REJECTED_NOELEITEMS2:
      case COPUN_REJECTED_NOELEITEMS3:
      case COPUN_REJECTED_NOELEITEMS4:
      case COPUN_REJECTED_NOELEITEMS5:
      case COPUN_REJECTED_NOELEITEMS6:
      case COPUN_REJECTED_NOELEITEMS7:
      case COPUN_REJECTED_NOELEITEMS8:
      case COPUN_REJECTED_NOELEITEMS9:
        {
          ErrorMsg =
            'Coupon cannot be applied as item is not eligible for discount.';
        }
        break;
      case COPUN_REJECTED_INVALID: // SOC changes
        {
          ErrorMsg = 'Invalid and unsupported barcode.';
        }
        break;
      case COPUN_REJECTED_INVALID1:
      case COPUN_REJECTED_INVALID2:
        {
          ErrorMsg = 'Invalid and unsupported barcode.';
        }
        break;
      case COPUN_REJECTED_EXPIRED:
        {
          ErrorMsg = 'Coupon has expired.';
        }
        break;
      case COPUN_REJECTED_NOTYETACTIVE:
        {
          ErrorMsg = 'Coupon is for a future date.';
        }
        break;
      case COPUN_REJECTED_NON711:
        {
          ErrorMsg = 'Coupon not accepted. Non 7-Eleven coupon.';
        }
        break;
      case COPUN_REJECTED_NOTFORMAT:
      case COPUN_REJECTED_NOTFORMAT1:
      case COPUN_REJECTED_NOTFORMAT2:
      case COPUN_REJECTED_NOTFORMAT3:
      case COPUN_REJECTED_NOTFORMAT4:
      case COPUN_REJECTED_NOTFORMAT5:
      case COPUN_REJECTED_NOTFORMAT6:
      case COPUN_REJECTED_NOTFORMAT7:
      case COPUN_REJECTED_NOTFORMAT8:
      case COPUN_REJECTED_NOTFORMAT9:
      case COPUN_REJECTED_NOTFORMAT0:
      case COPUN_REJECTED_NOTFORMAT01:
      case COPUN_REJECTED_NOTFORMAT02:
      case COPUN_REJECTED_NOTFORMAT03:
        {
          ErrorMsg = 'The coupon cannot be scan. Please apply manually.';
        }
        break;

      case UPC_COPUN_ACCEPTED:
      case GS1_COPUN_ACCEPTED:
      case COPUN_ACCEPTED_NEEDAMOUNT:
      case COPUN_ACCEPTED_NEEDAMOUNT1:
      case COPUN_ACCEPTED_NEEDITEM:
      case COPUN_ACCEPTED_NEEDITEMAMOUNT:
      case COPUN_ACCEPTED_NEEDITEMAMOUNT1:
      case COPUN_ACCEPTED_NEEDISAINTERVENTION:
        {
          ErrorMsg = '';
        }
        break;
      default:
        {
          ErrorMsg = 'Coupon service offline.';
        }
        break;
    }
    const CouponResponse = result.data;
    return { CouponResponse, ErrorMsg };
  } catch (error) {
    console.error(error);
    global?.logger?.error(
      `[7POS UI] - fetchCuponDetails details error ${JSON.stringify(error)}`
    );
    ErrorMsg = 'Coupon service offline.';
    return { iresult, ErrorMsg };
  }
};
