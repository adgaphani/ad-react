/* eslint-disable no-lone-blocks */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import {
  Box,
  Flex,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import { v1 as uuidv1 } from 'uuid';
import { useSoundToast } from '../../../hooks';
import { Button } from '../../../components/Common/Buttons';
import ExitButton from '../../../components/POS/ExitButton';
import Styles from './GS1Coupon.module.css';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { isCouponValidForTransaction } from './GS1CouponValidation';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { buildCartChangeTrial } from '../../../Utils/cartUtils';
import {
  UPC_COPUN_ACCEPTED,
  GS1_COPUN_ACCEPTED,
  COPUN_ACCEPTED_NEEDAMOUNT,
  COPUN_ACCEPTED_NEEDAMOUNT1,
  COPUN_ACCEPTED_NEEDITEM,
  COPUN_ACCEPTED_NEEDITEMAMOUNT,
  COPUN_ACCEPTED_NEEDITEMAMOUNT1,
  COPUN_ACCEPTED_NEEDISAINTERVENTION,
  CopuonErrorLookUpTable,
} from './GS1CouponConstants';
import { ITEM_TYPE, SKIP_PROMO } from '../../../constants';

const SCAN_COUPON = 1;

const GS1Coupon = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const {
    transactionId,
    cartItems,
    storeDetails,
    GS1CouponBarcode,
    selectedItem,
    CouponDetails,
    isTransactionRefund,
    isTransactionVoid,
    cartChangeTrial,
    tranItemSeqNumber,
    paymentTransactionId,
  } = useSelector(state => ({
    transactionId: state.cart.transactionId,
    cartItems: state.cart.cartItems,
    storeDetails: state.main.storeDetails,
    GS1CouponBarcode: state.cart.GS1CouponBarcode,
    selectedItem: state.cart.selectedItem,
    CouponDetails: state.cart.CouponDetails,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
    cartChangeTrial: state.cart.cartChangeTrial,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));

  const toast = useSoundToast();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [CouponDiscountAmt, setCouponDiscountAmt] = useState(0);

  const checkItemAvailabilty = QualifiedItems => {
    let DiscountedItem = '';
    QualifiedItems?.map(item => {
      if (item.DiscountedFlag === 1) {
        DiscountedItem = item.PLU;
      }
      return item;
    });
    let isItemFound = false;
    cartItems.map(item => {
      if (item.upc === DiscountedItem) {
        if (item.couponRemainQty > 0) {
          isItemFound = item;
          dispatch(cartActions.setSelectedItem(item));
        }
      }
      return item;
    });
    return isItemFound;
  };

  const DisplayToastMsg = (config, DisplayOnlyToast = false) => {
    toast({
      description: config.msg,
      status: config.status || 'error',
      duration: 5000,
      position: 'top-left',
    });

    if (!DisplayOnlyToast) {
      dispatch(cartActions.setCouponDetails(''));
      dispatch(cartActions.setGS1CouponBarcode(''));
      dispatch(cartActions.setSelectedItem(null));
      dispatch(cfdActions.setUserActionScreenActive(false));
      history.push('/home');
    }
  };

  const AddCoupon = (
    CouponAmt,
    adjustPrice = false,
    selectedItem,
    CouponDetails
  ) => {
    if (!selectedItem) return;
    let iItemAmount = 0;
    let item_discount = 0;
    iItemAmount = Math.abs(
      selectedItem.totalOverridedPrice > 0
        ? parseFloat(parseFloat(selectedItem.totalOverridedPrice))
        : parseFloat(parseFloat(selectedItem.totalRetailPrice))
    );

    if (selectedItem.storeCoupon && selectedItem.storeCoupon[0]) {
      selectedItem.storeCoupon.map(coupondata => {
        item_discount += Number(Math.abs(coupondata.amount * 100));
        return coupondata;
      });
    }
    if (selectedItem?.arbitration) {
      selectedItem.arbitration.forEach(arbit => {
        item_discount += Number(arbit.itemDiscount);
      });
    }
    const iAmountPerItem = iItemAmount / selectedItem.quantity;
    iItemAmount -= item_discount;
    if (iItemAmount < 0) iItemAmount = 0;
    if (
      selectedItem.quantity > 1 &&
      iItemAmount > 0 &&
      iItemAmount >= iAmountPerItem
    ) {
      iItemAmount = iAmountPerItem;
    }
    let price = Number(iItemAmount);
    price = Number(parseFloat(price).toFixed(2)) / 100;
    let amount = Number(CouponAmt) / 100;
    if (
      adjustPrice &&
      Math.abs(amount) > 0 &&
      Math.abs(amount) > Math.abs(price)
    )
      amount = price;
    if (Math.abs(amount) > 0 && Math.abs(amount) <= Math.abs(price)) {
      const CouponSeq = uuidv1();
      global?.logger?.info('CouponSeq', CouponSeq);
      const entrytype = SCAN_COUPON;
      let EligibleItemNotFound = false;

      if (entrytype === SCAN_COUPON) {
        if (CouponDetails?.QualifiedItems[0]) {
          const iCopyCouponDetails = CouponDetails?.QualifiedItems.map(
            dataItem => dataItem.PLU
          ) // get all unique PLU
            .filter((PLU, index, array) => array.indexOf(PLU) === index);

          const EligibleItems = iCopyCouponDetails.map(PLU => ({
            ItemUPC: PLU,
            count: CouponDetails?.QualifiedItems.filter(
              item => item.PLU === PLU
            ).length,
          }));

          EligibleItems.map(data => {
            const item = cartItems.filter(item => item.upc === data.ItemUPC);
            if (item.length > 0 && item[0].couponRemainQty >= data.count) {
              // Eligible items found
            } else {
              EligibleItemNotFound = true;
            }
            return data;
          });
          if (!EligibleItemNotFound) {
            EligibleItems.map(data => {
              const item = cartItems.filter(item => item.upc === data.ItemUPC);
              dispatch(
                cartActions.setCouponLinkDetails({
                  DiscounteditemId: selectedItem.itemId,
                  couponseq: CouponSeq,
                  quantity: data.count,
                  itemId: item[0].itemId,
                  entrytype,
                })
              );
              dispatch(
                cartActions.updateQuantity({
                  itemId: item[0].itemId,
                  quantity: item[0].quantity,
                  indx: item[0].itemSeq,
                })
              );
              return data;
            });
          }
        }
      }
      if (!EligibleItemNotFound && selectedItem.couponRemainQty > 0) {
        dispatch(
          cartActions.updateQuantity({
            itemId: selectedItem.itemId,
            quantity: selectedItem.quantity,
            itemSubIndex:
              selectedItem.tranSubItemSeqNumber > 0
                ? selectedItem.tranSubItemSeqNumber + 1
                : 1,
            indx: selectedItem.itemSeq,
          })
        );
        dispatch(cfdActions.setUserActionScreenActive(false));
        // #5829 move up promo skip flag before item update to tax trigger
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        dispatch(
          cartActions.setCouponValue({
            type:
              CouponDetails?.ManufacturerCouponFlag === 0
                ? 'Store'
                : 'Manufacturer',
            amount: parseFloat(amount).toFixed(2),
            itemId: selectedItem.itemId,
            couponseq: CouponSeq,
            name: `CP ${selectedItem.name}`,
            entrytype,
            CouponBarcode: GS1CouponBarcode,
            CouponDetails,
            itemSubIndex:
              selectedItem.tranSubItemSeqNumber > 0
                ? selectedItem.tranSubItemSeqNumber + 1
                : 1,
          })
        );
        dispatch(dailpadActions.resetDailpadState());
        setTimeout(() => {
          dispatch(cfdActions.setUserActionScreenActive(false));
          dispatch(cartActions.setCouponDetails(''));
          dispatch(cartActions.setGS1CouponBarcode(''));
          dispatch(cartActions.setSelectedItem(null));
          history.push('/home');
        }, 1000);
        DisplayToastMsg({ msg: 'Coupon Applied', status: 'success' }, true);
      } else {
        setTimeout(() => {
          dispatch(cfdActions.setUserActionScreenActive(false));
          dispatch(cartActions.setCouponDetails(''));
          dispatch(cartActions.setGS1CouponBarcode(''));
          dispatch(cartActions.setSelectedItem(null));
          history.push('/home');
        }, 500);
        DisplayToastMsg(
          {
            msg:
              'Coupon cannot be applied as item is not eligible for discount.',
          },
          true
        );
      }
    } else {
      dispatch(dailpadActions.resetDailpadState());
      DisplayToastMsg({
        msg: `Price cannot exceed ${price}`,
      });
    }
  };

  const applyCoupon = (selectedItem, CouponDetails) => {
    const couponamount = CouponDetails.CouponDetails.DiscountAmount;
    /* isTransactionVoid || isTransactionRefund
        ? CouponDetails.CouponDetails.DiscountAmount
        : -CouponDetails.CouponDetails.DiscountAmount; */
    AddCoupon(couponamount, true, selectedItem, CouponDetails);
  };

  const isCouponValid = async () => {
    dispatch(cartActions.setCouponDetails(''));
    dispatch(cfdActions.setUserActionScreenActive(true));
    const { CouponResponse, ErrorMsg } = await isCouponValidForTransaction(
      storeDetails,
      cartItems,
      transactionId,
      GS1CouponBarcode,
      paymentTransactionId
    );
    if (CouponResponse !== 'error' && ErrorMsg.length === 0) {
      dispatch(cartActions.setCouponDetails(CouponResponse));
      switch (CouponResponse?.CouponDetails?.StatusCode) {
        // Recieved success message -  coupon is accepted and discounted item is figured by ESL layer
        case UPC_COPUN_ACCEPTED:
        case GS1_COPUN_ACCEPTED:
          {
            // accepted
            const discountItem = checkItemAvailabilty(
              CouponResponse?.QualifiedItems
            );
            if (discountItem) {
              applyCoupon(discountItem, CouponResponse);
            } else {
              DisplayToastMsg({
                msg:
                  'Coupon cannot be applied as item is not eligible for discount.',
              });
            }
          }
          break;
        case COPUN_ACCEPTED_NEEDAMOUNT:
        case COPUN_ACCEPTED_NEEDAMOUNT1:
          {
            if (checkItemAvailabilty(CouponResponse?.QualifiedItems)) {
              if (CouponResponse?.CouponDetails?.ManufacturerCouponFlag === 0) {
                // check for 7-11 coupon
                history.push({
                  pathname: '/home/coupons',
                  search: '?couponType=store&amount=true&disablebackbtn=true',
                });
              } else {
                history.push({
                  pathname: '/home/coupons',
                  search:
                    '?couponType=manufacture&amount=true&disablebackbtn=true',
                });
              }
            } else {
              DisplayToastMsg({
                msg:
                  'Coupon cannot be applied as item is not eligible for discount.',
              });
            }
          }
          break;
        case COPUN_ACCEPTED_NEEDITEM:
          {
            const couponamount =
              isTransactionRefund || isTransactionVoid
                ? CouponResponse?.CouponDetails?.DiscountAmount
                : -CouponResponse?.CouponDetails?.DiscountAmount;
            if (CouponResponse?.CouponDetails?.ManufacturerCouponFlag === 0) {
              // check for 7-11 coupon
              history.push({
                pathname: '/home/coupons',
                search: `?couponType=store&item=true&discamount=${couponamount}&disablebackbtn=true`,
              });
            } else {
              history.push({
                pathname: '/home/coupons',
                search: `?couponType=manufacture&item=true&discamount=${couponamount}&disablebackbtn=true`,
              });
            }
          }
          break;
        case COPUN_ACCEPTED_NEEDITEMAMOUNT:
        case COPUN_ACCEPTED_NEEDITEMAMOUNT1:
          {
            if (CouponResponse?.CouponDetails?.ManufacturerCouponFlag === 0) {
              // check for 7-11 coupon
              history.push({
                pathname: '/home/coupons',
                search: '?couponType=store&itemamount=true&disablebackbtn=true',
              });
            } else {
              history.push({
                pathname: '/home/coupons',
                search:
                  '?couponType=manufacture&itemamount=true&disablebackbtn=true',
              });
            }
          }
          break;
        case COPUN_ACCEPTED_NEEDISAINTERVENTION:
          {
            // cahier accept
            if (checkItemAvailabilty(CouponResponse?.QualifiedItems)) {
              onOpen();
              const amount =
                parseFloat(
                  CouponResponse?.CouponDetails?.DiscountAmount
                ).toFixed(2) / 100;
              setCouponDiscountAmt(amount);
            } else {
              DisplayToastMsg({
                msg:
                  'Coupon cannot be applied as item is not eligible for discount.',
              });
            }
          }
          break;
        default:
          {
            DisplayToastMsg({ msg: 'Coupon service offline.' });
          }
          break;
      }
    } else {
      if (
        CouponResponse !== 'error' &&
        CouponResponse?.CouponDetails?.StatusCode > 0
      ) {
        let errMsg = '';
        CopuonErrorLookUpTable.map(err => {
          if (err.Code === CouponResponse?.CouponDetails?.StatusCode) {
            errMsg = err.ErrMsg;
          }
          return err;
        });
        // #4802 For any error using primary sequence number only eventhough sub item.
        const CartTrialPayLoad = buildCartChangeTrial({
          item: {
            name: 'Coupon Error',
            tranItemSeqNumber: tranItemSeqNumber + 1,
          },
          eventType: 'addItemError',
          eventSeq: cartChangeTrial.length,
          eventResult: `${errMsg}-${GS1CouponBarcode}`,
        });
        dispatch(
          cartActions.addToCartChangeTrial({
            CartTrialPayLoad,
            tranItemSeqNumber: tranItemSeqNumber + 1,
          })
        );
      }
      DisplayToastMsg({ msg: ErrorMsg });
    }
  };

  useEffect(() => {
    // #4824 modify the logic to find coupon eligible Items present or not.
    if (GS1CouponBarcode?.length > 0 && cartItems?.length > 0) {
      let isEligibleItem = false;
      cartItems
        .filter(item => !item.isFuel)
        .filter(item => !item.isMoneyOrder)
        .filter(item => item.couponRemainQty > 0)
        .filter(item => !item.isCarwash)
        .filter(item => item.itemTypeID !== ITEM_TYPE.DEPT)
        .filter(item => item.itemTypeID !== ITEM_TYPE.CARD_LOAD)
        .map(item => {
          if (item.couponRemainQty > 0 && !isEligibleItem)
            isEligibleItem = true;
          return item;
        });
      if (isEligibleItem) {
        isCouponValid();
      } else {
        // Primary Validation No Eligible items found in the transaction
        DisplayToastMsg({
          msg: 'Coupon cannot be applied as item is not eligible for discount.',
        });
      }
    } else if (GS1CouponBarcode?.length > 0) {
      // Primary Validationitems length
      DisplayToastMsg({
        msg: 'Invalid Operation, Cart is Empty',
      });
    }
  }, [GS1CouponBarcode]);

  const addCoupon = () => {
    applyCoupon(selectedItem, CouponDetails);
    history.push('/home');
  };

  const rejectCoupon = () => {
    onClose();
    history.push('/home');
  };

  const iNotificationMsg =
    'Coupon Validation in Progress<br />Please wait.<br />';
  return (
    <React.Fragment>
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="70%"
        background="rgb(255,255,255)"
        boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
        my="0.6rem"
        ml="0.5rem"
        mr="0.6rem"
      >
        <Flex
          alignItems="center"
          justifyContent="center"
          flexDirection="column"
          mt="20%"
        >
          <Text
            className={Styles.userentrynotification}
            dangerouslySetInnerHTML={{ __html: iNotificationMsg }}
          />
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton isDisabled />
        </Box>
      </Flex>
      <Modal isOpen={isOpen}>
        <ModalOverlay className={Styles.modalOverlay} />
        <ModalContent className={Styles.modalContainer}>
          <ModalHeader className={Styles.modalHeader}>
            <Text
              color="rgb(44, 47, 53)"
              fontsize="28px"
              fontFamily="Roboto-Bold"
              fontweight="bold"
              lineheight="30px"
              textalign="center"
            >
              APPLY COUPON CONFIRMATION
            </Text>
          </ModalHeader>
          <ModalBody className={Styles.modalBody} mx="30px">
            <Text
              color="rgb(44, 47, 53)"
              fontWeight="normal"
              lineHeight="28px"
              textAlign="center"
            >
              This coupon will apply the discount of ${CouponDiscountAmt}.
              Select &ldquo;Ok&ldquo; to continue or &ldquo;Cancel&ldquo; to
              reject.
            </Text>
          </ModalBody>
          <ModalFooter
            justifyContent="center"
            marginBottom="40px"
            mx="50px"
            padding="0px"
          >
            <Button
              className={Styles.noButton}
              width="200px"
              mr={3}
              onClick={rejectCoupon}
            >
              <Text>Cancel</Text>
            </Button>
            <Button
              className={Styles.okButton}
              width="200px"
              onClick={addCoupon}
            >
              <Text>Ok</Text>
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </React.Fragment>
  );
};

export default GS1Coupon;
