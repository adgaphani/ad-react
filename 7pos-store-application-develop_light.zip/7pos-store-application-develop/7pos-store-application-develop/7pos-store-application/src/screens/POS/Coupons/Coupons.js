import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { useSoundToast } from '../../../hooks';
import { Button } from '../../../components/Common/Buttons';

import ManufactureCoupons from './manufactureCoupons';
import ExitButton from '../../../components/POS/ExitButton';
import StoreCoupons from './storeCoupons';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';

// const SCAN_COUPON = 1;
const MANUAL_COUPON = 2;

const Coupons = () => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const paramas = new URLSearchParams(location.search);
  const couponType = paramas.get('couponType') || null;
  const isRequiredItemAmount = paramas.get('itemamount') || false;
  const isRequiredOnlyItem = paramas.get('item') || false;
  const isRequiredOnlyAmount = paramas.get('amount') || false;
  const selectedItem = useSelector(state => state.cart.selectedItem);

  const triggerCoupon = (search, scancoupon = false) => {
    if (selectedItem) {
      let isCouponApplicable = false;
      if (
        selectedItem.couponRemainQty === 0 &&
        !scancoupon &&
        !selectedItem.negativeSalesFlag
      ) {
        if (selectedItem.storeCoupon && selectedItem.storeCoupon[0]) {
          selectedItem.storeCoupon.map(coupondata => {
            if (coupondata.entrytype === MANUAL_COUPON)
              isCouponApplicable = true;
            return coupondata;
          });
        }
      }

      if (
        !selectedItem.negativeSalesFlag &&
        (selectedItem.couponRemainQty > 0 || isCouponApplicable)
      ) {
        history.push({
          pathname: '/home/coupons',
          search,
        });
      } else {
        dispatch(cfdActions.setUserActionScreenActive(false));
        toast({
          description:
            'Coupon cannot be applied as item is not eligible for discount.',
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
        dispatch(cartActions.setSelectedItem(null));
        if (!scancoupon) history.push('/home');
      }
    } else dispatch(cfdActions.setUserActionScreenActive(false));
  };

  const onStoreCoupClick = () => {
    if (!isRequiredItemAmount && !isRequiredOnlyAmount && !isRequiredOnlyItem) {
      dispatch(cfdActions.setUserActionScreenActive(true));
      triggerCoupon('?couponType=store');
    }
  };

  const onManufactureCoupClick = () => {
    if (!isRequiredItemAmount && !isRequiredOnlyAmount && !isRequiredOnlyItem) {
      dispatch(cfdActions.setUserActionScreenActive(true));
      triggerCoupon('?couponType=manufacture');
    }
  };

  const onClickExitBtn = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setSelectedItem(null));
    history.push('/home');
  };

  return (
    <>
      {selectedItem && couponType === 'store' ? (
        <StoreCoupons selectedItem={selectedItem} />
      ) : selectedItem && couponType === 'manufacture' ? (
        <ManufactureCoupons selectedItem={selectedItem} />
      ) : (
        <Flex
          flexDirection="column"
          justifyContent="space-between"
          bg="rgb(255, 255, 255)"
          width="100%"
          h="calc(100vh - 275px)"
        >
          <Flex flexDirection="column">
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Bold"
              fontSize="24px"
              fontWeight="bold"
              textAlign="center"
              m="1.75rem"
            >
              {selectedItem ? 'Apply Coupon' : 'Select item to apply coupon'}
            </Text>
            {!isRequiredOnlyItem && !isRequiredItemAmount && (
              <Flex flexDirection="column" alignItems="center" my={4}>
                <Button
                  background="rgb(226, 239, 236)"
                  borderRadius="3px"
                  height="50px"
                  mb="1.5rem"
                  width="360px"
                  border="1px solid rgb(16, 127, 98)"
                  _hover={{
                    bg: 'rgb(16, 127, 98)',
                    color: 'rgb(255, 255, 255)',
                  }}
                  onClick={onStoreCoupClick}
                >
                  <Text
                    fontFamily="Roboto-Medium"
                    fontSize="18px"
                    fontWeight="500"
                  >
                    Store Coupon
                  </Text>
                </Button>
                <Button
                  background="rgb(226, 239, 236)"
                  borderRadius="3px"
                  height="50px"
                  width="360px"
                  border="1px solid rgb(16, 127, 98)"
                  _hover={{
                    bg: 'rgb(16, 127, 98)',
                    color: 'rgb(255, 255, 255)',
                  }}
                  onClick={onManufactureCoupClick}
                >
                  <Text
                    fontFamily="Roboto-Medium"
                    fontSize="18px"
                    fontWeight="500"
                  >
                    Manufacturer Coupon
                  </Text>
                </Button>
              </Flex>
            )}
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onClickExitBtn} />
          </Box>
        </Flex>
      )}
    </>
  );
};

export default Coupons;
