import React from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Flex, Text, Image } from '@chakra-ui/react';
import discountImage from '@icons/fuelIcons/fuel_discount.svg';

// import Styles from './DiscountPrompt.module.css';
import { SideContainer } from '../../../components/Common/Containers';
import { Button } from '../../../components/Common';
import { Messages } from '../../../Messages';
import { centsToDollor } from '../../../Utils';
import { SendMessageToPOS } from '../../../Communication';
import MemberInfo from '../../../components/CFD/CFDALTID/MemberInfo';
import { cartActions } from '../../../slices/cart.slice';

export const Discountprompt = props => {
  console.log(props, 'Props');
  const history = useHistory();
  const dispatch = useDispatch();
  const { loyalty } = useSelector(state => ({
    loyalty: state.cart.fuelLoyalty,
  }));
  const onClick = isSelected => {
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
    SendMessageToPOS({ CMD: 'updateFuelLoyalty', isSelected });
    if (isSelected) {
      dispatch(cartActions.updatePromptableDiscount(isSelected));
    }
  };
  return (
    <SideContainer>
      <MemberInfo />
      <Flex
        alignItems="center"
        justifyContent="center"
        width="100%"
        height="99%"
        flexDirection="column"
        paddingX="2rem"
      >
        <Text fontWeight="bold" fontSize="1.5rem" paddingBottom="20px">
          {' '}
          {Messages.continue}?
        </Text>
        <Image
          height="200px"
          width="203px"
          src={discountImage}
          alt="sevenElevenLogo"
        />
        <Text fontSize="1.4rem" textAlign="center" p={4} paddingTop="18px">
          {' '}
          {Messages.fuel_prompt_discount_msg?.replace(
            '$',
            centsToDollor(loyalty?.promptable_discounts?.[0].discount ?? 0)
          )}
        </Text>
        <Flex width="100%" justifyContent="center" paddingTop="50px">
          <Button
            width="43%"
            mr="25px"
            height="45px"
            bg="default.posWhite"
            borderRadius={0}
            border="1px"
            onClick={() => {
              onClick(false);
            }}
          >
            <Text fontWeight="normal">NO</Text>
          </Button>
          <Button
            width="43%"
            bg="primary"
            height="45px"
            borderRadius={0}
            onClick={() => {
              onClick(true);
            }}
          >
            <Text color="default.posWhite">YES</Text>
          </Button>
        </Flex>
      </Flex>
    </SideContainer>
  );
};
