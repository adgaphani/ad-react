import { Box, Flex, Grid, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { v1 as uuidv1 } from 'uuid';
import { useSoundToast } from '../../../hooks';
import { dailpadActions } from '../../../slices/dailpad.slice';
import Icon_confirm from '../../../Icons/Icon_confirm.svg';
import ExitButton from '../../../components/POS/ExitButton';
import Keypad from '../../../components/Common/DailPad/Keypad/Keypad';
import { MANUFACTURE_COUPON_CONTENT, SKIP_PROMO } from '../../../constants';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';

const MANUAL_COUPON = 2;
const SCAN_COUPON = 1;

const ManufactureCoupons = ({ selectedItem }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const toast = useSoundToast();
  const [couponApplied, setCouponApplied] = useState(false);

  const { GS1CouponBarcode, CouponDetails, cartItems } = useSelector(state => ({
    GS1CouponBarcode: state.cart.GS1CouponBarcode,
    CouponDetails: state.cart.CouponDetails,
    cartItems: state.cart.cartItems,
  }));

  const location = useLocation();
  const paramas = new URLSearchParams(location.search);
  const isBackBtnisable = paramas.get('disablebackbtn') || false;
  let isDiscAmt = paramas.get('discamount') || 0;
  // TODO: NO UPPER Case Method Names
  const DisplayToastMsg = (cnfg, DisplayOnlyToast = false) => {
    toast({
      description: cnfg.msg,
      status: cnfg.status || 'error',
      duration: 5000,
      position: 'top-left',
    });

    if (!DisplayOnlyToast) {
      dispatch(cartActions.setCouponDetails(''));
      dispatch(cartActions.setGS1CouponBarcode(''));
      dispatch(cartActions.setSelectedItem(null));
      dispatch(cfdActions.setUserActionScreenActive(false));
      history.push('/home');
    }
  };

  const CouponAmtAdjust = (CouponAmt, adjustPrice = false) => {
    /* CouponAmt =
      isTransactionVoid || isTransactionRefund ? CouponAmt : -CouponAmt; */
    if (!selectedItem) return;
    const CouponType = 'Manufacturer';
    let iItemAmount = 0;
    let item_discount = 0;
    let isManualCouponAmount = 0;
    iItemAmount = Math.abs(
      selectedItem.totalOverridedPrice > 0
        ? parseFloat(parseFloat(selectedItem.totalOverridedPrice))
        : parseFloat(parseFloat(selectedItem.totalRetailPrice))
    );

    if (selectedItem.storeCoupon && selectedItem.storeCoupon[0]) {
      selectedItem.storeCoupon.map(coupondata => {
        if (coupondata.entrytype === MANUAL_COUPON)
          isManualCouponAmount = Number(Math.abs(coupondata.amount * 100));
        item_discount += Number(Math.abs(coupondata.amount * 100));
        return coupondata;
      });
    }
    if (selectedItem?.arbitration) {
      selectedItem.arbitration.forEach(arbit => {
        item_discount += Number(arbit.itemDiscount);
      });
    }
    const iAmountPerItem = iItemAmount / selectedItem.quantity;
    iItemAmount -= item_discount;
    if (iItemAmount < 0) iItemAmount = 0;

    if (
      selectedItem.quantity > 1 &&
      iItemAmount > 0 &&
      iItemAmount >= iAmountPerItem
    ) {
      iItemAmount = iAmountPerItem;
    } else if (
      isManualCouponAmount > 0 &&
      iAmountPerItem <= isManualCouponAmount + iItemAmount
    ) {
      iItemAmount += isManualCouponAmount;
    }
    let price = Number(iItemAmount);
    price = Number(parseFloat(price).toFixed(2)) / 100;
    let amount = Number(CouponAmt) / 100;
    if (
      adjustPrice &&
      Math.abs(amount) > 0 &&
      Math.abs(amount) > Math.abs(price)
    )
      amount = price;
    if (Math.abs(amount) > 0 && Math.abs(amount) <= Math.abs(price)) {
      let CouponSeq = null;
      let entrytype = MANUAL_COUPON;
      let ManualentrytypeSeq = '';
      if (selectedItem.storeCoupon && selectedItem.storeCoupon[0]) {
        selectedItem.storeCoupon.map(coupondata => {
          // eslint-disable-next-line no-plusplus
          if (coupondata.entrytype === MANUAL_COUPON)
            ManualentrytypeSeq = coupondata.couponseq;
          return coupondata;
        });
      }
      if (!isBackBtnisable && ManualentrytypeSeq.length > 0) {
        dispatch(cartActions.setCouponDetails(''));
        CouponSeq = ManualentrytypeSeq;
      } else CouponSeq = uuidv1();
      if (isBackBtnisable) entrytype = SCAN_COUPON;
      let EligibleItemNotFound = false;

      if (entrytype === SCAN_COUPON) {
        if (CouponDetails?.QualifiedItems[0]) {
          const iCopyCouponDetails = CouponDetails?.QualifiedItems.map(
            dataItem => dataItem.PLU
          ) // get all unique PLU
            .filter((PLU, index, array) => array.indexOf(PLU) === index);

          const EligibleItems = iCopyCouponDetails.map(PLU => ({
            ItemUPC: PLU,
            count: CouponDetails?.QualifiedItems.filter(
              item => item.PLU === PLU
            ).length,
          }));

          EligibleItems.map(data => {
            const item = cartItems.filter(item => item.upc === data.ItemUPC);
            if (item.length > 0 && item[0].couponRemainQty >= data.count) {
              // Eligible item found
            } else {
              EligibleItemNotFound = true;
            }
            return data;
          });
          if (!EligibleItemNotFound) {
            EligibleItems.map(data => {
              const item = cartItems.filter(item => item.upc === data.ItemUPC);
              dispatch(
                cartActions.setCouponLinkDetails({
                  DiscounteditemId: selectedItem.itemId,
                  couponseq: CouponSeq,
                  quantity: data.count,
                  itemId: item[0].itemId,
                  entrytype,
                })
              );
              dispatch(
                cartActions.updateQuantity({
                  itemId: item[0].itemId,
                  quantity: item[0].quantity,
                  indx: item[0].itemSeq,
                })
              );
              return data;
            });
          }
        }
      }
      if (
        entrytype === MANUAL_COUPON ||
        (!EligibleItemNotFound && selectedItem.couponRemainQty > 0)
      ) {
        if (entrytype === MANUAL_COUPON) {
          dispatch(
            cartActions.setCouponLinkDetails({
              DiscounteditemId: selectedItem.itemId,
              couponseq: CouponSeq,
              quantity: 1,
              itemId: selectedItem.itemId,
              entrytype,
            })
          );
        }
        dispatch(
          cartActions.updateQuantity({
            itemId: selectedItem.itemId,
            quantity: selectedItem.quantity,
            itemSubIndex:
              ManualentrytypeSeq.length > 0
                ? 0
                : selectedItem.tranSubItemSeqNumber > 0
                ? selectedItem.tranSubItemSeqNumber + 1
                : 1,
            indx: selectedItem.itemSeq,
          })
        );

        const CouponDetailsM = {
          QualifiedItems: [
            {
              PLU: selectedItem.upc,
              DiscountedFlag: 1,
            },
          ],
        };
        dispatch(cfdActions.setUserActionScreenActive(false));
        // #5829 move up promo skip flag before item update to tax trigger
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        dispatch(
          cartActions.setCouponValue({
            type: CouponType,
            amount: parseFloat(amount).toFixed(2),
            itemId: selectedItem.itemId,
            couponseq: CouponSeq,
            name: `CP ${selectedItem.name}`,
            entrytype,
            CouponBarcode: entrytype === SCAN_COUPON ? GS1CouponBarcode : '',
            CouponDetails:
              entrytype === SCAN_COUPON ? CouponDetails : CouponDetailsM,
            itemSubIndex:
              ManualentrytypeSeq.length > 0
                ? 0
                : selectedItem.tranSubItemSeqNumber > 0
                ? selectedItem.tranSubItemSeqNumber + 1
                : 1,
          })
        );
        dispatch(dailpadActions.resetDailpadState());
        setTimeout(() => {
          dispatch(cfdActions.setUserActionScreenActive(false));
          dispatch(cartActions.setCouponDetails(''));
          dispatch(cartActions.setGS1CouponBarcode(''));
          dispatch(cartActions.setSelectedItem(null));
          history.push('/home');
        }, 1000);
        if (setCouponApplied) setCouponApplied(true);
        DisplayToastMsg(
          {
            msg: 'Coupon Applied',
            status: 'success',
          },
          true
        );
      } else {
        setTimeout(() => {
          dispatch(cfdActions.setUserActionScreenActive(false));
          dispatch(cartActions.setCouponDetails(''));
          dispatch(cartActions.setGS1CouponBarcode(''));
          dispatch(cartActions.setSelectedItem(null));
          history.push('/home');
        }, 500);
        DisplayToastMsg(
          {
            msg:
              'Coupon cannot be applied as item is not eligible for discount.',
          },
          true
        );
      }
    } else {
      dispatch(dailpadActions.resetDailpadState());
      DisplayToastMsg(
        {
          msg: `Price cannot exceed ${price}`,
        },
        true
      );
    }
  };
  const onEnterValue = e => {
    CouponAmtAdjust(e);
  };
  const onGoback = () => {
    if (isBackBtnisable) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cartActions.setSelectedItem(null));
      history.push('/home');
      // record rejection
    } else history.push('/home/coupons');
  };
  const onExit = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cartActions.setSelectedItem(null));
    history.push('/home');
  };
  useEffect(() => {
    if (Math.abs(isDiscAmt) > 0) {
      CouponAmtAdjust(isDiscAmt, true);
      isDiscAmt = 0;
    }
  }, [isDiscAmt]);
  return (
    <Grid templateColumns="50% 50%" width="100%">
      <Box marginLeft="7px" pr="0.5rem">
        <Keypad onEnter={onEnterValue} />
      </Box>
      {couponApplied ? (
        <Flex
          h="100%"
          flexDirection="column"
          justifyContent="space-between"
          bg="rgb(255, 255, 255)"
          mr="0.5rem"
        >
          <Flex
            flexDirection="column"
            h="100%"
            alignItems="center"
            justifyContent="center"
          >
            <Box mb="0.75rem" textAlign="center">
              <img
                src={Icon_confirm}
                alt="Confirm"
                height="40px"
                width="40px"
              />
            </Box>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Medium"
              fontSize="24px"
              fontWeight="500"
              height="26px"
              lineHeight="26px"
            >
              Coupon Applied
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onExit} />
          </Box>
        </Flex>
      ) : (
        <Flex
          h="100%"
          flexDirection="column"
          justifyContent="space-between"
          bg="rgb(255, 255, 255)"
          mr="0.5rem"
        >
          <Flex flexDirection="column">
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Bold"
              fontSize="24px"
              fontWeight="bold"
              my="1.75rem"
              ml="2.5rem"
            >
              Enter coupon amount
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="16px"
              fontWeight="normal"
              mx="2.5rem"
            >
              {MANUFACTURE_COUPON_CONTENT}
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="1rem" w="100%">
            <ExitButton onClick={onGoback} />
          </Box>
        </Flex>
      )}
    </Grid>
  );
};

export default ManufactureCoupons;
