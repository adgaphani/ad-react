import React from 'react';
import { Box, Grid, Flex, Text } from '@chakra-ui/react';
import CfdCart from '../CfdCart/cfd_cart';
import CfdMain from '../CfdMain';
import Styles from './cfd.module.css';

function CfdHome(props) {
  return (
    <>
      <Grid border="5px" height="100vh" templateColumns="29.5% 70.5%">
        <Box
          w="100%"
          classname={Styles.cfdcart}
          shadow="md"
          background="#f8f8f8"
          box-shadow="-2px 0px 6px 0px rgba(0, 0, 0, 0.2)"
        >
          <Flex flexDirection="column" height="100%">
            <Flex
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              height="50px"
              color="rgb(44, 47, 53)"
              borderBottom="1px solid rgb(211, 211, 211)"
              mt={4}
              pb={4}
              fontFamily="Roboto-Bold"
              lineHeight="30px"
              width="100%"
            >
              <Text fontWeight="bold" fontSize="2.18vw">
                Your Items
              </Text>
            </Flex>
            <CfdCart {...props} />
          </Flex>
        </Box>
        <Box className={Styles.main}>
          <CfdMain {...props} />
        </Box>
      </Grid>
    </>
  );
}
export default CfdHome;
