import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import Styles from './cfd_cart.module.css';
import { displayCurrency } from '../../../Utils/appUtils';

const cfdTransactionSubItem = props => {
  const {
    itemName,
    itemAmount,
    itemColour = '',
    itemAmtColour = '',
    KeyIndex = 0,
    isRemoved = false,
    itemSuffix = '',
    type,
    flag,
    depositFee,
  } = props;
  const isFees = () => type === 'BOTTLE_DEPOSIT' || type === 'ECO_FEE';

  const getItemAmtColour = () => {
    if (isFees()) {
      return 'rgb(16, 127, 98)';
    }
    return itemAmtColour;
  };

  const getItemAmount = () => {
    if (isFees()) {
      return `${displayCurrency({ price: depositFee })} ${flag}`;
    }
    return itemAmount;
  };
  return (
    <Flex
      key={KeyIndex}
      flexDirection="row"
      justifyContent="space-between"
      alignItems="center"
      px={4}
      pt={2}
      fontSize={isFees() ? '1.40vw' : '1.56vw'}
      color="rgb(44, 47, 53)"
    >
      <Flex flexDirection="row" alignItems="center" color={itemColour}>
        <Text ml="14px" fontFamily="Roboto-Medium" fontWeight="500">
          {itemName}
        </Text>
      </Flex>
      <Box>
        <Text color={getItemAmtColour()} className={Styles.priceAlignment}>
          <span
            className={
              isRemoved
                ? itemSuffix === ''
                  ? Styles.priceCouponCfdStrike
                  : Styles.pricePromoCfdStrike
                : itemSuffix === ''
                ? Styles.priceCouponCfd
                : Styles.pricePromoCfd
            }
          >
            {getItemAmount()}
          </span>
        </Text>
      </Box>
    </Flex>
  );
};
cfdTransactionSubItem.defaultProps = {
  itemName: '',
  itemAmount: '',
  itemColour: '',
  itemAmtColour: '',
  KeyIndex: 0,
  isRemoved: false,
};

cfdTransactionSubItem.propTypes = {
  itemName: PropTypes.string,
  itemAmount: PropTypes.string,
  itemColour: PropTypes.string,
  itemAmtColour: PropTypes.string,
  KeyIndex: PropTypes.number,
  isRemoved: PropTypes.bool,
};
export default cfdTransactionSubItem;
