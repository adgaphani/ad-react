/* eslint-disable react/prop-types */
/* eslint-disable prefer-destructuring */
/* eslint-disable react/destructuring-assignment */
import React, { useMemo } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import TransactionComplete from '../../POS/Payment/PaymentTransaction/paymentSummary/transactionComplete';
import VoidTransactionText from '../../POS/Cart/VoidTransactionText';
import CFDTransactionItem from './cfditem';
import Styles from './cfd_cart.module.css';
import CFDTransactionTotal from './cfd_totaldetails';
import { displayCurrency, getTotalBtlDeposit } from '../../../Utils/appUtils';
import MediaAbortedText from '../../POS/Cart/MediaAbortedText';
import { getUpadtedFuelDiscounts } from '../../../Utils/cartUtils';

let Journalitems = [];
function CfdCart(props) {
  const {
    isTransactionFinalize,
    basketPromo,
    TransactionStatus,
    TransactionType,
    fuelDiscounts,
    hostDiscountsforSelectedGrade,
    updatedDiscounts,
    // finalTotalPriceToDisplay,
  } = useSelector(state => {
    const {
      fuelLoyalty: {
        forcedDiscountForSelectedGrade,
        promptable_discounts,
      } = {},
      hostDiscountsforSelectedGrade,
    } = state.cart;
    const fuelDiscounts = [
      ...(forcedDiscountForSelectedGrade?.length
        ? [...forcedDiscountForSelectedGrade]
        : []),
      ...(promptable_discounts?.length ? [...promptable_discounts] : []),
    ];
    return {
      isTransactionFinalize: state.cfd.isTransactionFinalize,
      basketPromo: state.cart.basketPromo,
      TransactionStatus: state.cfd.TransactionStatus,
      TransactionType: state.cfd.TransactionType,
      updatedDiscounts: state.cart.updatedDiscounts,
      fuelDiscounts,
      hostDiscountsforSelectedGrade,
    };
  });
  Journalitems = props.Journalitems;
  const TaxDetails = props.TaxDetails;
  const taxData = props.TaxInfo;
  const { TotalDetails } = props;

  let {
    finalsubTotalPrice,
    finalTotalPrice,
    totalPromotionPrice,
    totalDue,
    Cash,
    Change,
    CashBack,
    taxDeductionAmount,
  } = '0.00';
  let basketPromoDiscount = [];
  let PaymentMediaList = [];

  if (Journalitems?.length > 0 && TotalDetails?.finalTotalPrice) {
    finalsubTotalPrice = TotalDetails.finalsubTotalPrice
      ? TotalDetails.finalsubTotalPrice
      : '0.00';
    finalTotalPrice = TotalDetails.finalTotalPrice
      ? TotalDetails.finalTotalPrice
      : '0.00';
    totalPromotionPrice = TotalDetails.totalPromotionPrice
      ? TotalDetails.totalPromotionPrice
      : '0.00';
    taxDeductionAmount = TotalDetails.taxDeductionAmount;
    // #4838 added deduction amount as well total due before render.
    totalDue = Number(TotalDetails.totalDue)
      ? Number(TotalDetails.totalDue) + Number(taxDeductionAmount)
      : '0.00';
    Cash = TotalDetails.Cash ? TotalDetails.Cash : '0.00';
    Change = TotalDetails.Change ? TotalDetails.Change : '0.00';

    // const CardDetails = TotalDetails.Card ? TotalDetails.Card : [];
    CashBack = TotalDetails.CashBack ? TotalDetails.CashBack : '0.00';

    PaymentMediaList = TotalDetails.PaymentMediaList
      ? TotalDetails.PaymentMediaList
      : [];
  }
  if (isTransactionFinalize && basketPromo?.length > 0) {
    const promodiscount = basketPromo?.slice(-1);
    basketPromoDiscount = promodiscount
      ? {
          amount: (promodiscount[0]?.item_discount).toFixed(2) / 100,
          name: promodiscount[0]?.name,
        }
      : {};
  }
  const finalFuelDiscounts = useMemo(
    () => getUpadtedFuelDiscounts(fuelDiscounts, updatedDiscounts),
    [fuelDiscounts, updatedDiscounts]
  );
  return (
    <Flex
      direction="column"
      justifyContent="space-between"
      className={Styles.cfdcartContainer}
    >
      <Box className={Styles.cfdcartItemContainer}>
        {Journalitems?.map((item, keyindex) => (
          <CFDTransactionItem
            key={keyindex}
            item={item}
            isReturnVoid={
              TransactionType === 'Void' || TransactionType === 'Refund'
            }
            taxData={taxData}
            items={Journalitems}
            basketPromo={basketPromo}
            fuelDiscounts={finalFuelDiscounts}
            hostDiscounts={hostDiscountsforSelectedGrade}
          />
        ))}
        {isTransactionFinalize && basketPromo?.length > 0 && (
          <Flex
            flexDirection="row"
            alignItems="center"
            pl={3}
            alignSelf="center"
            py={2}
            fontSize="1.25vw"
            color="rgb(91, 97, 107)"
            fontWeight="normal"
            fontFamily="Roboto-Regular"
          >
            <Text color="#ec2526">
              {TransactionType === 'Void' || TransactionType === 'Refund'
                ? `$${basketPromoDiscount.amount}`
                : `-$${basketPromoDiscount.amount}`}
            </Text>
            <Text ml={2}>{basketPromoDiscount.name}</Text>
          </Flex>
        )}
      </Box>

      <Box>
        {(TransactionType === 'Void' || TransactionType === 'Refund') && (
          <VoidTransactionText
            type={TransactionType === 'Refund' ? 'REFUND' : 'VOID'}
          />
        )}
        {PaymentMediaList &&
          PaymentMediaList.length > 0 &&
          props?.isMediaAborted && <MediaAbortedText />}
        {!!getTotalBtlDeposit(props?.Journalitems || []) &&
          Journalitems?.length > 0 && (
            <CFDTransactionTotal
              {...props}
              TextValue="Total Btl Dep-N"
              Amount={displayCurrency({
                price: getTotalBtlDeposit(props?.Journalitems || []),
                currency: '$',
              })}
            />
          )}
        {Journalitems?.length > 0 && (
          <CFDTransactionTotal
            {...props}
            TextValue="Subtotal"
            Amount={
              Number(finalsubTotalPrice) >= 0
                ? `$${parseFloat(Math.abs(Number(finalsubTotalPrice))).toFixed(
                    2
                  )}`
                : `-$${parseFloat(Math.abs(Number(finalsubTotalPrice))).toFixed(
                    2
                  )}`
            }
          />
        )}
        {totalPromotionPrice !== 'NaN' &&
          totalPromotionPrice !== '0.00' &&
          Journalitems?.length > 0 && (
            <CFDTransactionTotal
              {...props}
              TextValue="Discount(s)"
              Amount={
                TransactionType === 'Void' || TransactionType === 'Refund'
                  ? `$${parseFloat(
                      Math.abs(Number(totalPromotionPrice))
                    ).toFixed(2)}`
                  : `-$${parseFloat(
                      Math.abs(Number(totalPromotionPrice))
                    ).toFixed(2)}`
              }
              TextColour="#ec2526"
            />
          )}
        {Journalitems?.length > 0 && TaxDetails && (
          <>
            {TaxDetails.map((taxDetails, keyindex) => (
              <CFDTransactionTotal
                {...props}
                TextValue={taxDetails.description}
                Amount={
                  isNaN(taxDetails?.amount) || taxDetails?.amount === '0.00'
                    ? '0.00'
                    : Number(taxDetails?.amount) >= 0
                    ? `$${parseFloat(
                        Math.abs(Number(taxDetails?.amount))
                      ).toFixed(2)}`
                    : `-$${parseFloat(
                        Math.abs(Number(taxDetails?.amount))
                      ).toFixed(2)}`
                }
                key={keyindex}
              />
            ))}
          </>
        )}
        {!TransactionStatus.length > 0 && Journalitems?.length > 0 && (
          <>
            {totalDue !== '0.00' &&
              totalDue !== 0 &&
              Journalitems?.length > 0 && (
                <CFDTransactionTotal
                  {...props}
                  TextValue={
                    TransactionType === 'Void' || TransactionType === 'Refund'
                      ? 'Refund Due'
                      : 'Total Due'
                  }
                  Amount={
                    Number(totalDue) >= 0
                      ? `$${parseFloat(totalDue).toFixed(2)}`
                      : `-$${parseFloat(Math.abs(Number(totalDue))).toFixed(2)}`
                  }
                />
              )}
            {taxDeductionAmount && Number(taxDeductionAmount) > 0 ? (
              <CFDTransactionTotal
                {...props}
                TextValue="Tax Deduction"
                Amount={`$${parseFloat(taxDeductionAmount).toFixed(2)}`}
              />
            ) : (
              ''
            )}
            {PaymentMediaList && PaymentMediaList.length > 0 && (
              <>
                {PaymentMediaList.map((paymentMedia, keyindex) => (
                  <CFDTransactionTotal
                    {...props}
                    comment={paymentMedia?.label}
                    TextValue={`${paymentMedia?.receiptDetails?.cardName} ${
                      paymentMedia?.receiptDetails?.cardName
                        .toLowerCase()
                        .includes('debit') ||
                      paymentMedia?.receiptDetails?.cardName
                        .toLowerCase()
                        .includes('credit')
                        ? 'Card'
                        : ''
                    }`}
                    Amount={
                      paymentMedia?.payment?.amount >= 0
                        ? `$${parseFloat(paymentMedia?.payment?.amount).toFixed(
                            2
                          )}`
                        : `-$${parseFloat(
                            Math.abs(paymentMedia?.payment?.amount)
                          ).toFixed(2)}`
                    }
                    key={keyindex}
                  />
                ))}
              </>
            )}
            {CashBack !== 'NaN' && CashBack !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Change (CashBack)"
                Amount={`$${CashBack}`}
              />
            )}
            {Cash !== 'NaN' && Cash !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Cash"
                Amount={
                  Number(Cash) >= 0
                    ? `$${parseFloat(Cash).toFixed(2)}`
                    : `-$${parseFloat(Math.abs(Number(Cash))).toFixed(2)}`
                }
              />
            )}
            {Change !== 'NaN' && Change !== '$0.00' && Change !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Change"
                Amount={Change}
              />
            )}
          </>
        )}
        {TransactionStatus.length > 0 && Journalitems?.length > 0 && (
          <>
            {Journalitems?.length > 0 && (
              <CFDTransactionTotal
                {...props}
                TextValue={
                  TransactionType === 'Void' || TransactionType === 'Refund'
                    ? 'Refund Due'
                    : 'Total Due'
                }
                Amount={
                  Number(totalDue) >= 0
                    ? `$${parseFloat(totalDue).toFixed(2)}`
                    : `-$${parseFloat(Math.abs(Number(totalDue))).toFixed(2)}`
                }
              />
            )}
            {taxDeductionAmount && Number(taxDeductionAmount) > 0 ? (
              <CFDTransactionTotal
                {...props}
                TextValue="Tax Deduction"
                Amount={`$${parseFloat(taxDeductionAmount).toFixed(2)}`}
              />
            ) : (
              ''
            )}
            {PaymentMediaList && PaymentMediaList.length > 0 && (
              <>
                {PaymentMediaList.map((paymentMedia, keyindex) => (
                  <CFDTransactionTotal
                    {...props}
                    comment={paymentMedia?.label}
                    TextValue={`${paymentMedia?.receiptDetails?.cardName} ${
                      paymentMedia?.receiptDetails?.cardName
                        .toLowerCase()
                        .includes('debit') ||
                      paymentMedia?.receiptDetails?.cardName
                        .toLowerCase()
                        .includes('credit')
                        ? 'Card'
                        : ''
                    }`}
                    Amount={
                      paymentMedia?.payment?.amount >= 0
                        ? `$${parseFloat(paymentMedia?.payment?.amount).toFixed(
                            2
                          )}`
                        : `-$${parseFloat(
                            Math.abs(paymentMedia?.payment?.amount)
                          ).toFixed(2)}`
                    }
                    key={keyindex}
                  />
                ))}
              </>
            )}
            {CashBack !== 'NaN' && CashBack !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Change (CashBack)"
                Amount={`$${CashBack}`}
              />
            )}
            {Cash !== 'NaN' && Cash !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Cash"
                Amount={
                  Number(Cash) >= 0
                    ? `$${parseFloat(Cash).toFixed(2)}`
                    : `-$${parseFloat(Math.abs(Number(Cash))).toFixed(2)}`
                }
              />
            )}
            {Change !== 'NaN' && Change !== '$0.00' && Change !== '0.00' && (
              <CFDTransactionTotal
                {...props}
                TextValue="Change"
                Amount={Change}
              />
            )}
          </>
        )}
        {/* #6374 separate transaction status render portion */}
        {TransactionStatus.length > 0 && (
          <>
            {TransactionStatus === '**** TRANSACTION ABORTED ****' && (
              <CFDTransactionTotal {...props} TextValue={TransactionStatus} />
            )}
            <TransactionComplete />
          </>
        )}
        <Flex
          justifyContent="space-between"
          mb={2}
          color="rgb(44, 47, 53)"
          borderTop="1px solid rgb(211, 211, 211)"
          width="100%"
          height="90px"
          backgroundColor="rgb(233, 233, 233)"
          alignItems="center"
        >
          <Text pl={4} fontWeight="bold" fontSize="2.18vw" mt="1%">
            Balance Due
          </Text>
          <Text pr={4} fontWeight="bold" fontSize="2.18vw" mt="1%">
            {finalTotalPrice !== '0.00' &&
            Journalitems?.length > 0 &&
            !TransactionStatus.length ? (
              <>
                {Number(finalTotalPrice) >= 0
                  ? `$${parseFloat(finalTotalPrice).toFixed(2)}`
                  : `-$${parseFloat(Math.abs(Number(finalTotalPrice))).toFixed(
                      2
                    )}`}
              </>
            ) : (
              '0.00'
            )}
          </Text>
        </Flex>
      </Box>
    </Flex>
  );
}

export default CfdCart;
