import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import { LOAD_FLG_INVALID, MO_FLG_INVALID } from '../../../constants';
import * as Constants from '../../../constants';

export const CFDCartItemName = ({ item }) => {
  const nameLines =
    // #6650 Added description feild also incase name is null
    item?.name?.split(Constants.cartItemDelimiter) ||
    item?.description?.split(Constants.cartItemDelimiter);
  return (
    <Flex flexDirection="column" backgroundColor="ffffff">
      {nameLines?.map((name, idx) => (
        <Text
          key={idx.toString()}
          fontFamily="Roboto-Medium"
          fontWeight="500"
          color={
            (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
            (item?.itemTypeID === Constants.ITEM_TYPE.CARD_LOAD &&
              item?.CardLoadFlag === LOAD_FLG_INVALID)
              ? '#ec2526'
              : ''
          }
        >
          {name}
        </Text>
      )) || (
        <Text
          key={1}
          fontFamily="Roboto-Medium"
          fontWeight="500"
          color={
            (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
            (item?.itemTypeID === Constants.ITEM_TYPE.CARD_LOAD &&
              item?.CardLoadFlag === LOAD_FLG_INVALID)
              ? '#ec2526'
              : ''
          }
        >
          No Item Name
        </Text>
      )}
    </Flex>
  );
};
