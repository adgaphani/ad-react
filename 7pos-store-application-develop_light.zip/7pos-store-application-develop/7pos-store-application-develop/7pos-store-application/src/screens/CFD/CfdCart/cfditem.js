import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import CFDItemSubline from './cfditemsubline';
import {
  getItemPriceSuffix,
  getMergedCouponPromo,
  getDiscountsTaxPrefix,
  getDepositTaxPrefix,
  getLineTax,
} from '../../../Utils/cartUtils';
import Styles from './cfd_cart.module.css';
import { CFDCartItemName } from './CFDCartItemName';
import {
  MO_FLG_INVALID,
  LOAD_FLG_INVALID,
  CARD_LOAD_BASE_INDEX,
  ITEM_TYPE,
} from '../../../constants';
import { centsToDollor } from '../../../Utils';

const cfdTransactionItem = props => {
  const {
    item,
    keyindex,
    isReturnVoid,
    taxData,
    items,
    basketPromo,
    fuelDiscounts,
    hostDiscounts,
  } = props;
  const itemprice =
    (item.quantity *
      parseFloat(
        item?.overridedPrice ? item.overridedPrice : item.retailPrice
      ).toFixed(2)) /
    100;
  const itemsuffix = getItemPriceSuffix({ item, taxData });
  const renderItem = getMergedCouponPromo(item).concat(item.fees || []);

  let cardLoadfeePrefix = '';
  if (item?.feeDetails?.retailPrice) {
    const lineNumber = Number(
      parseFloat(
        `${item.tranItemSeqNumber * CARD_LOAD_BASE_INDEX +
          item.tranItemSeqNumber}`
      )
    );
    const cardTax = getLineTax(item.feeDetails, taxData, lineNumber);
    if (Math.abs(cardTax) > 0) {
      cardLoadfeePrefix = 'T';
    }
  }

  const getTaxIndicator = data => {
    let itemsuffix = '';
    if (data?.type === 'BOTTLE_DEPOSIT') {
      itemsuffix = getDepositTaxPrefix({
        item: data,
        taxData,
        primaryItem: item,
      });
    } else {
      itemsuffix = getItemPriceSuffix({ item: data, taxData });
    }
    return itemsuffix;
  };

  let LoadDiscount = null;
  let LoadFeeDiscount = null;
  if (item?.cardDiscounts) {
    LoadDiscount = item.cardDiscounts.filter(i => i.type === 'L');
    LoadFeeDiscount = item.cardDiscounts.filter(i => i.type === 'F');
  }
  return (
    <Box key={keyindex}>
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        alignItems="center"
        px={4}
        pt={2}
        fontSize="1.56vw"
        color="rgb(44, 47, 53)"
        lineHeight="20px"
      >
        <Flex flexDirection="row" alignItems="center">
          <Text
            mr={1}
            fontFamily="Roboto-Medium"
            fontWeight="500"
            color={
              (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
              (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
                item?.CardLoadFlag === LOAD_FLG_INVALID)
                ? '#ec2526'
                : ''
            }
          >
            {item.isFuel ? '' : item.quantity}
          </Text>
          <CFDCartItemName item={item} />
        </Flex>
        <Box ml={2} />
        <Box ml={2}>
          <Text
            className={Styles.priceAlignment}
            color={
              (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
              (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
                item?.CardLoadFlag === LOAD_FLG_INVALID)
                ? '#ec2526'
                : ''
            }
          >
            <span
              className={
                (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
                (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
                  item?.CardLoadFlag === LOAD_FLG_INVALID)
                  ? Styles.priceAlignLeftStrike
                  : Styles.priceAlignLeft
              }
            >
              {Number(itemprice) >= 0
                ? `$${parseFloat(itemprice).toFixed(2)}`
                : `-$${parseFloat(Math.abs(Number(itemprice))).toFixed(2)}`}
            </span>
            <span
              className={
                (item.isMoneyOrder && item.MoneyOrderFlag === MO_FLG_INVALID) ||
                (item?.itemTypeID === ITEM_TYPE.CARD_LOAD &&
                  item?.CardLoadFlag === LOAD_FLG_INVALID)
                  ? Styles.priceAlignRightStrike
                  : Styles.priceAlignRight
              }
            >
              {itemsuffix}
            </span>
          </Text>
        </Box>
      </Flex>
      {item?.itemTypeID === ITEM_TYPE.CARD_LOAD && (
        <>
          {LoadDiscount && LoadDiscount.length > 0 && (
            <CFDItemSubline
              {...props}
              itemName={LoadDiscount[0]?.description}
              itemAmount={
                isReturnVoid
                  ? `$${parseFloat(LoadDiscount[0]?.amount).toFixed(
                      2
                    )}${itemsuffix}`
                  : `-$${parseFloat(LoadDiscount[0]?.amount).toFixed(
                      2
                    )}${itemsuffix}`
              }
              itemAmtColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              itemColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              itemSuffix={itemsuffix}
            />
          )}
          {item?.feeDetails && (
            <CFDItemSubline
              {...props}
              itemName={item?.feeDetails.name}
              itemAmount={
                Number(item?.feeDetails.retailPrice) >= 0
                  ? `$${parseFloat(item?.feeDetails.retailPrice).toFixed(
                      2
                    )}${cardLoadfeePrefix}`
                  : `-$${parseFloat(
                      Math.abs(Number(item?.feeDetails.retailPrice))
                    ).toFixed(2)}${cardLoadfeePrefix}`
              }
              itemAmtColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              itemColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              itemSuffix={cardLoadfeePrefix}
            />
          )}
          {LoadFeeDiscount && LoadFeeDiscount.length > 0 && (
            <CFDItemSubline
              {...props}
              itemName={LoadFeeDiscount[0]?.description}
              itemAmount={
                isReturnVoid
                  ? `$${parseFloat(LoadFeeDiscount[0]?.amount).toFixed(
                      2
                    )}${cardLoadfeePrefix}`
                  : `-$${parseFloat(LoadFeeDiscount[0]?.amount).toFixed(
                      2
                    )}${cardLoadfeePrefix}`
              }
              itemAmtColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              itemColour={
                item?.CardLoadFlag === LOAD_FLG_INVALID ? '#ec2526' : ''
              }
              isRemoved={item?.CardLoadFlag === LOAD_FLG_INVALID}
              itemSuffix={cardLoadfeePrefix}
            />
          )}
        </>
      )}
      {item.isMoneyOrder && Number(item?.moneyOrderFee) > 0 && (
        <CFDItemSubline
          {...props}
          itemName={item.moneyOrderFeeName}
          itemAmount={`$${parseFloat(item?.moneyOrderFee / 100).toFixed(2)}`}
          itemAmtColour={
            item.moneyOrderFeeOverride === 'Y' ||
            item.MoneyOrderFlag === MO_FLG_INVALID
              ? '#ec2526'
              : ''
          }
          itemColour={
            item.moneyOrderFeeOverride === 'Y' ||
            item.MoneyOrderFlag === MO_FLG_INVALID
              ? '#ec2526'
              : ''
          }
          isRemoved={
            item.moneyOrderFeeOverride === 'Y' ||
            item.MoneyOrderFlag === MO_FLG_INVALID
          }
        />
      )}

      {fuelDiscounts &&
        fuelDiscounts?.length > 0 &&
        item.isFuel &&
        fuelDiscounts?.map(dItem => (
          <CFDItemSubline
            {...props}
            itemName={`${centsToDollor(dItem?.discount)}/gal ${dItem.pos_text}`}
          />
        ))}
      {hostDiscounts &&
        hostDiscounts?.length > 0 &&
        item.isFuel &&
        hostDiscounts?.map(dItem => (
          <CFDItemSubline {...props} itemName={dItem.pos_text} />
        ))}
      {renderItem.length > 0 && (
        <>
          {renderItem.map((data, KeyIndex) => (
            <>
              {(data.itemDiscount || data?.retailPrice) && (
                <CFDItemSubline
                  {...props}
                  key={KeyIndex}
                  itemName={data.short_name ? data.short_name : data.name}
                  type={data.type}
                  flag={
                    data?.type === 'BOTTLE_DEPOSIT' || data?.type === 'ECO_FEE'
                      ? getTaxIndicator(data)
                      : ''
                  }
                  depositFee={((data.retailPrice || 0) / 100) * item.quantity}
                  itemAmount={
                    isReturnVoid
                      ? `$${parseFloat(data.itemDiscount / 100).toFixed(
                          2
                        )}${getDiscountsTaxPrefix({
                          item,
                          taxData,
                          discountDetails: data,
                          items,
                          basketPromo,
                        })}`
                      : `-$${parseFloat(data.itemDiscount / 100).toFixed(
                          2
                        )}${getDiscountsTaxPrefix({
                          item,
                          taxData,
                          discountDetails: data,
                          items,
                          basketPromo,
                        })}`
                  }
                  itemAmtColour="#ec2526"
                  itemSuffix={getDiscountsTaxPrefix({
                    item,
                    taxData,
                    discountDetails: data,
                    items,
                    basketPromo,
                  })}
                />
              )}
              {data.amount && (
                <CFDItemSubline
                  {...props}
                  key={KeyIndex}
                  itemName={data.name}
                  itemAmount={
                    isReturnVoid
                      ? `$${parseFloat(Math.abs(data.amount)).toFixed(
                          2
                        )}${getDiscountsTaxPrefix({
                          item,
                          taxData,
                          discountDetails: data,
                          items,
                          basketPromo,
                        })}`
                      : `-$${parseFloat(Math.abs(data.amount)).toFixed(
                          2
                        )}${getDiscountsTaxPrefix({
                          item,
                          taxData,
                          discountDetails: data,
                          items,
                          basketPromo,
                        })}`
                  }
                  itemAmtColour="#ec2526"
                  itemSuffix={getDiscountsTaxPrefix({
                    item,
                    taxData,
                    discountDetails: data,
                    items,
                    basketPromo,
                  })}
                />
              )}
            </>
          ))}
        </>
      )}

      {item.isExemptTax && (
        <Flex
          flexDirection="row"
          justifyContent="center"
          alignItems="center"
          pl={3}
          alignSelf="center"
          py={2}
          fontSize="1.56vw"
          color="rgb(91, 97, 107)"
          fontWeight="normal"
          fontFamily="Roboto-Regular"
        >
          <Text>****TAX EXEMPT****</Text>
        </Flex>
      )}
    </Box>
  );
};

cfdTransactionItem.defaultProps = {
  item: {},
  keyindex: 0,
  isReturnVoid: false,
  taxData: {},
};

cfdTransactionItem.propTypes = {
  item: PropTypes.object,
  keyindex: PropTypes.number,
  isReturnVoid: PropTypes.bool,
  taxData: PropTypes.object,
};
export default cfdTransactionItem;
