import React from 'react';
import { Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';

const cfdtotalDetails = props => {
  const { TextValue, Amount, TextColour = '', keyindex, comment } = props;
  const isUsCash = () => comment?.toLowerCase().includes('us cash');
  const getLabel = () => {
    if (isUsCash()) return 'US Cash';
    if (comment === 'Big Bucks') return 'Big Buck';
    if (comment !== undefined) return comment;
    return TextValue;
  };
  return (
    <>
      <Text
        px={4}
        fontSize="1.48vw"
        mt={isUsCash() ? 2 : 0}
        color="rgb(44,47,53)"
      >
        {isUsCash() ? comment : ''}
      </Text>
      <Flex
        key={keyindex}
        px={4}
        justifyContent={Amount ? 'space-between' : 'center'}
        mb={2}
        color="rgb(44,47,53)"
        fontSize="1.48vw"
        fontWeight="normal"
        fontFamily="Roboto-Regular"
        height="23px"
      >
        <Text>{getLabel()}</Text>
        {Amount && (
          <>
            {TextColour.length > 0 ? (
              <Text color={TextColour}>{Amount}</Text>
            ) : (
              <Text>{Amount}</Text>
            )}
          </>
        )}
      </Flex>
    </>
  );
};
cfdtotalDetails.defaultProps = {
  TextValue: '',
  Amount: '',
  TextColour: '',
};

cfdtotalDetails.propTypes = {
  TextValue: PropTypes.string,
  Amount: PropTypes.string,
  TextColour: PropTypes.string,
};
export default cfdtotalDetails;
