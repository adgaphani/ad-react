import React, { useState, useEffect } from 'react';
import useInterval from '@use-it/interval';
import { Flex, Box } from '@chakra-ui/react';
import { imageDimensions, loadImage } from '../../../Utils/fileUtils';

function MarketingImage({ fbImg }) {
  const [imageindex, setImageIndex] = useState(0);
  const [imagelist, setImageList] = useState([]);
  const IntialTimer = 500;
  const RotationTimeout = 10000;
  const [imageRotationTimer, setImageRotationTimer] = useState(IntialTimer);
  const updateImageIndex = async () => {
    try {
      const imagelistArray = await loadImage(fbImg).catch(e => {
        global?.logger?.info(
          `[7POS UI] - Error Loading images:${JSON.stringify(e)})`
        );
      });
      if (
        imagelist?.length !== imagelistArray?.length ||
        JSON.stringify(imagelist) !== JSON.stringify(imagelistArray)
      ) {
        setImageList(imagelistArray);
        global?.Logger?.debug(
          `[7POS UI] - CFD markieting Images are refreshed(Image Count:${imagelistArray?.length})`
        );
      }
      const dimensions = await imageDimensions(imagelist?.[imageindex]).catch(
        e => {
          console.log('dimen errr', e);
        }
      );
      // Display advertisement screen timer depending on resolution
      if (dimensions?.width > 1000) {
        setImageRotationTimer(RotationTimeout);
      } else {
        setImageRotationTimer(IntialTimer);
      }
      if (imageindex + 1 <= imagelist.length - 1) {
        setImageIndex(imageindex => imageindex + 1);
      } else {
        setImageIndex(imageindex => imageindex - imageindex);
      }
    } catch (error) {
      console.log('------------errr------', error);
    }
  };

  useInterval(() => {
    updateImageIndex();
  }, imageRotationTimer);

  useEffect(() => {
    loadImage(fbImg)
      .then(res => {
        if (imagelist.length !== res?.length) {
          setImageList(res);
          global?.Logger?.debug(
            `[7POS UI] - CFD markieting Images are refreshed(Image Count:${res?.length})`
          );
        }
      })
      .catch(e => {
        global?.logger?.error(
          `[7POS UI] - CFD markieting Error Reading files  ${JSON.stringify(e)}`
        );
      });
  }, [fbImg]);

  return (
    <Box maxH="800px" maxW="1280px">
      <Flex>
        <img
          src={imagelist?.[imageindex]}
          alt=""
          height="799px"
          width="1280px"
        />
      </Flex>
    </Box>
  );
}

export default MarketingImage;
