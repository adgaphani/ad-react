import React from 'react';
import CfdSevenElevenHeader from './cfd_sevenEleven_header';
import CfdSpeedwayHeader from './cfd_speedway_header';

function CfdHeader({ isSpeedyStore }) {
  // Speedway testings
  // eslint-disable-next-line react/destructuring-assignment
  return isSpeedyStore ? <CfdSpeedwayHeader /> : <CfdSevenElevenHeader />;
}

export default CfdHeader;
