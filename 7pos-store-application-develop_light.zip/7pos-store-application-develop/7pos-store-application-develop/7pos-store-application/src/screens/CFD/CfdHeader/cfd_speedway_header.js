import React from 'react';
import { Flex, Box, Image } from '@chakra-ui/react';
import logoSpeedway from '../images/speedwayImages/speedway-logo-nav.png';
import logoSpeedRewards from '../images/speedwayImages/speedy-rewards-two-color2.png';

function CfdSpeedwayHeader() {
  return (
    <Box px={2} bg="#EC2526">
      <Flex
        justifyContent="space-between"
        alignItems="center"
        height="70px"
        py="1.806%"
      >
        <Flex ml="1%">
          <Image
            height="47px"
            width="63px"
            src={logoSpeedway}
            alt="logoSpeedway"
          />
        </Flex>
        <Flex mr="3%">
          <Image
            height="50px"
            width="104px"
            src={logoSpeedRewards}
            alt="logoSpeedwayRewards"
          />
        </Flex>
      </Flex>
    </Box>
  );
}

export default CfdSpeedwayHeader;
