import React from 'react';
import { Flex, Box, Image } from '@chakra-ui/react';
import logoSevenEleven from '../images/SevenRewards.PNG';

function CfdSevenElevenHeader() {
  return (
    <Box px={2}>
      <Flex
        justifyContent="space-between"
        alignItems="center"
        py={4}
        height="70px"
      >
        {/* eslint-disable-next-line no-undef */}
        {/* {...indexedDBprops.children} */}
        <Flex
          justifyContent="center"
          alignItems="center"
          alignContent="center"
          ml="35%"
        >
          <Image
            height="70px"
            width="264px"
            src={logoSevenEleven}
            alt="logoSevenEleven"
            alignContent="center"
          />
        </Flex>
      </Flex>
    </Box>
  );
}

export default CfdSevenElevenHeader;
