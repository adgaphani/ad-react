import React, { useEffect, useState } from 'react';
import { Box } from '@chakra-ui/react';
import {
  Route,
  Switch,
  useRouteMatch,
  useLocation,
  useHistory,
} from 'react-router-dom';
import { useSelector } from 'react-redux';
import AltIDScreen from '../../components/CFD/CFDALTID/AltIDScreen';
import ItemRedemption from '../../components/CFD/CFDOffer/ItemRedemption';
import ZipCodeScreen from '../../components/CFD/CFDOffer/ZipCodeScreen';
import PostalCodeScreen from '../../components/CFD/CFDOffer/PostalCodeScreen';
import RedemptionStatusScreen from '../../components/CFD/CFDOffer/RedemptionStatusScreen';
import CfdHeader from './CfdHeader/cfd_header';
import TermsAndConditions from '../../components/CFD/CFDRegistration/TermsAndConditions';
import EmailIDScreen from '../../components/CFD/CFDRegistration/EmailIdScreen';
import MemberStatusScreen from '../../components/CFD/CFDRegistration/MemberStatusScreen';
import CFDFleetCard from '../../components/CFD/CFDFleet/cfdFleetCard';
import CFDPrepaidLoadConfirmation from '../../components/CFD/CFDPrepaidCards/CFDPrepaidLoadConfrimation';
import RoundUpCharity from '../../components/CFD/RoundUp/CharityRoundUp';
import PaymentConfirmationCFD from '../../components/CFD/Payment/paymentConfirmationCFD';
import EmailIDScreenReceipt from '../../components/CFD/Payment/emailReceiptCFD';
import PinpadMessage from '../../components/CFD/Payment/pinpadMessage';
import CFDPrepaidAccNumberScreen from '../../components/CFD/CFDPrepaidCards/CFDPrepaidAccNumberScreen';
import CFDSignatureCapture from '../../components/CFD/CFDSignatureCapture/CFDSignatureCapture';
import { Discountprompt } from '../POS/Coupons/DiscountPrompt';
import { MasterCardPrompt } from '../../components/Common/Loyalty/MasterCardPrompt';
import { SendMessageToPOS } from '../../Communication';
import { FullPageLoader } from '../../components/Common';
import SpeedyRedeemStatus from '../../components/CFD/CFDOffer/SpeedyRedeemStatus';
// import{ FuelPage}

function CfdMain({ fbImg }) {
  const {
    isTransactionFinalize,
    member,
    RegistrationScreenBtnClicked,
    isSpeedyStore,
    isSevenRewardsDisable,
    redeemOfferInProgress,
  } = useSelector(state => ({
    isTransactionFinalize: state.cfd.isTransactionFinalize,
    member: state.cart.member,
    RegistrationScreenBtnClicked: state.cfd.RegistrationScreenBtnClicked,
    isSpeedyStore: state.main.isSpeedyStore,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
    redeemOfferInProgress: state.cfd.redeemOfferInProgress,
  }));
  const [showLoader, setShowLoader] = useState(false);
  const location = useLocation();
  const history = useHistory();
  const { path } = useRouteMatch();

  const onMasterCardAction = isSelected => {
    history.push({ pathname: '/CfdHome', search: '?view=viewB' });
    SendMessageToPOS({
      CMD: 'MasterCardLoyalty',
      autoTriggerPayment: isSelected,
    });
  };

  // Resetting the Loader in CFD Which trigger after user redeemed the offer
  useEffect(() => {
    if (!isSpeedyStore) return;
    setShowLoader(redeemOfferInProgress);
  }, [redeemOfferInProgress, isSpeedyStore]);
  const isHeaderRequired =
    location.pathname.toLowerCase().includes('roundup') ||
    location.pathname.toLowerCase().includes('emailreceipt') ||
    location.pathname.toLowerCase().includes('paymentconfirmationcfd') ||
    location.pathname.toLowerCase().includes('pinpadmessage');
  return (
    <div className="Cfd">
      <Box className="main" shadow="md">
        {(!isTransactionFinalize ||
          member ||
          RegistrationScreenBtnClicked ||
          isHeaderRequired) &&
        !isSevenRewardsDisable ? (
          <CfdHeader isSpeedyStore={isSpeedyStore} />
        ) : (
          ''
        )}
        <Switch>
          <Route path={`${path}/`} exact>
            <AltIDScreen fbImg={fbImg} />
          </Route>
          <Route path={`${path}/Redeemption`}>
            <ItemRedemption />
          </Route>
          <Route path={`${path}/RoundUp`}>
            <RoundUpCharity />
          </Route>
          <Route path={`${path}/ZipCodeScreen`}>
            <ZipCodeScreen setShowLoader={setShowLoader} />
          </Route>
          <Route path={`${path}/PostalCodeScreen`}>
            <PostalCodeScreen />
          </Route>
          <Route path={`${path}/RedeemStatus`}>
            <RedemptionStatusScreen />
          </Route>
          <Route path={`${path}/SpeedyRedeemStatus`}>
            <SpeedyRedeemStatus />
          </Route>
          <Route path={`${path}/Terms`}>
            <TermsAndConditions />
          </Route>
          <Route path={`${path}/Email`}>
            <EmailIDScreen />
          </Route>
          <Route path={`${path}/MemberStatus`}>
            <MemberStatusScreen />
          </Route>
          <Route path={`${path}/FleetCard`}>
            <CFDFleetCard />
          </Route>
          <Route path={`${path}/PrepaidLoadConfirm`}>
            <CFDPrepaidLoadConfirmation />
          </Route>
          <Route path={`${path}/paymentConfirmationCFD`}>
            <PaymentConfirmationCFD />
          </Route>
          <Route path={`${path}/EmailReceipt`}>
            <EmailIDScreenReceipt />
          </Route>
          <Route path={`${path}/PrepaidAccNumber`}>
            <CFDPrepaidAccNumberScreen />
          </Route>
          <Route path={`${path}/PinpadMessage`}>
            <PinpadMessage fbImg={fbImg} />
          </Route>
          <Route path={`${path}/signatureCapture`}>
            <CFDSignatureCapture />
          </Route>
          <Route path={`${path}/fuelprompt`}>
            <Discountprompt />
          </Route>
          <Route path={`${path}/mastercardLoyalty`}>
            <MasterCardPrompt
              isCfd
              onCancel={() => onMasterCardAction(false)}
              onConfirm={() => onMasterCardAction(true)}
            />
          </Route>
          <Route component={Error} />
        </Switch>
      </Box>
      {showLoader && <FullPageLoader />}
    </div>
  );
}
export default CfdMain;
