import { useSelector } from 'react-redux';
import { useEffect } from 'react';

export const DebugDataAnalyzer = () => {
  const {
    cartChangeTrial = [],
    runningTotal = 0,
    runningTotalTax = 0,
  } = useSelector(state => ({
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    runningTotalTax: state.cart.runningTotalTax,
  }));

  useEffect(() => {
    console.log('__CART_TRAIL__: TRAIL-', cartChangeTrial);
  }, [cartChangeTrial.length]);

  useEffect(() => {
    console.log(`__CART_TRAIL__: TOTAL-  ${runningTotal}`);
  }, [runningTotal]);

  useEffect(() => {
    console.log(`__CART_TRAIL__: TOTAL_TAX-  ${runningTotalTax}`);
  }, [runningTotalTax]);

  return null;
};
