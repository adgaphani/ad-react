import { useContext, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { FuelApi } from '../../api/fuel';
import { appIntegrationRequest } from '../../Utils/appUtils';
import { WSSubscriptions, WSTopics } from '../../constants';
import { WSPayloadUtil, WSStatus } from '../../Utils';
import { FISActions, FISCommManager } from '../../components/Fuel';
import {
  useFuel,
  useFuelCache,
  useFuelPrices,
  useNotifications,
  useCarWash,
  useFuelRequest,
  useWSocket,
} from '../../hooks';
import { GridSizes } from '../../components/Fuel/FuelPumps/helpers';
import { FuelRedBarMsgs } from '../../components/Fuel/FuelPumps/helpers/FuelPumpStatus';
import { FuelConstants } from './FuelConstants';
import Icon_Waring from '../../Icons/fuelIcons/pump-warning.svg';
import AuthConfirmIcon from '../../Icons/fuelIcons/AuthConfirmIcon.svg';
import { AppContext } from '../../AppContext';

const dummyResponse = {
  isEnabled: true,
  isPOSSalesAllowed: true,
  isDEXSalesAllowed: true,
  packages: [
    {
      status: true,
      name: 'Super',
      description: 'Super',
      price: 20,
      id: 1,
    },
    {
      status: true,
      name: 'Deluxe',
      description: 'Deluxe',
      price: 15,
      id: 2,
    },
    {
      status: true,
      name: 'Works',
      description: 'Works',
      price: 5,
      id: 3,
    },
    {
      status: true,
      name: 'Express',
      description: 'Express',
      price: 1,
      id: 4,
    },
    {
      status: true,
      name: 'A',
      description: 'B',
      price: 1,
      id: 5,
    },
  ],
  deviceType: 6,
  vendor: 9,
  portType: 9,
  portNumber: 5,
};

export const FuelSubscription = () => {
  const { isConnected, ws } = useWSocket();
  const {
    isIntegratedFuelStore,
    fuelPumps,
    fuelPrices,
    getMultiPumpMsgs,
    getPumpRedbarMsg,
    getInactivePumpsCount,
    isDEXOnline,
    isAuthConfirmInProgress,
    dexComFormat,
  } = useFuel();

  const { authConfirmNotifySound } = useContext(AppContext);

  const { processFuelRequestAsPromise } = useFuelRequest();
  const { setFuelPrices } = useFuelPrices();
  const { handleCarWashPriceUpdate } = useCarWash();
  const {
    setFuelParams,
    setFuelPumps,
    resetFuelPumps,
    updateMultiPumpStatus,
    setCarwashConfig,
  } = useFuelCache();
  const {
    setNotifications,
    setBulkNotifications,
    dismissNotification,
  } = useNotifications();
  const location = useLocation();
  const fuelInitiationRef = useRef(false);
  const { deviceInfo, socketStatus, storeId, isLoggedIn } = useSelector(
    state => ({
      deviceInfo: state.main.deviceInfo,
      isLoggedIn: state.auth.isAppLogin,
      socketStatus: state.socket.status,
      storeId: IS_DEV ? '39325' : state.main.storeDetails?.storeId,
    })
  );
  const fuelPumpsRef = useRef(fuelPumps || []);
  const pricesRef = useRef(fuelPrices);

  useEffect(() => {
    if (isAuthConfirmInProgress) {
      authConfirmNotifySound.loop = true;
      authConfirmNotifySound?.play()?.catch(e => console.log('Sound error', e));
    } else {
      // Stopping the sound.
      authConfirmNotifySound?.pause();
      if (authConfirmNotifySound) {
        authConfirmNotifySound.currentTime = 0;
      }
    }
  }, [isAuthConfirmInProgress]);

  useEffect(() => {
    console.log('____ FUEL PRODUCTS UPDATE ____');
    pricesRef.current = fuelPrices;
  }, [fuelPrices]);

  /**
   * Show New Prices Notification
   */
  const showNewPricesNotification = () => {
    const msg = getPumpRedbarMsg({
      message: FuelRedBarMsgs.new_fuel_prices,
      icon: Icon_Waring,
      id: FuelConstants.newPricesNotificationId,
    });
    setNotifications(msg);
  };

  const fetchAndUpdateFuelPricesIfNeeded = async ({
    storeId,
    forceUpdate = false,
    displayLoader = false,
  }) => {
    if (pricesRef.current?.length && !forceUpdate) {
      console.log('[Fuel]____PRICES EXISTED____');
      Logger.debug(
        `[Fuel] Existing Fuel Prices: ${JSON.stringify(fuelPrices)}`
      );
      return fuelPumps;
    }
    Logger.info('[Fuel] Requesting prices from DEX...');
    if (!IS_DEV) {
      try {
        const dexResponse = await processFuelRequestAsPromise(
          FISActions.getPrices,
          undefined,
          {
            timeout: 15000,
            displayLoader,
          }
        );
        Logger.info(
          `[Fuel] DEX_PRICE_FETCH_SUCCESS: Prices: ${JSON.stringify(
            dexResponse
          )}`
        );
        const {
          fuelPrices: currentPrices = [],
          pendingFuelPrices = [],
          lastPriceUpdateDate,
        } = dexResponse || {};
        // Setting the current fuel prices
        currentPrices.length && setFuelPrices({ prices: currentPrices });
        // Setting the pending fuel prices if needed.
        pendingFuelPrices.length &&
          setFuelPrices({
            mpsDecision: FuelConstants.mpsPOSPending,
            prices: pendingFuelPrices,
            priceUpdateDateTime: lastPriceUpdateDate,
          });
        pendingFuelPrices.length && showNewPricesNotification();
        return;
      } catch (e) {
        Logger.error(
          `[Fuel] DEX_PRICE_FETCH_FAILED: PricesError: ${e.message}`
        );
      }
    }

    try {
      Logger.info(`[Fuel] Loading prices from API...`);
      const { data } = await FuelApi.fetchFuelPrices({ storeId });
      Logger.info(
        `[Fuel] API_PRICE_FETCH_SUCCESS: Prices: ${JSON.stringify(data)}`
      );
      setFuelPrices(data);
    } catch (e) {
      Logger.info(`[Fuel] API_PRICE_FETCH_FAILED PricesError: ${e}`);
    }
  };

  useEffect(() => {
    // No need to make the price api call if the store is not a fuel store.
    if (!isLoggedIn || !isDEXOnline) return;
    fetchAndUpdateFuelPricesIfNeeded({
      storeId,
      forceUpdate: false,
      displayLoader: false,
    }).catch(e =>
      Logger.error(`[Fuel] UserLoggedIn: PricesError: ${e.message}`)
    );
  }, [isLoggedIn, isDEXOnline]);

  const handleFuelStatusEvent = async event => {
    try {
      const body = WSPayloadUtil.getPayload(event);
      // Logger.info(`[Fuel] Status Response: ${JSON.stringify(body)}`);

      if (Array.isArray(body)) {
        if (body.length > 1) {
          Logger.info(
            `[Fuel] PUMP_INIT_STATUS_LOAD. STATUS COUNT: ${body.length}, PUMPS: ${fuelPumpsRef.current?.length}`
          );
        }
        const multiPumpState = FISCommManager.processMultiPumpState(body);
        // Generate Fuel Notification and dispatch action to save it
        const fuelNotifications = getMultiPumpMsgs(multiPumpState);
        setBulkNotifications(fuelNotifications);
        return updateMultiPumpStatus(multiPumpState);
      }
      const {
        errorCode,
        message: redbarMessage,
        eventType,
        fuelPrices: prices = [],
        mpsDecision = '',
      } = FISCommManager.getMessageDetails(body);
      if (errorCode === FuelConstants.dexDisconnect) {
        Logger.info(`[Fuel] DEX_DISCONNECT: RESETTING PUMPS...`);
        resetFuelPumps();
        return;
      }

      if (eventType === FuelConstants.fuelPrices) {
        if (mpsDecision === FuelConstants.mpsPOSPending) {
          showNewPricesNotification();
        }
        setFuelPrices({ mpsDecision, prices });
        return;
      }

      if (redbarMessage) {
        // Global and Fuel Notification
        const config = { message: redbarMessage };
        if (redbarMessage?.includes('FUEL_CARWASH_UPDATE')) {
          handleCarWashPriceUpdate(redbarMessage);
          config.message = FuelRedBarMsgs.carwash_price_update;
        }

        if (redbarMessage.includes(Messages.auth_confirm_identifier)) {
          config.borderColor = '#7B61FF';
          config.icon = AuthConfirmIcon;
          config.messageType = 'other';
        }
        const msg = getPumpRedbarMsg(config);
        setNotifications(msg);
        handleCarWashPriceUpdate(redbarMessage);
      }
    } catch (e) {
      console.log(e);
      Logger.info(
        `[Fuel] ERROR : Error Processing the status message ${JSON.stringify(
          e
        )}`
      );
    }
  };

  // Testing...
  useEffect(() => {
    if (IS_DEV) {
      const redbarMessage = 'Please Authorize Pump1';
      const config = { message: redbarMessage };
      if (redbarMessage.includes(Messages.auth_confirm_identifier)) {
        config.borderColor = '#7B61FF';
        config.icon = AuthConfirmIcon;
        config.messageType = 'other';
        config.id = 123;
      }
      const msg = getPumpRedbarMsg(config);
      setNotifications(msg);

      setTimeout(() => {
        console.log('Dismissing Notification...');
        dismissNotification(123);
      }, 10000);
      // const msg = getPumpRedbarMsg({
      //   message: FuelRedBarMsgs.new_fuel_prices,
      //   icon: Icon_Waring,
      // });
      // setNotifications(msg);
    }
  }, []);

  const unsubscribeToFuelStatusMessages = () => {
    if (!Object.keys(ws?.socket?.subscriptions || {})?.length) {
      return;
    }
    // Logger.info('[Fuel] Unsubscribing to status messages...');
    ws?.socket?.unsubscribe(WSSubscriptions.fis.statusMessages);
  };

  const subscribeToFuelStatusMessages = () => {
    // Logger.info('[Fuel] Subscribing to status messages...');
    if (!isConnected || !ws?.socket) return;
    if (
      Object.keys(ws.socket?.subscriptions).includes(
        WSSubscriptions.fis.statusMessages
      )
    ) {
      console.log('[Fuel] Already Subscribed');
      return;
    }
    ws?.socket?.subscribe(WSTopics.fis.statusMessage, handleFuelStatusEvent, {
      id: WSSubscriptions.fis.statusMessages,
    });
  };

  const initializeFuelRequest = () => {
    if (!isConnected || !ws) {
      Logger.info(`[Fuel] REQUEST :- FUEL_INIT_REQUEST_FAILED : NO Websocket}`);
      return;
    }
    const fuelInitializationRequest = appIntegrationRequest({
      type: 'Fuel',
      deviceInfo,
    });
    const req = {
      ...fuelInitializationRequest,
      messageHeader: {
        ...fuelInitializationRequest.messageHeader,
        dexComFormat,
      },
    };
    console.log('FUEL ___INIT_____REQ', req);
    ws.socket?.send(WSTopics.fis.initiate, {}, JSON.stringify(req));
    Logger.info(`[Fuel] REQUEST SENT:- FUEL_INIT_REQUEST:`);
  };

  const getFuelPumpsWithEmptyPadding = (fuelPumps = []) => {
    if (!fuelPumps.length) {
      return fuelPumps;
    }
    const sizeMapper = {
      [GridSizes.small]: 8,
      [GridSizes.medium]: 16,
      [GridSizes.large]: 32,
    };
    const getSize = () => {
      if (fuelPumps.length <= 8) {
        return GridSizes.small;
      }
      return fuelPumps.length > 16 ? GridSizes.large : GridSizes.medium;
    };
    const length = sizeMapper[getSize()] - fuelPumps.length;
    const emptyPumps = new Array(length).fill({});
    return [...fuelPumps, ...emptyPumps];
  };

  const fetchFuelParams = async () => {
    const config = await FuelApi.fetchFuelParameters().catch(e =>
      Logger.error(`[Fuel] ERROR : FuelParamsLoad Error ${e.message}`)
    );
    if (!config?.data?.length) {
      return;
    }
    console.log('FUELPARAMS______', config);
    setFuelParams(config.data[0]);
  };

  useEffect(() => {
    fuelPumpsRef.current = fuelPumps;
  }, [fuelPumps]);

  const fetchAllPumps = async () => {
    if (fuelPumpsRef.current?.length) {
      console.info(`[Fuel] SKIPPING FuelPUMPS...`);
      return fuelPumpsRef.current;
    }
    if (IS_DEV) {
      const pumps = new Array(20)
        .fill(0)
        .map((_, i) => ({ logicalNumber: i + 1 }))
        .map(({ logicalNumber: pumpNumber }) => ({ pumpNumber }));
      const p = getFuelPumpsWithEmptyPadding(pumps);
      setFuelPumps({
        fuelPumps: p,
      });
      setCarwashConfig(dummyResponse);
      return p;
    }
    Logger.info('[Fuel] PUMPS :- Fetching all pumps...');
    try {
      const response = await FuelApi.fetchFuelPumps();
      const controllerResponse = response.data;
      if (!controllerResponse) return;
      const { dispenser, carWash: carwash } = controllerResponse;
      if (!dispenser?.controllers?.length && !carwash?.controllers?.length) {
        return;
      }
      const availablePumps = dispenser?.controllers
        ?.map(c => c?.pumps || [])
        .flat()
        .map(({ logicalNumber: pumpNumber }) => ({ pumpNumber }));
      Logger.info(
        `[Fuel] PUMPS : Number of fuel pumps for the store ${availablePumps.length}`
      );
      const fuelPumpsWithPadding = getFuelPumpsWithEmptyPadding(availablePumps);
      setFuelPumps({ fuelPumps: fuelPumpsWithPadding });
      setCarwashConfig(carwash?.controllers?.[0]);
      return fuelPumpsWithPadding;
    } catch (e) {
      Logger.error(`[Fuel] ERROR : PumpLoadError: ${e.message}`);
    }
    return [];
  };

  useEffect(() => {
    if (isDEXOnline) {
      fetchAndUpdateFuelPricesIfNeeded({
        storeId,
        forceUpdate: true,
        displayLoader: false,
      }).catch(e => {
        Logger.error(`[Fuel] PRICE_FETCH_FAILED. ERROR: ${e.message}`);
      });
    }
    Logger.info('[Fuel] DEX is not connected yet / disconnected.');
  }, [isDEXOnline]);

  useEffect(() => {
    if (!fuelPumps.length) return;
    if (socketStatus === WSStatus.connected) {
      if (fuelInitiationRef.current) return;
      subscribeToFuelStatusMessages();
      initializeFuelRequest();
      fuelInitiationRef.current = true;
    } else {
      fuelInitiationRef.current = false;
      Logger.info(`[Fuel] MW_DISCONNECT : RESETTING PUMPS`);
      fuelPumps.length && resetFuelPumps();
    }
  }, [socketStatus]);

  // RE Initialize when DEXComFormat Update
  useEffect(() => {
    if (!dexComFormat || !isIntegratedFuelStore || !isConnected) return;
    Logger.info(`[Fuel] dexComFormat UPDATE : Reintializing the fuel INIT`);
    subscribeToFuelStatusMessages();
    initializeFuelRequest();
  }, [dexComFormat, isConnected]);

  useEffect(() => {
    // Wait until socket gets connected and store config gets loaded.
    console.log('[Fuel] ', isIntegratedFuelStore);
    if (!isIntegratedFuelStore) {
      fuelInitiationRef.current = false;
      // Logger.info('[Fuel] May not be fuel store...');
      return;
    }

    if (!deviceInfo?.id) {
      fuelInitiationRef.current = false;
      // Logger.info('[Fuel] Waiting for valid device info...');
      return;
    }

    Logger.info(
      `[Fuel]: TerminalId: ${deviceInfo?.id},
      SocketStatus: ${socketStatus},
      fuelInitiation: ${fuelInitiationRef.current},
      isFuelStore: ${isIntegratedFuelStore}`
    );
    fetchAllPumps()
      .then(pumps => {
        if (socketStatus === WSStatus.connected) {
          console.log('[Fuel] isInitialized: ', fuelInitiationRef.current);
          if (pumps?.length && !fuelInitiationRef.current) {
            subscribeToFuelStatusMessages();
            initializeFuelRequest();
            fuelInitiationRef.current = true;
          }
        } else {
          fuelInitiationRef.current = false;
          // unsubscribeToFuelStatusMessages();
        }
      })
      .catch(e => {
        Logger.error(e);
      });
    fetchFuelParams();
  }, [socketStatus, isIntegratedFuelStore, deviceInfo]);

  /**
   * Depending on the path, resending the FUEL INIT command if at least one of the pumps has invalid status which is inactive.
   */
  useEffect(() => {
    if (location?.pathname !== '/fuel') {
      return;
    }
    const inactivePumpCount = getInactivePumpsCount();
    // #6650 added web socket status before initialize fuel server.
    if (inactivePumpCount && socketStatus === WSStatus.connected) {
      Logger.info(
        `[Fuel] FUEL_INIT_REQUEST_RESEND:  INACTIVE_PUMP_COUNT: ${inactivePumpCount}`
      );
      return initializeFuelRequest();
    }
    console.log('[Fuel] NO NEED TO SEND INIT', inactivePumpCount);
  }, [location?.pathname]);

  useEffect(() => unsubscribeToFuelStatusMessages, []);

  return null;
};
