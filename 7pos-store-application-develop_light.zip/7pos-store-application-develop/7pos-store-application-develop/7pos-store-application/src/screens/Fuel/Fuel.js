import { Box, Flex, Grid } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { Route, Switch, useHistory, useRouteMatch } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Styles from './Fuel.module.css';
import {
  FuelActionManager,
  FuelMonitorSale,
  FuelPumps,
  FuelMultiRefund,
  GradeSelection,
} from '../../components/Fuel';
import { dailpadActions } from '../../slices/dailpad.slice';
import MenuBar from '../../components/POS/MenuBar/menuBar';
import FuelCart from '../POS/Cart/FuelCart';
import Notifications from '../../components/POS/Notifications/Notifications';
import { useFuel, useFuelCache } from '../../hooks';
import ReceiptReprintCntrl from '../POS/ReceiptReprint/receiptReprintCtrl';
import {
  Carwash,
  PromoCarwash,
  EnterCode,
  FreeCarwash,
  NoCarwash,
} from '../../components/Fuel/Carwash';
import { CrindDenial } from '../../components/Fuel/FuelActions/actions/CrindDenial';
import { getPriceDetails } from '../../Utils/cartUtils';

const FuelScreen = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { path } = useRouteMatch();
  const {
    selectPump,
    isIntegratedFuelStore,
    fuelPumps,
    selectedPump,
    crindDenialsReason,
  } = useFuel();
  const { resetFuelSelections } = useFuelCache();

  const {
    fuelAmount = 0.0,
    cartItems,
    taxData,
    isTransactionRefund,
    isTransactionVoid,
  } = useSelector(state => ({
    fuelAmount: state.dailpad.keypad?.value,
    cartItems: state.cart.cartItems,
    taxData: state.cart.taxInfo,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
  }));

  const cleanup = () => {
    dispatch(dailpadActions.resetDailpadState());
    resetFuelSelections();
  };

  const { finalTotalPrice } = getPriceDetails(
    cartItems,
    taxData,
    isTransactionVoid || isTransactionRefund
  );

  useEffect(() => {
    Logger.debug(`[Fuel] Navigated to Fuel Screen`);
    if (!isIntegratedFuelStore) {
      Logger.debug('[Fuel] Navigating to Home as Fuel is disabled.');
      history.replace('/home');
    }

    return cleanup;
  }, [isIntegratedFuelStore]);
  return (
    <Switch>
      <Flex className={Styles.wrapper}>
        <FuelPumps
          isFuelScreen
          fuelPumps={fuelPumps}
          onPumpSelected={selectPump}
        />
        <Grid templateColumns="34% 66%" mt="5px">
          <Box className={Styles.cartWrapper}>
            <FuelCart
              selectedPump={selectedPump}
              crindDenialsReason={crindDenialsReason}
            />
          </Box>
          <Flex flexDirection="column">
            <Notifications />
            <Route path={`${path}`} exact>
              <FuelActionManager
                fuelAmount={fuelAmount}
                finalTotalPrice={Number(finalTotalPrice || 0)}
              />
            </Route>
            <Route path={`${path}/monitorSale`}>
              <FuelMonitorSale />
            </Route>
            <Route path={`${path}/GradeSelection`}>
              <GradeSelection />
            </Route>
            <Route path={`${path}/reprint`}>
              <ReceiptReprintCntrl isFuel />
            </Route>
            <Route path={`${path}/carwash`}>
              <Carwash />
            </Route>
            <Route path={`${path}/enterCode`}>
              <EnterCode />
            </Route>
            <Route path={`${path}/promocarwash`}>
              <PromoCarwash />
            </Route>
            <Route path={`${path}/freecarwash`}>
              <FreeCarwash />
            </Route>
            <Route path={`${path}/multiRefund`}>
              <FuelMultiRefund />
            </Route>
            <Route path={`${path}/nocarwash`}>
              <NoCarwash />
            </Route>
            <Route path={`${path}/crinddenial`}>
              <CrindDenial />
            </Route>
          </Flex>
        </Grid>
        <MenuBar />
      </Flex>
    </Switch>
  );
};
export default FuelScreen;
