export const FuelConstants = {
  fuelPrices: 'FUEL_PRICES',
  dexDisconnect: 'DEX_DISCONNECT',
  mpsPOSPending: 'POS_PENDING',
  mpsPOSAccept: 'POS_COMPLETED',
  mpsPOSReject: 'POS_REJECTED',
  mpsExpired: 'EXPIRED',
  newPricesNotificationId: 'NEW_PRICES_ID',
};
