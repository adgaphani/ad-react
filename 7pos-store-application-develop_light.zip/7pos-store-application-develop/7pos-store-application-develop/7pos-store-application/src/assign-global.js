import { Messages } from './Messages';
import { FuelPumpStatus } from './components/Fuel/FuelPumps/helpers/FuelPumpStatus';

global.Messages = Messages;
global.Logger = {
  info: console.info,
  error: console.error,
  log: console.log,
  trace: console.trace,
};

global.IS_DEV = process.env.NODE_ENV === 'development';
global.PumpStates = FuelPumpStatus;
global.CHANNEL = '7pos';
