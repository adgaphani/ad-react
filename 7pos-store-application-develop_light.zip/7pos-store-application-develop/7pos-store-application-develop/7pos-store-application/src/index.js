import React from 'react';
import { render } from 'react-dom';
// import { createRoot } from 'react-dom/client';
import './index.css';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import ViewManager from './ViewManager';
import * as serviceWorker from './serviceWorker';
import store from './store/index';
import { WebSocketProvider } from './components/Common/WebSocket/WebSocketProvider';

require('./assign-global');

// console.log(process.env);
global.isDev = process.env.NODE_ENV === 'development';
const container = document.getElementById('root');
// const root = createRoot(container);

// Currently App behaving as if it is  using React 17, React 18 Unhandled Rejection are not warnings any more and DVRCOMM is not supported for mac user(which has unhandled promise rejection)
render(
  <React.StrictMode>
    <BrowserRouter>
      <Provider store={store}>
        <WebSocketProvider>
          <ViewManager />
        </WebSocketProvider>
      </Provider>
    </BrowserRouter>
  </React.StrictMode>,
  container
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
