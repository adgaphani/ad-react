import React, { useEffect, useState } from 'react';
import './cfd.css';
import { Route, Switch, useHistory, Redirect } from 'react-router-dom';
import { Box } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import POSRISTheme from './theme/ThemeProvider';
import CfdHome from './screens/CFD/Home/cfd_home';
import MarketingImage from './screens/CFD/CFDMarketing/MarketingImage';
import CFDIdleTimerContainer from './components/Common/IdleTimer/CFDIdleTimerContainer';
import { initiaizeAppLogger } from './Utils/appUtils';
import { cfdActions } from './slices/cfd.slice';
import { POSMessageHandler } from './Communication';
import { AppContext } from './AppContext';
import store from './store';

const electron = window.require('electron');
let JournalItemsList = [];
let taxInfo = null;
let iTotalDetails = null;
let taxDetails = null;
let iMediaAborted = false; // #5214 added media abort line to CFD

const Cfd = () => {
  const {
    isCFDSplitView,
    Country,
    RegistrationScreenBtnClicked,
    config,
    iTermsAndConditions,
    storeDetails,
    paymentTransactionId,
    isSpeedyStore,
    brand,
  } = useSelector(state => ({
    isCFDSplitView: state.cfd.isCFDSplitView,
    member: state.cart.member,
    Country: state.cfd.Country,
    RegistrationScreenBtnClicked: state.cfd.RegistrationScreenBtnClicked,
    config: state.main.configuration,
    iTermsAndConditions: state.cfd.iTermsAndConditions,
    storeDetails: state.main.storeDetails,
    paymentTransactionId: state.cart.paymentTransactionId,
    isSpeedyStore: state.main.isSpeedyStore,
    brand: state.main.configuration?.brand,
  }));

  const dispatch = useDispatch();
  const setItemCounter = useState(0)[1];
  const [TransactionState, setTransactionState] = useState(false);
  const [fbImg, setFbImg] = useState();
  const history = useHistory();
  const [errorSound, setErrorSound] = useState(null);
  const [keyPressSound, setKeyPressSound] = useState(null);

  useEffect(() => {
    setErrorSound(
      new Audio(`${process.env.PUBLIC_URL}/assets/sounds/POS_Error.wav`)
    );
    setKeyPressSound(
      new Audio(`${process.env.PUBLIC_URL}/assets/sounds/POS_KeyPress.wav`)
    );
  }, []);

  const iSetItemState = state => {
    if (state === 'Intialize') {
      setItemCounter(0);
    }
    if (state === 'Increment') {
      setItemCounter(State => ({
        ItemCounter: State.ItemCounter + 1,
      }));
    } else if (state === 'Reset') {
      setItemCounter(0);
      JournalItemsList = null;
    }
  };

  const iSetTranState = state => {
    setTransactionState(state);
  };

  const TermsAndConditionHandler = arg => {
    // console.log(arg);
    if (arg) {
      global?.logger?.info(
        `[7POS UI] - Setting Terms and  Conditions and File length:${arg.length}`
      );
      dispatch(cfdActions.setTermsAndConditions(arg));
    }
  };

  useEffect(() => {
    if (!brand) return;
    import(`./screens/CFD/images/promotion/${brand}/promotion-1-800x800.png`)
      .then(img => {
        setFbImg(img?.default);
      })
      .catch(e => console.log('Error loading fallback image', e));
  }, [brand]);

  useEffect(() => {
    // TODO: Temp fix for global logger error
    global.logger = {
      info: () => {},
      error: () => {},
    };
    // Async message handler
    electron.ipcRenderer.on('TOCFD', (event, arg) => {
      const { CMD } = arg;
      if (CMD === 'MemberStatus') {
        const { Status, url } = arg;
        if (Status === 'UpdateTerms') {
          electron.ipcRenderer.send('LoadUrl', url);
        }
      }
      const { Items, TaxInfo, TotalDetails, TaxDetails } = arg;
      if (Items) JournalItemsList = Items;
      if (TaxInfo?.totalTaxAmount) {
        taxInfo = TaxInfo;
      }
      if (TaxDetails) taxDetails = TaxDetails;
      if (TotalDetails) {
        iTotalDetails = null;
        iTotalDetails = TotalDetails;
      }
      if (arg?.isMediaAborted && TotalDetails?.PaymentMediaList)
        iMediaAborted = arg.isMediaAborted;
      if (CMD === 'IntialState') {
        taxInfo = null;
        iTotalDetails = null;
        JournalItemsList = [];
        iMediaAborted = false;
      }
      const { paymentTransactionId } = store.getState().cart;
      POSMessageHandler(
        arg,
        dispatch,
        history,
        iSetItemState,
        iSetTranState,
        JournalItemsList,
        paymentTransactionId
      );
    });
    electron.ipcRenderer.on('TOCFDDATA', (event, arg) => {
      TermsAndConditionHandler(arg);
    });
  }, []);

  useEffect(() => {
    if (!isCFDSplitView && TransactionState && !RegistrationScreenBtnClicked) {
      dispatch(cfdActions.setCFDFullSplitView(true));
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    }
    if (!iTermsAndConditions) {
      // console.log("read terms from file",);
      electron.ipcRenderer.send('CFD-message', 'ReadTerms');
      if (Country) {
        if (Country !== 'US')
          electron.ipcRenderer.send(
            'LoadUrl',
            'https://7-eleven.ca/terms-conditions?app=true'
          );
        else
          electron.ipcRenderer.send(
            'LoadUrl',
            'https://www.7-eleven.com/terms?app=true'
          );
      }
    }
    return () => {};
  }, [TransactionState]);

  useEffect(() => {
    // console.log(storeDetails, paymentTransactionId);
    if (storeDetails?.storeId !== undefined && paymentTransactionId !== null) {
      initiaizeAppLogger(
        storeDetails?.storeId,
        paymentTransactionId,
        '7pos-store-application-CFD',
        null,
        null
      );
    }
  }, [storeDetails, paymentTransactionId]);

  if (history.location.pathname.includes('index.html')) {
    console.log(history.location.pathname);
  }

  const redirectlocation = {
    pathname: '/',
    search: '?view=viewB',
  };

  return (
    <POSRISTheme isSpeedyStore={isSpeedyStore}>
      <AppContext.Provider
        value={{
          keyPressSound,
          errorSound,
        }}
      >
        <CFDIdleTimerContainer config={config}>
          <div className="cfd">
            <Box className="main" shadow="md">
              <Switch>
                <Route
                  path="/"
                  component={() => <MarketingImage fbImg={fbImg} />}
                  exact
                />
                <Route
                  path="/CfdHome"
                  render={props => (
                    <CfdHome
                      {...props}
                      Journalitems={JournalItemsList}
                      TaxInfo={taxInfo}
                      TotalDetails={iTotalDetails}
                      TaxDetails={taxDetails}
                      isMediaAborted={iMediaAborted}
                      fbImg={fbImg}
                    />
                  )}
                />
                <Route render={() => <Redirect to={redirectlocation} />} />
              </Switch>
            </Box>
          </div>
        </CFDIdleTimerContainer>
      </AppContext.Provider>
    </POSRISTheme>
  );
};
export default Cfd;
