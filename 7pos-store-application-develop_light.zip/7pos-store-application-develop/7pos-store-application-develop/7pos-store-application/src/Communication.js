import { cartActions } from './slices/cart.slice';
import { cfdActions } from './slices/cfd.slice';
import { setConfigDetails, setStoreDetails } from './slices/main.slice';

import {
  getMemberInfo,
  memberregistration,
  UpdateMemberDetails,
} from './Utils/7rewardsUtils';
import { getMemberTransactionId } from './Utils/paymentUtils';

const electron = window.require('electron');

export const SendMessageToCFD = iTransactionMessage => {
  electron.ipcRenderer.send('POS-message', iTransactionMessage);
};

export const SendMessageToPOS = iTransactionMessage => {
  electron.ipcRenderer?.send('CFD-message', iTransactionMessage);
};

export const SendMessageToApp = Command => {
  electron.ipcRenderer?.send('Main-Message', Command);
};

// Handles Message from CFD and updates POS State
export const CFDMessageHandler = (
  arg,
  dispatch,
  newRelicRequest,
  paymentTransactionId,
  isSpeedyStore
) => {
  const { CMD } = arg;
  // console.log(JSON.stringify(arg));
  const { ALTID, AltID, EMAIL, autoTriggerPayment, ...iReceivedMag } = arg;
  global?.Logger?.debug(
    `[7POS UI] - Received new message from CFD:${JSON.stringify(iReceivedMag)}`
  );
  if (CMD === 'AltID') {
    const isMemberTrigger = localStorage.getItem('isMemberTrigger');
    if (!isMemberTrigger) {
      const { ALTID } = arg;
      const MembertransactionId = getMemberTransactionId();
      dispatch(cartActions.setMemberTransactionId(MembertransactionId));
      newRelicRequest = {
        ...newRelicRequest,
        dgetranSeq: MembertransactionId,
      };
      getMemberInfo({
        memberId: ALTID,
        dispatch,
        newRelicRequest,
        paymentTransactionId,
        isSpeedyStore,
      });
    } else {
      global?.logger?.info(`[7POS UI] - Member retrive inprogress`);
    }
  } else if (CMD === 'AcceptSpeedyReward') {
    const { RewardOpt, selectedReward, zipcode, reward_type } = arg;
    dispatch(cfdActions.setSpeedyEnteredPin(zipcode));
    dispatch(cfdActions.setSpeedySelectedReward(selectedReward));
    dispatch(cfdActions.setSelectedSpeedyRewardType(reward_type));
    dispatch(cfdActions.setCatlogID(selectedReward));
    dispatch(cfdActions.setUserRewardAction(RewardOpt));
  } else if (CMD === 'AcceptReward') {
    const { RewardOpt, catalogId } = arg;
    dispatch(cfdActions.setCatlogID(catalogId));
    dispatch(cfdActions.setUserRewardAction(RewardOpt));
  } else if (CMD === 'AddMember') {
    memberregistration(
      arg,
      dispatch,
      newRelicRequest,
      paymentTransactionId,
      isSpeedyStore
    );
    // dispatch(cfdActions.setAltIDUserReset(true));
  } else if (CMD === 'updateFuelLoyalty') {
    if (arg.isSelected) {
      dispatch(cartActions.updatePromptableDiscount(arg.isSelected));
    }
    // dispatch(cfdActions.IntiatedItemRedemption(false));
    dispatch(cfdActions.setSpeedyFuelPrompt(true));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cfdActions.setFuelPromptEnabled(false));
  } else if (CMD === 'MasterCardLoyalty') {
    dispatch(cartActions.setProcessPaymentAsMCLoyalty(true));
    dispatch(cartActions.setIsMasterCardLoyaltyPayment(false));
    if (autoTriggerPayment) {
      dispatch(cartActions.setAutoTriggerCardPayment(true));
    } else {
      // Cancel payment
      dispatch(cartActions.setCancelPaymentForMCLoyalty(true));
    }
  } else if (CMD === 'AltIDEntryIntiated') {
    dispatch(cfdActions.setAltIDUserTrigger(true));
    dispatch(cfdActions.setAltIDUserReset(false));
  } else if (CMD === 'AltIDEntryReset') {
    dispatch(cfdActions.setAltIDUserReset(true));
  } else if (CMD === 'UpdateMember') {
    UpdateMemberDetails(arg, dispatch, paymentTransactionId, isSpeedyStore);
    // #7419 comment below and setting flag after get response from API
    // dispatch(cfdActions.setAltIDUserReset(true));
  } else if (CMD === 'FleetCardPromptsValue') {
    dispatch(cartActions.setFleetPromptValues(arg.promptValues));
  } else if (CMD === 'FleetPrompt') {
    dispatch(cfdActions.setCurrentFleetPrompt(arg.prompt));
  } else if (CMD === 'CFDActivityStatus') {
    const { Status } = arg;
    if (Status === 'Active') {
      dispatch(cfdActions.setUserActivityTrigger(true));
    } else {
      dispatch(cfdActions.setUserActivityTrigger(false));
    }
  } else if (CMD === 'PrepaidLoadConfirm') {
    dispatch(cartActions.setLoadConfirm(arg.status));
    dispatch(cartActions.setCancelLoad(arg.cancelLoad));
  } else if (CMD === 'AcceptRoundUp') {
    const { RoundUpOpt } = arg;
    dispatch(cartActions.setRoundUpCharityStatus(RoundUpOpt));
  } else if (CMD === 'PrepaidAccNumberValue') {
    dispatch(cartActions.setPrepaidAccNumberValue(arg.value));
  } else if (CMD === 'EmailReceipt') {
    const { Email } = arg;
    dispatch(cartActions.setEmailForReceipt(Email));
  } else if (CMD === 'MaxTryReached') {
    const { value } = arg;
    dispatch(cartActions.setMaxTrys(value));
  } else if (CMD === 'SignatureCapture' || CMD === 'CancelSignature') {
    if (CMD === 'SignatureCapture') {
      const { imgUrl } = arg;
      dispatch(cartActions.setCapturedSignature(imgUrl));
    } else {
      dispatch(cartActions.setCancelSignature(true));
      dispatch(cartActions.setCapturedSignature(null));
    }
  } else if (CMD === 'TriggerReward') {
    dispatch(cfdActions.setRewardUserTrigger(true));
  }
};

// Handles Message from POS and updates CFD State
export const POSMessageHandler = (
  arg,
  dispatch,
  history,
  iSetItemState,
  iSetTranState,
  JournalItemsList,
  paymentTransactionId
) => {
  const { CMD, ...restData } = arg;
  const {
    MemberInfo,
    AltID,
    Configuration,
    Items,
    TaxInfo,
    ...iReceivedMag
  } = arg;
  global?.logger?.info(
    `[7POS UI] - Received new message from POS:${JSON.stringify(iReceivedMag)}`
  );
  if (CMD === 'HostDiscount') {
    dispatch(
      cartActions.setHostDiscount({
        data: restData.data,
        selectedGrade: restData.selectedGrade,
      })
    );
  }
  if (CMD === 'redeemOfferInProgress') {
    const { isProgress } = arg;
    dispatch(cfdActions.setRedeemOfferInProgress(isProgress));
  }
  if (CMD === 'fuelLoyalty') {
    dispatch(cartActions.setFuelLoyalty(restData.data));
    console.log('Setting FUEL LOYALTY IN CFD', restData.data);
    if (restData?.data.promptable_discounts?.length) {
      // dispatch(cfdActions.IntiatedItemRedemption(true));
      history.push({
        pathname: '/CfdHome/fuelPrompt',
        search: '?view=viewB',
      });
    }
  }
  if (CMD === 'updatedDiscounts') {
    dispatch(cartActions.setUpdatedDiscounts(restData.data));
  }
  if (CMD === 'MasterCardLoyalty') {
    dispatch(cartActions.setProcessPaymentAsMCLoyalty(true));
    if (restData.alert) {
      return history.push({
        pathname: '/CfdHome/mastercardLoyalty',
        search: '?view=viewB',
      });
    }
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
  }
  if (
    CMD === 'StartTransaction' ||
    CMD === 'UpdateTransaction' ||
    CMD === 'FinalizeTransaction'
  ) {
    // Display first item info
    const { MemberInfo } = arg;
    if (MemberInfo !== null) {
      dispatch(cfdActions.ResetMemberStatus(true));
      dispatch(cartActions.setMemberDetails(MemberInfo));
    }
    iSetTranState(true);
    if (CMD === 'StartTransaction') {
      global?.logger?.info(
        `[7POS UI] - Start Transaction: ${paymentTransactionId}`
      );
      dispatch(cfdActions.setLandingPage('InTransactionPage'));
      iSetItemState('Intialize');
      const { COUNTRY, TransactionType } = arg;
      if (COUNTRY) {
        dispatch(cfdActions.setCountry(COUNTRY));
      }
      if (TransactionType) {
        dispatch(cfdActions.setTransactionType(TransactionType));
      }
      dispatch(cfdActions.setTransactionStatus(''));
      // #9318 added below code for any start transaction
      dispatch(cfdActions.setTransactionFinalize(false));
      dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
      dispatch(cfdActions.ResetMemberStatus(true));
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    } else if (CMD === 'UpdateTransaction') {
      iSetItemState('Increment');
      const { TransactionType } = arg;
      if (TransactionType) {
        dispatch(cfdActions.setTransactionType(TransactionType));
      }
    } else if (CMD === 'FinalizeTransaction') {
      // Display all Items information
      const { basketpromo } = arg;
      dispatch(cartActions.setBasketPromo(basketpromo));
      dispatch(cfdActions.setTransactionFinalize(true));
      iSetItemState('Increment');
    }
  } else if (CMD === 'DiscardMemberInfo') {
    dispatch(cartActions.removeMemberDetails());
    dispatch(cfdActions.ResetMemberStatus(true));
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
  } else if (CMD === 'updateFuelLoyalty') {
    // dispatch(fuelActions.updatePromptableDiscount(true));
  } else if (CMD === 'FleetCard') {
    history.push({
      pathname: '/CfdHome/FleetCard',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'RedeemEligibleItem') {
    dispatch(cfdActions.IntiatedItemRedemption(true));
    history.push({
      pathname: '/CfdHome/Redeemption',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'SWPEligibleItem') {
    dispatch(cfdActions.IntiatedSWP(true));
    history.push({
      pathname: '/CfdHome/Redeemption',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'RedeemResponse') {
    const { DiscountAmount, isSpeedyStore, processPaymentAsMCLoyalty } = arg;
    if (!processPaymentAsMCLoyalty) {
      dispatch(cfdActions.setItemRedemptionAmount(DiscountAmount));
      const pageName = isSpeedyStore
        ? '/CfdHome/SpeedyRedeemStatus'
        : '/CfdHome/RedeemStatus';
      history.push({
        pathname: pageName,
        search: '?view=viewB',
        state: arg,
      });
    }
  } else if (CMD === 'RedeemSpeedyResponse') {
    dispatch(cfdActions.setSpeedyRedeemFailed(true));
  } else if (CMD === 'DismissReward' || CMD === 'CancelUserEntry') {
    dispatch(cfdActions.IntiatedItemRedemption(false));
    dispatch(cfdActions.IntiatedSWP(false));
    dispatch(cfdActions.setAltIDUserTrigger(false));
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
  } else if (CMD === 'IntialState') {
    // Display Advertisement screens
    const { COUNTRY } = arg;
    if (COUNTRY) {
      dispatch(cfdActions.setCountry(COUNTRY));
    }
    iSetItemState('Reset');
    iSetTranState(false);
    dispatch(cfdActions.setCFDFullSplitView(false));
    dispatch(cfdActions.setLandingPage('AdvertisementPage'));
    dispatch(cartActions.removeMemberDetails());
    dispatch(cfdActions.ResetMemberStatus(true));
    dispatch(cfdActions.setTransactionFinalize(false));
    dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
    dispatch(cfdActions.setTransactionStatus(''));
    dispatch(cfdActions.setTransactionType(''));
    dispatch(cfdActions.setClearSign(false));
    dispatch(cartActions.resetHostDiscount());
    dispatch(cfdActions.setSpeedyFuelPrompt(false));
    history.push({
      pathname: '/',
      search: '?view=viewB',
    });
  } else if (CMD === 'TransactionComplete') {
    global?.logger?.info(
      `[7POS UI] - End Transaction: ${paymentTransactionId}`
    );
    // Display Advertisement screen
    const { Status, CFDRefreshTime, delayInMS: delay } = arg;
    let iAdvertiseMentRefreshTime = Number(CFDRefreshTime);
    if (
      iAdvertiseMentRefreshTime < 0 ||
      iAdvertiseMentRefreshTime !== undefined
    )
      iAdvertiseMentRefreshTime = 3;
    if (Status === 'Aborted') {
      dispatch(
        cfdActions.setTransactionStatus('**** TRANSACTION ABORTED ****')
      );
      setTimeout(() => {
        iSetItemState('Reset');
        iSetTranState(false);
        dispatch(cfdActions.setCFDFullSplitView(false));
        dispatch(cartActions.removeMemberDetails());
        dispatch(cfdActions.ResetMemberStatus(true));
        dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
        // #6374 corrected state update
        dispatch(cfdActions.setTransactionStatus(''));
        dispatch(cfdActions.setTransactionType(''));
        dispatch(cfdActions.setLandingPage('AdvertisementPage'));
        dispatch(cfdActions.setClearSign(false));
        history.push({
          pathname: '/',
          search: '?view=viewB',
        });
      }, iAdvertiseMentRefreshTime * 1000);
    } else {
      dispatch(cfdActions.setLandingPage('ConfirmationScreen'));
      dispatch(cfdActions.setTransactionType(''));
      dispatch(
        cfdActions.setTransactionStatus('---- TRANSACTION COMPLETE ----')
      );
      const delayInMs = delay ?? 1000;
      setTimeout(() => {
        history.push({
          pathname: '/CfdHome/paymentConfirmationCFD',
          search: '?view=viewB',
          state: arg,
        });
      }, delayInMs);
    }
  } else if (CMD === 'InTransaction') {
    if (JournalItemsList !== null) {
      dispatch(cfdActions.setTransactionFinalize(false));
      dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
      dispatch(cfdActions.ResetMemberStatus(true));
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    }
  } else if (CMD === 'MemberStatus') {
    const { Status, isSpeedyStore } = arg;
    if (Status === 'NOTFOUND' || Status === 'UpdateTerms') {
      if (isSpeedyStore) {
        history.push({
          pathname: '/CfdHome/Email',
          search: '?view=viewB',
          state: arg,
        });
      } else {
        history.push({
          pathname: '/CfdHome/Terms',
          search: '?view=viewB',
          state: arg,
        });
        // #4672 added Ald entry intiated when user enter from POS.
        dispatch(cfdActions.setAltIDUserTrigger(true));
      }
    } else if (
      !history?.location?.pathname?.includes('Redeemption') &&
      (Status === 'ADDED' ||
        Status === 'Failed' ||
        Status === 'EmailFailed' ||
        Status === 'UpdateFailed' ||
        Status === 'Updated')
    ) {
      history.push({
        pathname: '/CfdHome/MemberStatus',
        search: '?view=viewB',
        state: arg,
      });
    } else if (Status === 'PhoneNumeberFailed') {
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
        state: arg,
      });
      dispatch(cfdActions.setPhoneNumberValidationFailedStatus(true));
      dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
    }
  } else if (CMD === 'StoreConfig') {
    const { Configuration } = arg;
    dispatch(setConfigDetails(Configuration));
  } else if (CMD === 'StoreProfile') {
    const { Configuration, correlationID } = arg;
    dispatch(setStoreDetails(Configuration));
    if (correlationID)
      dispatch(cartActions.setPaymentTransactionId(correlationID));
  } else if (CMD === 'UpdateCorrelationID') {
    const { correlationID } = arg;
    if (correlationID)
      dispatch(cartActions.setPaymentTransactionId(correlationID));
  } else if (CMD === 'PrepaidLoadConfirm') {
    history.push({
      pathname: '/CfdHome/PrepaidLoadConfirm',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'RoundUpTrigger') {
    history.push({
      pathname: '/CfdHome/RoundUp',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'PrepaidAccountNumber') {
    history.push({
      pathname: '/CfdHome/PrepaidAccNumber',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'EmailReceipt') {
    const { Status } = arg;
    if (Status === 'Trigger') {
      dispatch(cfdActions.setLandingPage('EmailReceiptScreen'));
    }
    history.push({
      pathname: Status === 'Aborted' ? '/CfdHome' : '/CfdHome/EmailReceipt',
      search: '?view=viewB',
      state: arg,
    });
  } else if (CMD === 'PinpadMessage') {
    const { Status } = arg;
    if (Status === 'CancelCFDMessage') {
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    } else
      history.push({
        pathname: '/CfdHome/PinpadMessage',
        search: '?view=viewB',
        state: arg,
      });
  } else if (CMD === 'SignatureCapture') {
    dispatch(cfdActions.setClearSign(true));
    history.push({
      pathname: '/CfdHome/signatureCapture',
      search: '?view=viewB',
    });
  }
};
