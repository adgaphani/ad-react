/* eslint-disable max-lines */
/* eslint-disable no-else-return */
import React, { useEffect, useContext, useState, useRef } from 'react';
import './App.css';
import { Route, Switch, useHistory, Redirect } from 'react-router-dom';
import { v1 as uuidv1 } from 'uuid';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { Box, useToast } from '@chakra-ui/react';
import useInterval from '@use-it/interval';
import { getBarcodeData, isValidUPC } from 'ris-js-common';
import moment from 'moment';
import { updateCdb } from '7pos-hardtotals';
import LoginPage from './screens/POS/LoginPage/login';
import Home from './screens/POS/Home/Home';
import Payment from './screens/POS/Payment/payment';
import Fuel from './screens/Fuel/Fuel';
import { fetchConfig } from './api/app/fetchConfig';
import { fetchDeviceInfo } from './api/app/fetchDeviceInfo';
import { fetchItemAgeRestictions } from './api/app/fetchItemAgeRestictions';
import { fetchSaleHours } from './api/app/fetchSaleHours';
import { fetchDayShift } from './api/app/fetchDayShift';
import { fetchCashbackLimit } from './api/app/fetchCashbackLimit';
import { fetchEBTBagFeeExempt } from './api/app/fetchEBTBagFeeExempt';
import { fetchFunctionSecurityDetails } from './api/app/fetchFunctionSecurityDetails';
import { updateDeviceRegistrationStatus } from './api/app/fetchDeviceSetupStatus';
import {
  setConfigDetails,
  setDeviceInfo,
  setLookupCodes,
  setStoreDetails,
  setSaleHoursInfo,
  setDayShift,
  setEBTBagFeeExemptInfo,
  setFunctionSecurityDetails,
  setLoadingStoreDetails,
  setScannedBarcodeStatus,
  setChangedItems,
  setDisablePinpadForReset,
  setpinpadResetRemainderTimer,
} from './slices/main.slice';
import { cartActions } from './slices/cart.slice';
import IdleTimerContainer from './components/Common/IdleTimer/IdleTimerContainer';
import { WebSocketContext } from './components/Common/WebSocket/WebSocketProvider';
import { getItembyUpcApi } from './api/cart';
import { cfdActions } from './slices/cfd.slice';
import { balanceActions } from './slices/balance.slice';
import { socketActions } from './slices/socket.slice';
import { dailpadActions } from './slices/dailpad.slice';
import {
  CAPTURE_HARDTOTALS,
  CARD_READ,
  WAITING_FOR_CARD,
  WAITING_FOR_EBT_MANUAL_ENTRY,
  DECLINE,
  CASHBACK_AMOUNT,
  PROMPT_REFERENCE_NUMBER,
  // DECLINED_ORIGINALCARD_NOTFOUND,
  // DECLINED_ORIGINALSALE_NOTFOUND,
  // CANCEL,
  // INVALID_EBT_ACCOUNT,
  FLEET,
  // TIMEOUT,
  FLEET_VOID,
  EBT_ACCOUNT,
  EBTCB,
  EBTSNAP,
  BALANCE_INQUIRY,
  BALANCE_INQUIRY_WAITING_FOR_CARD,
  // BALANCE_INQUIRY_TIMEOUT,
  BALANCE_INQUIRY_CANCEL,
  BALANCE_INQUIRY_CARD_READ,
  CARD_LOOKUP_PROMPTS,
  // DECLINED_INVALID_PAYMENT_REQUEST,
  PAYMENT_TERMINATED,
  CANCEL_PINPAD,
  PINPAD_UNAVAILABLE,
  USB_DEVICE_NOT_FOUND,
  // DECLINED_TRANSACTION_NOT_ALLOWED,
  BALANCE_INQUIRY_INVALID_CARD,
  PAYMENT_CANCEL,
  PAYMENT_ERROR,
  PAYMENTDECLINE_INVALIDMEDIA,
  LOAD_FLG_INSALE,
  ACCOUNT_NBR_PROMPT,
  AMOUNT_RANGE_PROMPT,
  AMOUNT_CONFIRM_PROMPT,
  LOAD_REQUEST_INPROGRESS,
  RESET_REQUEST_STATUS,
  WSTopics,
  CASHBACK_RESTRICTION,
  SWIPE_ID_DATA,
  BAD_SWIPE,
  TRANSACTION_RESPONSE,
  PIN_ENTRY_START,
  CASHBACK_START,
  DEVICE_DISCONNECTED,
  CMD_NOT_AVAILABLE,
  ONLINE_REQUEST_TIMER,
  // PIN_ENTRY_END,
  PAYMENT_PROCESS,
  SIGNATURE_CAPTURE,
  isEBTBAGFEEENABLED,
  WAITING_FOR_SC_MOM_LOCK_RESPONSE,
  WAITING_FOR_MOM_PING_RESPONSE,
  SC_MOM_LOCK_ACQUIRED,
  SC_MOM_LOCK_FAILED,
  MOM_PING_SUCCESS,
  MOM_PING_FAILED,
  WAITING_FOR_SC_SAFE_LOCK_RESPONSE,
  SC_SAFE_LOCK_ACQUIRED,
  SC_SAFE_LOCK_FAILED,
  MAX_CREDIT_ITEMS,
  ITEM_TYPE,
} from './constants';
import {
  APPQUEUE_EVENTS_RECIVED_LOG,
  PINPAD_DISCONNECTED_LOG,
  APPQUEUE_EVENTS_ERROR_LOG,
  PIN_ENTRY_START_LOG,
  CASHBACK_START_LOG,
  CARD_LOOKUP_PROMPTS_LOG,
  CARD_LOAD_SUCCESS_LOG,
  CARD_LOAD_FAIL_LOG,
  // PIN_ENTRY_END_LOG,
  PAYMENT_PROCESS_LOG,
} from './loggerConstants';
import {
  notificationsActions,
  setInstallTimer,
  clearHideInstallNotification,
  setReceivedInstallNotification,
  dismissNotification,
} from './slices/notifications.slice';
import {
  appIntegrationRequest,
  checkIsItemExpired,
  getBarcodeInformation,
  getCorrelationID,
  verifyUserId,
  storeTranSeqNumber,
  finalizeHardTotals,
  captureHardTotals,
  transactionTimeTrack,
  waitForGivenTime,
  getStorageItems,
} from './Utils/appUtils';
import {
  handleMoneyOrderLockResponse,
  releaseMoneyOrderLock,
} from './Utils/moneyOrderUtils';
import store from './store';
import { buildCartChangeTrial } from './Utils/cartUtils';
import { isCardLoadsLimitCrossed } from './Utils/cardLoadUtils';
import {
  CFDMessageHandler,
  SendMessageToCFD,
  SendMessageToApp,
} from './Communication';
import { fetchAgeFromBarcodeData } from './api/scanner/fetchAgeFromBarcodeData';
import { fetchStoreProfile } from './api/app/fetchStoreProfile';
import { getMemberInfo } from './Utils/7rewardsUtils';
import { cashFunctionActions } from './slices/cashFunctions.slice';
import {
  incrementCashDrawerViolationCount,
  getMemberTransactionId,
  getBalanceDue,
} from './Utils/paymentUtils';
import { writeDataToFile, readDataToFile, deleteFile } from './Utils/fileUtils';
import { authActions } from './slices/auth.slice';
import { peripheralActions } from './slices/peripheral.slice';
import { FullPageLoader } from './components/Common';
import { AppContext } from './AppContext';
import { fetchTranseqId } from './api/transeqenceId/fetchTranseqId';
// import { fetchDepartmentInfo } from './api/app/fetchDepartmentInfo';
import { getDeclinedReceipts } from './screens/POS/Payment/DeclinedReceipt/DeclinedReceipt';
import { FuelSubscription } from './screens/Fuel/FuelSubscription';
import { getTenderedDetails } from './Utils/mediaAbortUtils';
import {
  useSharedFuelRequest,
  useInitializer,
  useFuelCache,
  useWSocket,
  useSafeInit,
  useUpdatedState,
  useCart,
  usePinpadCQListener,
  useDayShiftChange,
  useHardware,
  usePrivileges,
  usePromoUtils,
} from './hooks';
import { TransactionTypes } from './TransactionTypes';
import { getDVR } from './hardware/dvr';
import { setShowToast } from './hardware/ipc';
import { useKeyBoardConfig } from './hooks/useKeyBoardConfig';

const electron = window.require('electron');

const App = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const toast = useToast();
  const safeOflineTimer = useRef(null);
  const [ws] = useContext(WebSocketContext);
  const { isConnected, isDisconnected } = useWSocket();
  const subscriptionRef = useRef([]);
  const [cashDrwrLayover, setCashDrwrLayover] = useState(false);
  const { handleDayOrShiftCloseOnSyncEvent } = useDayShiftChange();
  const { isFuelTransactionInProgress, getCartMetrics } = useCart();
  const cashBackLimitRef = useRef('');
  const transHoldTimer = useRef(null);
  const [onlineReqTimerStart, setOnlineReqTimerStart] = useState(false);
  const { pinpadControlQueueListener } = usePinpadCQListener();
  const { subscribeSafeEvents, clearSafeSubs, initializeSafe } = useSafeInit();
  const updatedState = useUpdatedState();
  const { refreshKeyBoardConfig } = useKeyBoardConfig();
  let appQueue;
  let controlQueue;
  const {
    errorSound,
    successSound,
    keyPressSound,
    scanSound,
    authConfirmNotifySound,
  } = useInitializer();
  const {
    socketStatus,
    storeProfile,
    referenceAttempts,
    RegistrationInvoke,
    lookupCallProgress,
    pipoTransaction,
    EODEOSDetails,
    configuration,
    isSafeCashDrwrOpen,
    isSafeDrop,
    paymentTransactionId,
    isPaymentTriggered,
    isPIPOCashDrwrOpen,
    isDataSyncInProgress,
    isSpeedyStore,
    cancelPaymentForMCLoyalty,
    receivedInstallNotification,
    installTimer,
    posSystemStatus,
    isFunctionSecurityTriggered,
    iFunctionSecurityData,
  } = useSelector(
    state => ({
      socketStatus: state.socket.status,
      storeProfile: state.main.storeDetails,
      referenceAttempts: state.cart.referenceAttempts,
      RegistrationInvoke: state.auth.RegistrationInvoke,
      user: state.auth.user,
      lookupCallProgress: state.cart.lookupCallProgress,
      pipoTransaction: state.cashFunctions.pipoTransaction,
      EODEOSDetails: state.cart.EODEOSDetails,
      configuration: state.main.configuration,
      isSafeDrop: state.cart.isSafeDrop,
      isSafeCashDrwrOpen: state.cart.isSafeCashDrwrOpen,
      paymentTransactionId: state.cart.paymentTransactionId,
      isPaymentTriggered: state.cart.isPaymentTriggered,
      isPIPOCashDrwrOpen: state.peripheral.isPIPOCashDrwrOpen,
      isDataSyncInProgress: state.auth.isDataSyncInProgress,
      isSpeedyStore: state.main.isSpeedyStore,
      cancelPaymentForMCLoyalty: state.cart.cancelPaymentForMCLoyalty,
      receivedInstallNotification:
        state.notifications.receivedInstallNotification,
      installTimer: state.notifications.installTimer,
      posSystemStatus: state.cart.posSystemStatus,
      isFunctionSecurityTriggered: state.cart.isFunctionSecurityTriggered,
      iFunctionSecurityData: state.cart.iFunctionSecurityData,
    }),
    shallowEqual
  );
  const { isValidUserFunction } = usePrivileges();
  const [shutdownHardware] = useHardware();
  const { cancelFuelRewardInTransaction } = usePromoUtils();

  const showToast = ({
    description = 'Please pass the description...',
    status = 'error',
    duration = 3000,
    position = 'top',
  }) => {
    if (status === 'error')
      errorSound?.play().catch(e => console.log('Sound error', e));
    toast({
      description,
      status,
      duration,
      position,
    });
  };
  setShowToast(showToast);

  const forceLogoffDataNotSync = DisplayMessage => {
    const { isAppLogin } = store.getState().auth;
    if (isAppLogin) {
      global?.Logger?.error(
        `[7POS UI] - Logging off POS because POS didnt get ${DisplayMessage}`
      );
      showToast({
        description: `Failed to get ${DisplayMessage}`,
      });
      // eslint-disable-next-line no-use-before-define
      handleLogout();
    }
  };

  const validateAgeInformation = (
    data,
    paymentTransactionId,
    triggerSource
  ) => {
    try {
      if (
        window.location.pathname.includes('manualEntry') ||
        window.location.pathname.includes('verification')
      ) {
        fetchAgeFromBarcodeData(data, paymentTransactionId).then(response => {
          if (
            response?.data &&
            ['DL', 'CAC', 'ID'].includes(response?.data?.documentType)
          ) {
            dispatch(cartActions.setIdCardInfo(response.data));
            global?.Logger?.info(
              `Age infromation successfully retrieved from Scan/Swipe DL.`
            );
          } else {
            global?.Logger?.info(
              `[7POS UI] - Parse fail from POS ,idType is not one of 'DL', 'CAC','ID'. Resp:`,
              response,
              paymentTransactionId
            );
          }
        });
      } else {
        showToast({
          description: `DL Scan not allowed`,
          position: 'top-left',
        });
        global?.Logger?.info(
          `[7POS UI] - DL/I.D scan will allowed only during age restriction screen.`
        );
        return;
      }
    } catch (error) {
      showToast(
        triggerSource === 'DLSWIPE'
          ? { description: 'INVALID SWIPE DATA' }
          : {
              description: 'Unable to Scan ID this time',
            }
      );
      global?.Logger?.error(
        `[7POS UI] - ageScanError ${JSON.stringify(error)}`
      );
    }
  };

  const {
    processPrepayApprovalIfNeeded,
    processClearSaleIfNeeded,
  } = useSharedFuelRequest();
  const { setFuelPrepayPaymentMedia } = useFuelCache();

  const pipoRef = useRef(pipoTransaction);
  const fuelTransactionRef = useRef(isFuelTransactionInProgress);

  const [loading, showLoader] = useState(false);

  const stopLoading = () => {
    showLoader(false);
  };

  const startLoading = () => {
    showLoader(true);
  };

  const onApplicationExit = async (isLoading, reason) => {
    global?.Logger?.info(
      `[7POS UI] Shutdown at ${moment().format('MM/DD/YYYY - hh:mm:ss')} `
    );

    if (!isLoading) {
      shutdownHardware?.(reason || "Document 'beforeunload'");
    }
    subscriptionRef.current.forEach(e => e.unsubscribe());
    clearSafeSubs();
  };

  const appRestart = () => {
    onApplicationExit(false, 'Application Restart');
    SendMessageToApp('Restart');
  };

  const showInvalidKeySelection = operation => {
    history.push({
      pathname: '/home/InvalidKey',
      state: {
        title: Messages.middle_of_transaction,
        description: Messages.invalid_key_display_text(operation),
      },
    });
  };
  const setCashDrawerLayovr = canIShow => {
    setCashDrwrLayover(canIShow);
  };

  const [installTimerHandle, setInstallTimerHandle] = useState(null);
  const triggerForceInstall = installRemainder => {
    const {
      posSystemStatus,
      cartItems,
      transactionMemory,
    } = store.getState().cart;
    const triggeredEODEOS = localStorage.getItem('triggeredEODEOS') || false;
    if (
      EODEOSDetails?.IntiateEODEOS ||
      posSystemStatus === 'StartedNewTransaction' ||
      transactionMemory?.items?.length > 0 ||
      cartItems?.length > 0 ||
      triggeredEODEOS
    ) {
      Logger.error(
        `Active transaction at the POS due to postpone force installation`
      );
      toast({
        description: 'Please complete transaction, Installation is pending',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
    } else {
      clearInterval(installTimerHandle);
      dispatch(setInstallTimer(0));
      dispatch(setReceivedInstallNotification(false));
      if (installRemainder !== null) {
        const { installationData } = installRemainder;
        const payload = {
          from: 'POS',
          action: installationData?.action,
          component: 'Middleware',
          deviceType: 'Pinpad',
          reason: 'UserConfirmed',
          deploymentId: installationData?.deploymentId,
        };
        if (installationData?.packages) {
          payload.packages = installationData?.packages;
        }
        const request = appIntegrationRequest({
          type: 'Notification_Bar',
          payload,
          correlationId: paymentTransactionId,
        });
        Logger.info(
          `Force Installation trigger after timeout:, ${JSON.stringify(
            request
          )}`
        );
        ws.socket?.send(
          '/app/7pos/appnotifications',
          {},
          JSON.stringify(request)
        );
        dispatch(dismissNotification(installationData));
        dispatch(cartActions.setPOSSystemStatus('SoftwareInstallTriggered'));
        localStorage.removeItem('InstallRemainder');
        deleteFile({ fileName: 'InstallRemainder.json' });
        // eslint-disable-next-line no-use-before-define
        handleLogout();
      }
    }
  };

  useEffect(() => {
    if (receivedInstallNotification && installTimer > 0) {
      setInstallTimerHandle(
        setInterval(() => {
          const {
            installTimer,
            notifications,
            receivedInstallNotification,
          } = store.getState().notifications;
          let installRemainder = localStorage.getItem('InstallRemainder');
          try {
            installRemainder = JSON.parse(installRemainder);
          } catch (error) {
            Logger.error(
              `Error retrieve installation data from memory:${JSON.stringify(
                error
              )}`
            );
            installRemainder = null;
          }
          const remainigTimer = installTimer - 1 > 0 ? installTimer - 1 : 0;
          Logger.info(
            `Remaining timer for Force Installation:${JSON.stringify(
              remainigTimer
            )}`
          );
          if (installRemainder !== null) {
            let { installationData } = installRemainder;
            installationData = {
              ...installationData,
              remainingNotificationTime: remainigTimer,
            };
            localStorage.setItem(
              'InstallRemainder',
              JSON.stringify({
                installationData,
              })
            );
            writeDataToFile({
              fileName: 'InstallRemainder.json',
              fileData: JSON.stringify({
                installationData,
              }),
            });
          }
          dispatch(setInstallTimer(remainigTimer));
          // Notification remainder populate for installation
          if (
            remainigTimer === 45 ||
            remainigTimer === 30 ||
            remainigTimer === 15 ||
            remainigTimer === 5
          ) {
            if (
              notifications.findIndex(
                notification =>
                  notification?.deploymentId &&
                  (notification.from === 'DeploymentsAgent' ||
                    notification.sender === 'DeploymentsAgent')
              ) !== -1
            ) {
              Logger.info(
                `Enable popup installation notification at: ${remainigTimer}`
              );
              const payload = {
                remainigTimer,
              };
              dispatch(clearHideInstallNotification(payload));
            }
          } else if (remainigTimer === 0 && receivedInstallNotification) {
            triggerForceInstall(installRemainder);
          }
        }, 60000)
      );
    } else {
      // eslint-disable-next-line no-lonely-if
      if (installTimerHandle) clearInterval(installTimerHandle);
    }
  }, [receivedInstallNotification]);

  useEffect(() => {
    if (posSystemStatus && posSystemStatus?.length) {
      console.log(
        `[7POS UI]Status:(${posSystemStatus}) at ${moment().format(
          'MM/DD/YYYY - hh:mm:ss'
        )} and POS Version: ${process.env.REACT_APP_VERSION} `
      );
      Logger.info(
        `[7POS UI]Status:(${posSystemStatus}) at ${moment().format(
          'MM/DD/YYYY - hh:mm:ss'
        )} and POS Version: ${process.env.REACT_APP_VERSION} `
      );
      const {
        installTimer,
        receivedInstallNotification,
      } = store.getState().notifications;
      if (installTimer === 0 && receivedInstallNotification) {
        let installRemainder = localStorage.getItem('InstallRemainder');
        try {
          installRemainder = JSON.parse(installRemainder);
        } catch (error) {
          Logger.error(
            `Error retrieve installation data from memory:${JSON.stringify(
              error
            )}`
          );
          installRemainder = null;
        }
        triggerForceInstall(installRemainder);
      }
    }
  }, [posSystemStatus]);

  useEffect(() => {
    fuelTransactionRef.current = isFuelTransactionInProgress;
  }, [isFuelTransactionInProgress]);

  useEffect(() => {
    const { isPIPOCashDrwrOpen } = updatedState().peripheral;
    if ((isSafeCashDrwrOpen && !isSafeDrop) || isPIPOCashDrwrOpen) {
      setCashDrawerLayovr(true);
      return;
    }
    setCashDrawerLayovr(false);
  }, [isSafeDrop, isSafeCashDrwrOpen, isPIPOCashDrwrOpen]);

  const handleLogout = () => {
    global?.Logger?.info(`[7POS UI] - POS is logging off`);
    const iTransactionMessage = {
      CMD: 'IntialState',
      COUNTRY: storeProfile?.address?.country,
    };
    SendMessageToCFD(iTransactionMessage);
    dispatch(dailpadActions.resetDailpadState());
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(cfdActions.setAltIDUserReset(false));
    dispatch(cfdActions.setAltIDUserTrigger(false));
    dispatch(authActions.setAppLogInStatus(false));
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cartActions.setFinalizeClick(false));
    dispatch(cartActions.setPromoInProgress(false));
    dispatch(cfdActions.setTransactionFinalize(false));
    dispatch(socketActions.setCashDrawerStatus(null));
    dispatch(socketActions.setCashBack(null));
    dispatch(cartActions.setPaymentTriggerStatus(false));
    dispatch(cartActions.setIsMediaAbortTriggered(false));
    dispatch(cfdActions.setSpeedyFuelPrompt(false));
    dispatch(peripheralActions.setMOMLockStatus(null));
    dispatch(peripheralActions.setSafeLockStatus(null));
    dispatch(cartActions.setIsEndOfDayorShift(false));
    localStorage.removeItem('isMemberTrigger');
    localStorage.removeItem('isMemberPromoTrigger');
    localStorage.removeItem('finalTaxCallTriggered');
    history.replace('/');
  };

  const MoneyOrderEventReceived = async e => {
    try {
      const response = JSON.parse(JSON.stringify(e));
      const body = JSON.parse(response?.body);
      const messageType = body?.messageHeader?.messageType;
      global?.Logger?.info(
        `[7POS UI] - MoneyOrderEventReceived ${JSON.stringify(body)}`
      );
      const { momLockStatus } = store.getState().peripheral;
      if (messageType === 'terminalPingResponse') {
        if (momLockStatus === WAITING_FOR_MOM_PING_RESPONSE) {
          if (body?.messageBody?.message?.status === 'moneyOrderStatusGood')
            dispatch(peripheralActions.setMOMLockStatus(MOM_PING_SUCCESS));
          else dispatch(peripheralActions.setMOMLockStatus(MOM_PING_FAILED));
        }
      } else {
        const {
          storeDetails,
          deviceInfo,
          configuration,
        } = store.getState().main;
        const { cartItems } = store.getState().cart;
        let isMOTransaction = null;
        if (cartItems?.length > 0) {
          isMOTransaction = cartItems?.some(item => item.isMoneyOrder === true);
        }
        if (messageType === 'moneyOrderResponse') {
          // MO release request need to send store coordinator as soon as MO response received.
          releaseMoneyOrderLock(ws, deviceInfo?.id, storeDetails?.storeId);
          // Printer status only need to update current transaction have MO items.
          if (isMOTransaction) {
            dispatch(
              cartActions.setMoneyOrderDetails(body?.messageBody?.message)
            );
            dispatch(cartActions.setMoneyOrderPrinterStatus(true));
          }
        } else if (
          messageType === 'transaction' &&
          body?.messageHeader?.source.sourceType === 'mom'
        ) {
          // MO release request need to send store coordinator as soon as MO response received.
          releaseMoneyOrderLock(ws, deviceInfo?.id, storeDetails?.storeId);
          // Printer status only need to update current transaction have MO items.
          if (isMOTransaction) {
            const msg = JSON.parse(JSON.stringify(body)?.replace(/ /g, ''));
            dispatch(cartActions.setMoneyOrderDetails(msg?.messageBody));
            dispatch(cartActions.setMoneyOrderPrinterStatus(true));
          }
        } else if (messageType === 'endOfDayResponse') {
          // MO will lock from store coordinator to pull MO transactions.
          // once done release request send from POS to release the MO
          releaseMoneyOrderLock(ws, deviceInfo?.id, storeDetails?.storeId);
        }

        // display any message only integrated store
        if (
          configuration?.moneyOrderConfig?.serialNumber &&
          configuration?.moneyOrderConfig?.isIntegrated &&
          configuration?.moneyOrderConfig?.isMoneyOrderStore
        ) {
          const MSG = body?.messageBody?.message?.errorMessge;
          // #3712 NO need display MO online during EOD/EOS
          // #6100 when POS received message from Mo machine response no need display message here
          if (
            MSG &&
            MSG.length > 0 &&
            !MSG.includes('MONEY ORDER MACHINE ONLINE') &&
            messageType !== 'moneyOrderResponse'
          ) {
            showToast({
              description: MSG,
            });
          }
        }
      }
    } catch (error) {
      global?.Logger?.error(
        `[7POS UI] - MoneyOrderEventReceived ${JSON.stringify(error)}`
      );
    }
  };

  const MoneyOrderSubcribe = () => {
    if (socketStatus === 'CONNECTED') {
      if (!ws.socket) return;

      controlQueue = ws.socket?.subscribe(
        '/controlQueue/mom',
        MoneyOrderEventReceived
      );
      subscriptionRef.current = subscriptionRef.current || [];
      subscriptionRef.current.push(controlQueue);
    }
  };

  const getConfig = async () => {
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const configResp = await fetchConfig({
        correlationID: paymentTransactionId,
      });
      const configDetails = JSON.parse(configResp.data.data);
      global?.Logger?.info(`[7POS UI] - getConfig details success`);
      const { gas } = configDetails || {};
      if (gas?.isGasStore && gas?.isDEXInstalled) {
        global?.Logger?.info(`[Fuel] Fuel Enabled Store`);
      }
      dispatch(setConfigDetails(configDetails));
      const isMaxAllowedItemQty =
        configDetails?.storeConfig?.maxAllowedItemQuantity !== undefined ||
        configDetails?.storeConfig?.maxAllowedItemQuantity !== null ||
        false;

      const MaxallowedItemQty = isMaxAllowedItemQty
        ? Number(configDetails?.storeConfig?.maxAllowedItemQuantity)
        : 99;
      dispatch(cartActions.setMaxallowedItemQty(MaxallowedItemQty));
      const maxCreditItems =
        configDetails?.storeConfig?.maxCreditItems !== undefined &&
        configDetails?.storeConfig?.maxCreditItems !== null
          ? Number(configDetails?.storeConfig?.maxCreditItems)
          : MAX_CREDIT_ITEMS;
      localStorage.setItem('maxCreditItems', maxCreditItems);
      const iTransactionMessage = {
        CMD: 'StoreConfig',
        Configuration: configDetails,
      };
      SendMessageToCFD(iTransactionMessage);
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - getConfig details Error`);
    }
  };

  const getFunctionSecurityDetails = async () => {
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const response = await fetchFunctionSecurityDetails({
        correlationID: paymentTransactionId,
      });
      const functionSecurityDetails = JSON.parse(response.data.data);
      dispatch(
        setFunctionSecurityDetails(functionSecurityDetails[0]?.functions)
      );
      // PROD: Release Oct 11 2022 require to disable functional Security
      // dispatch(setFunctionSecurityDetails(null));
      Logger.info(`[7POS UI] - getFunctionSecurityDetails success`);
    } catch (error) {
      Logger.debug(`[7POS UI] - getFunctionSecurityDetails failed`);
    }
  };

  const getEBTBagFeeExempt = async () => {
    try {
      if (!isEBTBAGFEEENABLED) return;
      const { paymentTransactionId } = store.getState()?.cart;
      const ebtBagFeeResp = await fetchEBTBagFeeExempt({
        correlationID: paymentTransactionId,
      });
      const exemptEBTDetails = JSON.parse(ebtBagFeeResp.data.data);
      Logger.info(`[7POS UI] - getEBTBagFeeExempt details success`);
      dispatch(setEBTBagFeeExemptInfo(exemptEBTDetails));
    } catch (error) {
      Logger.error(`[7POS UI] - getEBTBagFeeExempt details Error`);
    }
  };

  const MoneyOrderIntialize = () => {
    const { deviceInfo, configuration } = store.getState().main;
    const { paymentTransactionId } = store.getState()?.cart;
    global?.Logger?.info(
      `[7POS UI] - Store Configuration for MO:- isIntegrated:${configuration?.moneyOrderConfig?.isIntegrated},
      isMoneyOrderStore:${configuration?.moneyOrderConfig?.isMoneyOrderStore} 
      and MoneyOrder Terminal Number:${configuration?.moneyOrderConfig?.serialNumber}`
    );
    // Make sure MO serial number should send to MO Intialise call
    if (
      configuration?.moneyOrderConfig?.serialNumber &&
      configuration?.moneyOrderConfig?.isIntegrated &&
      configuration?.moneyOrderConfig?.isMoneyOrderStore
    ) {
      const MoneyOrderIntialieResuest = appIntegrationRequest({
        type: 'MoneyOrder',
        deviceInfo,
        correlationId: paymentTransactionId,
      });
      MoneyOrderIntialieResuest.messageBody.message =
        configuration?.moneyOrderConfig?.serialNumber;
      if (MoneyOrderIntialieResuest.messageBody.message !== 'MOM') {
        ws.socket?.send(
          '/app/mom',
          {},
          JSON.stringify(MoneyOrderIntialieResuest)
        );
        MoneyOrderSubcribe();
      }
    } else {
      global?.Logger?.info(
        `[7POS UI] :- moneyorder paramters does not exist, retry to get from config.`
      );
      getConfig().then(() => {
        const { configuration } = store.getState().main;
        const MoneyOrderIntialieResuest = appIntegrationRequest({
          type: 'MoneyOrder',
          deviceInfo,
          correlationId: paymentTransactionId,
        });
        MoneyOrderIntialieResuest.messageBody.message =
          configuration?.moneyOrderConfig?.serialNumber || '';
        global?.Logger?.info(
          `[7POS UI] - MoneyOrder Store Status ${configuration?.moneyOrderConfig?.isIntegrated}
              and ${configuration?.moneyOrderConfig?.isMoneyOrderStore} and Terminal Number: ${configuration?.moneyOrderConfig?.serialNumber}`
        );
        if (
          configuration?.moneyOrderConfig?.serialNumber &&
          configuration?.moneyOrderConfig?.isIntegrated &&
          configuration?.moneyOrderConfig?.isMoneyOrderStore
        ) {
          if (MoneyOrderIntialieResuest.messageBody.message !== 'MOM') {
            ws.socket?.send(
              '/app/mom',
              {},
              JSON.stringify(MoneyOrderIntialieResuest)
            );
            MoneyOrderSubcribe();
          } else {
            global?.Logger?.info(
              `[7POS UI] - MoneyOrder Intialise failed due to not get terminal ID`
            );
          }
        } else {
          global?.Logger?.info(
            `[7POS UI] - MoneyOrder Intialise failed due to not Integrated/terminal Number`
          );
        }
      });
    }
  };

  // eslint-disable-next-line
  const isCashFunctionInProgress = () => {
    return pipoRef.current && !pipoRef.current?.isCompleted; // Incomplete pipoTransaction should be existed
  };

  const cashDrawerEvents = () => {
    const { paymentTransactionId } = store.getState()?.cart;
    const cashDrawerResuest = appIntegrationRequest({
      type: 'CashDrawer',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      WSTopics.cashdrawer.initiate,
      {},
      JSON.stringify(cashDrawerResuest)
    );
    const controlQueue = ws.socket?.subscribe(
      WSTopics.cashdrawer.listenStatus,
      e => {
        const response = JSON.parse(JSON.stringify(e));
        const body = JSON.parse(response.body);
        global?.Logger?.debug(
          `[7POS UI] - cashDrawerEvents ${JSON.stringify(
            body?.messageBody?.message
          )}`
        );
        const [drawerStatus] = body?.messageBody?.message?.split(':') || [];
        if (drawerStatus) {
          if (
            drawerStatus === 'CD_OPEN_FAILED' ||
            drawerStatus === 'CD_NOT_INITIALIZED'
          ) {
            const toastMsg =
              drawerStatus === 'CD_NOT_INITIALIZED'
                ? 'Cash drawer not initialized'
                : 'Unable to open Cash drawer';
            dispatch(socketActions.setCashDrawerStatus(null));
            const { user } = store.getState().auth;
            getDVR()?.setDrawerStatus(null, user);
            dispatch(cartActions.setNotifyScanStatus(toastMsg));
            return;
          }

          setTimeout(() => {
            dispatch(socketActions.setCashDrawerStatus(drawerStatus));
            const { user } = store.getState().auth;
            getDVR()?.setDrawerStatus(drawerStatus, user);
            // RISPIN-2711 added email receipt screen as well to skip cash drawer alram notification
            const isPaymentFlow =
              window.location.href.includes('success') ||
              window.location.href.includes('emailReceipt');

            // const { isSafeCashDrwrOpen, isSafeDrop } = updatedState().cart;
            // const { isPIPOCashDrwrOpen } = updatedState().peripheral;

            // Need to PIPO/Safe
            if (
              drawerStatus === 'CD_OPEN_OK' ||
              drawerStatus === 'CD_IS_OPEN'
            ) {
              const { isSafeDrop } = updatedState().cart;
              if (pipoRef.current)
                dispatch(peripheralActions.setIsPIPOCashDrwrOpen(true));
              else if (isSafeDrop)
                dispatch(cartActions.setSafeCashDrwerOpen(true));
            }
            // Handling CASH DRWER CLOSED FOR SAFE
            if (drawerStatus === 'CD_CLOSED') {
              dispatch(cartActions.setSafeCashDrwerOpen(false));
              dispatch(peripheralActions.setIsPIPOCashDrwrOpen(false));
            }
            if (drawerStatus === 'CD_ALARM_ON') {
              showToast({
                description: 'Please close cash drawer',
                position: 'top-left',
              });
              incrementCashDrawerViolationCount();
              updateCdb({ cashDrawerViolations: 1 });
              // #8466 moved to cashDrawer page itself checking drawer status
              // if (
              //   !isPaymentFlow &&
              //   !isSafeCashDrwrOpen &&
              //   !isSafeDrop &&
              //   !isPIPOCashDrwrOpen
              // ) {
              //   history.push({
              //     pathname: '/payment/cashDrawer',
              //     state: {
              //       isAlaramOn: true,
              //     },
              //     search: `?status=noSale`,
              //   });
              // }
            } else if (drawerStatus === 'CD_ALARM_OFF') {
              // Dont redirect if your in email screen RISPIN-2711
              dispatch(cartActions.setSafeCashDrwerOpen(false));
              dispatch(peripheralActions.setIsPIPOCashDrwrOpen(false));
              if (
                isPaymentFlow &&
                !isSafeDrop &&
                !window.location.href.includes('emailReceipt')
              ) {
                const {
                  balanceDue,
                  isTransactionVoid,
                  isTransactionRefund,
                } = store.getState().cart;
                if (
                  Number(balanceDue) === 0 ||
                  isTransactionVoid ||
                  isTransactionRefund
                ) {
                  history.push({
                    pathname: '/payment/success',
                  });
                }
              }
            }
          }, 0);
        }
      }
    );
    subscriptionRef.current = subscriptionRef.current || [];
    subscriptionRef.current.push(controlQueue);
  };

  const scannerInitialize = () => {
    const { paymentTransactionId } = store.getState()?.cart;
    const scannerRequest = appIntegrationRequest({
      type: 'Scanner',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/scanner', {}, JSON.stringify(scannerRequest));
  };

  const pinpadIntialize = () => {
    const { paymentTransactionId } = store.getState()?.cart;
    const pinpadReq = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: 'event',
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PINPAD',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: JSON.stringify({
          transactionId: uuidv1().toString(),
          pinpadConfig: {
            pinpadConnected: null, // future implementation
            cashbackThreshold: cashBackLimitRef?.current?.cashbackLimit,
          },
        }),
      },
    };
    ws.socket?.send('/app/pinpad', {}, JSON.stringify(pinpadReq));
  };

  const onAppNotificationsEvntsReceived = e => {
    if (
      typeof e.body === 'string'
      // && JSON.parse(e.body).sender === 'posnotifications'
    ) {
      const payload = JSON.parse(e.body);
      global?.Logger?.info(
        `[7POS UI] - onAppNotificationsEvntsReceived ${JSON.stringify(payload)}`
      );
      if (
        window.location.pathname.includes('verification') &&
        payload.action === 'SCAN_PASSPORT_RESULT'
      ) {
        if (payload.message.success === true) {
          dispatch(
            cartActions.setIdCardInfo(payload.message.data.idScanResult)
          );
          global?.logger?.info(
            `Age information successfully retrieved from Passport.`
          );
        } else {
          showToast({
            description: 'Unable to Scan Passport this time',
          });
          global?.logger?.error(
            `7POS Application - ageScanPassportError ${JSON.stringify(
              payload.message.data.reason
            )}`
          );
          history.replace('/home');
        }
        return;
      }

      if (
        Object.prototype.hasOwnProperty.call(payload, 'action') ||
        Object.prototype.hasOwnProperty.call(payload, 'mode')
      ) {
        if (typeof payload.message !== 'string') {
          payload.message = '';
        }
        if (payload.action === 'EOS') {
          // getHardTotals();
        }
        const { isDataSyncInProgress } = store.getState().auth;

        if (
          payload?.type === 'SYNC_PROGRESS' &&
          !payload?.meta.isSyncProgress &&
          isDataSyncInProgress
        ) {
          appRestart();
          dispatch(authActions.setRegistrationInvoke(2));
          return;
        }

        if (payload?.type === 'UPDATE_PLU_ITEM_CACHE') {
          global?.Logger?.info(`[7POS UI] - PLU ITEM CACHE UPDATE RECEIVED `);
          const changedData = payload?.meta;
          if (changedData?.length) {
            dispatch(setChangedItems(changedData));
          }
          return;
        }

        if (
          payload.sender === 'localdata' &&
          payload.action === 'notify' &&
          payload.message
        ) {
          // RISPIN-1933 added notification to get new config
          const pattern = [
            'storesetting',
            'storemessage',
            'storeconfiguration',
            'storeprofile',
          ];
          if (payload.message.includes('storeprofile')) {
            // eslint-disable-next-line no-use-before-define
            getStoreProfile(); // #5813 added to refresh new profile data
          } else if (payload.message.includes('lookupcode')) {
            // eslint-disable-next-line no-use-before-define
            getEBTBagFeeExempt(); // seprate lookupcode notification from store configuration
          }
          if (pattern.some(el => payload.message.includes(el))) {
            // eslint-disable-next-line no-use-before-define
            getConfig();
          } else if (payload.message.includes('productlookupfunction')) {
            // eslint-disable-next-line no-use-before-define
            getFunctionSecurityDetails();
          } else if (payload.message.includes('itemrestriction')) {
            // eslint-disable-next-line no-use-before-define
            getItemRestrictionInfo();
            // eslint-disable-next-line no-use-before-define
            getSaleHours();
          } else if (payload.message.includes('keyboardconfig')) {
            global?.Logger?.info(
              `[7POS UI] - KEYBOARD CONFIG UPDATE RECEIVED `
            );
            refreshKeyBoardConfig();
            dispatch(cartActions.setProductLookUpSyn(true));
          }
        }

        try {
          dispatch(notificationsActions.setNotifications(payload));
          // eslint-disable-next-line no-empty
        } catch (error) {}
      }
    }
  };

  const notificationsEvents = () => {
    const { paymentTransactionId } = store.getState()?.cart;
    const notificationsReq = appIntegrationRequest({
      type: 'Notifications',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/7pos/appnotifications',
      {},
      JSON.stringify(notificationsReq)
    );
  };

  const subscribeAppNotifications = () => {
    if (socketStatus === 'CONNECTED') {
      if (!ws.socket) return;
      controlQueue = ws.socket?.subscribe('/7pos/appnotifications', e => {
        onAppNotificationsEvntsReceived(e);
      });
      // retrieve Install remainder from memory any restart app
      let installRemainder = readDataToFile({
        fileName: 'InstallRemainder.json',
      });
      try {
        installRemainder = JSON.parse(installRemainder);
      } catch (error) {
        installRemainder = null;
      }
      if (installRemainder !== null) {
        const { installationData } = installRemainder;
        dispatch(notificationsActions.setNotifications(installationData));
      }
      subscriptionRef.current = subscriptionRef.current || [];
      subscriptionRef.current.push(controlQueue);
    }
  };

  const getDayShift = async () => {
    let response = {};
    try {
      const r = await fetchDayShift({
        correlationID: paymentTransactionId,
      });
      global?.Logger?.info(`[7POS UI] - getDayShift success`);
      response = JSON.parse(r.data.data);
      dispatch(setDayShift(response));
      initializeSafe();
    } catch (e) {
      global?.Logger?.error(`[7POS UI] - getDayShift details Error`);
    }
    // return response;
  };

  const getDeviceInfo = async () => {
    // if (deviceInfo) return;
    let deviceInformation = null;
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const deviceInfoResp = await fetchDeviceInfo({
        correlationID: paymentTransactionId,
      });
      // console.log('deviceInfoResp :', deviceInfoResp);
      deviceInformation = deviceInfoResp.data;
      dispatch(setDeviceInfo(deviceInformation));

      // initializePheripherals();
      global?.Logger?.info(
        `[7POS UI] - getDeviceInfo details success ${JSON.stringify(
          deviceInformation
        )}`
      );
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - getDeviceInfo details Error`);
    }
    if (deviceInformation === null) {
      forceLogoffDataNotSync('Device Information');
    }
  };

  const getCashbackLimit = async () => {
    if (cashBackLimitRef.current) {
      return Promise.resolve(cashBackLimitRef.current);
    }
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const cashbackLimitResp = await fetchCashbackLimit({
        correlationID: paymentTransactionId,
      });
      const cashbackLimitData = JSON.parse(
        JSON.stringify(cashbackLimitResp.data)
      );
      global?.Logger?.info(`[7POS UI] - getCashbackLimit details info`);
      cashBackLimitRef.current = cashbackLimitData;
      return cashBackLimitRef.current;
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - getCashbackLimit details Error`);
      Promise.reject();
    }
  };

  const getStoreProfile = async () => {
    // if (storeProfile) return;
    let storeProfile = null;
    try {
      let { paymentTransactionId } = store.getState()?.cart;
      if (!paymentTransactionId) {
        paymentTransactionId = getCorrelationID();
        dispatch(cartActions.setPaymentTransactionId(paymentTransactionId));
      }
      const response = await fetchStoreProfile({
        correlationID: paymentTransactionId,
      });
      storeProfile = JSON.parse(response.data.data);
      dispatch(setStoreDetails(storeProfile));
      global?.Logger?.info(
        `[7POS UI] Startup at ${moment().format(
          'MM/DD/YYYY - hh:mm:ss'
        )} and POS Version: ${process.env.REACT_APP_VERSION} `
      );
      const iTransactionMessage = {
        CMD: 'StoreProfile',
        Configuration: storeProfile,
        paymentTransactionId,
      };
      SendMessageToCFD(iTransactionMessage);
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - fetchStoreProfile details Error`);
      if (storeProfile === null) {
        forceLogoffDataNotSync('StoreProfile Information');
      }
    } finally {
      dispatch(setLoadingStoreDetails(false));
    }
    // Call after log intialized so that POS can tract the sequence details in logz
    // eslint-disable-next-line  no-use-before-define
    getTranseqId();
  };

  const getItemRestrictionInfo = async () => {
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const response = await fetchItemAgeRestictions({
        correlationID: paymentTransactionId,
      });
      const lookupCodes = JSON.parse(response.data.data);
      dispatch(setLookupCodes(lookupCodes));
      global?.Logger?.info(`[7POS UI] - fetching lookup codes success:`);
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - fetching lookup codes failed:`);
    }
  };

  const getSaleHours = async () => {
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const response = await fetchSaleHours({
        correlationID: paymentTransactionId,
      });
      const parsedData = JSON.parse(response.data.data);
      dispatch(setSaleHoursInfo(parsedData));
      global?.Logger?.info(`[7POS UI] - fetching salehours Success`);
    } catch (error) {
      global?.Logger?.error(`[7POS UI] - fetching salehours failed`);
    }
  };

  const getTranseqId = async () => {
    try {
      const { paymentTransactionId } = store.getState()?.cart;
      const response = await fetchTranseqId({
        correlationID: paymentTransactionId,
      });
      const resp = response?.data?.data;
      let transactionNum = resp?.transactionNumber || '';
      let memberTanseqNum = resp?.memberTanseqID || '';
      // Added transaction Number zero check as well when data get from Dataservice
      if (
        (transactionNum === '' && !transactionNum) ||
        Number(transactionNum) === 0 ||
        isNaN(transactionNum)
      ) {
        transactionNum = '0000';
      }
      dispatch(cartActions.setTransactionId(transactionNum));
      if (
        (memberTanseqNum === '' && !memberTanseqNum) ||
        Number(memberTanseqNum) === 0 ||
        isNaN(memberTanseqNum)
      ) {
        memberTanseqNum = '0000';
      }
      dispatch(cartActions.setMemberTransactionId(memberTanseqNum));
      // retrieve old transaction id from DataService and update new tran in POS APP
      dispatch(cartActions.updateTransactionId());
      // console.log(transactionNum, memberTanseqNum);
      global?.Logger?.info(
        `[7POS UI] - fetching transeq successful ${JSON.stringify(resp)}`
      );
    } catch (error) {
      global?.Logger?.error(
        `[7POS UI] - fetching transeq failed:${JSON.stringify(error)}`
      );
    }
  };

  const [EODEOSNotifyTimeOut, setEODEOSNotifyTimeOut] = useState(null);
  const intiateEODEOS = async EODEOSDetails => {
    if (EODEOSDetails.IntiateEODEOS) {
      clearTimeout(EODEOSNotifyTimeOut);
      global?.Logger?.info(
        `[7POS UI] - ${EODEOSDetails.type} triggered(${EODEOSDetails.eventNumber})`
      );
      try {
        startLoading();
        // Added 1sec timeout make sure before EOD/EOS call hardtotals sync updated latest values.
        setTimeout(() => {
          handleDayOrShiftCloseOnSyncEvent(EODEOSDetails, handleLogout);
          const payload = {
            eventNumber: '',
            type: '',
            IntiateEODEOS: false,
            isCartItemsOnClear: false,
          };
          global?.Logger?.info(`[7POS UI] - Reset EODEOS payload`);
          dispatch(cartActions.setEODEOS(payload));
        }, 1000);
      } catch (error) {
        global.logger.error(
          `[7POS UI] - intiateEODEOS Error ${JSON.stringify(error)}`
        );
      } finally {
        stopLoading();
      }
    }
  };

  useEffect(() => {
    if (EODEOSDetails.IntiateEODEOS && !EODEOSDetails.isCartItemsOnClear) {
      const eodToast = () => {
        const { EODEOSDetails, transactionMemory } = store.getState().cart;
        const MSG = !transactionMemory?.items
          ? `${EODEOSDetails?.type} initiated, Please complete transaction`
          : `${EODEOSDetails?.type} initiated, Please clear transaction from memory`;
        showToast({
          description: MSG,
          position: 'top-left',
        });
        global.logger.info(`[7POS UI] - ${MSG}`);
      };
      eodToast();
      setEODEOSNotifyTimeOut(
        setInterval(() => {
          const {
            cartItems,
            paymentMethod,
            transactionMemory: { items } = {},
            EODEOSDetails,
          } = store.getState().cart;
          const { isAppLogin } = store.getState().auth;
          if (
            (cartItems?.length > 0 || items?.length > 0) &&
            isAppLogin &&
            !paymentMethod
          ) {
            eodToast();
          } else {
            // eslint-disable-next-line no-lonely-if
            if (
              EODEOSDetails?.IntiateEODEOS &&
              EODEOSDetails?.isCartItemsOnClear
            )
              intiateEODEOS(EODEOSDetails);
          }
        }, 10000) // As per discussion #7817 reducethe timer from 30sec/10sec
      );
    } else if (EODEOSDetails?.isCartItemsOnClear) {
      intiateEODEOS(EODEOSDetails);
    } else if (EODEOSNotifyTimeOut) {
      clearTimeout(EODEOSNotifyTimeOut);
    }
  }, [EODEOSDetails?.IntiateEODEOS, EODEOSDetails?.isCartItemsOnClear]);

  const sendFuelPrepayApprovedRequestIfNeeded = paymentResp => {
    const prepayRequestPromise = processPrepayApprovalIfNeeded(paymentResp);
    if (!prepayRequestPromise) {
      return;
    }
    startLoading();
    return prepayRequestPromise
      .then(() => {
        showToast({
          description: Messages.prepay_accepted,
          status: 'success',
          position: 'top-left',
        });
      })
      .catch(async e => {
        showToast({
          description: Messages.prepay_not_accepted,
          position: 'top-left',
        });
        // SCALE-1567 - PREAUTH_CANCEL scenario - timeout - error
        let errorType = 'error';
        if (e.message === Messages.request_failed) errorType = 'error';
        if (e.message === Messages.request_timeout) errorType = 'timeout';
        await cancelFuelRewardInTransaction(errorType);
      })
      .finally(stopLoading);
  };

  const onTransactionComplete = () => {
    processClearSaleIfNeeded();
  };

  const waitOnFuelTransactionComplete = async paymentResp => {
    const { transactionTotal } = getCartMetrics();
    const approvedAmount = paymentResp?.paymentMedia?.payment?.amount * 100;
    const { balanceDue } = store.getState().cart;
    if (Number(balanceDue) > 0) {
      global?.Logger?.info(
        `[Fuel] PREAUTH_SPLIT_PAYMENT_ERROR : ${transactionTotal}, balance : ${balanceDue} Amount Approved : ${approvedAmount}`
      );
      throw new Error('PREAUTH_SPLIT_PAYMENT_ERROR');
    }
    await sendFuelPrepayApprovedRequestIfNeeded?.(paymentResp);
    processClearSaleIfNeeded();
    fuelTransactionRef.current &&
      console.log('[Fuel] Pump communication ended. ');
  };

  const storeSeqAndHardtotals = async () => {
    try {
      // Update tran sequence number once transaction complete
      const {
        paymentTransactionId,
        transactionId,
        allPayments,
      } = store.getState()?.cart;
      let storedSeq = localStorage.getItem('StoreSeqAndHardTotals');
      storedSeq = storedSeq
        ? JSON.parse(storedSeq)
        : { paymentTransactionId: '', status: false, transactionId: '' };
      if (
        storedSeq.paymentTransactionId === paymentTransactionId &&
        storedSeq.status &&
        storedSeq.transactionId === transactionId
      ) {
        global?.Logger?.debug(
          `[7POS UI] - already Posted Hard totals storeSeqAndHardtotals and ${paymentTransactionId}`
        );
        return;
      }
      global?.logger?.info(
        `[7POS UI] - Posting Hard totals from storeSeqAndHardtotals and ${paymentTransactionId} `
      );
      localStorage.setItem(
        'StoreSeqAndHardTotals',
        JSON.stringify({
          paymentTransactionId: paymentTransactionId.toString(),
          status: true,
          transactionId: transactionId.toString(),
        })
      );
      localStorage.setItem('mediaInformation', JSON.stringify(allPayments));
      storeTranSeqNumber({
        transactionId: store.getState()?.cart?.transactionId,
        MembertransactionId: store.getState()?.cart?.MembertransactionId,
        correlationID: paymentTransactionId,
      });
      // #7376 Make sure finalPaymentRequest present before proceed hardtotals update.
      const finalPaymentRequest = localStorage.getItem('finalPaymentRequest');
      if (!finalPaymentRequest) {
        Logger?.error(
          `[7POS UI] - Failed to retrive finalPaymentRequest for the ${paymentTransactionId} `
        );
        return;
      }
      const {
        items,
        member,
        runningTotalTax,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        runningTotal,
      } = store.getState().cart;
      // #6646 running total sending only credit item due to set runningTotalTax zero
      let adjustedRunningTotal = runningTotalTax;
      // #7238 always need to check abs value(refund due case end with negative running total)
      if (runningTotalTax === 0 && Math.abs(runningTotal) > 0) {
        adjustedRunningTotal = Number(runningTotal / 100);
        if (
          taxInfo &&
          taxInfo?.totalTaxAmount > 0 &&
          !isTransactionRefund &&
          !isTransactionVoid
        ) {
          const iTaxAmount = Number(taxInfo?.totalTaxAmount) || 0;
          adjustedRunningTotal += iTaxAmount;
        }
        dispatch(cartActions.setrunningTotalTax(adjustedRunningTotal));
      }
      const { cashBack } = store.getState().socket;
      finalizeHardTotals({
        items,
        member,
        runningTotalTax: adjustedRunningTotal,
        taxBeforeEBTExempt,
        taxInfo,
        taxableBeforeEBTExempt,
        totalCreditAmount,
        totalCreditTax,
        totalCreditCount,
        isTransactionRefund,
        isTransactionVoid,
        cashBack,
      });
      await captureHardTotals();
      const { EODEOSDetails, transactionMemory } = store.getState().cart;
      // #8047 need item length
      if (EODEOSDetails?.IntiateEODEOS && items?.length === 0) {
        if (!transactionMemory?.items) {
          const payload = {
            ...EODEOSDetails,
            isCartItemsOnClear: true,
          };
          global?.logger?.info(
            `[7POS UI] - EOD/EOS are intialised ${JSON.stringify(payload)}`
          );
          dispatch(cartActions.setEODEOS(payload));
        } else {
          if (transactionMemory?.items)
            showToast({
              description: `${EODEOSDetails?.type} initiated, Please Clear Memory Transaction`,
              position: 'top-left',
            });
          global?.logger?.info(
            `[7POS UI] - ${EODEOSDetails?.type} initiated, Please Clear Memory Transaction`
          );
        }
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - Store transaction seq and update Hartotals failed ${JSON.stringify(
          error
        )}`
      );
    }
  };

  const transactionComplete = (isCashTransaction = false) => {
    onTransactionComplete();
    const {
      paymentTransactionId,
      transactionStartTime,
      pinpadPayStartTime,
      isSigCaptureRequired,
    } = store.getState()?.cart;
    const payload = JSON.stringify({
      status: 'COMPLETE',
      signatureRequired: isSigCaptureRequired,
    });
    const transactionCompleteReq = appIntegrationRequest({
      type: 'Transaction',
      isCashTransaction,
      correlationId: paymentTransactionId,
      payload,
    });
    transactionTimeTrack(
      paymentTransactionId,
      transactionStartTime,
      pinpadPayStartTime
    );
    dispatch(cartActions.setTransactionStartTime(''));
    dispatch(cartActions.setPinpadPayStartTime(''));
    ws.socket?.send(
      '/app/transaction',
      {},
      JSON.stringify(transactionCompleteReq)
    );
    dispatch(cartActions.setPOSSystemStatus('CompletedTransaction'));
    storeSeqAndHardtotals();
  };

  // Media Abort Response handling
  const handleMediaAbortTenders = ({ paymentResp, approvedTenderedCount }) => {
    const { transactionStatus } = paymentResp || {};
    const { RealTimePaymentVoidSeq } = store.getState().cart;
    try {
      if (transactionStatus === 'MEDIA_ABORT') {
        global?.logger?.info(`[7POS UI] - Media abort response`);
        const mediaAbortedPayMediaList = paymentResp?.paymentMediaList
          ?.filter(pml => pml.status === 'APPROVED')
          ?.map(pml => ({
            tenderSequenceNumber: pml.tenderSequenceNumber,
          }));
        const mediaAbortedApprovedCount = mediaAbortedPayMediaList?.length || 0;
        const updatedApprovedCount =
          Number(approvedTenderedCount) - Number(mediaAbortedApprovedCount);
        dispatch(cartActions.setapprovedTenderedCount(updatedApprovedCount));
        if (mediaAbortedPayMediaList[0]) {
          // #3394 Added all media abort list
          mediaAbortedPayMediaList.map(media => {
            dispatch(cartActions.setMediaAbortedPaymentList(media));
            return media;
          });
        }
        // Skip real time void payment
        paymentResp?.paymentMediaList
          ?.filter(
            pml =>
              pml.status === 'APPROVED' &&
              pml.tenderSequenceNumber !== RealTimePaymentVoidSeq
          )
          ?.map(pml => {
            dispatch(
              cartActions.setTransactionComments(
                `CHARGE OF ${Math.abs(
                  Number(pml?.payment?.amount)
                )} WAS MEDIA ABORTED`
              )
            );
            return pml;
          });
      }
    } catch (error) {
      global.logger.error(
        `[7POS UI] - handle Media Abort fail from POS ${JSON.stringify(error)}`
      );
    } finally {
      // During media abort intiated loader and reset back
      stopLoading();
    }
  };

  const handleApprove = (
    paymentResp,
    approvedTenderedCount,
    tenderSequenceNumber
  ) => {
    // Setting Payment Media based on the card type.
    fuelTransactionRef.current &&
      setFuelPrepayPaymentMedia({
        mediaNumber: paymentResp?.paymentMedia?.paymentMediaNumber || 1,
        paymentTenderId: paymentResp?.paymentTenderId,
      });
    dispatch(cartActions.setapprovedTenderedCount(approvedTenderedCount + 1));
    dispatch(cartActions.setTenderSequenceNumber(tenderSequenceNumber + 1));

    // POS display message displayed any message sent from PAPI
    const displayMessage = paymentResp?.paymentMedia?.displayMessage;
    if (displayMessage) {
      showToast({
        description: displayMessage,
        status: 'success',
        duration: 3000,
        position: 'top-left',
      });
    }
    dispatch(cartActions.setPaymentDetails(paymentResp)); // Set Payment Details to Store
    dispatch(
      cartActions.updateLineItemTotalFinal({ isResetLineItemTotal: false })
    ); // Update lineItem Final amount.
    handleMediaAbortTenders({
      paymentResp,
      approvedTenderedCount,
    });
    const { cashBack } = store.getState().socket;
    if (cashBack && Number(cashBack) > 0) {
      dispatch(socketActions.setCardStatus(CARD_READ));
    } else {
      dispatch(socketActions.setCardStatus(null));
    }
    const { isTransactionVoid, isTransactionRefund } = store.getState().cart;
    dispatch(cartActions.setDigitalWalletToken(null));
    dispatch(cartActions.setDigitalWalletStatus(false));
    const cardLoad = paymentResp?.loadCardMedia || false;
    if (cardLoad) {
      if (
        !paymentResp?.loadCardMedia?.every(
          card =>
            card?.cardResult?.status === 'APPROVED' ||
            card?.cardResult?.statusCode === 0
        )
      ) {
        history.replace('/payment/loadnotification');
      }
      return;
    }
    // Added to delay executing the listener to wait for Redux Store updates to be done
    const scheduleMe = () => {
      startLoading();
      setTimeout(() => {
        let { balanceDue } = store.getState().cart;
        const { isSigCaptureRequired } = store.getState().cart;
        const {
          paymentHistory,
          allPayments,
          tranTotalDue,
        } = store.getState().cart;
        // #5311 Cross check balanceDue before move to payment screen.
        if (!isTransactionVoid && !isTransactionRefund) {
          // eslint-disable-next-line prefer-destructuring
          balanceDue = getBalanceDue({
            paymentHistory,
            finalTotalPrice: tranTotalDue,
            allPayments,
          }).balanceDue;
          dispatch(cartActions.setBalanceDue(balanceDue));
        }
        if (
          Number(balanceDue) <= 0 ||
          isTransactionVoid ||
          isTransactionRefund
        ) {
          global?.logger?.info(
            `[7POS UI] -  Transaction Complted and Tran Amount:${tranTotalDue}`
          );
          transactionComplete();
          if (isSigCaptureRequired) {
            stopLoading();
            const iTransactionMessage = {
              CMD: 'SignatureCapture',
            };
            SendMessageToCFD(iTransactionMessage);
            dispatch(socketActions.setCardStatus(SIGNATURE_CAPTURE));
            return;
          } else {
            const { cashBack } = store.getState().socket;
            if (cashBack && Number(cashBack) > 0) {
              ws.socket?.send(WSTopics.cashdrawer.open);
              global?.logger?.info(
                `[7POS UI] -  Sent cash drawer open event(handleApprove)`
              );
              setTimeout(() => {
                stopLoading();
                history.replace('/payment/success');
              }, 500);
              return;
            } else {
              stopLoading();
              history.replace('/payment/success');
            }
          }
          return;
        } else {
          global?.logger?.info(
            `[7POS UI] -  Remaining balance for the transaction:${balanceDue}`
          );
        }
        showLoader(false);
        if (paymentResp?.paymentMedia?.paymentMediaType === 'EBTSNAP')
          dispatch(cartActions.setEbtPaymentTendered(true));
        history.replace('/payment');
        // }
      }, 0);
    };
    if (!fuelTransactionRef.current) {
      return scheduleMe();
    }
    console.log('[Fuel] Sending  Auth Approval to Pump if needed..');
    waitOnFuelTransactionComplete(paymentResp)
      .then(scheduleMe)
      .catch(e => console.log(e));
  };

  const handleCardLoadReset = (isNotifyCFD = false) => {
    global?.logger?.info(`[7POS UI] - Card Lookup reset`);
    dispatch(dailpadActions.resetKeypadValue());
    dispatch(cartActions.setCardLoadReset());
    dispatch(socketActions.setCardStatus(null));
    if (isNotifyCFD) {
      const cancelLoadFromPos = true;
      SendMessageToCFD({
        CMD: 'PrepaidLoadConfirm',
        cancelLoadFromPos,
      });
      history.push('/home');
    }
  };

  const [CardLookUpTimeOut, setCardLookUpTimeOut] = useState(null);
  useEffect(() => {
    if (lookupCallProgress === LOAD_REQUEST_INPROGRESS) {
      setCardLookUpTimeOut(
        setTimeout(() => {
          const { tranItemSeqNumber, cartChangeTrial } = store.getState()?.cart;
          const CartTrialPayLoad = buildCartChangeTrial({
            item: {
              name: 'Card LookUp',
              tranItemSeqNumber: tranItemSeqNumber + 1,
            },
            eventType: 'addItemError',
            eventSeq: cartChangeTrial.length,
            eventResult: 'CARD LOAD OFFLINE',
          });
          dispatch(
            cartActions.addToCartChangeTrial({
              CartTrialPayLoad,
              tranItemSeqNumber: tranItemSeqNumber + 1,
            })
          );
          dispatch(cartActions.setNotifyScanStatus('CARD LOAD OFFLINE'));
          global?.logger?.error(`[7POS UI] - Card Lookup timeout`);
          // eslint-disable-next-line no-use-before-define
          cancelPayment();
          handleCardLoadReset(true);
          showLoader(false);
        }, 125000) // TO-DO need to check with Midddleware time out
      );
    } else {
      // showLoader(false);
      clearTimeout(CardLookUpTimeOut);
    }
    return () => {
      clearTimeout(CardLookUpTimeOut);
    };
  }, [lookupCallProgress]);

  const handleCardLoadDeclineForVG = () => {
    try {
      const { loadCardMediaList } = store.getState().cart;
      if (loadCardMediaList) {
        loadCardMediaList?.forEach(requestcard => {
          let cardResult = requestcard?.cardResult;
          cardResult = {
            ...cardResult,
            statusCode: null,
            statusMessage: null,
            status: 'DECLINED',
            hostResponseCode: null,
            hostResponseReason: null,
            reason: ['Load object not found'],
          };
          const updateCard = {
            ...requestcard,
            cardResult,
          };
          dispatch(cartActions.setLoadCardMedia(updateCard));
        });
      }
      showLoader(false);
      dispatch(cartActions.setPaymentMethod('CASH'));
      dispatch(cartActions.setCardLoadStatus('DECLINED'));
      handleCardLoadReset();
      return history.replace('/payment/loadnotification');
    } catch (error) {
      global?.logger?.info(
        `[7POS UI] - handleCardLoadDeclineForVG: ${JSON.stringify(error)}`
      );
    }
  };

  const handleCardLoadCashPaymentResp = (
    responseData,
    paymentTransactionId
  ) => {
    const loadCardMediaWithCash = responseData?.paymentResponse?.loadCardMedia;
    let DeclineMessage = 'Card Load Declined';
    loadCardMediaWithCash?.forEach(card => {
      if (card?.cardResult?.statusCode !== 0) {
        DeclineMessage = card?.cardResult?.statusMessage;
        dispatch(cartActions.setNotifyScanStatus(DeclineMessage));
        global?.logger?.error(
          `${CARD_LOAD_FAIL_LOG}${DeclineMessage}`,
          paymentTransactionId
        );
      }
      if (!card?.cardResult) {
        let cardResult = card?.cardResult;
        cardResult = {
          ...cardResult,
          statusCode: null,
          statusMessage: null,
          status: 'DECLINED',
          hostResponseCode: null,
          hostResponseReason: null,
          reason: ['Load object not found'],
        };
        const updateCard = {
          ...card,
          cardResult,
        };
        dispatch(cartActions.setLoadCardMedia(updateCard));
      } else dispatch(cartActions.setLoadCardMedia(card));
    });
    const { loadCardMediaList } = store.getState().cart;
    // Exceptional scenario when load request and response mismatch
    // POS go through it missing object treat as declined for not
    // until PAPI fix the issue.
    if (
      loadCardMediaList &&
      loadCardMediaWithCash &&
      loadCardMediaWithCash?.length !== loadCardMediaList?.length
    ) {
      loadCardMediaList?.forEach(requestcard => {
        const cardIndex = loadCardMediaWithCash.findIndex(
          card => card.loadRequestId === requestcard.loadRequestId
        );
        if (cardIndex === -1) {
          let cardResult = requestcard?.cardResult;
          cardResult = {
            ...cardResult,
            statusCode: null,
            statusMessage: null,
            status: 'DECLINED',
            hostResponseCode: null,
            hostResponseReason: null,
            reason: ['Load object not found'],
          };
          const updateCard = {
            ...requestcard,
            cardResult,
          };
          dispatch(cartActions.setLoadCardMedia(updateCard));
        }
      });
    }
    if (
      loadCardMediaWithCash?.every(
        card =>
          card?.cardResult?.status === 'APPROVED' ||
          card?.cardResult?.statusCode === 0
      )
    ) {
      dispatch(cartActions.setPaymentMethod('CASH'));
      dispatch(cartActions.setCardLoadStatus('APPROVED'));
      dispatch(cartActions.setCardLoadNotificationStatus(true));
      global?.logger?.info(CARD_LOAD_SUCCESS_LOG, paymentTransactionId);
    }
    if (
      loadCardMediaWithCash?.some(
        card =>
          card?.cardResult?.status === 'DECLINED' ||
          card?.cardResult?.statusCode !== 0
      )
    ) {
      dispatch(cartActions.setPaymentMethod('CASH'));
      dispatch(cartActions.setCardLoadStatus('DECLINED'));
    }
    showLoader(false);
  };

  const handleLookupApprovedResp = async responseData => {
    const itemId =
      responseData.loadCardMedia?.cardDetails?.itemID ||
      responseData.loadCardMedia?.cardDetails?.departmentId;
    const { loadAmount } = store.getState().cart;
    const retailPrice =
      responseData?.loadCardMedia?.loadMessage?.amount || loadAmount;
    const itemTypeID = ITEM_TYPE.CARD_LOAD;
    const sttn = responseData.loadCardMedia?.cardDetails?.sttn;
    // As per PAPI request card load/void and look up call should have different request ID
    const itemSeq = uuidv1().toString(); // responseData.loadCardMedia?.loadRequestId;
    const CardLoadFlag = LOAD_FLG_INSALE;
    const { prepaidAccNumberValue, isTransactionVoid } = store.getState().cart;
    try {
      let Feepayload = null;
      const include711012Tax =
        responseData.loadCardMedia?.cardDetails?.include711012Tax || false;
      dispatch(cartActions.setFinalizePayStatus(true));
      const { paymentTransactionId } = store.getState()?.cart;
      let skipFeeOrFoundFee = true;
      if (
        responseData.loadCardMedia?.cardDetails?.commissionType !== 'E' &&
        responseData.loadCardMedia?.feeDetails
      ) {
        const feeDesc = responseData.loadCardMedia?.cardDetails?.feeDescription;
        const feeData = responseData.loadCardMedia?.feeDetails.filter(
          i => i.feeType === 'TL'
        );
        /* const productCategoryId =
          responseData.loadCardMedia?.cardDetails?.feeDeptNumber; */
        const feeItemID = responseData.loadCardMedia?.cardDetails?.feeItemID;
        try {
          const response = await getItembyUpcApi(
            '',
            feeItemID,
            paymentTransactionId
          );
          const data = response;
          const item = data.length ? data[0] : data;
          global?.logger?.info(`[7POS UI] - fetch Item  Success`);
          const upc = item?.itemUPC?.find(k => k.isDefaultUPC)?.UPC;
          global?.logger?.info(`[7POS UI] - fetch fee Item  Success`);
          Feepayload = {
            ...item,
            itemShortName: feeDesc,
            shortName: feeDesc,
            itemName: feeDesc,
            name: feeDesc,
            upc,
            retailPrice: isTransactionVoid
              ? -feeData[0].feeAmount
              : feeData[0].feeAmount,
            itemTypeID,
            quantity: 1, // #7493 added quantity for card load fee
          };
        } catch (error) {
          skipFeeOrFoundFee = false;
          dispatch(cartActions.setNotifyScanStatus('Fee Item Not Found'));
          global?.logger?.error(
            `[7POS UI] - Failed to fetch Fee Item Info(card lookup):${feeItemID}`
          );
        }
      }
      if (Number(retailPrice) > 0 && skipFeeOrFoundFee) {
        const CardDiscounts = responseData.loadCardMedia?.cardDiscounts;
        const response = await getItembyUpcApi(
          '',
          itemId,
          paymentTransactionId
        );
        const data = response;
        const item = data.length ? data[0] : data;
        global?.logger?.info(`[7POS UI] - fetch Item  Success`);
        const upc = item?.itemUPC?.find(k => k.isDefaultUPC)?.UPC;
        // #6654 replace item descritpion with load description
        const loadDescription =
          responseData.loadCardMedia?.cardDetails?.loadDescription;
        dispatch(
          cartActions.addToCart({
            ...item,
            itemShortName: loadDescription,
            shortName: loadDescription,
            itemName: loadDescription,
            name: loadDescription,
            upc,
            retailPrice,
            itemTypeID,
            sttn,
            itemSeq,
            CardLoadFlag,
            feeDetails: Feepayload || undefined,
            include711012Tax,
            cardDiscounts: CardDiscounts,
            fees: undefined, // make sure linked fee should not part of card load
          })
        );
        let cardMedia = responseData?.loadCardMedia;
        let loadMessage = responseData?.loadCardMedia?.loadMessage;
        if (isTransactionVoid) {
          loadMessage = {
            ...loadMessage,
            activationPin: prepaidAccNumberValue,
          };
        }
        cardMedia = {
          ...cardMedia,
          loadRequestId: itemSeq,
          loadMessage,
        };
        dispatch(cartActions.setLoadCardMedia(cardMedia));
        global?.logger?.info(
          `[7POS UI] - Card Lookup Success:${JSON.stringify(cardMedia)}`
        );
      } else {
        dispatch(cartActions.setNotifyScanStatus('CARD LOOKUP FAILED'));
        global?.logger?.error(
          `[7POS UI] - Card Lookup Failed(amount is missing)`
        );
      }
    } catch (error) {
      dispatch(cartActions.setNotifyScanStatus('Item Not Found'));
      global?.logger?.error(
        `[7POS UI] - Card Lookup Failed:${JSON.stringify(error)}`
      );
    } finally {
      // #8284 card load flag reset at the end of the card look up
      handleCardLoadReset();
      dispatch(cartActions.setFinalizePayStatus(false));
      const cardLookUpReceived = true;
      SendMessageToCFD({
        CMD: 'PrepaidLoadConfirm',
        cardLookUpReceived,
      });
      showLoader(false);
      history.push('/home');
    }
  };

  const handleAllPaymentsDecline = (
    paymentResp,
    tenderSequenceNumber,
    approvedTenderedCount
  ) => {
    // Insuffcient Amount for card payment
    if (
      paymentResp?.paymentMedia?.receiptDetails?.statusCode === 11 &&
      approvedTenderedCount < 4
    ) {
      const CardbalanceAmount =
        paymentResp?.paymentMedia?.receiptDetails?.balanceAmount || 0;
      if (CardbalanceAmount > 0) {
        const RequestedAmount = paymentResp?.paymentMedia?.payment?.amount;
        const RemainingAmount = parseFloat(
          RequestedAmount - CardbalanceAmount
        ).toFixed(2);
        const payload = {
          CardbalanceAmount,
          RequestedAmount,
          RemainingAmount,
        };
        if (!paymentResp?.offlineDecline)
          // #5160/#5866 added offline decline check before increment
          dispatch(
            cartActions.setTenderSequenceNumber(tenderSequenceNumber + 1)
          );
        dispatch(cartActions.setInSufficentCardDetails(payload));
        dispatch(cartActions.setPaymentMethod('INSUFFICIENT_AMOUNT'));
        dispatch(cfdActions.setCurrentFleetPrompt(null));
        dispatch(socketActions.setCardStatus(null));
        showLoader(false);
        dispatch(
          cartActions.setStatusCode(paymentResp?.paymentMedia?.statusCode)
        );
        global?.logger?.info(
          `[7POS UI] - handleAllPaymentsDecline trigger CARD balance amount${CardbalanceAmount} trigger partial auth`
        );
        return;
      } else {
        global?.logger?.info(
          `[7POS UI] - handleAllPaymentsDecline CARD balance amount not found/zero`
        );
      }
    }

    const {
      isTransactionRefund,
      isTransactionVoid,
      taxDeductionAmount,
      isEBTPayment,
      allPayments,
      items,
    } = store.getState().cart;
    const displayMessage =
      paymentResp?.paymentMedia?.displayMessage || 'Declined';
    const mediaAbortTrans =
      paymentResp?.transactionStatus === 'MEDIA_ABORT' || false;
    dispatch(socketActions.setCashBack(null)); // TODO: RISPIN1808 ebt cb cash back,need to test
    if (paymentResp?.paymentMedia?.receiptDetails?.statusCode !== 11) {
      // SVC Insufficient dont set status code
      dispatch(
        cartActions.setStatusCode(paymentResp?.paymentMedia?.statusCode)
      );
    }
    if (!paymentResp?.offlineDecline)
      // #5160/#5866 added offline decline check before increment
      dispatch(cartActions.setTenderSequenceNumber(tenderSequenceNumber + 1));

    if (!mediaAbortTrans)
      dispatch(cartActions.setNotifyScanStatus(displayMessage));
    const { allEbtSnapDecline } = getTenderedDetails({ paymentResp });
    if (allEbtSnapDecline) {
      if (!mediaAbortTrans) {
        global?.logger?.info(
          `[7POS UI] - handleAllPaymentsDecline reset tax deduction.`
        );
        dispatch(cartActions.setEbtPaymentTendered(true));
      }
    } else if (
      // Only EBT tender as first media decline reset the tax
      (Math.abs(Number(taxDeductionAmount)) > 0 || isEBTPayment) &&
      !mediaAbortTrans
    ) {
      global?.logger?.info(
        `[7POS UI] - handleAllPaymentsDecline reset tax deduction.`
      );
      dispatch(cartActions.setEbtPaymentTendered(true));
    }
    // Only one tender allowed in void transaction so any decline reset tax deduction
    if (
      (isTransactionRefund || isTransactionVoid) &&
      (Math.abs(Number(taxDeductionAmount)) > 0 || isEBTPayment) &&
      !mediaAbortTrans
    ) {
      dispatch(cartActions.setEbtPaymentTendered(true));
    }
    if (paymentResp.paymentEntryType === 'SCANNED') {
      dispatch(socketActions.setCardStatus(DECLINE));
      dispatch(cartActions.setDigitalWalletToken(null));
      dispatch(cartActions.setDigitalWalletStatus(false));
    }
    dispatch(socketActions.setCardStatus(null));
    const isCashMediaAborted =
      allPayments.some(
        ap =>
          ap.paymentMediaType === 'CASH' &&
          ap.transactionStatus !== 'CASH_ABORTED'
      ) || false;
    const { allTendersDeclinedFromPapi } = getTenderedDetails({
      paymentResp,
    });
    if (
      allTendersDeclinedFromPapi &&
      !isCashMediaAborted &&
      paymentResp?.transactionStatus === 'MEDIA_ABORT'
    ) {
      dispatch(cartActions.setIsMediaAborted(false));
    }
    const {
      someTendersDeclinedFromPapi,
      declinedFromVanguard,
    } = getTenderedDetails({
      paymentResp,
    });
    if (
      mediaAbortTrans &&
      (allTendersDeclinedFromPapi ||
        someTendersDeclinedFromPapi ||
        declinedFromVanguard)
    ) {
      const chargeReversalFailedList = paymentResp?.paymentMediaList
        ?.filter(pml => pml?.status?.toLowerCase()?.indexOf('declined') > -1)
        ?.map(pml => ({
          tenderSequenceNumber: pml.tenderSequenceNumber,
        }));
      if (chargeReversalFailedList && chargeReversalFailedList[0]) {
        // Added all charge reversal abort list
        chargeReversalFailedList.map(media => {
          dispatch(cartActions.setChargeReversalMediaPaymentList(media));
          return media;
        });
      }
      const { allEbtCbDecline, someEbtCbDecline } = getTenderedDetails({
        paymentResp,
      });
      if (allEbtCbDecline || someEbtCbDecline) {
        const cbAmount = paymentResp?.paymentMediaList
          ?.filter(pml => pml?.paymentMediaType === 'EBTCB')
          .reduce((sum, pml) => sum + Math.abs(pml?.payment?.amount), 0);
        const showEbtCbReversal = true;
        const showChargeReversal = true;
        showLoader(false);
        global?.logger?.info(
          `[7POS UI] - handleAllPaymentsDecline redirect media abort screen for EBTCB`
        );
        history.replace({
          pathname: '/payment/mediaAbort',
          state: { showChargeReversal, showEbtCbReversal, cbAmount },
        });
      } else {
        const cbAmount = 0;
        const showEbtCbReversal = false;
        const showChargeReversal = true;
        showLoader(false);
        global?.logger?.info(
          `[7POS UI] - handleAllPaymentsDecline redirect media abort screen`
        );
        history.replace({
          pathname: '/payment/mediaAbort',
          state: { showChargeReversal, showEbtCbReversal, cbAmount },
        });
      }
    } else {
      global?.logger?.info(
        `[7POS UI] - handleAllPaymentsDecline redirect payment screen`
      );
      showLoader(false);
      // Card load partial approval not allowed so media declined means load not trigger
      if (paymentResp?.loadCardMedia) {
        const list = paymentResp?.loadCardMedia;
        let DeclineMessage = 'Card Load Declined';
        // RISPIN2619 - if all card loads decline with status code 252 than POS redirect media
        // screen to retry the other media.
        if (
          list?.every(
            card => card?.cardResult?.statusCode === PAYMENTDECLINE_INVALIDMEDIA
          )
        ) {
          // As per PAPI request need to generate new loadrequestId for PAYMENTDECLINE_INVALIDMEDIA tender.
          dispatch(cartActions.updateLoadRequestID());
          return history.replace({
            pathname: '/payment',
            search: ``,
          });
        } else {
          // #4696 make sure below execute only card load decline.
          // #7663/#6554 for payment decline case just make sure all card load are declined
          // without any other items then complete the transaction
          Logger?.info(
            `[7POS UI] - POS will complete the transaction only if transaction have only card loads and all are declined `
          );
          if (
            items?.every(item => item.itemTypeID === ITEM_TYPE.CARD_LOAD) && // #7777 corrected flag check for card load only transaction
            list?.every(
              card =>
                card?.cardResult &&
                (card?.cardResult?.status === 'DECLINED' ||
                  card?.cardResult?.statusCode !== 0)
            )
          ) {
            list?.forEach(card => {
              if (
                card?.cardResult?.statusCode &&
                card?.cardResult?.statusCode !== 0
              ) {
                DeclineMessage = card?.cardResult?.statusMessage;
                dispatch(cartActions.setNotifyScanStatus(DeclineMessage));
              }
              // #7973 below code line deleted during code cleanup
              dispatch(cartActions.setLoadCardMedia(card));
            });
            dispatch(cartActions.setCardLoadStatus('DECLINED'));
            handleCardLoadReset();
            return history.replace('/payment/loadnotification');
          }
        }
      }
      return history.replace({
        pathname: '/payment',
        search: ``,
      });
    }
  };

  const handlePartialApproval = (
    paymentResp,
    approvedTenderedCount,
    tenderSequenceNumber
  ) => {
    dispatch(cartActions.setPaymentMethod('PARTIAL_PAYMENT'));
    dispatch(cartActions.setPaymentDetails(paymentResp));
    handleMediaAbortTenders(paymentResp, approvedTenderedCount);
    dispatch(cartActions.setStatusCode(12));
    dispatch(cfdActions.setCurrentFleetPrompt(null));
    dispatch(cartActions.setTenderSequenceNumber(tenderSequenceNumber + 1));
    if (paymentResp?.paymentMedia?.status === 'APPROVED') {
      dispatch(cartActions.setapprovedTenderedCount(approvedTenderedCount + 1));
    }
    global?.logger?.info(
      `[7POS UI] - handlePartialApproval partial payment screen`
    );
  };

  const isEBTTenderPresent = () => {
    const { allPayments, mediaAbortedPaymentList } = store.getState().cart;
    let isEbtSnapPresent = false;
    let isMediaAbort = [];
    allPayments
      ?.filter(pml => pml?.paymentMediaType === 'EBTSNAP')
      ?.map(pml => {
        if (mediaAbortedPaymentList[0]) {
          isMediaAbort = mediaAbortedPaymentList?.filter(
            payment =>
              payment?.tenderSequenceNumber === pml?.tenderSequenceNumber
          );
          if (!isMediaAbort[0]) {
            isEbtSnapPresent = true;
          }
        } else {
          isEbtSnapPresent = true;
        }
        return pml;
      });
    global?.logger?.info(`[7POS UI] - isEBTTenderPresent:${isEbtSnapPresent}`);
    return isEbtSnapPresent;
  };

  const cancelPayment = isMCLoyaltyFlow => {
    const { paymentTransactionId } = store.getState()?.cart;
    let paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    if (isMCLoyaltyFlow && isSpeedyStore) {
      paymentCancelReq = {
        ...paymentCancelReq,
        messageHeader: {
          ...paymentCancelReq.messageHeader,
          messageType: 'LOYALTY_PAYMENT_CANCEL',
        },
      };
    }
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
  };

  useEffect(() => {
    if (!cancelPaymentForMCLoyalty) return;
    cancelPayment(true);
    dispatch(cartActions.setCancelPaymentForMCLoyalty(false));
  }, [cancelPaymentForMCLoyalty]);

  const [paymentTimeout, setPaymentTimeout] = useState(null);
  useEffect(() => {
    if (onlineReqTimerStart) {
      clearTimeout(paymentTimeout);
    }
    if (isPaymentTriggered || onlineReqTimerStart) {
      setOnlineReqTimerStart(false);
      setPaymentTimeout(
        setTimeout(() => {
          if (
            window.location.href.includes('emailReceipt') ||
            window.location.href.includes('success')
          )
            return;
          global?.logger?.info(`[7POS UI] - Payment Timeout`);
          showToast({
            description: `Network Timeout`,
            position: 'top-left',
          });
          cancelPayment();
          dispatch(cartActions.setStatusCode(null));
          dispatch(socketActions.setCashBack(null));
          dispatch(cartActions.setPaymentTriggerStatus(false));
          dispatch(socketActions.setCardStatus(null));
          dispatch(cfdActions.setUserActionScreenActive(false));
          dispatch(notificationsActions.setShowNotifications(true));
          stopLoading();
          // #7369 handling network timeout for Card load + cash flow
          const {
            loadCardMediaList,
            lastTenderedMedia,
          } = store.getState().cart;
          if (!loadCardMediaList?.length > 0)
            dispatch(notificationsActions.setShowNotifications(true));
          if (
            loadCardMediaList?.length > 0 &&
            lastTenderedMedia === 'CASHTENDER'
          ) {
            dispatch(cartActions.setLastTenderInfo(''));
            handleCardLoadDeclineForVG();
          }
        }, 120000)
      );
    } else {
      // console.log('clear payment Timeout...');
      clearTimeout(paymentTimeout);
    }
    return () => {
      clearTimeout(paymentTimeout);
    };
  }, [isPaymentTriggered, onlineReqTimerStart]);

  // Handles Master Card Loyalty response from PAPI
  const handleLoyaltyResponse = async ({
    loyaltyToken,
    statusCode,
    tenderSequenceNumber,
    approvedTenderedCount,
    paymentResponse,
  }) => {
    Logger?.info(`[7POS UI] : MC Loyalty Card Status Code ${statusCode}`);
    const idMapper = {
      287: 'MC_CARD',
      286: 'LOYALTY_ID',
    };
    dispatch(
      cartActions.setPinpadProcessMsg(
        'Loyalty Card swiped, fetching member details'
      )
    );
    showToast({
      description: 'Loyalty Card swiped, fetching member details',
      status: 'success',
      duration: 3000,
    });
    try {
      const { isSpeedyStore } = store.getState().main;
      await getMemberInfo({
        memberId: loyaltyToken,
        dispatch,
        queryParams: { idType: idMapper[statusCode] ?? 'MC_CARD' },
        isMCLoyaltyFlow: true,
        isSpeedyStore,
      });
      dispatch(cartActions.setLoyaltyMasterStatusCode(statusCode));
      // This decides weather to display Master card prompt or no
      dispatch(
        cartActions.setMasterCardLoyaltyPaymentResponse(paymentResponse)
      );
      history.push('/home');
      await waitForGivenTime(0);
      if (statusCode === 287) {
        dispatch(cartActions.setProcessPaymentAsMCLoyalty(true));
        dispatch(cartActions.setIsMasterCardLoyaltyPayment(true));
      }
    } catch (e) {
      Logger.info(
        `[7POS UI] :- MC Loyalty Card Error fetching member info: ${JSON.stringify(
          e
        )}`
      );
      cancelPayment(true);
      handleAllPaymentsDecline(
        paymentResponse,
        tenderSequenceNumber,
        approvedTenderedCount
      );
    }
  };

  const paymentSubscribe = () => {
    if (!ws.socket) return;
    appQueue = ws.socket?.subscribe('/appQueue/paymentResponse', e => {
      const response = JSON.parse(JSON.stringify(e));
      const data = JSON.parse(JSON.stringify(response.body));
      const respData = JSON.parse(data);
      const messageType = respData?.messageHeader?.messageType;
      if (messageType === TRANSACTION_RESPONSE) {
        dispatch(cartActions.setIsTAPITransCompleted(true));
        return;
      }
      const responseData = JSON.parse(respData.messageBody.message);
      global?.logger?.info(
        `[7POS UI] - Payment Response: ${JSON.stringify(responseData)}`
      );
      // const isLoyaltyResponse =
      //   paymentResponse.messageBody.message === 'LOYALTY_RESPONSE';
      const isCashTransaction = responseData?.paymentCallStatus || false;
      const paymentResp = responseData?.paymentResponse;
      // Signature Required set on payment response
      if (paymentResp?.paymentMedia?.payment?.signatureRequired) {
        const isSignatureCaptureRequired =
          paymentResp?.paymentMedia?.payment?.signatureRequired || false;
        dispatch(
          cartActions.setIsSigCaptureRequired(isSignatureCaptureRequired)
        );
      }

      const hostDiscounts = paymentResp?.paymentMedia?.hostDiscounts;
      const {
        approvedTenderedCount,
        tenderSequenceNumber,
        paymentTransactionId,
        isEBTPayment,
        isPaymentTriggered,
        allPayments,
        isMediaAbortTriggered,
        selectedGrade,
      } = store.getState().cart;

      // reset any loader added during payment
      if (isPaymentTriggered) {
        stopLoading();
        setOnlineReqTimerStart(false);
      }
      if (hostDiscounts) {
        dispatch(
          cartActions.setHostDiscount({ data: hostDiscounts, selectedGrade })
        );
        SendMessageToCFD({
          CMD: 'HostDiscount',
          data: hostDiscounts,
          selectedGrade,
        });
      }
      dispatch(cartActions.setPaymentTriggerStatus(false));
      dispatch(cartActions.setStatusCode(null));
      dispatch(cartActions.setInSufficentCardDetails({}));
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(cfdActions.setCurrentFleetPrompt(null));

      // For preauth cancel request - transactionId may not match for request and response.
      // Added explicit condition below to handle
      // #8018 added cash transaction ID check
      if (
        paymentResp?.transactionType !== TransactionTypes.preAuthCancel &&
        ((paymentResp?.transactionId &&
          paymentResp?.transactionId !== paymentTransactionId) ||
          (isCashTransaction &&
            responseData?.transactionId &&
            responseData?.transactionId !== paymentTransactionId))
      ) {
        global?.logger?.info(
          `[7POS UI] - payment Transaction ID mismatch between
           POS transaction ID is ${paymentTransactionId} and 
           received transaction ID is ${paymentResp?.transactionId}`
        );
        stopLoading();
        if (isPaymentTriggered) {
          const isEbtSnapPresent = isEBTTenderPresent() || false;
          if (isEBTPayment && !isEbtSnapPresent) {
            dispatch(cartActions.setTaxBeforeEBTExempt(0));
            dispatch(cartActions.setTaxDeductionAmount(0));
            localStorage.removeItem('taxInfoBeforeEBT');
            dispatch(cartActions.setTaxableBeforeEBTExempt(0));
          }
          dispatch(cartActions.setPaymentMethod(null));
          dispatch(socketActions.setCardStatus(null));
          dispatch(cartActions.setStatusCode(null));
          dispatch(cartActions.setInSufficentCardDetails({}));
          history.replace('/payment');
        }
        return;
      }
      const { channel } = store.getState().main;
      const loyaltyStatus = [286, 287];
      const { paymentMedia: { statusCode, loyaltyToken } = {} } =
        paymentResp || {};
      if (loyaltyStatus.findIndex(status => statusCode === status) !== -1) {
        handleLoyaltyResponse({
          loyaltyToken,
          statusCode,
          paymentResp,
          tenderSequenceNumber,
          approvedTenderedCount,
          paymentResponse: paymentResp,
        });
        return;
      }
      if (!isCashTransaction)
        getDeclinedReceipts(respData, paymentTransactionId, channel);
      const isLoadCashResp =
        (responseData.paymentCallStatus &&
          responseData?.paymentResponse?.loadCardMedia) ||
        false;
      if (isLoadCashResp) {
        handleCardLoadCashPaymentResp(responseData, paymentTransactionId); // Load Cash payment response
      }
      const cardStatusDecline =
        responseData?.loadCardMedia?.cardResult?.status.startsWith('DECLINE') ||
        responseData?.loadCardMedia?.cardResult?.statusCode !== 0 ||
        false;
      if (
        responseData?.transactionType === 'CARD_LOOKUP' &&
        (responseData?.loadCardMedia?.cardResult?.status === 'APPROVED' ||
          responseData?.loadCardMedia?.cardResult?.statusCode === 0)
      ) {
        handleLookupApprovedResp(responseData); // Lookup approval response
      }
      if (
        responseData?.transactionType === 'CARD_LOOKUP' &&
        cardStatusDecline
      ) {
        const { tranItemSeqNumber, cartChangeTrial } = store.getState()?.cart;
        let FailureReason = 'Look up Failed';
        if (responseData?.loadCardMedia?.cardResult?.reason) {
          FailureReason = Array.isArray(
            responseData?.loadCardMedia?.cardResult?.reason
          )
            ? responseData?.loadCardMedia?.cardResult?.reason[0]
            : responseData?.loadCardMedia?.cardResult?.reason;
        }
        const CartTrialPayLoad = buildCartChangeTrial({
          item: {
            name: 'Card LookUp',
            tranItemSeqNumber: tranItemSeqNumber + 1,
          },
          eventType: 'addItemError',
          eventSeq: cartChangeTrial.length,
          eventResult: FailureReason,
        });
        dispatch(
          cartActions.addToCartChangeTrial({
            CartTrialPayLoad,
            tranItemSeqNumber: tranItemSeqNumber + 1,
          })
        );
        const DeclineMessage =
          responseData?.loadCardMedia?.cardResult?.statusMessage ||
          'Card LookUp Failed';
        dispatch(cartActions.setNotifyScanStatus(DeclineMessage));
        // #8120 reset loader for lookup failed case
        stopLoading();
        handleCardLoadReset(true);
      }

      const {
        allTendersDeclinedFromPapi,
        someTendersDeclinedFromPapi,
        declinedFromVanguard,
      } = getTenderedDetails({
        paymentResp,
      });
      const isMediaAbortDecline =
        (paymentResp?.paymentMediaList &&
          paymentResp?.transactionStatus === 'MEDIA_ABORT' &&
          (allTendersDeclinedFromPapi ||
            someTendersDeclinedFromPapi ||
            declinedFromVanguard)) ||
        false;
      if (
        // #7884 added BALANCE_INQUIRY check for skip decline for BI
        paymentResp?.transactionType !== BALANCE_INQUIRY &&
        (paymentResp?.paymentMedia?.status === 'DECLINED' ||
          paymentResp?.paymentMedia?.status?.startsWith(DECLINE) ||
          paymentResp?.paymentMedia?.receiptDetails?.statusMessage?.startsWith(
            DECLINE
          ) ||
          isMediaAbortDecline)
      ) {
        handleAllPaymentsDecline(
          paymentResp,
          tenderSequenceNumber,
          approvedTenderedCount
        );
      }

      // In production eventhough full apptroval getting status code 12 so added balance check as well.
      let isPartialApproved = false;
      if (
        !isCashTransaction &&
        paymentResp?.paymentMedia?.receiptDetails &&
        paymentResp?.paymentMedia?.receiptDetails?.statusCode === 12
      ) {
        // 0a972360-901a-11ed-8a59-4fb889a7203f trancation PAPI charged more and end with status code 12
        const { balanceDue } = store.getState().cart;
        if (Number(balanceDue) > paymentResp?.paymentMedia?.payment?.amount) {
          isPartialApproved = true;
          handlePartialApproval(
            paymentResp,
            approvedTenderedCount,
            tenderSequenceNumber
          );
        }
      }
      if (
        paymentResp?.transactionType === BALANCE_INQUIRY &&
        paymentResp?.paymentMedia?.status === 'APPROVED'
      ) {
        dispatch(cartActions.setPaymentMethod(BALANCE_INQUIRY));
        dispatch(balanceActions.setBalanceInfo(paymentResp));
        transactionComplete();
        dispatch(socketActions.setCardStatus(null));
        history.replace('/home/balance_success');
      } else if (
        paymentResp?.paymentMedia?.status === 'APPROVED' &&
        !isPartialApproved
      ) {
        const list = paymentResp?.loadCardMedia;
        let DeclineMessage = 'Card Load Declined';
        list?.forEach(card => {
          if (card?.cardResult?.statusCode !== 0) {
            DeclineMessage = card?.cardResult?.statusMessage;
            dispatch(cartActions.setNotifyScanStatus(DeclineMessage));
          }
          // Handling #7177 missing cardResult object from PAPI. Need to fix from PAPI
          if (!card?.cardResult) {
            let cardResult = card?.cardResult;
            cardResult = {
              ...cardResult,
              statusCode: null,
              statusMessage: null,
              status: 'DECLINED',
              hostResponseCode: null,
              hostResponseReason: null,
              reason: ['Load object not found'],
            };
            const updateCard = {
              ...card,
              cardResult,
            };
            dispatch(cartActions.setLoadCardMedia(updateCard));
          } else dispatch(cartActions.setLoadCardMedia(card));
        });
        if (list?.some(card => card?.cardResult?.statusCode !== 0)) {
          dispatch(cartActions.setCardLoadStatus('DECLINED'));
          handleCardLoadReset();
        } else if (
          list?.every(
            card =>
              card?.cardResult?.status === 'APPROVED' ||
              card?.cardResult?.statusCode === 0
          )
        ) {
          dispatch(cartActions.setCardLoadStatus('APPROVED'));
          dispatch(cartActions.setCardLoadNotificationStatus(true));
        }
        dispatch(cartActions.setEBTPaymentIntiateStatus(false));
        handleApprove(paymentResp, approvedTenderedCount, tenderSequenceNumber);
      } else if (
        isCashTransaction &&
        !responseData?.paymentResponse?.loadCardMedia
      ) {
        if (pipoRef.current) {
          dispatch(cashFunctionActions.finishPIPOTransaction());
        }
        let { balanceDue } = store.getState().cart;
        const {
          isTransactionVoid,
          isTransactionRefund,
          tranTotalDue,
          paymentHistory,
        } = store.getState().cart;
        // #6259 added recalculate balance due logic before completeion.
        if (!isTransactionVoid && !isTransactionRefund) {
          // eslint-disable-next-line prefer-destructuring
          balanceDue = getBalanceDue({
            paymentHistory,
            finalTotalPrice: tranTotalDue,
            allPayments,
          }).balanceDue;
          dispatch(cartActions.setBalanceDue(balanceDue));
        }
        if (
          Number(balanceDue) <= 0 ||
          isTransactionVoid ||
          isTransactionRefund
        ) {
          global?.logger?.info(
            `[7POS UI] -  Transaction Complted and Tran Amount:${tranTotalDue}`
          );
          transactionComplete(true);
          return;
        } else {
          global?.logger?.info(
            `[7POS UI] -  Remaining balance for the transaction:${balanceDue}`
          );
        }
      } else if (
        paymentResp?.paymentMediaList ||
        paymentResp?.transactionStatus === 'MEDIA_ABORT'
      ) {
        // MediaAbort: any one of the tender decline and rest approve
        const {
          allTendersDeclinedFromPapi,
          someTendersDeclinedFromPapi,
          someEbtSnapDecline,
        } = getTenderedDetails({ paymentResp });
        if (
          (someTendersDeclinedFromPapi && !allTendersDeclinedFromPapi) ||
          !(someTendersDeclinedFromPapi && allTendersDeclinedFromPapi)
        ) {
          const ApprovedMediaAborts = paymentResp?.paymentMediaList?.filter(
            pml => pml?.status === 'APPROVED'
          );
          if (ApprovedMediaAborts)
            dispatch(cartActions.setPaymentMediaList(ApprovedMediaAborts));
          handleMediaAbortTenders({
            paymentResp,
            approvedTenderedCount,
          });
          // #8200 tax deduction clean up for Media Abort Snap approved scenario
          if (someEbtSnapDecline)
            dispatch(cartActions.setEbtPaymentTendered(true));
          // #7071 make sure redirect to home screen for only for Media abort
          if (isMediaAbortTriggered && !someTendersDeclinedFromPapi) {
            setTimeout(() => {
              dispatch(cartActions.setStatusCode(null));
              dispatch(socketActions.setCardStatus(null));
              dispatch(cartActions.setIsMediaAbortTriggered(false));
              dispatch(cartActions.setRealTimePaymentVoidSeq(0));
              history.replace('/home');
            }, 0);
          }
        }
        return;
      } else if (
        // Refactor this code
        paymentResp?.paymentMedia?.status === 'DECLINED' ||
        paymentResp?.paymentMedia?.status?.startsWith(DECLINE)
      ) {
        if (paymentResp?.transactionType === BALANCE_INQUIRY) {
          // #7884 added toast message for BALANCE_INQUIRY
          showToast({
            description:
              paymentResp?.paymentMedia?.displayMessage || 'Declined',
            position: 'top-left',
          });
          storeTranSeqNumber({
            transactionId: store.getState()?.cart?.transactionId,
            MembertransactionId: store.getState()?.cart?.MembertransactionId,
            correlationID: paymentTransactionId,
          });
          dispatch(balanceActions.setBalanceActive(false));
          dispatch(balanceActions.setBalanceInquiryTrigger(false));
          dispatch(socketActions.setCardStatus(BALANCE_INQUIRY_INVALID_CARD));
          transactionComplete();
          return history.push('/home');
        }
        dispatch(cartActions.setDeclinedPaymentDetails(paymentResp));
        if (referenceAttempts >= 2) {
          dispatch(cartActions.resetReferenceAttempts());
          history.push('/home');
        }
      } else if (
        isCashTransaction &&
        responseData?.paymentResponse?.loadCardMedia
      ) {
        if (
          !responseData?.paymentResponse?.loadCardMedia?.every(
            card =>
              card?.cardResult?.status === 'APPROVED' ||
              card?.cardResult?.statusCode === 0
          )
        ) {
          history.replace('/payment/loadnotification');
        }
        return;
      }
      const isPaymentFlow =
        window.location.href.includes('success') ||
        window.location.href.includes('emailReceipt');
      if (isMediaAbortTriggered && !isPaymentFlow) {
        setTimeout(() => {
          dispatch(cartActions.setStatusCode(null));
          dispatch(socketActions.setCardStatus(null));
          dispatch(cartActions.setIsMediaAbortTriggered(false));
          dispatch(cartActions.setRealTimePaymentVoidSeq(0));
          history.replace('/home');
        }, 0);
      }
    });
    subscriptionRef.current = subscriptionRef.current || [];
    subscriptionRef.current.push(appQueue);
  };

  const onPinpadAppEventsReceived = e => {
    // TODO: Refactor and Remove dead code post MVP
    try {
      const { isSigCaptureRequired } = store.getState().cart;
      if (isSigCaptureRequired) return;
      const isBalanceInquiryMode = window.location.pathname.includes('balance');
      const { isBalanceInquiryTrigger } = store.getState()?.balance;
      const response = JSON.parse(JSON.stringify(e));
      const body = JSON.parse(response.body);
      const event = body?.messageBody?.message;
      const messageContent = body?.messageBody?.messageContent;
      const messageHeader = body?.messageHeader;
      const reason = body?.messageBody?.reason;
      let search = `?cardStatus=${event}`;
      const { paymentTransactionId } = store.getState().cart;

      // #6559 restricted trace Age information data in logz
      if (event.includes('{')) {
        const eventInfo = JSON.parse(event);
        const eventCode = eventInfo?.eventCode;
        if (eventCode !== SWIPE_ID_DATA) {
          global?.logger?.info(
            `${APPQUEUE_EVENTS_RECIVED_LOG}${JSON.stringify(
              event
            )},${paymentTransactionId}`
          );
        } else {
          global?.logger?.info(
            `${APPQUEUE_EVENTS_RECIVED_LOG} DL Swiped,${paymentTransactionId}`
          );
        }
      } else {
        global?.logger?.info(
          `${APPQUEUE_EVENTS_RECIVED_LOG}${JSON.stringify(
            e
          )},${paymentTransactionId}`
        );
      }

      // #6222 Display generic toast message from MW
      if (event === 'ERROR') {
        // console.log(messageContent);
        dispatch(cartActions.setNotifyScanStatus(messageContent));
        return;
      }

      const {
        lookupCallProgress,
        loadBarcodeData,
        loadConfirm,
        isDigitalWallet,
        cartItems,
        isEBTPayment,
        CashAmountToBeApplied,
        isPaymentTriggered,
        originalRefAttempt,
      } = store.getState().cart;

      const handlePinpadFails = () => {
        dispatch(cartActions.setStatusCode(null));
        dispatch(cfdActions.setUserActionScreenActive(false));
        dispatch(socketActions.setCashBack(null));
      };
      if (event === ONLINE_REQUEST_TIMER) {
        setOnlineReqTimerStart(true);
        if (originalRefAttempt) {
          search = '';
          dispatch(cartActions.setOriginalRefAttempt(false));
        }
      } else if (isPaymentTriggered && event !== PAYMENT_PROCESS) {
        // Loader should except ONLINE_REQUEST_TIMER for Original Reference Enter
        stopLoading();
      }
      if (event === DEVICE_DISCONNECTED || event === CMD_NOT_AVAILABLE) {
        global?.logger?.info(
          `${PINPAD_DISCONNECTED_LOG} ${event}`,
          paymentTransactionId
        );
        showToast({
          description: `Pinpad Disconnected`,
          position: 'top-left',
        });
        // Pinpad Should not disconnect in middle of transaction,
        // if pinpad getting disconneted POS Navigating back to payment method screen
        handlePinpadFails();
        dispatch(cartActions.setPaymentTriggerStatus(false));
        showLoader(false);
        return;
      }
      if (event === PAYMENT_ERROR || event === 'DECLINE') {
        const toastMsg =
          event === PAYMENT_ERROR
            ? 'Error Processing Payment'
            : 'Payment Declined';
        handlePinpadFails();
        dispatch(cartActions.setPaymentTriggerStatus(false));
        dispatch(cartActions.setNotifyScanStatus(toastMsg));
        dispatch(socketActions.setCardStatus(null));
        search = '';
        showLoader(false);
        // #5969 handling payment error for cash + Card load
        const { loadCardMediaList, lastTenderedMedia } = store.getState().cart;
        if (!loadCardMediaList?.length > 0)
          dispatch(notificationsActions.setShowNotifications(true));
        if (
          loadCardMediaList?.length > 0 &&
          lastTenderedMedia === 'CASHTENDER'
        ) {
          dispatch(cartActions.setLastTenderInfo(''));
          handleCardLoadDeclineForVG();
        }
        return;
      }
      if (event === CAPTURE_HARDTOTALS) {
        // #4445 Added transaction ID check before posting GT
        if (
          messageHeader?.correlationId &&
          messageHeader?.correlationId === paymentTransactionId
        ) {
          storeSeqAndHardtotals();
        }
        return;
      } else if (event === CARD_READ) {
        if (isBalanceInquiryTrigger) {
          dispatch(balanceActions.setBalanceActive(true));
          dispatch(socketActions.setCardStatus(BALANCE_INQUIRY_CARD_READ));
          return;
        }
        // As per our discusiion offline split sequence issue we need start timer after CARD_READ event only.
        setOnlineReqTimerStart(true);
        dispatch(socketActions.setCardStatus(CARD_READ));
      } else if (event === PIN_ENTRY_START) {
        dispatch(
          cartActions.setPinpadProcessMsg(
            'Waiting on Customer to enter PIN at the PINPAD'
          )
        );
        global?.logger?.info(PIN_ENTRY_START_LOG, paymentTransactionId);
      } else if (event === PAYMENT_PROCESS) {
        // As per our discussion during split sequence for Offline MW timer need to reset for PAYMENT_PROCESS
        setOnlineReqTimerStart(true);
        dispatch(cartActions.setPinpadProcessMsg('Processing Request...'));
        global?.logger?.info(PAYMENT_PROCESS_LOG, paymentTransactionId);
      } else if (event === CASHBACK_START) {
        dispatch(
          cartActions.setPinpadProcessMsg(
            'Waiting on Customer to select CASHBACK'
          )
        );
        global?.logger?.info(CASHBACK_START_LOG, paymentTransactionId);
      } else if (event === WAITING_FOR_CARD) {
        setOnlineReqTimerStart(false);
        dispatch(cartActions.setOriginalRefAttempt(false));
        if (isBalanceInquiryMode) {
          dispatch(
            socketActions.setCardStatus(BALANCE_INQUIRY_WAITING_FOR_CARD)
          );
          return;
        }
        dispatch(socketActions.setCardStatus(WAITING_FOR_CARD));
        if (window.location.pathname.includes('cardProcess')) {
          search += '&from=cardProcess';
        }
        if (lookupCallProgress === LOAD_REQUEST_INPROGRESS) {
          history.push({
            pathname: '/payment',
            search,
          });
          return;
        }
      } else if (event === WAITING_FOR_EBT_MANUAL_ENTRY) {
        setOnlineReqTimerStart(false);
        dispatch(cartActions.setOriginalRefAttempt(false));
        dispatch(socketActions.setCardStatus(WAITING_FOR_EBT_MANUAL_ENTRY));
      } else if (event === PROMPT_REFERENCE_NUMBER) {
        dispatch(socketActions.setCardStatus(PROMPT_REFERENCE_NUMBER));
        search = '';
        // TODO: Refund Scenario 3 attempts discussion need to be finalized
        // } else if (event === DECLINED_ORIGINALCARD_NOTFOUND) {
        //   dispatch(socketActions.setCardStatus(DECLINED_ORIGINALCARD_NOTFOUND));
        // } else if (
        //   event === DECLINE &&
        //   messageContent === DECLINED_ORIGINALSALE_NOTFOUND
        // ) {
        //   dispatch(socketActions.setCardStatus(DECLINED_ORIGINALSALE_NOTFOUND));
        //   dispatch(socketActions.incrementOriginalSaleDeclinedCount());
      } else if (event === CASHBACK_RESTRICTION) {
        const products = JSON.parse(messageContent)?.plu?.items;
        if (products?.length > 0) {
          let iRestrictAmount = products?.reduce((sum, item) => {
            if (item?.restricted) return sum + item.lineItemTotalFinal;
            return sum;
          }, 0);
          if (CashAmountToBeApplied > 0) {
            if (iRestrictAmount > CashAmountToBeApplied)
              iRestrictAmount -= CashAmountToBeApplied;
            else iRestrictAmount = 0;
          }
          // console.log('Item restircted Amount:', iRestrictAmount);
          dispatch(cartActions.setCashBackRestictionAmount(iRestrictAmount));
        }
        dispatch(socketActions.setCardStatus(CASHBACK_RESTRICTION));
        // dispatch(cartActions.setPaymentTriggerStatus(false));
        return;
      } else if (event === EBT_ACCOUNT) {
        // Swipe card during balance Inquiry set status as BALANCE_INQUIRY_CARD_READ
        if (isBalanceInquiryTrigger) {
          dispatch(balanceActions.setBalanceActive(true));
          dispatch(socketActions.setCardStatus(BALANCE_INQUIRY_CARD_READ));
        } else {
          if (messageContent === EBTCB) {
            dispatch(socketActions.setCardStatus(EBTCB));
          }
          if (messageContent === EBTSNAP) {
            dispatch(socketActions.setCardStatus(EBTSNAP));
          }
        }
      } else if (
        event === PAYMENT_TERMINATED ||
        event === PAYMENT_CANCEL ||
        event === CANCEL_PINPAD ||
        event === PINPAD_UNAVAILABLE ||
        event === USB_DEVICE_NOT_FOUND
      ) {
        if (
          // #6646 added payment trigger status as well
          // #4610 below code execut only card load timeout/cancel from pinpad
          !isPaymentTriggered &&
          (loadConfirm || lookupCallProgress === LOAD_REQUEST_INPROGRESS)
        ) {
          if ((loadBarcodeData || isDigitalWallet) && event === CANCEL_PINPAD)
            return;
          dispatch(cartActions.setLookUpCallProgress(RESET_REQUEST_STATUS));
          if (event === PAYMENT_TERMINATED) {
            // message display only timeout case
            dispatch(cartActions.setNotifyScanStatus('CARD LOAD OFFLINE'));
          }
          stopLoading();
          handleCardLoadReset(true);
          return history.push('/home');
        }
        // Ignore payment terminate event incase email screen
        if (
          window.location.href.includes('success') ||
          window.location.href.includes('emailReceipt')
        ) {
          Logger.info('Transaction already completed.');
          return;
        }
        const isEbtSnapPresent = isEBTTenderPresent() || false;
        handlePinpadFails();
        if (isEBTPayment) {
          if (!isEbtSnapPresent) {
            dispatch(cartActions.setTaxBeforeEBTExempt(0));
            dispatch(cartActions.setTaxDeductionAmount(0));
            localStorage.removeItem('taxInfoBeforeEBT');
            dispatch(cartActions.setTaxableBeforeEBTExempt(0));
          }
          dispatch(cartActions.setPaymentTriggerStatus(false));
          dispatch(cartActions.setEBTPaymentIntiateStatus(false));
        }
        if (isBalanceInquiryMode) {
          dispatch(balanceActions.setBalanceActive(false));
          dispatch(balanceActions.setBalanceInquiryTrigger(false));
          dispatch(socketActions.setCardStatus(BALANCE_INQUIRY_CANCEL));
          return history.push('/home');
        }

        if (event === CANCEL_PINPAD || event === PAYMENT_TERMINATED) {
          dispatch(cfdActions.setUserActionScreenActive(false));
          if (event === PAYMENT_TERMINATED) {
            dispatch(cartActions.setPaymentTriggerStatus(false));
            dispatch(cartActions.setNotifyScanStatus('PAYMENT TERMINATED'));
          }
        }
        // Checking any card load scan in progress or DW payment intiate before
        // display toast message.
        if (
          (event === CANCEL_PINPAD || event === PAYMENT_CANCEL) &&
          lookupCallProgress !== LOAD_REQUEST_INPROGRESS &&
          !isDigitalWallet &&
          isPaymentTriggered
        ) {
          const { paymentExit } = store.getState().cart;
          const msg = paymentExit
            ? 'Payment cancelled by associate'
            : 'Payment cancelled by user';
          dispatch(cartActions.setPaymentExit(false));
          dispatch(cartActions.setPaymentTriggerStatus(false));
          dispatch(cartActions.setNotifyScanStatus(msg));
        }
        stopLoading(); // #7239 stop loading should be independent
        dispatch(socketActions.setCardStatus(PAYMENT_TERMINATED));
        search = '';
      } else if (event === FLEET) {
        const iTransactionMessage = {
          CMD: 'FleetCard',
          fleetPrompts: messageContent,
          reason,
        };
        SendMessageToCFD(iTransactionMessage);
      } else if (event === FLEET_VOID) {
        if (messageContent) {
          dispatch(
            cartActions.setFleetVoidPrompts({
              messageContent,
              reason,
            })
          );
        }
        search = '';
        dispatch(socketActions.setCardStatus(PROMPT_REFERENCE_NUMBER));
      } else if (event === CARD_LOOKUP_PROMPTS) {
        showLoader(false);
        dispatch(cartActions.setLookUpCallProgress(RESET_REQUEST_STATUS));
        global?.logger?.info(
          `${CARD_LOOKUP_PROMPTS_LOG} ${JSON.stringify(
            messageContent
          )},${paymentTransactionId}`
        );
        const innerMessage = JSON.parse(messageContent);
        if (innerMessage?.accountNumber === null) {
          dispatch(cartActions.setloadPromptRequest(ACCOUNT_NBR_PROMPT));
          history.push({
            pathname: '/home/cardProcess',
            state: {
              type: 'load',
            },
          });
        } else if (
          innerMessage?.activationAmount === null &&
          innerMessage?.minActivationAmount &&
          innerMessage?.maxActivationAmount
        ) {
          dispatch(cartActions.setloadPromptRequest(AMOUNT_RANGE_PROMPT));
          const item = {
            minActivationAmount: innerMessage.minActivationAmount,
            maxActivationAmount: innerMessage.maxActivationAmount,
          };
          history.push({
            pathname: '/home/prepaidCardLookup',
            state: { item },
          });
        } else if (
          innerMessage?.activationAmount !== null &&
          innerMessage?.amountConfirmation === null
        ) {
          dispatch(cartActions.setloadPromptRequest(AMOUNT_CONFIRM_PROMPT));
          history.push({
            pathname: '/home/cardProcess',
            state: {
              type: 'load',
              amount: Number(innerMessage.activationAmount),
            },
          });
        }
        return;
      } else if (event === BAD_SWIPE) {
        showToast({
          description: `Bad read please re-swipe`,
          position: 'top-left',
        });
        const dlSwipeReq = appIntegrationRequest({
          type: 'Dlswipe_Req',
          correlationId: paymentTransactionId,
        });
        ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
        return;
      }
      if (isBalanceInquiryMode) return false;
      // #8258 any card lookup inprogress not going for generic check
      if (lookupCallProgress === LOAD_REQUEST_INPROGRESS) return;
      try {
        if (event.includes('{')) {
          const eventInfo = JSON.parse(event);
          const eventCode = eventInfo?.eventCode;
          const eventData = eventInfo?.eventData;
          if (eventCode === CASHBACK_AMOUNT && eventData !== '0.00') {
            dispatch(socketActions.setCashBack(eventData));
          }
          if (eventCode === SWIPE_ID_DATA) {
            validateAgeInformation(eventData, paymentTransactionId, 'DLSWIPE');
          }
        } else {
          // Checking cart items length or pos is waiting for any card read event before redirect
          // Production observed WAITING_FOR_CARD event during restart so added extra condition before rediect
          // eslint-disable-next-line no-lonely-if
          if (
            ((cartItems?.length > 0 && isPaymentTriggered) ||
              (event === WAITING_FOR_CARD && isPaymentTriggered)) &&
            event !== CASHBACK_RESTRICTION
          ) {
            history.push({
              pathname: '/payment',
              search,
            });
          } else {
            stopLoading(); // #7239 stop loading should be independent
            global?.logger?.error(
              APPQUEUE_EVENTS_ERROR_LOG,
              paymentTransactionId
            );
          }
        }
      } catch (error) {
        stopLoading(); // #7239 stop loading should be independent
        dispatch(cartActions.setPaymentTriggerStatus(false));
        global?.logger?.error(
          `${APPQUEUE_EVENTS_RECIVED_LOG}${JSON.stringify(error)}`
        );
      }
    } catch (error) {
      stopLoading(); // #7239 stop loading should be independent
      dispatch(cartActions.setPaymentTriggerStatus(false));
      global?.logger?.error(
        `${APPQUEUE_EVENTS_RECIVED_LOG}${JSON.stringify(error)}`
      );
    }
  };

  // #7812 added security level check for scan ahead flow for card load
  const cardLoadSecurityPrivileges = (functionName, data) => {
    const isUserHavePermission = isValidUserFunction(functionName);
    if (!isUserHavePermission) {
      dispatch(cartActions.setFunctionSecurityData(data));
      history.push({
        pathname: '/home/functionSecurity',
        triggerFrom: functionName,
        iFunctionName: functionName,
      });
    }
    return isUserHavePermission;
  };

  useEffect(() => {
    if (
      isFunctionSecurityTriggered === 'scanload' &&
      iFunctionSecurityData !== null
    ) {
      dispatch(cartActions.setLoadBarcodeData(iFunctionSecurityData));
      global?.logger?.info(
        `Updated load barcode information: ${JSON.stringify(
          iFunctionSecurityData
        )}`
      );
      dispatch(cartActions.setFunctionSecurityData(null));
      dispatch(cartActions.setFunctionSecurityTriggered(''));
    }
  }, [isFunctionSecurityTriggered]);

  const ValidateBarcodeInfo = async BarcodeData => {
    const {
      tranAgeVerifyInfo,
      items,
      isTransactionVoid,
      cartItems,
      transactionId,
      lookupCallProgress,
      loadBarcodeData,
      paymentTransactionId,
      tranItemSeqNumber,
      cartChangeTrial,
      isTransactionAborted,
      loadConfirm,
      safeDropType,
      isSafeActionInProgress,
      isFinalizeClick,
    } = store.getState()?.cart;

    const { isAppLogin } = store.getState().auth;
    const { isBalanceInquiryTrigger } = store.getState()?.balance;
    const balanceInquiryIsActive =
      window.location.pathname.includes('balance') && isBalanceInquiryTrigger;
    const {
      isTransactionFinalize,
      UserActionScreenActive,
      isItemRedemptionIntiated,
      isSWPIntiated,
    } = store.getState()?.cfd;
    const isCanada =
      store.getState().main?.storeDetails?.address?.country === 'CA';
    // #5968 POS should not accept barcode scan on receipt screen
    // #8259 added ignore scan input during promo  call
    const isRestricScanFlow =
      window.location.href.includes('success') ||
      window.location.href.includes('emailReceipt') ||
      window.location.pathname.includes('prepaidCardMenu') ||
      window.location.pathname.includes('prepaidCardLookup') ||
      window.location.pathname.includes('cardProcess') ||
      window.location.pathname.includes('safeDrop') ||
      window.location.pathname.includes('nonIntegratedSafe') ||
      localStorage.getItem('isMemberPromoTrigger');
    // #7384 blocking scan during safe transaction
    // #8480 Blocking scan during login/logoff cart data sync
    const cartInfo = getStorageItems();
    if (
      !isAppLogin ||
      loading ||
      isTransactionAborted ||
      (lookupCallProgress === LOAD_REQUEST_INPROGRESS && loadBarcodeData) ||
      window.location.pathname.includes('itemPrice') ||
      isRestricScanFlow ||
      safeDropType ||
      isSafeActionInProgress ||
      cartInfo?.cartItems?.length
    ) {
      if (!isAppLogin)
        global?.Logger?.debug(
          `[7POS UI] - Scan not support application logoff state.`
        );
      else if (loading || isTransactionAborted)
        global?.Logger?.debug(
          `[7POS UI] - Scan not support during transaction abort${isTransactionAborted}/cart process${loading}.`
        );
      else if (isRestricScanFlow)
        global?.Logger?.debug(
          `[7POS UI] - Receipt screen should not allowed to scan barcode.`
        );
      else if (isSafeActionInProgress || safeDropType)
        global?.Logger?.debug(`[7POS UI] - Safe transaction inprogress.`);
      else if (cartInfo?.cartItems?.length)
        global?.Logger?.debug(`7POS Application - Cart sync.`);
      else
        global?.Logger?.debug(
          `[7POS UI] - Card lookup in progress and ignore next scan`
        );
      showToast({
        description: `Scan Not Allowed`,
        position: 'top-left',
      });
      return;
    }
    const statusList = ['CD_OPEN_OK', 'CD_IS_OPEN', 'CD_ALARM_ON'];
    const { cashDrawerStatus } = store.getState().socket;
    if (
      statusList.includes(cashDrawerStatus) ||
      window.location.pathname.includes('itemReHeatScreen')
    ) {
      dispatch(cartActions.setNotifyScanStatus('Scan not allowed'));
      if (window.location.pathname.includes('itemReHeatScreen')) return;
      global?.logger?.info(
        `[7POS UI] - Scan is not allowed during cash drawer open(${cashDrawerStatus})`
      );
      return;
    }

    try {
      const { isSpeedyStore } = store.getState().main;
      const barcodeData = isSpeedyStore
        ? getBarcodeData(BarcodeData, '', 'SpeedyStore')
        : getBarcodeData(BarcodeData);
      if (!barcodeData?.id)
        // #6559 filter log not to trace Age barcode information.
        global?.logger?.info(
          `[7POS UI] - Scanned Barcode Info:${JSON.stringify(barcodeData)}`
        );
      if (isTransactionFinalize && !barcodeData.dwStatus) {
        global?.logger?.info(
          `[7POS UI] - Only Wallet Barcode will allowed during payment screen.`
        );
        showToast({
          description:
            !barcodeData.dwStatus && isCanada
              ? 'Location is not enabled for DW'
              : `Item Scan not allowed`,
          position: 'top-left',
        });
        return;
      } else if (isSWPIntiated || isItemRedemptionIntiated) {
        global?.logger?.info(
          `[7POS UI] - Scan not allowed during item redemption..`
        );
        showToast({
          description: `Scan not allowed`,
          position: 'top-left',
        });
        return;
      } else if (
        // #7337 QA pathename will append extra data to compare path name
        (window.location.pathname.includes('CFDNotification') ||
          (UserActionScreenActive &&
            !window?.location?.pathname.includes('/C:/home/group') &&
            !window?.location?.pathname.includes('/C:/home') &&
            !window?.location?.pathname.includes('/home/group') &&
            !window?.location?.pathname.includes('/home')) ||
          isFinalizeClick) &&
        !barcodeData.lid &&
        !window.location.pathname.includes('manualEntry') &&
        !window.location.pathname.includes('verification')
      ) {
        global?.logger?.info(
          `[7POS UI] - Only Member Barcode will allowed during notification screen.`
        );
        showToast({
          description: `Item Scan not allowed`,
          position: 'top-left',
        });
        return;
      }
      if (
        window.location.pathname.includes('manualEntry') ||
        window.location.pathname.includes('verification')
      ) {
        if (!barcodeData.id) {
          global?.logger?.info(
            `[7POS UI] - Only DL scan will allowed during age restriction screen.`
          );
          showToast({
            description: `Item/Member Scan not allowed`,
            position: 'top-left',
          });
          return;
        }
      }
      if (barcodeData?.id) {
        validateAgeInformation(barcodeData.id, paymentTransactionId);
      }
      const { configuration } = store.getState().main;
      const loadAmount = 0;
      const { isError, displayErrorMsg } = isCardLoadsLimitCrossed(
        cartItems,
        configuration,
        loadAmount,
        isTransactionVoid,
        isFuelTransactionInProgress,
        Messages
      );
      // Legacy PNM barcode
      if (barcodeData.isLoadCard && barcodeData.gtin === '') {
        if (
          !balanceInquiryIsActive &&
          !fuelTransactionRef.current &&
          ((loadConfirm &&
            window.location.search ===
              '?cardStatus=WAITING_FOR_CARD&from=cardProcess') ||
            !window.location.pathname.includes('cardProcess'))
        ) {
          if (
            window.location.search ===
            '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
          ) {
            cancelPayment();
          }
          if (isError) {
            dispatch(dailpadActions.resetDailpadState());
            dispatch(cartActions.setNotifyScanStatus(displayErrorMsg));
            handleCardLoadReset(true);
            return;
          }
          const loadBarcode = barcodeData.CardBarcode;
          let isUserHavePermission = true;
          if (
            window.location.search !==
            '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
          )
            isUserHavePermission = cardLoadSecurityPrivileges(
              'scanload',
              loadBarcode
            );
          if (isUserHavePermission)
            dispatch(cartActions.setLoadBarcodeData(loadBarcode));
          else {
            global?.Logger?.debug(`[7POS UI] - Prompt Store Manger input`);
          }
          return;
        } else {
          global?.logger?.info(
            `[7POS UI] - Scan is not allowed balanceInquiry/without amount confirm.`
          );
          showToast({
            description:
              !loadConfirm &&
              window.location.search ===
                '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
                ? `Please confirm load amount at CFD`
                : `Scan not allowed`,
            position: 'top-left',
          });
        }
      } else if (barcodeData.gtin && !barcodeData.isCoupon) {
        const { isItemExpired, iExpireDate } = checkIsItemExpired(barcodeData);
        let itemInfo = null;
        try {
          dispatch(cartActions.setFinalizePayStatus(true));
          const response = await getItembyUpcApi(
            barcodeData.gtin,
            '',
            paymentTransactionId
          );
          global?.logger?.info(`[7POS UI] - getItembyUpcApi successful`);
          itemInfo = response;
          // Identify card load barcode
          if (barcodeData.isLoadCard && itemInfo) {
            const citem = itemInfo.length ? itemInfo[0] : itemInfo;
            const departmentId =
              citem?.category?.id ||
              (
                citem?.PSAGroupInfo?.psaCode +
                citem?.PSAGroupInfo?.catCode +
                citem?.PSAGroupInfo?.subcatCode
              ).toString();
            // Verifiyng card load item belongs to loadable PSA and CAT
            if (
              departmentId.length === 6 && isCanada // for Canada testing added below PSA CAT
                ? departmentId?.toString()?.slice(0, 4) === '3406' ||
                  departmentId?.toString()?.slice(0, 4) === '3408' ||
                  departmentId?.toString()?.slice(0, 4) === '3409' ||
                  departmentId?.toString()?.slice(0, 4) === '3410'
                : departmentId?.toString()?.slice(0, 4) === '3410'
            ) {
              if (
                !balanceInquiryIsActive &&
                !fuelTransactionRef.current &&
                ((loadConfirm &&
                  window.location.search ===
                    '?cardStatus=WAITING_FOR_CARD&from=cardProcess') ||
                  !window.location.pathname.includes('cardProcess'))
              ) {
                if (
                  window.location.search ===
                  '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
                ) {
                  cancelPayment();
                }
                if (isError) {
                  dispatch(dailpadActions.resetDailpadState());
                  dispatch(cartActions.setNotifyScanStatus(displayErrorMsg));
                  handleCardLoadReset(true);
                  dispatch(cartActions.setFinalizePayStatus(false));
                  return;
                }
                // Treat as loadable card otherwise normal Item
                const loadBarcode = barcodeData.CardBarcode;
                let isUserHavePermission = true;
                if (
                  window.location.search !==
                  '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
                )
                  isUserHavePermission = cardLoadSecurityPrivileges(
                    'scanload',
                    loadBarcode
                  );
                if (isUserHavePermission)
                  dispatch(cartActions.setLoadBarcodeData(loadBarcode));
                else {
                  global?.logger?.info(`[7POS UI] - Prompt Store Manger input`);
                }
                dispatch(cartActions.setFinalizePayStatus(false));
                return;
              } else {
                global?.logger?.info(
                  `[7POS UI] - Scan is not allowed balanceInquiry/without amount confirm.`
                );
                showToast({
                  description:
                    !loadConfirm &&
                    window.location.search ===
                      '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
                      ? `Please confirm load amount at CFD`
                      : `Scan not allowed`,
                  position: 'top-left',
                });
                dispatch(cartActions.setFinalizePayStatus(false));
                return;
              }
            }
          }
          if (!isItemExpired) {
            if (
              balanceInquiryIsActive ||
              window.location.search ===
                '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
            ) {
              global?.logger?.info(
                `[7POS UI] - Item scan is not allowed during load/BalanceInquiry screen.`
              );
              showToast({
                description: `Item Scan not allowed`,
                position: 'top-left',
              });
              dispatch(cartActions.setFinalizePayStatus(false));
              return;
            }
            dispatch(cfdActions.setUserActionScreenActive(false));
            if (itemInfo.length > 1) {
              const eligibleLItems = itemInfo?.filter(i => i.retailPrice);
              if (!eligibleLItems.length) {
                throw new Error('Item Not Found');
              }
              if (eligibleLItems.length > 1) {
                dispatch(cartActions.setFinalizePayStatus(false));
                history.push({
                  pathname: '/home/sharedUPC',
                  state: {
                    items: eligibleLItems,
                    extraData: {
                      tranAgeVerifyInfo,
                    },
                  },
                });
                return;
              } else {
                itemInfo = eligibleLItems;
              }
            }
            dispatch(dailpadActions.resetKeypadValue());
            const { lookupCodes, saleHours } = store.getState().main;
            const {
              citem,
              lookup,
              notVerified,
              underAged,
              restrictedHours,
            } = verifyUserId({
              data: itemInfo,
              lookupCodes,
              tranAgeVerifyInfo,
              saleHours,
              cartItems: items,
              storeDetails: store.getState()?.main?.storeDetails,
            });
            const state = {
              item: { ...citem, upc: barcodeData.gtin },
              restriction: lookup,
            };
            if (window.location.pathname.includes('search')) {
              dispatch(cartActions.addToPluScanItem({ itemInfo }));
            } else {
              if (Number(citem.itemRestrictionCode) === 6) {
                if (
                  window?.location?.pathname.includes('verification') ||
                  window?.location?.pathname.includes('manualEntry')
                ) {
                  return;
                }
                // Reheat screen trigger for code 6 items
                history.push({
                  pathname: '/home/itemReHeatScreen',
                  state: { item: citem, upc: barcodeData.gtin },
                });
                return;
              }
              if (fuelTransactionRef.current && citem.negativeSalesFlag) {
                showToast({ description: Messages.invalid_action_fuel });
                dispatch(cartActions.setFinalizePayStatus(false));
                return;
              }
              if (restrictedHours && saleHours) {
                dispatch(cartActions.setRestrictedSale(true));
                return;
              }
              if (underAged) {
                // If Item Reheat already Triggered, Reheat item need to be add to cart first
                if (window?.location?.pathname.includes('itemReHeatScreen')) {
                  return;
                }
                dispatch(cartActions.setFinalizePayStatus(false));
                history.push({
                  pathname: '/home/manualEntry',
                  state: { ...state, underAged: true },
                });
                return;
              }
              if (notVerified) {
                // If Item Reheat already Triggered, Reheat item need to be add to cart first
                if (window?.location?.pathname.includes('itemReHeatScreen')) {
                  return;
                }
                const dlSwipeReq = appIntegrationRequest({
                  type: 'Dlswipe_Req',
                  correlationId: paymentTransactionId,
                });
                ws.socket?.send(
                  '/app/pinpad/swipeId',
                  {},
                  JSON.stringify(dlSwipeReq)
                );
                dispatch(cartActions.setFinalizePayStatus(false));
                history.push({
                  pathname: '/home/verification',
                  state,
                });
                return;
              }
              itemInfo.forEach(item => {
                const upc = item.upc || barcodeData.gtin;
                dispatch(
                  cartActions.addToCart({
                    ...item,
                    requiredAge: citem.requiredAge,
                    upc,
                  })
                );
              });
            }
          }
          dispatch(cartActions.setFinalizePayStatus(false));
        } catch (error) {
          dispatch(cartActions.setFinalizePayStatus(false));
          if (
            balanceInquiryIsActive ||
            window.location.search ===
              '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
          ) {
            global?.logger?.info(
              `[7POS UI] - Item scan is not allowed during load/balanceInquiry screen.`
            );
            showToast({
              description: `Item Scan not allowed`,
              position: 'top-left',
            });
            return;
          }
          // #7280 if scanned barcode belongs to loadable barcode we should not treat as Item not found
          if (barcodeData.isLoadCard)
            showToast({
              description: `Item Not Found`,
              position: 'top-left',
            });
          if (!isItemExpired && !barcodeData.isLoadCard) {
            const item = {
              upc: barcodeData.gtin,
            };
            const isValid = isValidUPC(barcodeData.gtin);
            if (isValid) {
              dispatch(cartActions.setNotifyScanStatus('Item Not Found'));
              history.push({
                pathname: '/home/itemPrice',
                state: { item },
              });
            } else {
              showToast({
                description: `Invalid UPC number. Please check and re-enter.`,
                position: 'top-left',
              });
              global?.logger?.error(
                `[7POS UI] - Invalid UPC number:${barcodeData.gtin}`
              );
            }
          }
          global?.logger?.error(`[7POS UI] - failed to getItemByUPC`);
        }
        if (isItemExpired) {
          if (
            balanceInquiryIsActive ||
            window.location.search ===
              '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
          ) {
            global?.logger?.info(
              `[7POS UI] - Item scan is not allowed during load/balanceInquiry screen.`
            );
            showToast({
              description: `Item Scan not allowed`,
              position: 'top-left',
            });
            return;
          }
          global?.logger?.info(
            `[7POS UI] - Scan item expired  info ${iExpireDate}`
          );
          const citem = itemInfo && (itemInfo.length ? itemInfo[0] : itemInfo);
          const CartTrialPayLoad = buildCartChangeTrial({
            item: {
              name:
                citem?.itemName ||
                citem?.shortName ||
                citem?.name ||
                'Item Not Found',
              tranItemSeqNumber: tranItemSeqNumber + 1,
              itemId: citem?.itemId !== undefined ? citem?.itemId : undefined,
              upc: citem?.upc !== undefined ? citem?.upc : undefined,
            },
            eventType: 'addItemError',
            eventSeq: cartChangeTrial.length,
            eventResult: `itemExpired-${BarcodeData}`,
          });
          dispatch(
            cartActions.addToCartChangeTrial({
              CartTrialPayLoad,
              tranItemSeqNumber: tranItemSeqNumber + 1,
            })
          );
          dispatch(
            cartActions.setNotifyScanStatus(
              'Item is expired and cannot be accepted'
            )
          );
        }
      } else if (barcodeData.lid) {
        const { isSevenRewardsDisable } = store.getState().main;
        if (
          (window.location.search ===
            '?cardStatus=WAITING_FOR_CARD&from=cardProcess' &&
            (!barcodeData.dwStatus || isCanada)) ||
          balanceInquiryIsActive ||
          (window.location.pathname.includes('cardProcess') &&
            !isTransactionFinalize) ||
          isSevenRewardsDisable
        ) {
          global?.logger?.info(
            `[7POS UI] - Member scan is not allowed during load/BalanceInquiry screen.`
          );
          showToast({
            description:
              window.location.pathname.includes('cardProcess') &&
              !isTransactionFinalize
                ? 'Please confirm the amount at CFD'
                : barcodeData.dwStatus && isCanada
                ? 'Location is not enabled for DW'
                : `Member Scan not allowed`,
            position: 'top-left',
          });
          return;
        }
        // cross validate existing member vs scan member before call API
        const { member } = store.getState().cart;
        const isMemberTrigger = localStorage.getItem('isMemberTrigger');
        if (
          !isMemberTrigger &&
          (!member?.loyalty_id || member?.loyalty_id !== barcodeData?.lid)
        ) {
          const MemberTransSeqNum = getMemberTransactionId();
          dispatch(cartActions.setMemberTransactionId(MemberTransSeqNum));
          let iBarcodeInfo = null;
          const barcodeInfo = getBarcodeInformation(
            barcodeData?.MemberBarcode.trim().replace(/ /g, '')
          );
          iBarcodeInfo = barcodeInfo.BarcodeInfo;
          dispatch(cartActions.setMemberBarcodeInfo(iBarcodeInfo));
          const { storeDetails, deviceInfo } = store.getState().main;
          const newRelicRequest = {
            storeProfile: storeDetails,
            terminalID: deviceInfo?.id,
            tranSeq: transactionId,
            dgetranSeq: MemberTransSeqNum,
            MemberBarcodeInfo: iBarcodeInfo,
            MemberID: barcodeData.lid,
          };
          const retValue = await getMemberInfo({
            // commented removing space between barcode and 7rewards required space if present.
            // memberId: barcodeData?.MemberBarcode.trim().replace(/ /g, ''),
            memberId: barcodeData?.MemberBarcode,
            dispatch,
            isActiveMember: member !== null || false,
            newRelicRequest,
            paymentTransactionId,
            ...(isSpeedyStore ? { queryParams: { idType: 'UPC' } } : {}),
            isSpeedyStore,
          });
          // #2896 Display 7rewards error only during main screen not on pinpad payment.
          if (
            !retValue &&
            !isTransactionFinalize &&
            window.location.search !==
              '?cardStatus=WAITING_FOR_CARD&from=cardProcess' &&
            window.location.search !== '?cardStatus=WAITING_FOR_CARD' &&
            !window.location.href.includes('payment')
          ) {
            history.push('/home/7PosAppError');
          }
        }
        if (barcodeData.dwStatus) {
          if (isError && !isTransactionFinalize) {
            dispatch(dailpadActions.resetDailpadState());
            dispatch(cartActions.setNotifyScanStatus(displayErrorMsg));
            handleCardLoadReset(true);
            return;
          }
          dispatch(cartActions.setDigitalWalletStatus(true));
          if (
            window.location.search === '?cardStatus=WAITING_FOR_CARD' ||
            window.location.search ===
              '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
          ) {
            dispatch(
              cartActions.setDigitalWalletToken(barcodeData.digitalWallet.token)
            );
            cancelPayment();
          }
        }
      } else if (barcodeData.isCoupon) {
        if (
          balanceInquiryIsActive ||
          window.location.search ===
            '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
        ) {
          global?.logger?.info(
            `[7POS UI] - Coupon Scan not allowed during load/BalanceInquiry screen.`
          );
          showToast({
            description: `Coupon Scan not allowed`,
            position: 'top-left',
          });
          return;
        }
        if (
          barcodeData.CouponBarcode === undefined ||
          barcodeData.CouponBarcode[0] === '5'
        ) {
          dispatch(
            cartActions.setNotifyScanStatus(
              'Scanned Coupon barcode is not supported Please scan a different barcode if available'
            )
          );
          global?.logger?.info(
            `[7POS UI] - Scanned UPC-A Coupon Barcode and restricted for scan ${BarcodeData}`
          );
          const CartTrialPayLoad = buildCartChangeTrial({
            item: {
              name: 'UPC-A Coupon',
              tranItemSeqNumber: tranItemSeqNumber + 1,
            },
            eventType: 'addItemError',
            eventSeq: cartChangeTrial.length,
            eventResult: `upcACouponNotSupported-${BarcodeData}`,
          });
          dispatch(
            cartActions.addToCartChangeTrial({
              CartTrialPayLoad,
              tranItemSeqNumber: tranItemSeqNumber + 1,
            })
          );
        } else {
          dispatch(cartActions.setGS1CouponBarcode(barcodeData.CouponBarcode));
          dispatch(cartActions.settriggerCouponValidation(true));
        }
      } else {
        errorSound &&
          errorSound.play().catch(e => console.log('Sound error', e));
      }
    } catch (error) {
      if (
        balanceInquiryIsActive ||
        window.location.search ===
          '?cardStatus=WAITING_FOR_CARD&from=cardProcess'
      ) {
        global?.logger?.info(
          `[7POS UI] - Item(error) scan not allowed during load/balanceInquiry screen.`
        );
        showToast({
          description: `Item Scan not allowed`,
          position: 'top-left',
        });
        return;
      }
      dispatch(cartActions.setNotifyScanStatus('Unsupported Barcode'));
      const CartTrialPayLoad = buildCartChangeTrial({
        item: {
          name: 'Unsupported Barcode',
          tranItemSeqNumber: tranItemSeqNumber + 1,
        },
        eventType: 'addItemError',
        eventSeq: cartChangeTrial.length,
        eventResult: `unsupportedBarcode-${BarcodeData}`,
      });
      dispatch(
        cartActions.addToCartChangeTrial({
          CartTrialPayLoad,
          tranItemSeqNumber: tranItemSeqNumber + 1,
        })
      );
      global?.logger?.info(
        `[7POS UI] - Scan Unsupported Barcode  info ${BarcodeData}`
      );
    }
  };

  /*
    Adding useEffect to update the ref to the latest value of pipoTransaction
   */
  useEffect(() => {
    // Always update the ref with the latest pipoTransaction Value
    pipoRef.current = pipoTransaction;
  }, [pipoTransaction]);

  const scannerEventReceived = async e => {
    if (
      history?.location?.pathname?.includes('/home/operatormenu') ||
      history?.location?.pathname?.includes('networkMaintenance') ||
      history?.location?.pathname?.includes('/home/restart')
    )
      return;
    if (history?.location?.state?.disableScan) return;
    scanSound && scanSound.play().catch(e => console.log('Sound error', e));
    try {
      if (isCashFunctionInProgress()) {
        global?.Logger?.debug(
          'Cash Function is in progress scan not allowed..'
        );
        showToast({
          description: Messages.invalid_key,
          position: 'top-left',
        });
        return;
      }
      // global?.logger?.info('Cash Function is not in progress. Proceeding...');
      const response = JSON.parse(JSON.stringify(e));
      const body = JSON.parse(response.body);
      const barcodeString = body?.messageBody?.message;
      // eslint-disable-next-line prefer-const
      let [type, Barcodedata] = barcodeString.split('BARCODE: ');
      global?.logger?.info(`Barcode data type:${type}`);
      if (!Barcodedata) return;
      Barcodedata = Barcodedata.trim();
      dispatch(setScannedBarcodeStatus(true));
      await ValidateBarcodeInfo(Barcodedata);
      dispatch(setScannedBarcodeStatus(false));
    } catch (error) {
      global?.logger?.error(`scannerEventReceived ${JSON.stringify(error)}`);
    }
  };

  const syncServiceEventReceived = async e => {
    try {
      const response = JSON.parse(JSON.stringify(e));
      const body = JSON.parse(response.body);
      global?.logger?.info(
        `[7POS UI] - Sync event from store coordinator ${JSON.stringify(body)}`
      );
      const {
        cartItems,
        transactionMemory,
        EODEOSDetails,
      } = store.getState().cart;
      const { momLockStatus, safeLockStatus } = store.getState().peripheral;
      if (
        body.target === '7pos-app' &&
        body.sender === '7pos-store-coordinator'
      ) {
        if (body?.serviceName === 'MONEY_ORDER') {
          let isMOTransaction = false;
          if (cartItems?.length > 0) {
            isMOTransaction = cartItems?.some(
              item => item.isMoneyOrder === true
            );
          }
          if (isMOTransaction) {
            handleMoneyOrderLockResponse(ws, body, dispatch, cartActions);
          }
          if (momLockStatus === WAITING_FOR_SC_MOM_LOCK_RESPONSE) {
            if (body?.message === 'LOCK_REQUEST_APPROVED')
              dispatch(
                peripheralActions.setMOMLockStatus(SC_MOM_LOCK_ACQUIRED)
              );
            else
              dispatch(peripheralActions.setMOMLockStatus(SC_MOM_LOCK_FAILED));
          }
        } else if (body?.serviceName === 'EOD_EOS') {
          const previousEventID = localStorage.getItem('EODEOSEventID');
          const eventNumber = body.messageDetail.eventId;
          const type = body?.messageDetail?.action;
          if (previousEventID === eventNumber) {
            Logger?.error(
              `[7POS UI] - ${type} already triggered previous eventID:${previousEventID} and received eventID:${eventNumber}`
            );
            if (EODEOSDetails?.IntiateEODEOS) {
              Logger?.info(
                `[7POS UI] - running EOD/EOS details:${JSON.stringify(
                  EODEOSDetails
                )} `
              );
            }
            return;
          }
          localStorage.setItem('EODEOSEventID', eventNumber);
          global?.logger?.info(
            `[7POS UI] - ${type} triggered(${body?.comment})`
          );
          if (cartItems.length === 0 && !transactionMemory?.items) {
            startLoading();
            handleDayOrShiftCloseOnSyncEvent(
              { eventNumber, type },
              handleLogout
            );
            stopLoading();
          }
          if (cartItems.length > 0 || transactionMemory?.items?.length > 0) {
            global?.Logger?.debug(`[7POS UI] - Active transaction at the POS`);
            const payload = {
              eventNumber,
              type,
              IntiateEODEOS: true,
              isCartItemsOnClear: false,
            };
            global?.logger?.info(
              `[7POS UI] - EOD/EOS are intialized ${JSON.stringify(payload)}`
            );
            dispatch(cartActions.setEODEOS(payload));
          }
        } else if (
          body?.serviceName === 'SAFE' &&
          safeLockStatus === WAITING_FOR_SC_SAFE_LOCK_RESPONSE
        ) {
          if (body?.message === 'LOCK_REQUEST_APPROVED')
            dispatch(
              peripheralActions.setSafeLockStatus(SC_SAFE_LOCK_ACQUIRED)
            );
          else
            dispatch(peripheralActions.setSafeLockStatus(SC_SAFE_LOCK_FAILED));
        }
      }
    } catch (error) {
      global?.logger?.error(
        `[7POS UI] - syncServiceEventReceived ${JSON.stringify(error)}`
      );
    }
  };

  // Pinpad CQ handling globally
  const onPinpadControlQueueEvents = e => {
    global?.logger?.info(
      `[7POS UI] - onPinpadControlQueueEvents: ${JSON.stringify(
        e.body
      )},${paymentTransactionId}`
    );
    // Handling pinppad activity during payment and display message
    const { isPaymentTriggered } = store.getState().cart;
    if (isPaymentTriggered) {
      const { message } = JSON.parse(e.body)?.messageBody;
      if (
        message === DEVICE_DISCONNECTED ||
        message === CMD_NOT_AVAILABLE ||
        message === PINPAD_UNAVAILABLE ||
        message === USB_DEVICE_NOT_FOUND
      ) {
        showToast({
          description: 'Please check the pinpad connection',
          position: 'top-left',
        });
        stopLoading();
      }
    }
    pinpadControlQueueListener(e);
  };

  const subscribeScanner = () => {
    if (socketStatus === 'CONNECTED') {
      if (!ws.socket) return;
      controlQueue = ws.socket?.subscribe('/controlQueue/scanner', e => {
        scannerEventReceived(e);
      });
      const appQueue = ws.socket?.subscribe(
        '/appQueue/pinpad',
        onPinpadAppEventsReceived
      );
      // Pinpad control queue subscribe
      const cq = ws.socket?.subscribe(
        '/controlQueue/pinpad',
        onPinpadControlQueueEvents
      );
      subscriptionRef.current = subscriptionRef.current || [];
      subscriptionRef.current.push(controlQueue);
      subscriptionRef.current.push(appQueue);
      subscriptionRef.current.push(cq);
    }
  };

  const subscribeSyncService = () => {
    if (socketStatus === 'CONNECTED') {
      if (!ws.socket) return;
      controlQueue = ws.socket?.subscribe('/7pos/sync-service', e => {
        syncServiceEventReceived(e);
      });
      subscriptionRef.current.push(controlQueue);
    }
  };

  const initializePheripherals = () => {
    // Check for ==> Websocket connection
    if (!isConnected) {
      console.log('No Socket ');
      return;
    }
    // ws.socket?.send("/controlQue/pinpad");
    getCashbackLimit().then(() => pinpadIntialize());
    scannerInitialize();
    cashDrawerEvents();
    paymentSubscribe();
    subscribeScanner();
    subscribeAppNotifications();
    subscribeSyncService();
    subscribeSafeEvents();
    // FuelIntialize();
    // FuelSubcribe();
    notificationsEvents();
    MoneyOrderIntialize();
    getDayShift();
    dispatch(cartActions.setPaymentTriggerStatus(false));
  };

  useEffect(() => {
    window.addEventListener('beforeunload', onApplicationExit);
    return () => {
      window.removeEventListener('beforeunload', onApplicationExit);
    };
  }, []);

  // useEffect(() => {
  //   if (RegistrationInvoke === 1) {
  //     dispatch(authActions.setRegistrationInvoke(2));
  //   }
  // }, [RegistrationInvoke]);

  useEffect(() => {
    if (RegistrationInvoke === 2) {
      // console.log('Getting Config information...', RegistrationInvoke);
      dispatch(authActions.setRegistrationInvoke(0));
      getStoreProfile();
      getConfig();
      getEBTBagFeeExempt();
      getItemRestrictionInfo();
      getSaleHours();
      getCashbackLimit();
      getDeviceInfo();
      getFunctionSecurityDetails();
      // unsubscribe current Middleware channels and subscribe again.
      onApplicationExit(true);
      initializePheripherals();
      // Setting isDataSyncInProgress flag in SignIn.js
      if (isDataSyncInProgress) {
        history.push('/home');
        dispatch(authActions.setIsDataSyncInProgress(false));
        const { paymentTransactionId } = store.getState().cart;
        updateDeviceRegistrationStatus({ correlationId: paymentTransactionId });
      }
    }
  }, [RegistrationInvoke, isDataSyncInProgress]);

  const cleanUpSubs = () => {
    global?.logger?.info(
      `Cleaning Existing SUBS:----`,
      subscriptionRef?.current?.length
    );
    clearSafeSubs();
    subscriptionRef.current.forEach(e => e.unsubscribe());
    subscriptionRef.current = [];
    appQueue?.unsubscribe();
    // eslint-disable-next-line no-unused-expressions
    controlQueue?.unsubscribe();
  };

  useEffect(() => {
    if (isDisconnected) {
      global?.logger?.info(`Web Socket connection Failure`);
      cleanUpSubs();
    }
    // console.log('Getting Config information...', socketStatus);
    getStoreProfile();
    getConfig();
    getEBTBagFeeExempt();
    getItemRestrictionInfo();
    getSaleHours();
    getCashbackLimit();
    getDeviceInfo();
    getFunctionSecurityDetails();
    initializePheripherals();
    // Tets
    return () => {
      cleanUpSubs();
    };
  }, [isConnected, isDisconnected]);

  // #8363 schedule pinpad reset implementaion
  const { pinPadResetTimer } = useSelector(state => ({
    pinPadResetTimer: state.main.pinPadResetTimer,
  }));
  const [pinpadResetTimeOut, setPinpadResetTimeOut] = useState(null);

  useEffect(() => {
    if (pinPadResetTimer !== '') {
      setPinpadResetTimeOut(
        setInterval(() => {
          const timerInSec =
            parseInt(Math.abs(new Date() - pinPadResetTimer) / 1000, 10) || 0;
          if (timerInSec !== 0) {
            if (
              timerInSec / 60 > 0 &&
              timerInSec / 60 >= 2 &&
              timerInSec / 60 <= 7
            ) {
              dispatch(setDisablePinpadForReset(true));
              Logger.info(
                `PinPad disabled due to schedule pinpad reset: ${timerInSec /
                  60}`
              );
            } else if (timerInSec / 60 > 7) {
              dispatch(setDisablePinpadForReset(false));
              dispatch(setpinpadResetRemainderTimer(''));
              clearTimeout(pinpadResetTimeOut);
            }
          }
        }, 5000)
      );
    } else {
      dispatch(setDisablePinpadForReset(false));
      dispatch(setpinpadResetRemainderTimer(''));
      clearTimeout(pinpadResetTimeOut);
    }
    return () => {
      clearTimeout(pinpadResetTimeOut);
    };
  }, [pinPadResetTimer]);

  useInterval(() => {
    SendMessageToApp('Uptime');
  }, 10000 * 6 * 5);

  useEffect(() => {
    // TODO: Temp fix for global logger error
    global.logger = {
      info: () => {},
      error: () => {},
    };
    // Async message handler
    // window.ipcRenderer?.on('TOPOS', (event, arg) => {
    electron.ipcRenderer.on('TOPOS', (event, arg) => {
      let newRelicRequest = null;
      if (arg.CMD === 'Uptime') {
        // Soft application relaunch after 5hrs and system is idle and no active transaction.
        const { isAppLogin } = store.getState().auth;
        const { cartItems } = store.getState().cart;
        const { pinPadResetTimer } = store.getState().main;
        const {
          installTimer,
          receivedInstallNotification,
        } = store.getState().notifications;
        const installationInprogress =
          (installTimer === 0 && receivedInstallNotification) || false;
        const triggeredEODEOS =
          localStorage.getItem('triggeredEODEOS') || false;
        const autoRebootTimeOut =
          localStorage.getItem('rebootTimeout') || 3 * 60 * 60;
        if (
          !isAppLogin &&
          cartItems?.length === 0 &&
          arg.UpTime >= autoRebootTimeOut &&
          !triggeredEODEOS &&
          !installationInprogress &&
          pinPadResetTimer !== ''
        ) {
          if (autoRebootTimeOut) {
            localStorage.removeItem('rebootTimeout');
            global?.logger?.info(`[7POS UI] - Autorestart after 3.5 hours`);
          } else global?.logger?.info(`[7POS UI] - Autorestart after 3 hours`);
          onApplicationExit(false, 'Autorestart');
          SendMessageToApp('Restart');
        }
      }
      if (arg.CMD === 'AltID' || arg.CMD === 'AddMember') {
        const { transactionId, MembertransactionId } = store.getState().cart;
        const { storeDetails, deviceInfo } = store.getState().main;
        const iBarcodeInfo = {
          BarCodeVersion: '000',
          BarCodeParam1: arg.CMD === 'AddMember' ? 'J' : 'P',
          BarCodeParam2: 'NULL',
          BarCodeParam3: 'NULL',
          BarCodeParam4: 'NULL',
          BarCodeParam5: 'NULL',
          BarCodeParam6: 'NULL',
        };
        dispatch(cartActions.setMemberBarcodeInfo(iBarcodeInfo));
        newRelicRequest = {
          storeProfile: storeDetails,
          terminalID: deviceInfo?.id,
          tranSeq: transactionId,
          dgetranSeq: MembertransactionId,
          MemberBarcodeInfo: iBarcodeInfo,
        };
      }
      const { paymentTransactionId } = store.getState().cart;
      const { isSpeedyStore } = store.getState().main;
      CFDMessageHandler(
        arg,
        dispatch,
        newRelicRequest,
        paymentTransactionId,
        isSpeedyStore
      );
    });
  }, []);

  const { isSafeReady } = store.getState().peripheral;

  if (history.location.pathname.includes('index.html')) {
    global?.logger?.info(history.location.pathname);
  }

  return (
    <AppContext.Provider
      value={{
        showLoader,
        keyPressSound,
        errorSound,
        successSound,
        stopLoading,
        startLoading,
        showToast,
        showInvalidKeySelection,
        transHoldTimer, // Strictly for TransHold DO NOT ASSIGN ANYTHING TO IT's CURRENT
        safeOflineTimer,
        isSafeReady,
        setCashDrawerLayovr,
        isSpeedyStore,
        authConfirmNotifySound,
      }}
    >
      <FuelSubscription />
      <IdleTimerContainer config={configuration} logout={handleLogout}>
        <div className="App">
          <Box className="main" shadow="md">
            <Switch>
              <Route path="/" component={LoginPage} exact />
              <Route path="/home">
                <Home appRestart={appRestart} />
              </Route>
              <Route path="/payment" component={Payment} />
              <Route path="/fuel" component={Fuel} />
              <Route render={() => <Redirect to="/" />} />
            </Switch>
          </Box>
          {loading && <FullPageLoader />}
          {cashDrwrLayover && (
            <Box
              className="app-layover"
              onClick={() =>
                showToast({ description: 'Please close Cash Drawer' })
              }
            />
          )}
        </div>
      </IdleTimerContainer>
    </AppContext.Provider>
  );
};
export default App;
