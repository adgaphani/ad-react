import React, { useState } from 'react';
import { useSelector } from 'react-redux';

import { AutoRegistation } from './components/Common/Registration';
import App from './App';
import POSRISTheme from './theme/ThemeProvider';

export const AppWrapper = () => {
  const [isAutoRegistered, setIsAutoRegistered] = useState(false);
  const { isSpeedyStore } = useSelector(state => ({
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  return (
    <POSRISTheme isSpeedyStore={isSpeedyStore}>
      {isAutoRegistered && <App />}
      {!isAutoRegistered && (
        <AutoRegistation
          isSpeedyStore={isSpeedyStore}
          setRegistered={f => {
            setIsAutoRegistered(f);
          }}
        />
      )}
    </POSRISTheme>
  );
};
