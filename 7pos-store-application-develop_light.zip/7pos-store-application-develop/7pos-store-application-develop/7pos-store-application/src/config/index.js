export const departmentMap = {
  carwash: '67',
};
