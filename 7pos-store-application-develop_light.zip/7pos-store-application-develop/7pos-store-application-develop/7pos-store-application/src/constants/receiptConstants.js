export const cdbConstants = {
  cdbReceiptBanner: '**  CASH DRAWER  **',
  cdbReceiptHeader1: 'CASH DRAWER BALANCE',
  cdbReceiptHeader2: 'OPERATOR #',
};
