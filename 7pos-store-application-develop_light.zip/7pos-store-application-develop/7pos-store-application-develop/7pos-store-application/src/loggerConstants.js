// Pinpad Events

// appQueue Logs
export const APPQUEUE_EVENTS_RECIVED_LOG =
  '[7POS UI] - onPinpadAppEventsReceived:';
export const APPQUEUE_EVENTS_ERROR_LOG =
  '[7POS UI] - onPinpadAppEventsReceived generic error event';
export const PINPAD_DISCONNECTED_LOG =
  '[7POS UI] - Pinpad Disconnected, Reason Event:';
export const PINPAD_TIMEOUT_LOG = '[7POS UI] - Pinpad Timeout';
export const PIN_ENTRY_START_LOG = '[7POS UI] - PIN entry start from Pinpad';
export const CASHBACK_START_LOG = '[7POS UI] - Cashback start from Pinpad';
export const PIN_ENTRY_END_LOG = '[7POS UI] - PIN entry Completed from Pinpad';
export const PAYMENT_PROCESS_LOG =
  '[7POS UI] - PAYMENT_PROCESS receieved from Pinpad';

// Payment Subscribe Logs
// Card Loads Logs
export const CARD_LOOKUP_PROMPTS_LOG = '[7POS UI] - Card Lookup prompts';
export const CARD_LOAD_SUCCESS_LOG = '[7POS UI] - Card Load Success';
export const CARD_LOAD_FAIL_LOG = '[7POS UI] - Card Load Failed:';
