/* eslint-disable react/prop-types */
/* eslint-disable react/destructuring-assignment */

import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';

import React from 'react';
import { Button } from '../../Common/Buttons';
import Styles from './ConfirmModal.module.css';
import { debounceMe } from '../../../Utils/appUtils';

function ConfirmModal(props) {
  const { onYes, onRetry } = props;
  return (
    <Modal
      closeOnOverlayClick={false}
      isOpen={props.isOpen}
      onClose={props.onClose}
    >
      <ModalOverlay className={Styles.modalOverlay} onClose={props.onClose} />
      <ModalContent className={Styles.modalContainer}>
        <ModalHeader className={Styles.modalHeader}>
          <Text
            color="rgb(44, 47, 53)"
            fontSize="28px"
            fontFamily="Roboto-Bold"
            fontWeight="bold"
            lineHeight="30px"
            textAlign="center"
          >
            {props.header}
          </Text>
        </ModalHeader>
        <ModalBody className={Styles.modalBody} mx="30px">
          <Text
            color="rgb(44, 47, 53)"
            fontSize="20px"
            fontFamily="Roboto-Regular"
            fontWeight="normal"
            lineHeight="28px"
            textAlign="left"
          >
            {props.body}
          </Text>
          {props.children}
        </ModalBody>
        <ModalFooter justifyContent="center" marginBottom="40px" padding="0px">
          {props.showCancelButton && (
            <Button
              className={Styles.cancelButton}
              width={props.showRetryButton ? '150px' : '200px'}
              onClick={debounceMe({ cb: props.onClose })}
            >
              <Text
                fontSize="18px"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
                textAlign="center"
              >
                {props.cancelText ? props.cancelText : 'NO'}
              </Text>
            </Button>
          )}
          {props.showRetryButton && (
            <Button
              className={Styles.retryButton}
              width="100px"
              onClick={debounceMe({ cb: onRetry })}
            >
              <Text
                fontSize="18px"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
                textAlign="center"
              >
                {props.RetryText ? props.RetryText : 'RETRY'}
              </Text>
            </Button>
          )}
          <Button
            className={Styles.okButton}
            width={props.showRetryButton ? '150px' : '200px'}
            onClick={debounceMe({ cb: onYes })}
            isDisabled={props.disable}
          >
            <Text
              fontSize="18px"
              fontFamily="Roboto-Bold"
              fontWeight="bold"
              textAlign="center"
            >
              {props.confirmText ? props.confirmText : 'OK'}
            </Text>
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default ConfirmModal;
