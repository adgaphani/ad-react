export const heartBeat = {
  body: JSON.stringify({
    messageBody: {
      message: {
        status: 'safeHeartbeat',
      },
    },
  }),
};
export const suc = {
  body: JSON.stringify({
    messageBody: {
      message: {
        status: 'SafeServerStatusGood',
        responseAmount: [
          {
            currencyCode: 'USD',
            amount: '1000',
          },
        ],
      },
    },
  }),
};
export const ofline = {
  body: JSON.stringify({
    messageBody: {
      message: {
        status: 'safeOffline',
        responseAmount: [
          {
            currencyCode: 'USD',
            amount: '1000',
          },
        ],
      },
    },
  }),
};
