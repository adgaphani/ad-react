import React from 'react';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import { Text, Grid, Flex, Box } from '@chakra-ui/react';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import { Button } from '../../Common/Buttons';
import Icon_WARNING from '../../../Icons/Icon_Warning.svg';
import { safeDrop } from '../../../constants';
import { SPayment } from './ofline';
import { useSafe } from '../../../hooks';
import { VaultEnvelop } from './ofline/VaultEnvelop';

export const SafeOfline = ({ onExit }) => {
  const { path } = useRouteMatch();
  const {
    onOflineValueEnter,
    safeDropType,
    onSafePaymentSelect,
    isVault,
    vaultUserEntries,
  } = useSafe();
  console.log(path, '++++++++++++');
  return (
    <>
      <Grid templateColumns="50% 50%" width="100%">
        <Box marginLeft="7px" pr="0.5rem">
          <Keypad
            onEnter={onOflineValueEnter}
            {...(isVault && vaultUserEntries.amount ? { max: 4 } : {})}
          />
        </Box>
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex
              h="100%"
              flexDirection="column"
              justifyContent="space-between"
              bg="rgb(255, 255, 255)"
              mr="0.5rem"
              alignItems="center"
            >
              <Flex flexDirection="column" mt={150}>
                <img src={Icon_WARNING} alt="" />
                <Text
                  color="rgb(44, 47, 53)"
                  fontFamily="Roboto-Regular"
                  fontSize="16px"
                  fontWeight="bold"
                  mx="2.5rem"
                  my={2}
                  textAlign="center"
                >
                  Safe is Offline.
                </Text>
                {safeDropType && (
                  <Text
                    color="rgb(44, 47, 53)"
                    fontFamily="Roboto-Regular"
                    fontSize="16px"
                    fontWeight="bold"
                    mx="2.5rem"
                    textAlign="center"
                  >
                    {safeDrop[safeDropType]?.label} at Safe
                  </Text>
                )}
              </Flex>
              <Box display="block" textAlign="right" p="1rem" w="100%">
                <Button
                  onClick={() => onOflineValueEnter()}
                  className="btn primaryButton"
                  _hover={{ bg: '#107f62' }}
                >
                  <Text
                    color="rgb(255, 255, 255)"
                    fontSize="18px"
                    fontWeight="bold"
                    textAlign="center"
                    fontFamily="Roboto-Bold"
                  >
                    {' '}
                    Continue
                  </Text>
                </Button>
              </Box>
            </Flex>
          </Route>
          <Route path={`${path}/payment`}>
            <SPayment
              onExit={onExit}
              onSafePaymentSelect={onSafePaymentSelect}
            />
          </Route>
          <Route path={`${path}/envelop`}>
            <VaultEnvelop onExit={onExit} />
          </Route>
        </Switch>
      </Grid>
    </>
  );
};
