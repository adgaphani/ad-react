import { Heading, Flex } from '@chakra-ui/react';
import React from 'react';
import { useSelector } from 'react-redux';

import { safeDrop } from '../../../constants';
import { SideContainer } from '../../Common/Containers';
import { useSafe } from '../../../hooks';

const icon = require('../../../Icons/localresources/icon-safe.svg');

export const StartSafe = () => {
  const { safeDropType } = useSelector(state => ({
    safeDropType: state.cart.safeDropType,
  }));
  const { handleAbortSafe, isVault } = useSafe();
  const props = !isVault
    ? {
        onExit: handleAbortSafe,
      }
    : {};
  const msg = isVault
    ? `Proceed to Safe and ${safeDrop[safeDropType]?.label}`
    : `Proceed to Safe and ${safeDrop[safeDropType]?.label} or Press "EXIT" to Abort Transaction`;
  return (
    <SideContainer {...props}>
      <Flex flexDirection="column" pt="25%" alignItems="center">
        <img src={icon} alt="safeProcessLogo" width="100px" />
        <Heading
          textAlign="center"
          justifyContent="center"
          fontSize="24px"
          mt={46}
          mx={75}
        >
          {msg}
        </Heading>
      </Flex>
    </SideContainer>
  );
};
