import React from 'react';

import { Flex } from '@chakra-ui/react';
import { SideContainer } from '../../Common/Containers';
import { Processing } from '../../Common/Loader';
import { useSafe } from '../../../hooks';

export const ProcessSafe = () => {
  const { isSafeAbortInProgress } = useSafe();
  console.log(isSafeAbortInProgress);
  return (
    <SideContainer>
      <Flex flexDirection="column" pt="35%" alignItems="center">
        <Processing
          msg="Processing the request" /* {
            isSafeAbortInProgress
              ? 'Processing the abort request'
              : 'Processing the request'
          } */
        />
      </Flex>
    </SideContainer>
  );
};
