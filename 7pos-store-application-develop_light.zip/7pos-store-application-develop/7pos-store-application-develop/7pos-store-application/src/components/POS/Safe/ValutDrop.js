import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { EnterAmount } from '../../Common/Transaction/EnterAmount';
import { useSafe } from '../../../hooks';
import { dailpadActions } from '../../../slices/dailpad.slice';

export const VaultDrop = ({ onExit }) => {
  const dispatch = useDispatch();
  const { startVaultDrop, showToast, keypadValue } = useSafe();
  const [amount, setAmount] = useState();
  const [enevlope, setEnvelop] = useState();
  const onEnterValue = (val = keypadValue) => {
    if (!val && !amount) {
      showToast('Enter Amount');
      return;
    }
    dispatch(dailpadActions.resetKeypadValue());
    if (!amount) {
      setAmount(val);
      // dispatch(cartActions.setSafeResponse([{ amount }]));
    } else {
      setEnvelop(val);
      console.log('Amount_______', enevlope);
      startVaultDrop(amount, val);
    }
  };
  return (
    <>
      <EnterAmount
        onEnterValue={onEnterValue}
        content={{
          header: 'Enter ENVELOPE#',
        }}
        amount={amount}
        onExit={onExit}
      />
    </>
  );
};
