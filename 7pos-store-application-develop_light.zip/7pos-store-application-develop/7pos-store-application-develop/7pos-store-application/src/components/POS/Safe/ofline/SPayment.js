import React from 'react';
import { Box } from '@chakra-ui/react';

import { ExitButton } from '../../../Common/Buttons';
import PaymentMethodTypes from '../../../../screens/POS/Payment/PaymentMethod/paymentMethodTypes';

export const SPayment = ({ onExit, onSafePaymentSelect }) => (
  <>
    <Box bg="rgb(255, 255, 255)" p={0}>
      <PaymentMethodTypes
        onCashPayment={() => onSafePaymentSelect('cash')}
        onManualEbt={onSafePaymentSelect}
        handlePay={onSafePaymentSelect}
        isCashOnly
        disableMoneyExchange
        disableBBucks
        disableOtherMedia
        disableExitButton
      />
      {onExit && (
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={onExit} />
        </Box>
      )}
    </Box>
  </>
);
