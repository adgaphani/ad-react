/* eslint-disable import/order */

import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
/* eslint-disable*/
import {
  StartSafe,
  ProcessSafe,
  CompleteSafe,
  VaultDrop,
  SafeOfline,
} from '../Safe';
import React from 'react';
import { useSafe } from '../../../hooks';
import { safeFeatures } from './config';

export default function SafeDrop() {
  const { path } = useRouteMatch();
  const { onSafeSelection, onSafeExit, safeOflineExit } = useSafe(true);
  return (
    <Box h="calc(100vh - 120px)" p={2}>
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex
              flexDirection="column"
              background="rgb(255, 255, 255)"
              height="100%"
            >
              <Heading
                textAlign="center"
                justifyContent="center"
                fontSize="24px"
                mt={46}
              >
                Select Safe Functions
              </Heading>
              <Flex
                flexDirection="column"
                alignItems="center"
                my={4}
                w="52%"
                m="1em auto"
              >
                {safeFeatures?.map(safe => (
                  <Button
                    size="lg"
                    className="btn optionButtonNew"
                    // color="rgb(255, 255, 255)"
                    border="1px solid rgb(16, 127, 98)"
                    width="360px"
                    h="50px"
                    m={3}
                    onClick={() => onSafeSelection(safe.feature)}
                  >
                    <Text
                      fontFamily="Roboto-bold"
                      fontSize="18px"
                      fontWeight="bold"
                    >
                      {safe.label}
                    </Text>
                  </Button>
                ))}
              </Flex>
            </Flex>
            <Flex
              width="100%"
              background="rgb(255, 255, 255)"
              justifyContent="flex-end"
            >
              <Button
                alignSelf="flex-end"
                onClick={() => onSafeExit()}
                backgroundColor="#ffffff"
                borderRadius="3px"
                border="1px solid rgb(91, 97, 107)"
                height="40px"
                width="90px"
                mb={15}
                mr={15}
              >
                <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
                  EXIT
                </Text>
              </Button>
            </Flex>
          </Route>
          <Route path={`${path}/start`}>
            <StartSafe />
          </Route>
          <Route path={`${path}/processing`}>
            <ProcessSafe />
          </Route>
          <Route path={`${path}/complete`}>
            <CompleteSafe onExit={() => onSafeExit()} />
          </Route>
          <Route path={`${path}/vaultStart`}>
            <VaultDrop onExit={() => onSafeExit()} />
          </Route>
          <Route path={`${path}/ofline`}>
            <SafeOfline onExit={safeOflineExit} />
          </Route>
        </Switch>
      </Flex>
    </Box>
  );
}
