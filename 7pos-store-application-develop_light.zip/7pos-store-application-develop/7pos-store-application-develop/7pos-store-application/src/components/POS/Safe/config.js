export const safeFeatures = [
  {
    label: 'Insert Bills',
    feature: 'insertBills',
  },
  {
    label: 'Load Tube',
    feature: 'loadTube',
  },
  {
    label: 'Vend Tube',
    feature: 'vendTube',
  },
  {
    label: 'Vault Drop Cash',
    feature: 'vaultDrop',
  },
];

export const nonIntegratedSafeFeatures = [
  {
    label: 'Cash Drop',
    feature: 'vaultDrop',
  },
  {
    label: 'Vend',
    feature: 'vendTube',
  },
];
