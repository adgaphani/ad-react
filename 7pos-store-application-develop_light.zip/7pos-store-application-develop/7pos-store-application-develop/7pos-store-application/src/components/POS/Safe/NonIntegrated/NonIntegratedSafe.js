import React from 'react';
import { useDispatch } from 'react-redux';
import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import { Button } from '../../../Common/Buttons';
import { cartActions } from '../../../../slices/cart.slice';
import { useNonIntegratedSafe } from '../../../../hooks/useNonIntegratedSafe';
import { useSafeDropHistory } from '../../../../hooks/useSafeDropHistory';
import { ManualEnter } from './ManualEnter';
import { nonIntegratedSafeFeatures } from '../config';

export default function NonIntegratedSafe() {
  const { path } = useRouteMatch();
  const dispatch = useDispatch();
  const navigation = useSafeDropHistory();
  const { onSafeSelection } = useNonIntegratedSafe();

  const onClickExitBtn = () => {
    navigation.navigateTOHome();
    dispatch(cartActions.completeSafeDrop());
  };

  return (
    <Box h="calc(100vh - 120px)" p={2}>
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex
              flexDirection="column"
              background="rgb(255, 255, 255)"
              height="100%"
            >
              <Heading
                textAlign="center"
                justifyContent="center"
                fontSize="24px"
                mt={46}
              >
                Select Safe Functions
              </Heading>
              <Flex
                flexDirection="column"
                alignItems="center"
                my={4}
                w="52%"
                m="1em auto"
              >
                {nonIntegratedSafeFeatures?.map(safe => (
                  <Button
                    size="lg"
                    className="btn optionButtonNew"
                    border="1px solid rgb(16, 127, 98)"
                    width="360px"
                    h="50px"
                    m={3}
                    onClick={() => onSafeSelection(safe.feature)}
                  >
                    <Text
                      fontFamily="Roboto-bold"
                      fontSize="18px"
                      fontWeight="bold"
                    >
                      {safe.label}
                    </Text>
                  </Button>
                ))}
              </Flex>
            </Flex>
            <Flex
              width="100%"
              background="rgb(255, 255, 255)"
              justifyContent="flex-end"
            >
              <Button
                alignSelf="flex-end"
                onClick={onClickExitBtn}
                backgroundColor="#ffffff"
                borderRadius="3px"
                border="1px solid rgb(91, 97, 107)"
                height="40px"
                width="90px"
                mb={15}
                mr={15}
              >
                <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
                  EXIT
                </Text>
              </Button>
            </Flex>
          </Route>
          <Route path={`${path}/ManualEnter`}>
            <ManualEnter />
          </Route>
        </Switch>
      </Flex>
    </Box>
  );
}
