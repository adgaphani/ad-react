import React, { useEffect, useRef } from 'react';
import { Heading, Flex } from '@chakra-ui/react';
import { useSelector } from 'react-redux';

import Icon_confirm from '../../../../Icons/Icon_confirm.svg';
import { SideContainer } from '../../../Common/Containers';
import { safeDrop } from '../../../../constants';
import { useNonIntegratedSafe } from '../../../../hooks';

export const SafeComplete = () => {
  const { safeDropType } = useSelector(state => ({
    safeDropType: state.cart.safeDropType,
  }));
  const { onSafeComplete } = useNonIntegratedSafe();
  const timerRef = useRef(null);
  useEffect(() => {
    clearTimeout(timerRef?.current);
    timerRef.current = setTimeout(() => {
      onSafeComplete();
    }, 2000);
    return () => {
      clearTimeout(timerRef?.current);
    };
  }, []);
  return (
    <>
      <SideContainer onExit={onSafeComplete}>
        <Flex flexDirection="column" pt="35%">
          <img src={Icon_confirm} height="40px" alt="" />
          <Heading
            textAlign="center"
            justifyContent="center"
            fontSize="18px"
            mt={5}
          >
            {`${safeDrop[safeDropType]?.label} Complete`}
          </Heading>
        </Flex>
      </SideContainer>
    </>
  );
};
