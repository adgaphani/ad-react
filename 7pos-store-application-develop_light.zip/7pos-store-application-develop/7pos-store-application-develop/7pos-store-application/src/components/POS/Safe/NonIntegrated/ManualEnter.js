import React from 'react';
import { useSelector } from 'react-redux';
import { Box, Heading, Grid, Flex } from '@chakra-ui/react';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import { useNonIntegratedSafe } from '../../../../hooks';
import Keypad from '../../../Common/DailPad/Keypad/Keypad';
import { SPayment } from '../ofline';
import { VaultEnvelop } from '../ofline/VaultEnvelop';
import { SafeComplete } from './SafeComplete';

export const ManualEnter = () => {
  const { onValueEnter, onPaymentSelect } = useNonIntegratedSafe();
  const { path } = useRouteMatch();
  const { isVault, vaultUserEntries } = useSelector(state => ({
    isVault: state.cart.safeDropType === 'vaultDrop',
    vaultUserEntries: state.cart.vaultUserEntries,
  }));

  return (
    <>
      <Grid templateColumns="50% 50%" width="100%">
        <Box marginLeft="7px" pr="0.5rem">
          <Keypad
            onEnter={onValueEnter}
            {...(isVault && vaultUserEntries.amount ? { max: 4 } : {})}
          />
        </Box>
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex
              h="100%"
              flexDirection="column"
              justifyContent="space-between"
              bg="rgb(255, 255, 255)"
              mr="0.5rem"
              alignItems="center"
            >
              <Box
                bg="rgb(255, 255, 255)"
                p={0}
                display="flex"
                flexDirection="column"
                justifyContent="space-between"
              >
                <Heading
                  textAlign="center"
                  justifyContent="center"
                  mt="20px"
                  mb="30px"
                  color="rgb(44, 47, 53)"
                  fontSize="24px"
                  fontWeight="bold"
                  fontFamily="Roboto-Bold"
                >
                  Enter Amount#
                </Heading>
              </Box>
            </Flex>
          </Route>
          <Route path={`${path}/payment`}>
            <SPayment onSafePaymentSelect={onPaymentSelect} />
          </Route>
          <Route path={`${path}/envelop`}>
            <VaultEnvelop />
          </Route>
          <Route path={`${path}/complete`}>
            <SafeComplete />
          </Route>
        </Switch>
      </Grid>
    </>
  );
};
