import React from 'react';
import { Box, Heading } from '@chakra-ui/react';

import { ExitButton } from '../../../Common/Buttons';

export const VaultEnvelop = ({ onExit }) => (
  <>
    <Box
      bg="rgb(255, 255, 255)"
      p={0}
      display="flex"
      flexDirection="column"
      justifyContent="space-between"
    >
      <Heading
        textAlign="center"
        justifyContent="center"
        mt="20px"
        mb="30px"
        color="rgb(44, 47, 53)"
        fontSize="24px"
        fontWeight="bold"
        fontFamily="Roboto-Bold"
      >
        Enter ENVELOPE#
      </Heading>
      {onExit && (
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={onExit} />
        </Box>
      )}
    </Box>
  </>
);
