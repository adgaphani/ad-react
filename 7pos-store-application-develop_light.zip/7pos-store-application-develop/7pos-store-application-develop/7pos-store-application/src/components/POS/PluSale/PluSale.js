import { Box, Flex, Heading, Input, Text } from '@chakra-ui/react';
import React, { memo, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Button } from '../../Common/Buttons';
import Styles from './PluSale.module.css';
import { cartActions } from '../../../slices/cart.slice';
import { getItembyUpcApi } from '../../../api/cart/getItembyUpcApi';
import { verifyUserId, appIntegrationRequest } from '../../../Utils/appUtils';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';

function PluSale({ onExit }) {
  const [upc, setUpc] = useState('');
  const dispatch = useDispatch();
  const history = useHistory();
  const [ws] = useContext(WebSocketContext);
  const {
    lookupCodes,
    tranAgeVerifyInfo,
    paymentTransactionId,
    storeDetails,
    items,
    saleHours,
  } = useSelector(state => ({
    lookupCodes: state.main.lookupCodes,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    isTransactionVoid: state.cart.isTransactionVoid,
    paymentTransactionId: state.cart.paymentTransactionId,
    storeDetails: state.main.storeDetails,
    items: state.cart.items,
    saleHours: state.main.saleHours,
  }));

  const addItemByUPC = async () => {
    if (!upc) return;
    try {
      dispatch(cartActions.setFinalizePayStatus(true));
      const response = await getItembyUpcApi(upc, '', paymentTransactionId);
      setUpc('');
      const data = response;
      global?.Logger?.debug(`7POS Application - fetch Item Success`);
      const {
        citem,
        lookup,
        notVerified,
        underAged,
        restrictedHours,
      } = verifyUserId({
        data,
        lookupCodes,
        tranAgeVerifyInfo,
        saleHours,
        cartItems: items,
        storeDetails,
      });
      const state = { item: { ...citem, upc }, restriction: lookup };
      if (Number(citem.itemRestrictionCode) === 6) {
        // Reheat screen trigger for code 6 items
        history.push({
          pathname: '/home/itemReHeatScreen',
          state: { item: citem, upc },
        });
        return;
      }
      if (restrictedHours && saleHours) {
        dispatch(cartActions.setRestrictedSale(true));
        return;
      }
      if (underAged) {
        history.push({
          pathname: '/home/manualEntry',
          state: { ...state, underAged: true },
        });
        dispatch(cartActions.setFinalizePayStatus(false));
        return;
      }

      if (notVerified) {
        const dlSwipeReq = appIntegrationRequest({
          type: 'Dlswipe_Req',
          correlationId: paymentTransactionId,
        });
        ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
        history.push({ pathname: '/home/verification', state });
        dispatch(cartActions.setFinalizePayStatus(false));
        return;
      }
      data.forEach(item => {
        dispatch(cartActions.addToCart({ ...item, upc }));
      });
    } catch (error) {
      global?.logger?.error(`[7POS UI] - fetch Item failed`);
    }
    dispatch(cartActions.setFinalizePayStatus(false));
  };

  const onEnterClick = e => {
    if (e.keyCode === 13 && upc) addItemByUPC();
  };

  return (
    <Box bg="#ffffff" p={4} shadow="md" height="100%">
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Flex flexDirection="column">
          <Heading
            textAlign="center"
            justifyContent="center"
            color="rgb(111, 110, 127)"
            mb={10}
          >
            Search Item to Add
          </Heading>
          <Flex alignItems="center" my={4} w="70%" m="1em auto">
            <Input
              placeholder="Search by: Item Desc, Item Number, UPC"
              size="lg"
              mr={4}
              value={upc}
              onKeyDown={onEnterClick}
              onChange={e => setUpc(e.target.value)}
            />
            <Button
              size="lg"
              variantColor="gray"
              onClick={addItemByUPC}
              className={Styles.addButton}
            >
              Add
            </Button>
          </Flex>
        </Flex>
        <Button
          alignSelf="flex-end"
          onClick={onExit}
          className={Styles.exitButton}
          mb={15}
          mr={15}
        >
          <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
            EXIT
          </Text>
        </Button>
      </Flex>
    </Box>
  );
}

export default memo(PluSale);
