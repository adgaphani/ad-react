import React, { useEffect, useState, useRef } from 'react';
import { Grid, Box, Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useSoundToast } from '../../../hooks';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import ExitButton from '../ExitButton';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { mainActions } from '../../../slices/main.slice';
import { fetchProductLookUps } from '../../../api/app/fetchProductLookUps';

const ItemPrice = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const history = useHistory();
  const { item } = location?.state || {};
  const { keyConfig, paymentTransactionId } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    keyConfig: state.main.keyConfig,
  }));
  const APIResponse = useRef([]);
  const [items, setItems] = useState(null);

  const getProducts = async () => {
    try {
      if (!keyConfig) {
        const pluResponse = await fetchProductLookUps({
          correlationID: paymentTransactionId,
        });
        const response = JSON.parse(JSON.stringify(pluResponse?.data));
        APIResponse.current = JSON.parse(response?.data);
        dispatch(mainActions.setKeyConfig(response?.data));
        const isCdbActive =
          JSON.parse(response.data)
            .flatMap(data =>
              data.name?.toLowerCase()?.includes('keyboard') ? data.groups : []
            )
            .flatMap(group => group.keys)
            .find(key =>
              key.subKeys.some(
                subKey => subKey.name?.toLowerCase() === 'cdbreport'
              )
            )
            ?.subKeys.find(subKey => subKey.name?.toLowerCase() === 'cdbreport')
            ?.isActive ?? false;
        dispatch(mainActions.setIsCdbBtnAcive(isCdbActive));
        if (APIResponse.current) {
          APIResponse.current.map(data => {
            if (data?.name?.toLowerCase()?.includes('othermediaconfig')) {
              global?.logger?.info(
                `[7POS UI] - Other Media Config ${JSON.stringify(data)}`
              );
              dispatch(mainActions.setMediaConfig(data));
            } else if (data?.name?.toLowerCase()?.includes('keyboard')) {
              setItems(data.groups);
            } else {
              global?.logger?.error(
                `[7POS UI] - Keyboard configuration missing.`
              );
            }
            return data;
          });
        }
        global?.logger?.info(`[7POS UI] - fetchProductLookUps successful`);
      } else {
        APIResponse.current = JSON.parse(keyConfig);
        if (APIResponse.current) {
          APIResponse.current.map(data => {
            if (data?.name?.toLowerCase()?.includes('othermediaconfig')) {
              dispatch(mainActions.setMediaConfig(data));
            }
            if (data?.name?.toLowerCase()?.includes('keyboard')) {
              setItems(data.groups);
            }
            return data;
          });
        }
      }
    } catch (error) {
      global?.logger?.error(`[7POS UI] - fetchProductLookUps details Error `);
    }
  };

  useEffect(() => {
    getProducts();
    dispatch(dailpadActions.resetKeypadValue());
  }, []);

  const onNoClick = () => {
    dispatch(dailpadActions.resetKeypadValue());
    history.push('/home');
  };

  const onEnterValue = e => {
    if (!e) return;
    const amount = Number(e) / 100;
    if (!item.upc) {
      global?.logger?.error(
        `[7POS UI] - UPC not found ${JSON.stringify(item)}`
      );
    } else if (amount >= 0) {
      let DepartmentInfo = null;
      items.map(item => {
        if (
          item?.name?.toLowerCase() === 'other depts' ||
          item?.name?.toLowerCase() === 'otherdepartment'
        ) {
          DepartmentInfo = item;
        }
        return item;
      });
      history.push({
        pathname: '/home/otherDepartments',
        search: `?itemId=${item.id}`,
        state: {
          items: DepartmentInfo?.keys
            ? DepartmentInfo?.keys
            : DepartmentInfo?.subKeys,
          UPC: item.upc,
        },
      });
    } else {
      toast({
        description: 'Entered Amount is not in range',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
    }
  };

  return (
    <Grid templateColumns="50% 50%" width="100%">
      <Box marginLeft="7px" pr="0.5rem">
        <Keypad onEnter={onEnterValue} />
      </Box>
      <Flex
        h="100%"
        flexDirection="column"
        justifyContent="space-between"
        bg="rgb(255, 255, 255)"
        mr="0.5rem"
      >
        <Flex flexDirection="column">
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Bold"
            fontSize="24px"
            fontWeight="bold"
            my="1.75rem"
            ml="2.5rem"
          >
            Please enter item amount
          </Text>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={onNoClick} />
        </Box>
      </Flex>
    </Grid>
  );
};

export default ItemPrice;
