import {
  Box,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
} from '@chakra-ui/react';

import React from 'react';
import PropTypes from 'prop-types';
import { Button } from '../../../Common/Buttons';
import Styles from './birthDateInvalidModal.module.css';
import Icon_Restrict from '../../../../Icons/Icon_Restrict.svg';

function BirthDateInvalid({ isOpen, onClose, item, onOk, MSG }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay className={Styles.modalOverlay} onClick={onClose} />
      <ModalContent className={Styles.modalContainer}>
        <ModalHeader className={Styles.modalHeader}>
          <Box mb="20px" textAlign="center">
            <img src={Icon_Restrict} alt="Warning" height="47px" width="47px" />
          </Box>
          <Box mx="80px">
            <Text
              color="rgb(44, 47, 53)"
              fontsize="28px"
              fontFamily="Roboto-Bold"
              fontWeight="bold"
              textAlign="center"
            >
              {MSG}
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontsize="28px"
              fontFamily="Roboto-Bold"
              fontWeight="bold"
              textAlign="center"
            >
              ITEM DENIED
            </Text>
          </Box>
        </ModalHeader>
        <ModalBody className={Styles.modalBody} mx="16px">
          <Text
            color="rgb(44, 47, 53)"
            fontWeight="normal"
            fontSize="20px"
            textAlign="center"
          >
            Customer may not purchase <strong>{item?.itemShortName}</strong>.
            <br />
            Refuse the sale of the age restricted item.
          </Text>
        </ModalBody>

        <ModalFooter justifyContent="center" padding="0px" mt="12px">
          <Button className={Styles.okButton} width="240px" onClick={onOk}>
            <Text>OK</Text>
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

BirthDateInvalid.defaultProps = {
  item: {},
  isOpen: false,
  onClose: () => null,
  onOk: () => null,
};

BirthDateInvalid.propTypes = {
  item: PropTypes.object,
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
};

export default BirthDateInvalid;
