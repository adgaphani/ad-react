import React from 'react';
import loader from '../../../Icons/Icons_redeemreward_loader.svg';

export default function Loader() {
  return (
    <object type="image/svg+xml" data={loader}>
      svg-animation
    </object>
  );
}
