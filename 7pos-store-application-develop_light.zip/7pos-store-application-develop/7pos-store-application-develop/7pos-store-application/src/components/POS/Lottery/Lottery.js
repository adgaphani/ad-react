import React, { useEffect } from 'react';
// import { useSelector } from 'react-redux';

// import { verifyUserId } from '../../../Utils/appUtils';

export default function Lottery() {
  //   const { transactionAgeVerificationDOB } = useSelector(state => ({
  //     transactionAgeVerificationDOB: state.cart.transactionAgeVerificationDOB,
  //   }));

  useEffect(() => {
    // const { citem, lookup, notVerified, underAged } = verifyUserId(
    //     data,
    //     lookupCodes,
    //     transactionAgeVerificationDOB,
    //     selectedVisualIdOk
    //   );
    //   const state = {
    //     item: { ...citem, upc: item.upc },
    //     restriction: lookup,
    //   };
    //   if (underAged) {
    //     history.push({
    //       pathname: '/home/manualEntry',
    //       state: { ...state, underAged: true },
    //     });
    //     return;
    //   }
    //   if (notVerified) {
    //     history.push({ pathname: '/home/verification', state });
    //     return;
    //   }
  }, []);
  return <div> TEST</div>;
}
