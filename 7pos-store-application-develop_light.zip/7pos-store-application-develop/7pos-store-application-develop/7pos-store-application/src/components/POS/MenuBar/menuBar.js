import React, { useState, useContext, useEffect } from 'react';
import {
  Box,
  Flex,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  useDisclosure,
} from '@chakra-ui/react';
import { NavLink, useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  useCart,
  useFuel,
  useFuelPrices,
  useSoundToast,
  useTransHold,
} from '../../../hooks';
import { Button } from '../../Common';
import Styles from './menubar.module.css';
import { checkMenuTabEnabled } from '../../../Utils/appUtils';
import { SendMessageToCFD } from '../../../Communication';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { authActions } from '../../../slices/auth.slice';
import Menu_Ham from '../../../Icons/Icon_menu.svg';
import Icon_Waring from '../../../Icons/fuelIcons/pump-warning.svg';
import { AppContext } from '../../../AppContext';
import { CardStatus, getMenuConfig } from '../../Common/Config';
import { fetchAppInfo } from '../../../api/app/fetchAppInfo';

function MenuBar() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const history = useHistory();
  const toast = useSoundToast();
  const { isIntegratedFuelStore, isFuelIntegrated, isFuelEnabled } = useFuel();
  const { isPendingMPSApproval } = useFuelPrices();
  const { isFuelTransactionInProgress, isCarwashInProgress } = useCart();
  const { handleTranHold } = useTransHold();
  const {
    items,
    taxInfo,
    member,
    storeDetails,
    UserActionScreenActive,
    fuel,
    isTransactionVoid,
    isTransactionRefund,
    cartChangeTrial,
    runningTotal,
    preCartItems,
    loadCardMediaList,
    isTransHold,
    EODEOSDetails,
    isActive,
    transactionMemory,
    showTransHoldText,
    disableFinalizePay,
    safeDropType,
    isSafeDrop,
    isSignOff,
    tenderSequenceNumber,
    paymentTransactionId,
    MemberBarcodeInfo,
    isPromoInProgress,
    isSpeedyStore,
    isSevenRewardsDisable,
    transactionStartTime,
    tranAgeVerifyInfo,
    tranItemSeqNumber,
    isMoMAllowed,
    itemQuantity,
    allPayments,
  } = useSelector(state => ({
    items: state.cart.items,
    taxInfo: state.cart.taxInfo,
    member: state.cart.member,
    fuel: state.cart.fuel,
    storeDetails: state.main.storeDetails,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    preCartItems: state.cart.preCartItems,
    config: state.main.configuration,
    loadCardMediaList: state.cart.loadCardMediaList,
    isTransHold: state.cart.isTransHold,
    itemsInMemory: state.cart.transactionMemory?.items,
    transactionMemory: state.cart.transactionMemory,
    transactionId: state.cart.transactionId,
    EODEOSDetails: state.cart.EODEOSDetails,
    isActive: state.balance.isActive,
    showTransHoldText: state.cart.showTransHoldText,
    disableFinalizePay: state.cart.disableFinalizePay,
    safeDropType: state.cart.safeDropType,
    isSafeDrop: state.cart.isSafeDrop,
    isSignOff: state.cart.isSignOff,
    tenderSequenceNumber: state.cart.tenderSequenceNumber,
    paymentTransactionId: state.cart.paymentTransactionId,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    isPromoInProgress: state.cart.isPromoInProgress,
    isSpeedyStore: state.main.isSpeedyStore,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
    transactionStartTime: state.cart.transactionStartTime,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    isMoMAllowed: state.cart.isMoMAllowed,
    itemQuantity: state.cart.itemQuantity,
    allPayments: state.cart.allPayments,
  }));
  const { keyPressSound, showToast } = useContext(AppContext);
  const cashDrawerStatus = useSelector(state => state.socket.cashDrawerStatus);
  const dispatch = useDispatch();
  const location = useLocation();
  const [isMenuOpen, setMenuOpen] = useState(false);
  const isPaymentSuccess = location.pathname.includes('payment/success');
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [aboutResponse, setAboutResponse] = useState(null);

  const { cardStatus } = Object.fromEntries(
    new URLSearchParams(location.search)
  );
  const logoutToast = () => {
    toast({
      description: 'You have successfully logged out!',
      status: 'success',
      duration: 3000,
      position: 'top',
    });
  };

  const confirmLogout = () => {
    // Need to restrict payment screen level itself instead of each child level
    if (
      location.pathname.includes('/payment') ||
      location.pathname === '/home/manualEntry' ||
      location.pathname === '/home/verification' ||
      location.pathname === '/home/safeDrop/processing' ||
      location.pathname === '/home/balance_success' ||
      location.pathname === '/home/functionSecurity' ||
      location.pathname === '/home/prepaidCardLookup' ||
      location.pathname === '/home/cardProcess' ||
      location.pathname === '/home/prepaidCardMenu' ||
      UserActionScreenActive ||
      safeDropType ||
      isSafeDrop ||
      allPayments?.length > 0 // #9334 blocking logoff any media present in the transaction
    ) {
      toast({
        description: 'Please Complete transaction first',
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      return;
    }
    if (items && items.length) {
      onOpen();
    } else {
      logoutToast();
      const iTransactionMessage = {
        CMD: 'IntialState',
        COUNTRY: storeDetails?.address?.country,
      };
      SendMessageToCFD(iTransactionMessage);
      dispatch(cfdActions.setAltIDUserReset(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      dispatch(authActions.setAppLogInStatus(false));
      dispatch(cfdActions.setTransactionFinalize(false));
      history.replace('/');
    }
  };
  const handleAbout = async () => {
    try {
      const appInfoResponse = await fetchAppInfo({
        correlationID: paymentTransactionId,
      });
      if (appInfoResponse?.data) {
        setAboutResponse(appInfoResponse.data);
      }
    } finally {
      setIsAboutModalOpen(true);
    }
  };
  const handleNewPrices = () => {
    console.log('___handleNewPrices');
  };

  const renderAboutData = aboutList => {
    const data = [];
    const innerItemList = [
      'Pinpad',
      'PinpadConfig',
      'PinpadFirmware',
      'PinpadSerialNumber',
    ];

    const getList = (key, value) => {
      if (value) {
        return (
          <Flex alignItems="center" className={Styles.aboutContainer}>
            <div>{key}</div> :{' '}
            <div className={Styles.aboutVersion}>{value}</div>
          </Flex>
        );
      }
      return null;
    };

    const getNestedList = list =>
      Object.keys(list).map(dataKey => {
        if (innerItemList.includes(dataKey)) {
          return getList(dataKey, list[dataKey]);
        }
        return null;
      });

    if (aboutList) {
      Object.keys(aboutList)
        .sort()
        .forEach(list => {
          data.push(
            <div key={list}>
              {getList(list, aboutList[list]?.Version)}
              {getNestedList(aboutList[list])}
            </div>
          );
        });
    }
    if (!data.filter(i => i).length) {
      return <div className={Styles.noData}>No Data found</div>;
    }
    return data;
  };

  const routeCBMap = {
    home: () => {},
    hold: () => handleTranHold(location),
  };

  const enableFuel =
    isIntegratedFuelStore &&
    !(isFuelTransactionInProgress && isCarwashInProgress);

  const showError = message =>
    showToast({
      description: message,
      position: 'top-left',
    });

  const onNavLinkClick = e => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    const menu = e?.currentTarget?.getAttribute('routeid');
    if (
      !checkMenuTabEnabled(storeDetails?.storeId || 0) &&
      menu !== 'home' &&
      menu !== 'rewards' &&
      menu !== 'hold' &&
      menu !== 'fuel' &&
      !isIntegratedFuelStore
    ) {
      e.preventDefault();
    }

    if (menu === 'hold') {
      e.preventDefault();
      if (isFuelTransactionInProgress) {
        return showError(Messages.trans_hold_not_allowed_fuel);
      }
    }

    let isAllowed = true;
    let displayToast = false;
    // #4944 added promo progress check for Memory ON/Off
    if (
      UserActionScreenActive ||
      (menu === 'hold' && (isActive || disableFinalizePay || isPromoInProgress))
    ) {
      isAllowed = false;
      displayToast = false;
    }
    const drawerStatusList = ['CD_ALARM_ON', 'CD_ALARM_OPEN', 'CD_OPEN_OK'];
    // Need to restrict payment screen level itself instead of each child level
    if (
      CardStatus?.disableMenu?.includes(cardStatus) ||
      drawerStatusList.includes(cashDrawerStatus) ||
      location.pathname.includes('/payment') ||
      location.pathname === '/home/restart' ||
      location.pathname === '/home/operatormenu' ||
      location.pathname.includes('networkMaintenance') ||
      location.pathname === '/home/safeDrop/processing' ||
      location.pathname === '/home/manualEntry' ||
      location.pathname === '/home/verification' ||
      location.pathname === '/home/balance_success' ||
      location.pathname === '/home/balance' ||
      location.pathname === '/home/functionSecurity' ||
      location.pathname === '/home/prepaidCardLookup' ||
      location.pathname === '/home/cardProcess' ||
      location.pathname === '/home/prepaidCardMenu' ||
      safeDropType ||
      isSafeDrop ||
      itemQuantity >= 1
    ) {
      isAllowed = false;
      displayToast = true;
    }

    if (!isAllowed) {
      if (itemQuantity >= 1)
        showToast({
          description: 'Invalid key for qty multiplier.',
          position: 'top-left',
        });
      else if (displayToast)
        toast({
          description: 'Please Complete transaction first',
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      e.preventDefault();
      e.stopPropagation();
    }

    if (items.length === 0) {
      if (
        !member?.loyalty_id &&
        !isTransactionVoid &&
        !isTransactionRefund &&
        location.pathname !== '/home/prepaidCardLookup' &&
        location.pathname !== '/home/cardProcess' &&
        location.pathname !== '/home/prepaidCardMenu'
      ) {
        const iTransactionMessage = {
          CMD: 'IntialState',
          COUNTRY: storeDetails?.address?.country,
        };
        SendMessageToCFD(iTransactionMessage);
      }
    }
    dispatch(cartActions.setSelectedItem(null));
    if (isAllowed) routeCBMap[menu]?.();
  };

  // const confirmClockout = () => {
  //   if (UserActionScreenActive ) return;
  //   if (items && items.length) {
  //     onOpen();
  //   } else {
  //     history.replace({ pathname: '/', state: { logInTabIndex } });
  //     toast({
  //       description: 'You have clocked out successfully!',
  //       status: 'success',
  //       duration: 3000,
  //       position: 'top',
  //     });
  //   }
  // };
  const handleLogout = () => {
    if (UserActionScreenActive) return;
    onClose();
    if (isPaymentSuccess) {
      dispatch(cartActions.emptyCart());
    } else if (items.length || fuel.length) {
      localStorage.setItem(
        'cartInfo',
        JSON.stringify({
          cartItems: items,
          preCartItems,
          taxInfo,
          member,
          fuel,
          isTransactionVoid,
          isTransactionRefund,
          cartChangeTrial,
          runningTotal,
          loadCardMediaList,
          EODEOSDetails,
          isTransHold,
          transactionMemory,
          showTransHoldText,
          tenderSequenceNumber,
          transactionStartTime,
          tranAgeVerifyInfo,
          MemberBarcodeInfo,
          tranItemSeqNumber,
          isMoMAllowed,
        })
      );
    }
    logoutToast();
    const iTransactionMessage = {
      CMD: 'IntialState',
      COUNTRY: storeDetails?.address?.country,
    };
    SendMessageToCFD(iTransactionMessage);
    dispatch(cfdActions.setAltIDUserReset(false));
    dispatch(cfdActions.setAltIDUserTrigger(false));
    dispatch(authActions.setAppLogInStatus(false));
    dispatch(cfdActions.setTransactionFinalize(false));
    history.replace('/');
  };

  const handelMenu = () => {
    if (UserActionScreenActive) return false;
    setMenuOpen(!isMenuOpen);
  };
  const getMenuOptions = () =>
    getMenuConfig({
      isTransHold,
      storeDetails,
      enableFuel,
      isFuelEnabled,
      isFuelIntegrated,
      isSpeedyStore,
      isSevenRewardsDisable,
    })?.map((m, index) => (
      <NavLink
        exact
        {...m}
        activeClassName={m.activeClassName}
        className={m.className}
        to={m.link}
        onClick={onNavLinkClick}
        routeid={m.routeid}
        key={index}
      >
        <Flex
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          my={2}
        >
          {m.icon && (
            <img
              height={m.iconHeight ? `${m.iconHeight}` : '17px'}
              width={m.iconWidth ? `${m.iconWidth}` : '24px'}
              src={m.icon}
              alt={m.lable}
              label={m.label}
            />
          )}
          <Text
            pt="4px"
            color="rgb(255, 255, 255)"
            fontSize="14px"
            fontWeight="normal"
            fontFamily="Roboto-Regular"
          >
            {m.label}
          </Text>
        </Flex>
      </NavLink>
    ));

  useEffect(() => {
    if (isSignOff) {
      dispatch(cartActions.setIsSignOff(false));
      confirmLogout();
    }
  }, [isSignOff]);

  return (
    <React.Fragment>
      <Box bg="#2c2f35" w="100%" h="60px" position="fixed" bottom="0px">
        <Flex alignItems="center">
          <Menu>
            {({ isMenuOpen }) => (
              <>
                <MenuButton
                  isActive={isMenuOpen}
                  p={4}
                  onClick={() => {
                    if (
                      location.pathname === '/home/restart' ||
                      location.pathname === '/home/operatormenu' ||
                      location.pathname.includes('networkMaintenance') ||
                      location.pathname === '/payment/mediaAbort'
                    )
                      return;
                    keyPressSound
                      ?.play?.()
                      .catch(e => console.log('Sound error', e));
                    handelMenu();
                  }}
                  className={Styles.menuButton}
                  width="80px"
                >
                  <img src={Menu_Ham} alt="menu" height="17px" width="18px" />
                </MenuButton>
                <MenuList className={Styles.menuList}>
                  {/* <MenuItem
                    className={`${Styles.menuItem} ${Styles.menuClock}`}
                    _focus={{ bg: '#107f62', color: '#fff' }}
                    _hover={{ bg: '#107f62', color: '#fff' }}
                    borderBottom="1px solid #d3d3d3"
                    onClick={confirmClockout}
                  >
                    <span className={Styles.clock} />
                    <Text>Clock In / Out</Text>
                  </MenuItem> */}
                  {isPendingMPSApproval && (
                    <MenuItem
                      className={`${Styles.menuItem}`}
                      _focus={{ bg: 'primary', color: 'btn.text.default' }}
                      _hover={{ bg: 'primary', color: 'btn.text.default' }}
                      onClick={() => {
                        keyPressSound
                          ?.play?.()
                          .catch(e => console.log('Sound error', e));
                        handleNewPrices();
                      }}
                    >
                      <Flex className={Styles.pricesWrapper}>
                        <img
                          className={Styles.pricesWaring}
                          src={Icon_Waring}
                          alt="prices"
                        />
                        <Text className={Styles.pricesLabel}>
                          New Fuel Prices
                        </Text>
                      </Flex>
                    </MenuItem>
                  )}
                  <MenuItem
                    className={`${Styles.menuItem} ${Styles.menuAbout}`}
                    _focus={{ bg: 'primary', color: 'btn.text.default' }}
                    _hover={{ bg: 'primary', color: 'btn.text.default' }}
                    onClick={() => {
                      keyPressSound
                        ?.play?.()
                        .catch(e => console.log('Sound error', e));
                      handleAbout();
                    }}
                  >
                    <span className={Styles.about} />
                    <Text>About</Text>
                  </MenuItem>
                  <MenuItem
                    className={`${Styles.menuItem} ${Styles.menuLogout}`}
                    _focus={{ bg: 'primary', color: 'btn.text.defualt' }}
                    _hover={{ bg: 'primary', color: 'btn.text.default' }}
                    onClick={() => {
                      if (
                        location.pathname === '/home/restart' ||
                        location.pathname === '/home/operatormenu' ||
                        location.pathname.includes('networkMaintenance') ||
                        location.pathname === '/payment/mediaAbort'
                      )
                        return;
                      keyPressSound
                        ?.play?.()
                        .catch(e => console.log('Sound error', e));
                      confirmLogout();
                    }}
                  >
                    <span className={Styles.logout} />
                    <Text>Logout</Text>
                  </MenuItem>
                </MenuList>
              </>
            )}
          </Menu>

          <Flex
            width="100%"
            flexDirection="row"
            justifyContent="space-between"
            alignItems="center"
            pr={2}
          >
            {getMenuOptions()}
          </Flex>
        </Flex>
      </Box>
      <Modal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
      >
        <ModalOverlay onClick={() => setIsAboutModalOpen(false)} />
        <ModalContent>
          <ModalHeader className={Styles.aboutModalHeader}>
            <span>App Versions</span>
            <button
              type="button"
              className={Styles.closeIcon}
              onClick={() => setIsAboutModalOpen(false)}
            >
              X
            </button>
          </ModalHeader>
          <ModalBody className={Styles.aboutModalBody}>
            {renderAboutData(aboutResponse)}
          </ModalBody>
        </ModalContent>
      </Modal>

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay className={Styles.modalOverlay} onClick={onClose} />
        <ModalContent className={Styles.modalContainer}>
          <ModalHeader className={Styles.modalHeader}>
            <Text
              color="rgb(44, 47, 53)"
              fontsize="28px"
              fontFamily="Roboto-Bold"
              fontweight="bold"
              lineheight="30px"
              textalign="center"
            >
              YOU ARE ABOUT TO LOGOUT
            </Text>
          </ModalHeader>
          <ModalBody className={Styles.modalBody} mx="30px">
            <Text
              color="rgb(44, 47, 53)"
              fontWeight="normal"
              lineHeight="28px"
              textAlign="center"
            >
              There is a transaction in progress, it will be available when you
              log back in.
            </Text>
          </ModalBody>

          <ModalFooter
            justifyContent="center"
            marginBottom="40px"
            mx="50px"
            padding="0px"
          >
            <Button
              className={Styles.noButton}
              width="200px"
              mr={3}
              onClick={onClose}
            >
              <Text>CANCEL</Text>
            </Button>
            <Button
              className={Styles.okButton}
              width="200px"
              onClick={handleLogout}
            >
              <Text>OK</Text>
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </React.Fragment>
  );
}
export default MenuBar;
