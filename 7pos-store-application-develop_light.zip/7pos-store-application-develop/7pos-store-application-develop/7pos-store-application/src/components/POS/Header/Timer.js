import React, { useEffect, useState } from 'react';

import moment from 'moment';

const Timer = () => {
  const [time, setTime] = useState('');

  const currentTime = () => moment().format('MM/DD/YYYY - hh:mm:ss');

  useEffect(() => {
    const isTimer = setInterval(() => {
      setTime(currentTime());
    }, 1000);
    return () => {
      clearInterval(isTimer);
    };
  }, []);

  return <>{time}</>;
};

export default Timer;
