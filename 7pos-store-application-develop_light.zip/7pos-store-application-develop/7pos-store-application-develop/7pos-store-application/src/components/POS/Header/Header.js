import { Box, Flex, Image, Text } from '@chakra-ui/react';
import React from 'react';
import { useSelector } from 'react-redux';
import speedyLogo from '@icons/speedway/speedy_logo.svg';

import Styles from './Header.module.css';
import Timer from './Timer';
import logoSevenEleven from '../../../Icons/logoSevenEleven.svg';

function Header() {
  const {
    user,
    deviceInfo,
    storeDetails,
    shiftNumber,
    isSpeedyStore,
  } = useSelector(state => ({
    user: state.auth.user,
    deviceInfo: state.main.deviceInfo,
    storeDetails: state.main.storeDetails,
    shiftNumber: state.main.shiftNumber,
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  const renderShiftNumber = () => {
    if ([undefined, null, ''].includes(shiftNumber)) return 'Sh';
    const sNumber = shiftNumber <= 9 ? `0${shiftNumber}` : shiftNumber;
    return `Sh ${sNumber}`;
  };

  return (
    <Box className={Styles.header}>
      <Flex justifyContent="space-between" alignItems="center" height="39px">
        {/* <Box> {props.children}</Box> */}
        <Text
          fontWeight="normal"
          color="rgb(91, 97, 107)"
          fontSize="12px"
          pl="1.13rem"
        >
          Store #: {storeDetails?.storeId || 'NA'} | POS:{' '}
          {deviceInfo?.id || 'NA'} | Store Associate: {user?.firstName} |{' '}
          {renderShiftNumber()} | <Timer />
        </Text>
        <Box pr="1rem">
          <Image
            height={isSpeedyStore ? '32px' : '14px'}
            width={isSpeedyStore ? '41px' : '73px'}
            src={isSpeedyStore ? speedyLogo : logoSevenEleven}
            alt="logoSevenEleven"
          />
        </Box>
      </Flex>
    </Box>
  );
}

export default Header;
