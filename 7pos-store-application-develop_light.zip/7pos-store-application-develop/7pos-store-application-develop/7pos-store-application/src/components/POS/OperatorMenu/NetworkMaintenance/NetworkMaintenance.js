import React, { useContext, useEffect, useState, useRef } from 'react';
import { useSelector } from 'react-redux';
import moment from 'moment';
import { useHistory, useLocation } from 'react-router';
import { Flex, Grid } from '@chakra-ui/react';
import * as Styles from './NetworkMaintenance.module.css';
import { WebSocketContext } from '../../../Common/WebSocket/WebSocketProvider';
import MaintenanceItem from '../../../Common/grid-item/GridItem';
import Keypad from '../../../Common/DailPad/Keypad/Keypad';
import { KeysUtil } from '../../../../Utils';
import { AppContext } from '../../../../AppContext';
import { AlertModal, Toast } from '../../../Common';
import { RedInfo } from '../../../../Icons/operatorMenu';

export default () => {
  const history = useHistory();
  const location = useLocation();
  const [ws] = useContext(WebSocketContext);
  const [loader, setLoader] = useState(false);
  const [selectedItem, setSelectedItem] = useState({});
  const { keyPressSound } = useContext(AppContext);
  const [failedCount, setFailedCount] = useState(1);
  const loading = useRef();
  const alertModalRef = useRef();
  const toastRef = useRef();
  const { items: allItems = [] } = location?.state || {};
  const items = KeysUtil.getAllKeysFromInput({
    inputKeys: allItems,
    maxKeyCount: 24,
  });

  const { paymentTransactionId } = useSelector(state => ({
    paymentTransactionId: state?.cart?.paymentTransactionId || '',
  }));
  loading.current = loader;

  const paymentListener = e => {
    try {
      const { message } = JSON.parse(e.body)?.messageBody;
      if (message === 'DEVICE_INITIALIZED') {
        toastRef.current.showToast({
          messages: ['Pin Pad reset was successful'],
          status: 'success',
        });
        setFailedCount(1);
        setTimeout(() => {
          setLoader(false);
          history.push('/home');
        }, 2500);
      }

      if (message === 'DEVICE_BUSY' || message === 'COMM_LINK_UNINITIALIZED') {
        toastRef.current.showToast({
          messages: [
            `PIN Pad Reset has failed`,
            `(Attempt ${failedCount} of 3)`,
          ],
          status: 'warning',
        });
        setFailedCount(failedCount + 1);
        setTimeout(() => {
          setLoader(false);
        }, 2500);
      }
    } catch (e) {
      setLoader(false);
    }
  };

  useEffect(() => {
    let listener;
    if (ws?.socket?.subscribe) {
      listener = ws.socket?.subscribe('/controlQueue/pinpad', paymentListener);
    }

    return () => {
      if (listener?.unsubscribe) {
        listener?.unsubscribe();
      }
    };
  }, [failedCount]);

  const pinpadResetTimeout = () => {
    const currentTime = Date.now();
    const intervel = setInterval(() => {
      if (!loading.current) {
        clearInterval(intervel);
        setLoader(false);
      } else if (Date.now() - currentTime > 15000) {
        toastRef.current.showToast({
          messages: [
            `PIN Pad Reset has failed`,
            `(Attempt ${failedCount} of 3)`,
          ],
          status: 'warning',
        });
        setLoader(false);
        setFailedCount(failedCount + 1);
        clearInterval(intervel);
      }
    }, 1000);
  };

  const pinpadReset = () => {
    if (loader) return;
    if (failedCount > 3) {
      alertModalRef.current.onModalOpen();
      return;
    }

    toastRef.current.showToast({
      messages: ['PIN Pad reset initiated'],
      status: 'info',
    });

    setLoader(true);
    ws?.socket?.send(
      '/app/pinpad/reset',
      {},
      JSON.stringify({
        messageHeader: {
          timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
          messageType: 'event',
          correlationId: paymentTransactionId,
          source: {
            sourceType: 'POS',
            sourceIdentifier: '1',
            version: process.env.REACT_APP_VERSION,
          },
          destination: {
            destinationType: 'PINPAD',
            destinationIdentifier: '1',
          },
        },
        messageBody: {
          message: 'PINPAD_RESET',
        },
      })
    );
    setTimeout(() => {
      pinpadResetTimeout();
    }, 2000);
  };

  const onItemClick = item => {
    if (loader) return;
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    setSelectedItem(item);
    switch (item?.name?.toLowerCase()) {
      case 'pinpadreset':
        pinpadReset();
        break;
      case 'exit':
        history.push('/home');
        break;
      default:
        break;
    }
  };

  return (
    <>
      <Toast ref={toastRef} />
      <Flex className={Styles.container}>
        <AlertModal
          ref={alertModalRef}
          header={{ name: `PIN Pad Reset Failure`, icon: RedInfo }}
          body={`The PIN Pad has failed to reset 3 consecutive times. Please call the
            HELP DESK for a replacement PIN Pad.`}
        />
        <Flex className={Styles.keypadContainer}>
          <Keypad disableDecimal />
        </Flex>

        <Grid className={Styles.gridView}>
          {items.map((functionItem, index) => (
            <MaintenanceItem
              key={`${functionItem.name}_${index}`}
              functionItem={functionItem}
              selectedItem={selectedItem}
              onItemClick={onItemClick}
              isExit={functionItem?.name?.toLowerCase() === 'exit'}
            />
          ))}
        </Grid>
      </Flex>
    </>
  );
};
