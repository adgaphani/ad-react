import React, { useState, useContext, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Flex, Grid } from '@chakra-ui/react';
import MaintenanceItem from '../../Common/grid-item/GridItem';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import { cartActions } from '../../../slices/cart.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { AppContext } from '../../../AppContext';
import Styles from './POSOperatorMenu.module.css';
import { useFuel, usePrivileges } from '../../../hooks';
import { KeysUtil } from '../../../Utils';

export default function POSOperatorMenu() {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const [selectedItem, setSelectedItem] = useState({});
  const { isIntegratedFuelStore } = useFuel();
  const { keyPressSound, showInvalidKeySelection } = useContext(AppContext);
  const allItems = location?.state?.items || [];
  const items = KeysUtil.getAllKeysFromInput({
    inputKeys: allItems,
    maxKeyCount: 24,
  });
  const { isValidUserFunction } = usePrivileges();
  const { isFunctionSecurityTriggered, iFunctionSecurityData } = useSelector(
    state => ({
      isFunctionSecurityTriggered: state.cart.isFunctionSecurityTriggered,
      iFunctionSecurityData: state.cart.iFunctionSecurityData,
    })
  );

  const onItemClick = item => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    let isUserHavePermission = true;
    if (isFunctionSecurityTriggered === '') {
      isUserHavePermission = isValidUserFunction(item?.name?.toLowerCase());
    } else {
      dispatch(cartActions.setFunctionSecurityTriggered(''));
    }
    if (!isUserHavePermission) {
      dispatch(cartActions.setFunctionSecurityData(item));
      history.push({
        pathname: '/home/functionSecurity',
        redirectionData: {
          pathname: '/home/operatormenu',
          state: {
            items: allItems,
          },
        },
        triggerFrom: 'operMenu',
        iFunctionName: item?.name?.toLowerCase(),
      });
      return;
    }
    setSelectedItem(item);
    switch (item.name?.toLowerCase()) {
      case 'pumpmaintenance':
        if (!isIntegratedFuelStore) {
          return showInvalidKeySelection(item.name);
        }
        history.push({
          pathname: '/home/pumpmaintenance',
          state: {
            items: item?.keys || item?.subKeys || [],
          },
        });
        break;
      case 'networkmaintenance':
        if (item?.keys?.length || item?.subKeys?.length) {
          history.push({
            pathname: '/home/networkMaintenance',
            search: `?itemId=${Date.now()}`,
            state: {
              items: item?.keys || item?.subKeys || [],
            },
          });
        }

        break;
      case 'exit':
        dispatch(dailpadActions.resetKeypadValue());
        history.push('/home');
        break;
      default:
        console.log('Not a valid action');
    }
  };

  useEffect(() => {
    if (
      isFunctionSecurityTriggered === 'operMenu' &&
      iFunctionSecurityData !== null
    ) {
      const item = iFunctionSecurityData;
      dispatch(cartActions.setFunctionSecurityData(null));
      onItemClick(item);
    }
  }, [isFunctionSecurityTriggered]);

  return (
    <Flex className={Styles.container}>
      <Flex className={Styles.keypadContainer}>
        <Keypad disableDecimal />
      </Flex>
      <Grid className={Styles.gridView}>
        {items.map((functionItem, index) => (
          <MaintenanceItem
            key={`${functionItem.name}_${index}`}
            functionItem={functionItem}
            selectedItem={selectedItem}
            onItemClick={onItemClick}
            isExit={functionItem?.name?.toLowerCase() === 'exit'}
          />
        ))}
      </Grid>
    </Flex>
  );
}
