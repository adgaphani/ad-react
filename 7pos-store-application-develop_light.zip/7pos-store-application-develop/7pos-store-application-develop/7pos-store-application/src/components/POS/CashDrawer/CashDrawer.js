import React, { useEffect, useState } from 'react';
import { Flex, Box, Text } from '@chakra-ui/react';
import { useSelector, useDispatch } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';

import Error_Node from '../../../Icons/Error_Node.svg';
import { cartActions } from '../../../slices/cart.slice';
import { socketActions } from '../../../slices/socket.slice';
import { peripheralActions } from '../../../slices/peripheral.slice';
import { getDVR } from '../../../hardware/dvr';

const CashDrawer = () => {
  const { cashDrawerStatus, isSafeCashDrwrOpen, user } = useSelector(state => ({
    cashDrawerStatus: state.socket.cashDrawerStatus,
    isSafeCashDrwrOpen: state.cart.isSafeCashDrwrOpen,
    user: state.auth.user,
  }));
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  // #8466 locally added cash drawer status to update page
  const [icashDrawerStatus, setiCashDrawerStatus] = useState(cashDrawerStatus);

  const params = new URLSearchParams(location.search);
  const status = params.get('status');

  useEffect(() => {
    let isTimer = null;
    setiCashDrawerStatus(cashDrawerStatus);
    if (
      (cashDrawerStatus === 'CD_ALARM_OFF' &&
        location.pathname.includes('/payment/cashDrawer')) ||
      (cashDrawerStatus === 'CD_CLOSED' && status === 'noSale')
    ) {
      dispatch(cartActions.setSafeCashDrwerOpen(false));
      dispatch(peripheralActions.setIsPIPOCashDrwrOpen(false));
      if (status === 'noSale') {
        dispatch(cartActions.emptyCart());
        dispatch(socketActions.setCashBack(null));
        isTimer = setTimeout(() => {
          dispatch(socketActions.setCashDrawerStatus(null));
          getDVR().setDrawerStatus(null, user);
          history.replace('/home');
        }, 250);
      } else {
        dispatch(socketActions.setCashDrawerStatus(null));
        getDVR().setDrawerStatus(null, user);
        // dispatch(cartActions.setSafeCashDrwerOpen(false));
      }
    } else if (cashDrawerStatus === 'CD_ALARM_OFF' && isSafeCashDrwrOpen) {
      dispatch(cartActions.setSafeCashDrwerOpen(false));
      dispatch(peripheralActions.setIsPIPOCashDrwrOpen(false));
    }
    return () => {
      clearTimeout(isTimer);
    };
  }, [cashDrawerStatus, isSafeCashDrwrOpen]);

  return (
    <Box
      justifyContent="space-between"
      height="calc(100vh - 128px)"
      py="0.5rem"
    >
      <Flex
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        height="100%"
        width="100%"
        bg="rgb(255,255,255)"
      >
        {icashDrawerStatus === 'CD_ALARM_ON' && (
          <Box textAlign="center">
            <img src={Error_Node} alt="Error_Node" height="40px" width="40px" />
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Medium"
              fontSize="24px"
              fontWeight="500"
              mt=".75rem"
            >
              Cash Drawer Open Too Long
            </Text>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Regular"
              fontSize="18px"
              fontWeight="normal"
              mt=".75rem"
            >
              Please close cash drawer to start a new transaction
            </Text>
          </Box>
        )}
        {status === 'noSale' && icashDrawerStatus !== 'CD_ALARM_ON' && (
          <Flex
            flexDirection="column"
            justifyContent="space-between"
            height="100%"
            width="100%"
            bg="rgb(255,255,255)"
          >
            <Flex
              justifyContent="center"
              alignItems="center"
              flexDirection="column"
              height="100%"
            >
              <Text
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
                lineHeight="32px"
                fontSize="24px"
                textAlign="center"
              >
                Cash Drawer is open and No Sale
              </Text>
              <Text
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-Bold"
                fontWeight="bold"
                lineHeight="32px"
                fontSize="24px"
                textAlign="center"
              >
                transaction recorded
              </Text>
            </Flex>
          </Flex>
        )}
      </Flex>
    </Box>
  );
};

export default CashDrawer;
