import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { Flex, Text } from '@chakra-ui/react';
import Styles from './Itemgroup.module.css';
import { AppContext } from '../../../AppContext';

const itemCategory = props => {
  const { items, selected, onSelectCategory } = props;
  const { keyPressSound } = useContext(AppContext);
  return (
    <Flex marginLeft="7px" my="20px">
      {items.map((item, index) => (
        <Flex
          key={`item-category-${index}`}
          background={
            selected === item.id ? 'rgb(16, 127, 98)' : 'rgb(255, 255, 255)'
          }
          borderRadius="20px"
          height="40px"
          width="100px"
          mr="20px"
          alignItems="center"
          justifyContent="center"
          className={Styles.textHide}
          onClick={() => {
            keyPressSound?.play?.().catch(e => console.log('Sound error', e));
            selected !== item.id && onSelectCategory(item.id);
          }}
        >
          <Text
            color={
              selected === item.id ? 'rgb(255, 255, 255)' : 'rgb(44, 47, 53)'
            }
            fontFamily="Roboto-Medium"
            fontSize="16px"
            fontWeight="500"
          >
            {item.label}
          </Text>
        </Flex>
      ))}
    </Flex>
  );
};

itemCategory.defaultProps = {
  items: [],
  selected: 0,
  onSelectCategory: () => null,
};

itemCategory.propTypes = {
  items: PropTypes.array,
  selected: PropTypes.number,
  onSelectCategory: PropTypes.func,
};

export default itemCategory;
