import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import PropTypes from 'prop-types';

import ItemCategory from './ItemCategories';
import ItemGroup from './ItemGroup';

const ItemGroupContainer = ({ onItemClick }) => {
  const location = useLocation();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [categoryList, setCategoryList] = useState([]);
  const [selectedCategoryData, setSelectedCategoryData] = useState([]);

  useEffect(() => {
    const items = location?.state?.items || [];
    if (items.length > 0) {
      setSelectedCategory(items[0].id);
      setCategoryList(items);
      const filteredData = items[0].subKeys.filter(
        sItem => sItem.name !== 'EXIT'
      );
      setSelectedCategoryData(filteredData);
    }
  }, []);
  const onSelectCategory = id => {
    setSelectedCategory(id);
    const categoryIndex = categoryList.findIndex(cItem => cItem.id === id);
    const filteredData = categoryList[categoryIndex].subKeys.filter(
      sItem => sItem.name !== 'EXIT'
    );
    setSelectedCategoryData(filteredData);
  };
  return (
    <>
      <ItemCategory
        items={categoryList}
        selected={selectedCategory}
        onSelectCategory={onSelectCategory}
      />
      <ItemGroup
        items={selectedCategoryData}
        onItemClick={onItemClick}
        isGroupView={false}
        minItems={29}
      />
    </>
  );
};

ItemGroupContainer.defaultProps = {
  onItemClick: () => null,
};

ItemGroupContainer.propTypes = {
  onItemClick: PropTypes.func,
};

export default ItemGroupContainer;
