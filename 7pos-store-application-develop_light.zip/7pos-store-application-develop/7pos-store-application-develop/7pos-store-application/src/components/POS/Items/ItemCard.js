import React, { useContext } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import Styles from './Itemgroup.module.css';
import { getTitle } from '../../../Utils/cartUtils';
import { ItemImage } from './ItemImage';
import { AppContext } from '../../../AppContext';

export const ItemCard = ({ item, className, onItemClick }) => {
  const { keyPressSound, isSafeReady } = useContext(AppContext);
  const disableSafe =
    item?.name?.toLowerCase()?.indexOf('safe') > -1 && !isSafeReady;
  const isActive = !item?.isActive || !item?.id;
  const classes = !item?.id ? `${className}  Itemgroup_noBorder` : className;
  const isDisabled =
    (disableSafe || isActive) && !location.pathname.includes('prepaid');
  return (
    <Box
      m={1}
      key={item.sequenceNumber}
      className={classes}
      onClick={() => {
        if (isDisabled) {
          return;
        }
        item?.name &&
          keyPressSound?.play?.().catch(e => console.log('Sound error', e));
        onItemClick(item);
      }}
      cursor={isDisabled ? 'not-allowed' : 'pointer'}
      opacity={isDisabled ? 0.3 : 1}
    >
      <Flex height="100%" alignItems="center" direction="column" pt=".75rem">
        <ItemImage type={item.type} item={item} />
        <Box width="100%">
          <Flex
            direction="column"
            lineHeight="14px"
            className={Styles.textHide}
          >
            <Text className={Styles.itemTitle}>{getTitle(item)}</Text>
          </Flex>
        </Box>
      </Flex>
    </Box>
  );
};

ItemCard.defaultProps = {
  item: {},
  className: '',
  onItemClick: () => null,
};

ItemCard.propTypes = {
  item: PropTypes.object,
  className: PropTypes.string,
  onItemClick: PropTypes.func,
};
export default ItemCard;
