/* eslint-disable no-plusplus */
import React, { useContext } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';

import Exit from '../../../Icons/Exit.svg';
import NextActive from '../../../Icons/NextActive.svg';
import NextInActive from '../../../Icons/NextInActive.svg';
import PrevActive from '../../../Icons/PrevActive.svg';
import PrevInActive from '../../../Icons/PrevInActive.svg';
import Styles from './Itemgroup.module.css';
import { ItemCard } from './ItemCard';
import { AppContext } from '../../../AppContext';

const ItemGroup = ({
  items = [],
  onItemClick,
  minItems = items?.length,
  borderClass = '',
  isGroupView = true,
  isNextBtnEnable = false,
  isPreviousBtnEnable = false,
  onNextBtnClick = () => {},
  onPreviousBtnClick = () => {},
  onExit: onPropsExit = undefined,
}) => {
  const location = useLocation();
  const history = useHistory();
  const { keyPressSound } = useContext(AppContext);
  let emptyGrid = [];
  let isItemListView = !isGroupView || location.pathname.includes('prepaid');
  const itemList =
    (items && items.length
      ? items
      : isItemListView
      ? []
      : location?.state?.items) || [];
  const params = new URLSearchParams(location.search);

  let enableExtraBtn = false;
  if (params.get('itemId') || minItems > 0) {
    let totalItems = itemList.length;
    if (
      location.pathname.includes('prepaid') &&
      (isNextBtnEnable || isPreviousBtnEnable)
    ) {
      enableExtraBtn = true;
      totalItems += 2;
    }

    if (totalItems === minItems) {
      emptyGrid = [];
    } else if (totalItems < minItems) {
      const noofEmptygrids = minItems - totalItems;
      emptyGrid = Array.from(Array(noofEmptygrids)).map((_, i) => ({
        value: i + 1,
      }));
    }
  }
  if (!location.pathname.includes('prepaid')) {
    isItemListView = !!params.get('itemId');
  }

  const getSortedItems = itemlist => {
    const sortedItems = itemlist?.sort(
      (a, b) => a.sequenceNumber - b.sequenceNumber
    );
    if (sortedItems) {
      let counter = 1;
      return sortedItems.map((item, index) => {
        // #5245 only update borderClass first time
        if (!item?.borderClass) {
          if (item?.type?.toLowerCase() === 'group') {
            item.borderClass = Styles[`borderBottomRow${counter}`];
            if ((index + 1) % 4 === 0) counter++;
          } else if (borderClass) {
            item.borderClass = borderClass;
          } else {
            item.borderClass = Styles.borderBottomRow;
          }
        }
        return item;
      });
    }
  };

  const onExit = async () => {
    await keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (onPropsExit) {
      onPropsExit();
      return;
    }
    if (params.get('itemId')) {
      // history.goBack();
      history.push('/home');
    } else history.push('/home');
  };
  const sortedItems = getSortedItems(itemList);

  return (
    <Flex wrap="wrap" className="item-group">
      {sortedItems &&
        sortedItems.map((item, index) => (
          <Flex key={index}>
            {!item.name && !location.pathname.includes('prepaid') ? (
              <Box
                key={index}
                m={1}
                className={isItemListView ? Styles.itemEmpty : Styles.itemGroup}
              />
            ) : item.type?.toLowerCase() === 'group' ? (
              <ItemCard
                item={item}
                className={`${Styles.itemGroup}  ${Styles.borderBottomRow}  ${item.borderClass}`}
                onItemClick={onItemClick}
              />
            ) : (
              <ItemCard
                item={item}
                className={`${Styles.item} ${Styles.borderBottomRow} ${item.borderClass}`}
                onItemClick={onItemClick}
              />
            )}
          </Flex>
        ))}
      {emptyGrid.map(e => (
        <Box
          key={e.value}
          m={1}
          className={isItemListView ? Styles.item : Styles.itemGroup}
        />
      ))}
      {enableExtraBtn && (
        <>
          <Box
            m={1}
            mb="24px"
            className={`${Styles.item} ${!isPreviousBtnEnable &&
              Styles.itemDisabled}`}
            onClick={onPreviousBtnClick}
          >
            <Flex
              height="100%"
              justifyContent="center"
              alignItems="center"
              direction="column"
            >
              <Box>
                <img
                  src={!isPreviousBtnEnable ? PrevInActive : PrevActive}
                  alt="Exit"
                  height="50px"
                  width="50px"
                />
              </Box>
            </Flex>
          </Box>
          <Box
            m={1}
            mb="24px"
            className={`${Styles.item} ${!isNextBtnEnable &&
              Styles.itemDisabled}`}
            onClick={onNextBtnClick}
          >
            <Flex
              height="100%"
              justifyContent="center"
              alignItems="center"
              direction="column"
            >
              <Box>
                <img
                  src={!isNextBtnEnable ? NextInActive : NextActive}
                  alt="Exit"
                  height="50px"
                  width="50px"
                />
              </Box>
            </Flex>
          </Box>
        </>
      )}
      {isItemListView && (
        <Box m={1} mb="24px" className={Styles.item} onClick={onExit}>
          <Flex
            height="100%"
            justifyContent="center"
            alignItems="center"
            direction="column"
          >
            <Box>
              <img src={Exit} alt="Exit" height="24px" width="24px" />
            </Box>
            <Text
              color="rgb(91, 97, 107)"
              fontFamily="Roboto-Medium"
              fontSize="18px"
              fontWeight="500"
            >
              EXIT
            </Text>
          </Flex>
        </Box>
      )}
    </Flex>
  );
};

export default ItemGroup;
