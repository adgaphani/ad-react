import { Box } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import { getItemIcon } from '../../../Utils/itemCardLogoUtils';
import { loadPrepaidCardImage } from '../../../Utils/prepaidlogoUtils';

const IMG_TOEKN =
  '722852f45616a6ecdd7319061179bdc32fccd4dfa3cec451ccbfe3cbac7ece';
export const ItemImage = ({ item, type = '' }) => {
  const imgProps = {
    height: '23px',
    width: '24px',
  };

  const isCanada = useSelector(
    state => state.main.storeDetails?.address?.country === 'CA'
  );
  let imageName = '';
  let isPrePaidCard = false;
  if (location.pathname.includes('prepaid')) {
    if (type !== 'item') {
      imageName = loadPrepaidCardImage(isCanada, item?.label);
      isPrePaidCard = true;
      imgProps.height = '100px';
      imgProps.width = '100px';
    }
  }
  const getThubnailImage = item => `${item?.thumbnail}?${IMG_TOEKN}`;

  const label = item?.label || item?.label1 || '';
  if (type?.toLowerCase() !== 'group') {
    // delete imgProps.width;
    imgProps.height = '49px';
    imgProps.width = '49px';
  }

  if (type?.toLowerCase() === 'group') {
    delete item.thumbnail;
  }

  if (item.name === 'Media Exchange') {
    // imgProps.height = '40px';
    imgProps.width = '38px';
  }

  if (item.name === 'US Dollar') {
    // imgProps.height = '40px';
    imgProps.width = '25px';
  }

  return (
    <Box>
      {!item.thumbnail && label ? (
        <img
          src={
            isPrePaidCard && imageName !== ''
              ? imageName
              : getItemIcon(item?.name)
          }
          alt={item?.label1 || ''}
          {...imgProps}
        />
      ) : label !== '' ? (
        <img src={getThubnailImage(item)} alt={label} {...imgProps} />
      ) : (
        ''
      )}
    </Box>
  );
};

ItemImage.defaultProps = {
  item: {},
  type: '',
};

ItemImage.propTypes = {
  item: PropTypes.object,
  type: PropTypes.string,
};

export default ItemImage;
