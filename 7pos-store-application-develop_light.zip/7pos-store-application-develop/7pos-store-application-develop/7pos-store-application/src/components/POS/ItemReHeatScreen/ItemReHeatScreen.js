import { Flex, Text, Box } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import ExitButton from '../ExitButton';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';

const ItemReHeatScreen = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const item = location?.state?.item;
  const upc = location?.state?.upc;
  const onExit = () => {
    dispatch(cartActions.addToCart({ ...item, upc }));
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cfdActions.setUserActionScreenActive(false));
    dispatch(dailpadActions.resetKeypadValue());
    global?.logger?.info(
      `[7POS UI] - RestrictionCode:6 item added to the cart`
    );
    history.replace('/home');
  };

  useEffect(() => {
    dispatch(cartActions.setFinalizePayStatus(true));
    dispatch(cfdActions.setUserActionScreenActive(true));
    return () => {};
  }, []);

  return (
    <Box h="calc(100vh - 100px)" p="0.5rem">
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        height="100%"
        bg="rgb(255,255,255)"
      >
        <>
          <Flex
            flexDirection="column"
            aliginItems="center"
            justifyContent="flex-end"
            mt="140px"
            height="200px"
          >
            <Text
              color="rgb(67, 69, 80)"
              fontSize="24px"
              fontFamily="Roboto-Bold"
              fontWeight="bold"
              textAlign="center"
              my="30px"
            >
              Please complete transaction before reheating!
            </Text>
          </Flex>
          <Box display="block" textAlign="right" p="2rem" w="100%">
            <ExitButton onClick={onExit} />
          </Box>
        </>
      </Flex>
    </Box>
  );
};

export default ItemReHeatScreen;
