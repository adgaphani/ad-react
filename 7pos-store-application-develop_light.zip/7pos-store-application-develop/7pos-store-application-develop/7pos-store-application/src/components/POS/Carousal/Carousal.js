/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */

import React, { useState } from 'react';

import Styles from './Carousal.module.css';
import useIntervel from '../../../hooks/useIntervel';

function Carousal(props) {
  const [currentSlide, setCurrentSlider] = useState(0);
  useIntervel(() => {
    if (currentSlide < props.images.length - 1) {
      setCurrentSlider(currentSlide + 1);
    } else {
      setCurrentSlider(0);
    }
  }, 1500);
  return (
    <div className={Styles.slideContainer}>
      {props.images?.map((slide, index) => (
        <div
          className={Styles.slide}
          key={index}
          style={{
            left: `${index * 100}%`,
            transform: `translateX(-${currentSlide * 100}%)`,
          }}
        >
          <img
            height="131px"
            width="110px"
            src={slide.image}
            alt={slide.name}
          />
        </div>
      ))}
    </div>
  );
}

export default Carousal;
