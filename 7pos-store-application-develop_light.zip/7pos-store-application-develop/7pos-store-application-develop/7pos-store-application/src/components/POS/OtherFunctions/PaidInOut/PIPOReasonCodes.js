import React, { useEffect, useState, useContext } from 'react';
import { Flex, Grid, Text } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import Styles from './PIPOReasonCodes.module.css';
import { PIPOExitButton } from './ExitButton';
import { getStoreConfiguration } from '../../../../api/storeConfiguration';
import { AppContext } from '../../../../AppContext';

export const PIPOReasonCodes = ({ isPaidIn, onExit, onSelectReasonCode }) => {
  const [selectedOption, setSelectedOption] = useState('');
  const [reasonCodes, setReasonCodes] = useState([]);
  const { keyPressSound, showInvalidKeySelection } = useContext(AppContext);
  const { cartItems, paymentTransactionId } = useSelector(state => ({
    cartItems: state.cart.cartItems,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));
  const isMerchandiseInProgress = cartItems?.length > 0;

  const onClickPIPOOption = reason => {
    if (!reason?.shortDescription) {
      return;
    }
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (isMerchandiseInProgress) {
      showInvalidKeySelection(isPaidIn ? Messages.paid_in : Messages.paid_out);
    }
    setSelectedOption(reason);
    onSelectReasonCode(isPaidIn, reason);
  };

  const fetchReasonCodes = () => {
    getStoreConfiguration(
      isPaidIn ? 'paid_in_reason' : 'paid_out_reason',
      paymentTransactionId
    )
      .then(response => {
        const reasonArray = response.data.map(
          ({ id, description, shortDescription }) => ({
            id,
            description,
            shortDescription,
          })
        );
        setReasonCodes(reasonArray);
      })
      .catch(() => {
        global?.logger?.error(`[7POS UI] - fetch reason codes Error`);
      });
  };

  const isSelected = reasonCode => reasonCode?.id === selectedOption?.id;

  useEffect(() => {
    fetchReasonCodes();
  }, [reasonCodes.length]);

  return (
    <Flex className={Styles.wrapper}>
      <Grid className={Styles.optionsGrid}>
        <Text className={Styles.pageTitle}>
          {`Select Paid ${isPaidIn ? 'In' : 'Out'}`}
        </Text>
        {reasonCodes.map((rc, index) => (
          <Flex
            className={`${Styles.gridItem} ${
              isSelected(rc) ? Styles.gridItemSelected : ''
            }`}
            key={index.toString()}
            onClick={() => onClickPIPOOption(rc)}
          >
            <Text fontFamily="Roboto-bold" fontSize="20px" fontWeight="bold">
              {rc?.shortDescription}
            </Text>
          </Flex>
        ))}
      </Grid>
      <Flex className={Styles.exitWrapper}>
        <PIPOExitButton onExit={onExit} mb={0} mr={0} />
      </Flex>
    </Flex>
  );
};
