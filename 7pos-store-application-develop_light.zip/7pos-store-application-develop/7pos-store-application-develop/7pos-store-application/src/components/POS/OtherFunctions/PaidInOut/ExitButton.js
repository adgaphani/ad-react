import { Text } from '@chakra-ui/react';
import React from 'react';
import { Button } from '../../../Common/Buttons';
import Styles from './PaidInOutParent.module.css';

export const PIPOExitButton = ({ onExit, mb = 15, mr = 15 }) => (
  <Button
    alignSelf="flex-end"
    onClick={onExit}
    className={Styles.exitButton}
    mb={mb}
    mr={mr}
  >
    <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
      EXIT
    </Text>
  </Button>
);
