import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { Route, Switch, useHistory, useRouteMatch } from 'react-router-dom';
import React, { useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '../../../Common';
import Styles from './PaidInOutParent.module.css';
import { PIPOExitButton } from './ExitButton';
import { PIPOReasonCodes } from './PIPOReasonCodes';
import { cashFunctionActions } from '../../../../slices/cashFunctions.slice';
import { TransactionTypes } from '../../../../TransactionTypes';
import { AppContext } from '../../../../AppContext';

const PaidInOutParent = () => {
  const { path } = useRouteMatch();
  const history = useHistory();
  const dispatch = useDispatch();
  const { showInvalidKeySelection } = useContext(AppContext);
  const { cartItems } = useSelector(state => ({
    cartItems: state.cart.cartItems,
  }));
  const isMerchandiseInProgress = cartItems?.length > 0;

  const onExit = () => {
    history.push('/home');
  };

  const onPaidInClick = () => {
    if (isMerchandiseInProgress) {
      return showInvalidKeySelection(Messages.paid_in);
    }
    history.push('/home/PaidInOutParent/PaidIn');
  };

  const onPaidOutClick = () => {
    if (isMerchandiseInProgress) {
      return showInvalidKeySelection(Messages.paid_out);
    }
    history.push('/home/PaidInOutParent/PaidOut');
  };

  const onSelectReasonCode = (isPaidIn, reasonCode) => {
    dispatch(
      cashFunctionActions.initiatePIPOTransaction({
        transactionType: isPaidIn
          ? TransactionTypes.paidIn
          : TransactionTypes.paidOut,
        displayLabel: isPaidIn ? 'Paid In' : 'Paid Out',
        shortLabel: isPaidIn ? 'PI' : 'PO',
        reason: reasonCode,
        multiplicationFactor: isPaidIn ? 1 : -1,
      })
    );
    history.push('/payment');
  };

  const isPaidInOrPaidOut = !history?.location?.pathname.endsWith(
    'PaidInOutParent'
  );
  return (
    <Box
      className={`${Styles.paidInOutContainer} ${
        !isPaidInOrPaidOut ? Styles.hasBackground : ''
      }`}
    >
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex flexDirection="column">
              <Heading
                textAlign="center"
                justifyContent="center"
                // color="rgb(111, 110, 127)"
                mt={46}
              >
                Select One
              </Heading>
              <Flex
                flexDirection="column"
                alignItems="center"
                my={4}
                w="52%"
                m="1em auto"
              >
                <Button
                  size="lg"
                  className="btn optionButton"
                  color="rgb(255, 255, 255)"
                  border="1px solid rgb(16, 127, 98)"
                  width="360px"
                  h="50px"
                  m={3}
                  onClick={onPaidInClick}
                >
                  <Text
                    fontFamily="Roboto-bold"
                    fontSize="18px"
                    fontWeight="bold"
                  >
                    Paid In
                  </Text>
                </Button>
                <Button
                  size="lg"
                  className="btn optionButton"
                  color="rgb(255, 255, 255)"
                  border="1px solid rgb(16, 127, 98)"
                  width="360px"
                  h="50px"
                  m={3}
                  onClick={onPaidOutClick}
                >
                  <Text
                    fontFamily="Roboto-bold"
                    fontSize="18px"
                    fontWeight="bold"
                  >
                    Paid Out
                  </Text>
                </Button>
              </Flex>
            </Flex>
            <PIPOExitButton onExit={onExit} />
          </Route>
          <Route path={`${path}/PaidIn`}>
            <PIPOReasonCodes
              isPaidIn
              onExit={onExit}
              onSelectReasonCode={onSelectReasonCode}
            />
          </Route>
          <Route path={`${path}/PaidOut`}>
            <PIPOReasonCodes
              onExit={onExit}
              onSelectReasonCode={onSelectReasonCode}
            />
          </Route>
        </Switch>
      </Flex>
    </Box>
  );
};

export default PaidInOutParent;
