import React from 'react';
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import {
  MOM_NOT_INTEGRATED,
  MOM_PING_SUCCESS,
  SAFE_LOCK_SUCCESS,
  SAFE_NOT_ENABLED,
} from '../../../constants';

export default function EODSConfirmation({
  safeAvailable,
  momAvailable,
  EOD,
  isOpen,
  onClose,
  onConfirm,
}) {
  const getBodyText = () => {
    const safeIntergrated = safeAvailable !== SAFE_NOT_ENABLED ? 1 : 0;
    const momIntegrated = momAvailable !== MOM_NOT_INTEGRATED ? 1 : 0;

    const safeNotAvailable =
      safeIntergrated && safeAvailable !== SAFE_LOCK_SUCCESS ? 1 : 0;
    const momNotAvailable =
      momIntegrated && momAvailable !== MOM_PING_SUCCESS ? 1 : 0;
    if (safeNotAvailable && momNotAvailable && EOD)
      return 'If you proceed now, SAFE totals needs to be manually reconciled.';
    if (safeNotAvailable)
      return 'If you proceed now, SAFE totals needs to be manually reconciled.';
    if (momNotAvailable && EOD)
      return 'If you proceed now, Money Order totals will reconcile at the next end of day.';
  };
  return (
    <>
      <ConfirmModal
        header="Are You Sure?"
        isOpen={isOpen}
        onClose={onClose}
        onYes={onConfirm}
        showCancelButton
        confirmText="Yes - Proceed"
        cancelText="No - Go Back"
        body={getBodyText()}
      />
    </>
  );
}
