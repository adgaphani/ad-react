import React from 'react';
import { Flex } from '@chakra-ui/react';

export const MenuBarSpace = () => (
  <Flex height="40px" backgroundColor="#000000" />
);
