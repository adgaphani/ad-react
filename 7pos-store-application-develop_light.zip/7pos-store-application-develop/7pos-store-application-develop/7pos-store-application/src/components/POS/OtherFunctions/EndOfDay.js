import React from 'react';
import { Text, Flex, HStack } from '@chakra-ui/react';
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import Icon_Available from '../../../Icons/OtherFunctions/Available.svg';
import Icon_Busy from '../../../Icons/OtherFunctions/Busy.svg';
import Icon_Info from '../../../Icons/warning_yellow.svg';
import FlexStyle from '../ConfirmModal/ConfirmModal.module.css';
import {
  MOM_NOT_INTEGRATED,
  MOM_PING_SUCCESS,
  SAFE_LOCK_SUCCESS,
  SC_SAFE_LOCK_FAILED,
  SAFE_NOT_ENABLED,
  WAITING_FOR_SC_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SC_MOM_LOCK_RESPONSE,
  WAITING_FOR_MOM_PING_RESPONSE,
  MOM_PING_FAILED,
  SC_MOM_LOCK_FAILED,
} from '../../../constants';

export default function EndOfDay({
  safeAvailable,
  momAvailable,
  onClose,
  onConfirm,
  isOpen,
  onRetry,
  showRetryButton,
  modalType,
}) {
  const getHeaderText = () => {
    if (modalType === 'Confirmation') return 'END OF DAY CONFIRMATION';
    if (modalType === 'In Process') return 'END OF DAY IN PROCESS';
    if (modalType === 'Not Allowed') return 'END OF DAY NOT ALLOWED';
  };
  const getBodyText = () => {
    if (modalType === 'Confirmation')
      return 'You have selected End of Day. This should be completed only once per day. Are you sure?';
    if (modalType === 'In Process')
      return 'End of Day is still processing. You will need to wait until it is complete. Try it again within 1 hour.';
    if (modalType === 'Not Allowed')
      return 'Too soon from the previous End of Day.';
  };
  const getSafeText = () => {
    if (modalType === 'Confirmation') {
      if (safeAvailable === SAFE_NOT_ENABLED || safeAvailable === null) return;

      let Msg = 'Safe is offline';
      let Icon = Icon_Busy;
      if (
        safeAvailable === WAITING_FOR_SC_SAFE_LOCK_RESPONSE ||
        safeAvailable === WAITING_FOR_SAFE_LOCK_RESPONSE
      ) {
        Msg = 'Trying to connect to SAFE';
        Icon = Icon_Info;
      } else if (safeAvailable === SAFE_LOCK_SUCCESS) {
        Msg = 'SAFE is ready';
        Icon = Icon_Available;
      } else if (safeAvailable === SC_SAFE_LOCK_FAILED) {
        Msg = 'SAFE is busy, please try again later';
        Icon = Icon_Info;
      }

      const safeFormat = (
        <HStack spacing="20px">
          <img src={Icon} alt="" />
          <Text fontSize="16px">{Msg}</Text>
        </HStack>
      );

      return <Flex className={FlexStyle.flex}>{safeFormat}</Flex>;
    }
  };
  const getMomText = () => {
    if (modalType === 'Confirmation') {
      if (momAvailable === MOM_NOT_INTEGRATED || momAvailable === null) return;

      let Msg = 'Money Order is offline';
      let Icon = Icon_Busy;

      if (
        momAvailable === WAITING_FOR_SC_MOM_LOCK_RESPONSE ||
        momAvailable === WAITING_FOR_MOM_PING_RESPONSE
      ) {
        Msg = 'Trying to connect to Money Order Machine';
        Icon = Icon_Info;
      } else if (momAvailable === MOM_PING_SUCCESS) {
        Msg = 'Money Order is ready';
        Icon = Icon_Available;
      } else if (momAvailable === SC_MOM_LOCK_FAILED) {
        Msg = 'Money Order is busy, please try again later';
        Icon = Icon_Info;
      }

      const momFormat =
        momAvailable === MOM_PING_FAILED ? (
          <HStack spacing="20px">
            <img src={Icon_Busy} alt="" />
            <div>
              <Text fontSize="16px">Money Order is offline</Text>
              <Text fontSize="14px">
                Ensure Money Order machine is available and ready
              </Text>
            </div>
          </HStack>
        ) : (
          <HStack spacing="20px">
            <img src={Icon} alt="" />
            <Text fontSize="16px">{Msg}</Text>
          </HStack>
        );
      return <Flex className={FlexStyle.flex}>{momFormat}</Flex>;
    }
  };
  const disableConfirmButton = () => {
    if (
      momAvailable === WAITING_FOR_SC_MOM_LOCK_RESPONSE ||
      momAvailable === WAITING_FOR_MOM_PING_RESPONSE ||
      safeAvailable === WAITING_FOR_SC_SAFE_LOCK_RESPONSE ||
      safeAvailable === WAITING_FOR_SAFE_LOCK_RESPONSE
    ) {
      return true;
    }
  };
  return (
    <>
      <ConfirmModal
        header={getHeaderText()}
        isOpen={isOpen}
        onClose={onClose}
        onYes={onConfirm}
        disable={modalType === 'Confirmation' ? disableConfirmButton() : false}
        showCancelButton={modalType === 'Confirmation'}
        confirmText={modalType === 'Confirmation' ? 'CONTINUE' : 'OK'}
        cancelText={modalType === 'Confirmation' ? 'CANCEL' : 'NO'}
        onRetry={onRetry}
        showRetryButton={modalType === 'Confirmation' ? showRetryButton : false}
        body={getBodyText()}
      >
        {getSafeText()}
        {getMomText()}
      </ConfirmModal>
    </>
  );
}
