import React from 'react';
import { Text, Flex, HStack } from '@chakra-ui/react';
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import Icon_Available from '../../../Icons/OtherFunctions/Available.svg';
import Icon_Busy from '../../../Icons/OtherFunctions/Busy.svg';
import Icon_Info from '../../../Icons/warning_yellow.svg';
import FlexStyle from '../ConfirmModal/ConfirmModal.module.css';
import {
  SC_SAFE_LOCK_FAILED,
  SAFE_LOCK_SUCCESS,
  SAFE_NOT_ENABLED,
  WAITING_FOR_SC_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SAFE_LOCK_RESPONSE,
} from '../../../constants';

export default function EndOfShift({
  safeAvailable,
  onClose,
  onConfirm,
  isOpen,
  onRetry,
  showRetryButton,
  modalType,
}) {
  const getHeaderText = () => {
    if (modalType === 'Confirmation') return 'END OF SHIFT CONFIRMATION';
    if (modalType === 'Not Allowed') return 'END OF SHIFT NOT ALLOWED';
  };
  const getBodyText = () => {
    if (modalType === 'Confirmation')
      return 'You have selected End of Shift. Are you sure?';
    if (modalType === 'Not Allowed')
      return 'Too soon from the previous End of Shift. Are you sure you want to end the shift?';
  };
  const getSafeText = () => {
    if (modalType === 'Confirmation') {
      if (safeAvailable === SAFE_NOT_ENABLED || safeAvailable === null) return;

      let Msg = 'Safe is offline';
      let Icon = Icon_Busy;
      if (
        safeAvailable === WAITING_FOR_SC_SAFE_LOCK_RESPONSE ||
        safeAvailable === WAITING_FOR_SAFE_LOCK_RESPONSE
      ) {
        Msg = 'Trying to connect to SAFE';
        Icon = Icon_Info;
      } else if (safeAvailable === SAFE_LOCK_SUCCESS) {
        Msg = 'SAFE is ready';
        Icon = Icon_Available;
      } else if (safeAvailable === SC_SAFE_LOCK_FAILED)
        Msg = 'SAFE is busy, please try again later';

      const safeFormat = (
        <HStack spacing="20px">
          <img src={Icon} alt="" />
          <Text fontSize="16px">{Msg}</Text>
        </HStack>
      );

      return <Flex className={FlexStyle.flex}>{safeFormat}</Flex>;
    }
  };
  const disableConfirmButton = () => {
    if (
      safeAvailable === WAITING_FOR_SC_SAFE_LOCK_RESPONSE ||
      safeAvailable === WAITING_FOR_SAFE_LOCK_RESPONSE
    ) {
      return true;
    }
  };
  return (
    <>
      <ConfirmModal
        header={getHeaderText()}
        isOpen={isOpen}
        onClose={onClose}
        onYes={onConfirm}
        disable={modalType === 'Confirmation' ? disableConfirmButton() : false}
        showCancelButton
        confirmText="CONTINUE"
        cancelText="CANCEL"
        onRetry={onRetry}
        showRetryButton={modalType === 'Confirmation' ? showRetryButton : false}
        body={getBodyText()}
      >
        {getSafeText()}
      </ConfirmModal>
    </>
  );
}
