/* eslint-disable max-lines */
/* eslint-disable no-else-return */
import { Flex, Grid, Text } from '@chakra-ui/react';
import React, { useState, useContext, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import EndOfDay from './EndOfDay';
import EndOfShift from './EndOfShift';
import { getOtherFunctionsIcons } from '../../../Utils/otherfunctionsUtils';
import { cartActions } from '../../../slices/cart.slice';
import EODSConfirmation from './EODSConfirmation';
import { useTimer } from '../../../hooks/useTimer';
import Styles from './otherFunction.module.css';
import { AppContext } from '../../../AppContext';
import {
  useSoundToast,
  useTransHold,
  useDayShiftChange,
  usePrivileges,
  useFuel,
  useCdbUtils,
} from '../../../hooks';
import {
  MOM_NOT_INTEGRATED,
  MOM_PING_SUCCESS,
  SAFE_LOCK_SUCCESS,
  SAFE_NOT_ENABLED,
  SC_MOM_LOCK_FAILED,
  SC_SAFE_LOCK_FAILED,
  SC_MOM_LOCK_ACQUIRED,
  SC_SAFE_LOCK_ACQUIRED,
  SAFE_LOCK_FAILED,
  MOM_PING_FAILED,
  SKIP_PROMO,
  WAITING_FOR_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SC_SAFE_LOCK_RESPONSE,
  WAITING_FOR_SC_MOM_LOCK_RESPONSE,
  WAITING_FOR_MOM_PING_RESPONSE,
  MO_FLG_INSALE,
} from '../../../constants';
import { peripheralActions } from '../../../slices/peripheral.slice';

export default function OtherFunctions() {
  const history = useHistory();
  const {
    handleDayOrShiftClose,
    sendSafeSCLockRequest,
    sendMOMSCLockRequest,
    safeReserveRequest,
    safeReserveCancel,
    sendMOMPingRequest,
    releaseStoreCordinatorLocks,
  } = useDayShiftChange();
  const [showEndOfDay, setShowEndOfDay] = useState(false);
  const eodModalType = 'Confirmation';
  const [showEndOfShift, setShowEndOfShift] = useState(false);
  const eosModalType = 'Confirmation';
  const [selectedItem, setSelectedItem] = useState('');
  const toast = useSoundToast();
  const { handleEOD, clearTransHoldCart } = useTransHold();
  const dispatch = useDispatch();
  const location = useLocation();
  const { keyPressSound, showInvalidKeySelection, showLoader } = useContext(
    AppContext
  );
  const { isValidUserFunction } = usePrivileges();
  const { checkPendingFuelRefunds } = useFuel();
  const { onCdbReport } = useCdbUtils();

  const [showEODSConfirmation, setShowEODSConfirmation] = useState(false);
  const [actionDayShift, setAction] = useState('');
  const {
    member,
    items,
    transactionId,
    cartItems,
    UserActionScreenActive,
    transactionMemory,
    balanceActive,
    isFunctionSecurityTriggered,
    iFunctionSecurityData,
    KeypadValue,
    isTransactionRefund,
    isTransactionVoid,
    isPromoInProgress,
    isTransactionTriggered,
    disableTransHoldFP,
    disableFinalizePay,
    safeLockStatus,
    momLockStatus,
    isCdbBtnAcive,
  } = useSelector(state => ({
    member: state.cart.member,
    items: state.cart.items,
    transactionId: state.cart.transactionId,
    cartItems: state.cart.cartItems,
    storeDetails: state.main.storeDetails,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    user: state.auth.user,
    transactionMemory: state.cart.transactionMemory,
    balanceActive: state.balance.isActive,
    isFunctionSecurityTriggered: state.cart.isFunctionSecurityTriggered,
    iFunctionSecurityData: state.cart.iFunctionSecurityData,
    KeypadValue: state.dailpad.keypad.value,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
    functionSecuirtyData: state.main.functionSecuirtyData,
    isPromoInProgress: state.cart.isPromoInProgress,
    isTransactionTriggered: state.cart.isTransactionTriggered,
    disableTransHoldFP: state.cart.disableTransHoldFP,
    disableFinalizePay: state.cart.disableFinalizePay,
    safeLockStatus: state.peripheral.safeLockStatus,
    momLockStatus: state.peripheral.momLockStatus,
    isCdbBtnAcive: state.main.isCdbBtnAcive,
  }));

  const isMerchandiseInProgress = cartItems?.length > 0;
  const { start, stop } = useTimer(180000, 'End of Day Shift Timer');

  const DisplayToastMsg = (MSG, position) => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: position || 'top',
    });
  };

  const otherFuncConfig = location?.state?.items || [];
  const deptItems = otherFuncConfig
    .map(i => {
      if (i.name === 'Favorites' && i.subKeys?.length) {
        return i.subKeys;
      }
      return [];
    })
    .flat();

  if (!deptItems.filter(i => i.name === 'exit' || i.name === 'EXIT').length) {
    const exitPayload = {
      _id: '6088753e50fabb0008016372',
      id: 24,
      isActive: false,
      isNextLevelExist: false,
      isTabsVisible: true,
      itemId: null,
      itemSize: null,
      label: 'EXIT',
      name: 'EXIT',
      productCategoryId: null,
      sequenceNumber: 24,
      thumbnail: 'icon-exit',
      type: 'item',
      upc: null,
    };
    deptItems.push(exitPayload);
  }

  const onAbortTrans = async () => {
    if (
      (cartItems.length === 0 && !isTransactionTriggered) ||
      UserActionScreenActive ||
      disableFinalizePay ||
      disableTransHoldFP ||
      isPromoInProgress
    ) {
      global?.logger?.error(
        `[7POS UI] - Tax/Promo API inprogress so transaction abort not allowed at this moment (Item Length :${cartItems.length}) (Screen Status :${UserActionScreenActive})(Finalize Button Status Status :${disableFinalizePay})`
      );
      DisplayToastMsg('Abort Transaction Not Allowed', 'top-left');
      return;
    }
    return history.push('/home/abortConfirmation');
  };

  const ResetLockState = () => {
    safeReserveCancel();
    dispatch(peripheralActions.setMOMLockStatus(null));
    dispatch(peripheralActions.setSafeLockStatus(null));
    dispatch(cartActions.setIsEndOfDayorShift(false));
    setAction('');
    setShowEODSConfirmation(false);
    stop();
    releaseStoreCordinatorLocks();
  };

  const Timer = () => {
    // After 3 minutes set the show value to false
    if (actionDayShift === 'EOS') {
      setShowEndOfShift(false);
    }
    if (actionDayShift === 'EOD') {
      setShowEndOfDay(false);
    }
    if (showEODSConfirmation) {
      setShowEODSConfirmation(false);
    }
    ResetLockState();
  };
  const screenAction = async item => {
    let isUserHavePermission = true;
    if (isFunctionSecurityTriggered === '') {
      isUserHavePermission = isValidUserFunction(item?.name?.toLowerCase());
    } else {
      dispatch(cartActions.setFunctionSecurityTriggered(''));
    }
    if (!isUserHavePermission) {
      dispatch(cartActions.setFunctionSecurityData(item));
      history.push({
        pathname: '/home/functionSecurity',
        redirectionData:
          item?.name?.toLowerCase() !== 'load'
            ? {
                pathname: '/home/otherFunctions',
                state: {
                  items: otherFuncConfig,
                },
              }
            : undefined,
        KeypadValue,
        triggerFrom:
          item?.name?.toLowerCase() !== 'load' ? 'otherFunction' : 'home',
        iFunctionName: item?.name?.toLowerCase(),
      });
      return;
    }
    setSelectedItem(item.name);
    if (item?.name === '7PosAppRestart') {
      if (
        cartItems?.length > 0 ||
        member?.loyalty_id ||
        member?.iMemberStatus === 'Unknown'
      ) {
        DisplayToastMsg(
          'Please complete In Progress Transaction for Reboot',
          'top-left'
        );
        return;
      }
      return history.push('/home/restart');
    } else if (
      item.name?.toLowerCase() === 'home' ||
      item.name?.toLowerCase() === 'exit'
    ) {
      return history.push('/home');
    } else if (
      item.name?.toLowerCase() === 'void money order fee' ||
      item.name?.toLowerCase() === 'void mo fee' ||
      item.name?.toLowerCase() === 'voidmoneyorderfee'
    ) {
      const isMoneyItem = items.filter(
        item =>
          item.isMoneyOrder === true && item?.MoneyOrderFlag === MO_FLG_INSALE
      );
      if (isMoneyItem?.length) {
        const overrideFlag = 'Y';
        dispatch(
          cartActions.UpdateMOFeeRemovalStatus({
            overrideFlag,
          })
        );
        dispatch(cartActions.setPromoCallSkipFlag(SKIP_PROMO));
        DisplayToastMsg('Money Order fee removed', 'top-left');
      }
      return history.push('/home');
    } else if (item.name?.toLowerCase() === 'paid in/out') {
      if (isMerchandiseInProgress || member) {
        return showInvalidKeySelection(Messages.paid_in_out);
      }
      clearTransHoldCart();
      return history.push({
        pathname: '/home/PaidInOutParent',
      });
    } else if (
      item.name?.toLowerCase() === 'paidin' ||
      item.name?.toLowerCase() === 'paid in'
    ) {
      if (isMerchandiseInProgress || member) {
        return showInvalidKeySelection(Messages.paid_in);
      }
      clearTransHoldCart();
      return history.push({
        pathname: '/home/PaidInOutParent/PaidIn',
      });
    } else if (
      item.name?.toLowerCase() === 'paidout' ||
      item.name?.toLowerCase() === 'paid out'
    ) {
      if (isMerchandiseInProgress || member) {
        return showInvalidKeySelection(Messages.paid_out);
      }
      clearTransHoldCart();
      return history.push({
        pathname: '/home/PaidInOutParent/PaidOut',
      });
    } else if (item.name?.toLowerCase() === 'priceoverride') {
      if (cartItems?.length > 0) {
        clearTransHoldCart();
        return history.push({
          pathname: '/home/OverrideItem',
        });
      } else {
        DisplayToastMsg('Invalid Operation, Cart is Empty', 'top-left');
      }
    } else if (
      item.name?.toLowerCase() === 'tax exempt' ||
      item.name?.toLowerCase() === 'taxexempt'
    ) {
      if (!isMerchandiseInProgress) {
        return DisplayToastMsg('Tax Exempt Not Allowed', 'top-left');
      }
      clearTransHoldCart();
      return history.push({
        pathname: '/home/TaxExempt',
      });
    } else if (
      item.name?.toLowerCase() === 'void trans' ||
      item.name?.toLowerCase() === 'voidtransaction'
    ) {
      clearTransHoldCart();
      if (
        !member &&
        !isTransactionRefund &&
        (items?.length === 0 ||
          (transactionMemory.items?.length &&
            transactionId === transactionMemory.transactionId))
      ) {
        dispatch(cartActions.setVoidTransaction(true));
      } else {
        DisplayToastMsg('Void Transaction Not Allowed', 'top-left');
      }
      return history.push('/home');
    } else if (item.name?.toLowerCase() === 'refund') {
      if (
        !member &&
        !isTransactionVoid &&
        (items?.length === 0 ||
          (transactionMemory.items?.length &&
            transactionId === transactionMemory.transactionId))
      ) {
        dispatch(cartActions.setRefundTransaction(true));
      } else {
        DisplayToastMsg('Refund Not Allowed', 'top-left');
      }
      return history.push('/home');
    } else if (
      item.name?.toLowerCase() === 'day close' ||
      item.name?.toLowerCase() === 'endofday'
    ) {
      const fuelRefundIsPending = checkPendingFuelRefunds() || false;
      if (fuelRefundIsPending) {
        Logger.info('7POS - EOD/EOS Rejected due to pending fuel refund');
        DisplayToastMsg('Complete Pending Prepay Refund before ending day');
        return;
      }
      if (transactionMemory.items?.length) {
        handleEOD();
        return;
      }
      if (
        cartItems?.length ||
        member ||
        balanceActive ||
        isTransactionRefund ||
        isTransactionVoid
      ) {
        DisplayToastMsg('EOD initiated, Please Complete Transaction');
        return;
      }
      dispatch(cartActions.setIsEndOfDayorShift(true));
      setAction('EOD');
      sendSafeSCLockRequest();
      sendMOMSCLockRequest('EOD');
      setShowEndOfDay(true);
    } else if (
      item.name?.toLowerCase() === 'end of shift' ||
      item.name?.toLowerCase() === 'endofshift'
    ) {
      const fuelRefundIsPending = checkPendingFuelRefunds() || false;
      if (fuelRefundIsPending) {
        Logger.info('7POS - EOD/EOS Rejected due to pending fuel refund');
        DisplayToastMsg('Complete Pending Prepay Refund before ending shift');
        return;
      }
      if (transactionMemory.items?.length) {
        handleEOD();
        return;
      }
      if (
        cartItems?.length ||
        member ||
        balanceActive ||
        isTransactionRefund ||
        isTransactionVoid
      ) {
        DisplayToastMsg('EOS initiated, Please Complete Transaction');
        return;
      }
      dispatch(cartActions.setIsEndOfDayorShift(true));
      setAction('EOS');
      sendSafeSCLockRequest();
      sendMOMSCLockRequest('EOS');
      setShowEndOfShift(true);
    } else if (
      item.name?.toLowerCase() === 'receipt reprint' ||
      item.name?.toLowerCase() === 'reprint receipt' ||
      item.name?.toLowerCase() === 'receiptreprint'
    ) {
      if (cartItems.length > 0) {
        DisplayToastMsg('RECEIPT REPRINT NOT AVAILABLE', 'top-left');
        return history.push('/home');
      }
      return history.push('/home/recieptReprint');
    } else if (
      item.name?.toLowerCase() === 'abort trans' ||
      item.name?.toLowerCase() === 'aborttransaction'
    ) {
      if (UserActionScreenActive || !cartItems.length) {
        DisplayToastMsg('Abort Transaction Not Allowed', 'top-left');
        return history.push('/home');
      }
      onAbortTrans();
    } else if (
      item.name?.toLowerCase() === 'signoff' ||
      item.name?.toLowerCase() === 'sign off'
    ) {
      dispatch(cartActions.setIsSignOff(true));
    } else if (
      item.name?.toLowerCase() === 'cdb report' ||
      item.name?.toLowerCase() === 'cdbreport'
    ) {
      if (!isCdbBtnAcive) return;
      if (
        cartItems?.length > 0 ||
        member?.loyalty_id ||
        member?.iMemberStatus === 'Unknown'
      ) {
        DisplayToastMsg(
          'Please complete In Progress Transaction for CDB',
          'top-left'
        );
        return;
      }
      showLoader(true);
      onCdbReport();
    }
  };

  const redirectToScreen = item => () => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    screenAction(item);
  };
  useEffect(() => {
    if (
      isFunctionSecurityTriggered === 'otherFunction' &&
      iFunctionSecurityData !== null
    ) {
      const item = iFunctionSecurityData;
      dispatch(cartActions.setFunctionSecurityData(null));
      screenAction(item);
    }
  }, [isFunctionSecurityTriggered]);

  const showConfirmation = () => {
    let stat = false;

    if (
      safeLockStatus !== null &&
      safeLockStatus !== SAFE_NOT_ENABLED &&
      safeLockStatus !== SAFE_LOCK_SUCCESS
    ) {
      stat = true;
    }
    if (actionDayShift === 'EOD') {
      if (
        momLockStatus !== null &&
        momLockStatus !== MOM_NOT_INTEGRATED &&
        momLockStatus !== MOM_PING_SUCCESS
      ) {
        stat = true;
      }
    }
    return stat;
  };

  const showRetry = () => {
    if (
      safeLockStatus === WAITING_FOR_SAFE_LOCK_RESPONSE ||
      safeLockStatus === WAITING_FOR_SC_SAFE_LOCK_RESPONSE ||
      momLockStatus === WAITING_FOR_SC_MOM_LOCK_RESPONSE ||
      momLockStatus === WAITING_FOR_MOM_PING_RESPONSE
    ) {
      return false;
    } else if (
      safeLockStatus === SC_SAFE_LOCK_FAILED ||
      safeLockStatus === SAFE_LOCK_FAILED ||
      momLockStatus === SC_MOM_LOCK_FAILED ||
      momLockStatus === MOM_PING_FAILED
    ) {
      return true;
    }
  };

  useEffect(() => {
    if (safeLockStatus === SC_SAFE_LOCK_ACQUIRED) safeReserveRequest();
    if (momLockStatus === SC_MOM_LOCK_ACQUIRED && actionDayShift === 'EOD')
      sendMOMPingRequest();
  }, [safeLockStatus, momLockStatus]);

  useEffect(() => {
    if (
      actionDayShift === 'EOS' ||
      actionDayShift === 'EOD' ||
      showEODSConfirmation
    ) {
      start(Timer);
    }
  }, [actionDayShift, showEODSConfirmation]);

  const onCloseEndOfDay = () => {
    setShowEndOfDay(false);
    ResetLockState();
    history.push('/home');
  };
  const onConfirmEndOfDay = async () => {
    setShowEndOfDay(false);
    if (showConfirmation()) {
      setShowEODSConfirmation(true);
    } else {
      handleDayOrShiftClose('EOD');
    }
  };

  const onCloseEndOfShift = () => {
    setShowEndOfShift(false);
    ResetLockState();
    history.push('/home');
  };

  const onConfirmEndOfShift = () => {
    setShowEndOfShift(false);
    if (showConfirmation()) {
      setShowEODSConfirmation(true);
    } else {
      handleDayOrShiftClose('EOS');
    }
  };

  const onCloseEODSConfirm = () => {
    ResetLockState();
    history.push('/home');
  };

  const onEODSConfirm = () => {
    handleDayOrShiftClose(actionDayShift);
    history.push('/home');
  };

  const onRetry = () => {
    if (safeLockStatus === SC_SAFE_LOCK_FAILED) {
      sendSafeSCLockRequest();
    } else if (safeLockStatus === SAFE_LOCK_FAILED) {
      safeReserveRequest();
    }
    if (momLockStatus === SC_MOM_LOCK_FAILED) {
      sendMOMSCLockRequest(actionDayShift);
    } else if (actionDayShift === 'EOD' && momLockStatus === MOM_PING_FAILED) {
      sendMOMPingRequest();
    }
  };

  const onRetryEndofShift = () => {
    onRetry();
  };

  const onRetryEndofDay = () => {
    onRetry();
  };

  const gridItemStyle = action => {
    const selected = selectedItem === action.name;
    const isExit = action.name?.toLowerCase() === 'exit';
    const resultStyle = `${Styles.gridItem}`;
    if (isExit) {
      return `${resultStyle} ${Styles.lastItem}`;
    }
    if (selected) {
      return `${resultStyle} ${Styles.gridBorder}`;
    }
    if (!action.noBorderBottom) {
      return `${resultStyle} ${Styles.gridBorderBottom}`;
    }
    return resultStyle;
  };

  return (
    <>
      <EndOfDay
        safeAvailable={safeLockStatus}
        momAvailable={momLockStatus}
        isOpen={showEndOfDay}
        onClose={onCloseEndOfDay}
        onConfirm={onConfirmEndOfDay}
        onRetry={onRetryEndofDay}
        showRetryButton={showRetry()}
        modalType={eodModalType}
      />
      <EndOfShift
        safeAvailable={safeLockStatus}
        isOpen={showEndOfShift}
        onClose={onCloseEndOfShift}
        onConfirm={onConfirmEndOfShift}
        onRetry={onRetryEndofShift}
        showRetryButton={showRetry()}
        modalType={eosModalType}
      />
      <EODSConfirmation
        safeAvailable={safeLockStatus}
        momAvailable={momLockStatus}
        EOD={actionDayShift === 'EOD'}
        isOpen={showEODSConfirmation}
        onClose={onCloseEODSConfirm}
        onConfirm={onEODSConfirm}
      />

      <Grid className={Styles.gridClass}>
        {deptItems.map((functionItem, index) => (
          <Flex
            key={`${functionItem.name}_${index}`}
            onClick={redirectToScreen(functionItem)}
            className={gridItemStyle(functionItem)}
          >
            {functionItem.name !== '' && (
              <img
                src={getOtherFunctionsIcons(functionItem.name)}
                className={Styles.iconImage}
                alt=""
              />
            )}
            <Text className={Styles.gridItemText}>{functionItem.label}</Text>
          </Flex>
        ))}
        {/* <Flex
          onClick={onExit}
          className={`${Styles.gridItem} ${Styles.gridBorderBottom}`}
        >
          <img src={Exit} className={Styles.iconImage} alt="" />
          <Text className={Styles.gridItemText}>EXIT</Text>
        </Flex> */}
      </Grid>
    </>
  );
}
