import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { useDispatch } from 'react-redux';
import { Route, Switch, useHistory, useRouteMatch } from 'react-router-dom';
import React from 'react';
import { Button } from '../../Common/Buttons';
import Styles from './TaxExempt.module.css';
import { cartActions } from '../../../slices/cart.slice';

const TaxExempt = () => {
  const { path } = useRouteMatch();
  const history = useHistory();
  const dispatch = useDispatch();
  const onExit = () => {
    history.push('/home');
  };

  return (
    <Box
      className={`${Styles.taxExemptContainer} ${Styles.hasBackground}`}
      h="calc(100vh - 275px)"
    >
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Switch>
          <Route path={`${path}/`} exact>
            <Flex
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              alignItems="center"
            >
              <Heading
                textAlign="center"
                justifyContent="center"
                // color="rgb(111, 110, 127)"
                mt={46}
                style={{
                  width: '400px',
                  height: '64px',
                  color: 'rgb(44, 47, 53)',
                  fontSize: '24px',
                  fontFamily: 'Roboto-Bold',
                  fontWeight: 'bold',
                  textAlign: 'center',
                  lineHeight: '32px',
                }}
              >
                Please confirm Tax Exempt for selected items
              </Heading>
              <Flex
                flexDirection="column"
                alignItems="center"
                my={4}
                w="52%"
                m="1em auto"
              >
                <Button
                  className="btn primaryButton"
                  size="lg"
                  height="50px"
                  width="140px"
                  _hover={{ bg: 'primary' }}
                  onClick={() => {
                    dispatch(cartActions.taxExemptConfirm());
                    history.push('/home');
                  }}
                >
                  <Text
                    color="rgb(255, 255, 255)"
                    fontSize="18px"
                    fontWeight="bold"
                    textAlign="center"
                    fontFamily="Roboto-Bold"
                  >
                    CONFIRM
                  </Text>
                </Button>
              </Flex>
            </Flex>
            <Button
              alignSelf="flex-end"
              onClick={onExit}
              className={Styles.exitButton}
              mb={15}
              mr={15}
            >
              <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
                EXIT
              </Text>
            </Button>
          </Route>
        </Switch>
      </Flex>
    </Box>
  );
};

export default TaxExempt;
