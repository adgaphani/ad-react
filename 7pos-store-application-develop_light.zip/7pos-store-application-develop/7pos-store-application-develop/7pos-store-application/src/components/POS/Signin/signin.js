/* eslint-disable import/order */
/* eslint-disable no-use-before-define */
/* eslint-disable jsx-a11y/label-has-for */
/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable react/prop-types */

import { Box, Input, InputGroup, Stack /* , Text */ } from '@chakra-ui/react';
// import { Button } from '../../Common/Buttons';
import React, { useEffect, useRef, useState /* , useContext */ } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';

import Styles from './signin.module.css';
import DailPad from '../../Common/DailPad/DailPad';
import { authActions } from '../../../slices/auth.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { mainActions } from '../../../slices/main.slice';
import { loginApi } from '../../../api/user';
import { updateDeviceRegistrationStatus } from '../../../api/app/fetchDeviceSetupStatus';
// import { AppContext } from '../../../AppContext';
import { useSoundToast } from '../../../hooks';
import {
  getDeviceInfo,
  getStoreProfile,
  getStoreDocumentsCount,
} from '../../../Utils/configurationUtils';
import InlineLoader from '../../Common/Loader/InlineLoader';
import { setShowToast } from '../../../hardware/ipc';
import { useKeyBoardConfig } from '../../../hooks/useKeyBoardConfig';

// import { useToast } from "@chakra-ui/react";

const loginErrorMessage = 'Wrong user id or password. Please try again.';
function Signin({ tabIndex }) {
  const history = useHistory();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  setShowToast(toast);
  const [currentField, setCurrentField] = useState('');
  const [values, setValues] = useState({ userId: '', password: null });
  const [isLoginError, setLoginError] = useState(false);
  const [charAt, setCharAt] = useState(0);
  const { getKeyBoardConfigIfNeeded } = useKeyBoardConfig();
  const {
    paymentTransactionId,
    storeProfile,
    deviceInfo,
    documentsCount,
  } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,
    storeProfile: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    keyConfig: state.main.keyConfig,
    documentsCount: state.main.documentsCount,
  }));
  const [apiCallInProcess, setApiCallInProcess] = useState(false);
  const userIdRef = useRef(null);
  const passwordRef = useRef(null);
  const updateCursorPosition = currentEl => () => {
    setCharAt(currentEl.current.selectionStart);
  };
  const onUpdateFieldValue = (cVal, wasBackSpace = false) => {
    setValues({
      ...values,
      [currentField]: cVal.slice(0, currentField === 'userId' ? 2 : 6),
    });
    setCharAt(wasBackSpace ? (charAt > 0 ? charAt - 1 : 0) : charAt + 1);
    changeFocus(currentField, cVal);
    resetLoginError();
  };

  const changeFocus = (name, value) => {
    if (name === 'userId' && userIdRef && passwordRef && value.length === 2) {
      userIdRef.current.blur();
      passwordRef.current.focus();
    }
  };

  const resetLoginError = () => {
    if (isLoginError) {
      global?.Logger?.info(`Reset login fields on error.`);
      setLoginError(false);
    }
  };
  const handleChange = e => {
    onUpdateFieldValue(e.target.value);
  };

  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 10000,
      position: 'top',
    });
  };
  const getStoreProfileIfNeeded = async () => {
    try {
      if (storeProfile) return storeProfile;
      const storeProfileData = await getStoreProfile(paymentTransactionId);
      if (!storeProfileData) {
        throw new Error('No StoreProfile Information');
      }
      dispatch(mainActions.setStoreDetails(storeProfileData));
    } catch (e) {
      DisplayToastMsg('No StoreProfile Information');
      Logger?.error('[7POS-UI]-[LoginValidation]:No StoreProfile Information');
      throw new Error(e?.message);
    }
  };
  const getDeviceInfoIfNeeded = async () => {
    try {
      if (deviceInfo?.id) return deviceInfo;
      const deviceInformation = await getDeviceInfo(paymentTransactionId);
      if (!deviceInformation) {
        throw new Error('No Device Information');
      }
      dispatch(mainActions.setDeviceInfo(deviceInformation));
    } catch (e) {
      DisplayToastMsg('No Device Information');
      Logger?.error('[LoginValidation]:No Device Information');
      throw new Error(e?.message);
    }
  };
  const getDocumentsCountInfNeeded = async () => {
    try {
      if (documentsCount) return documentsCount;
      const documentsCountData = await getStoreDocumentsCount(
        paymentTransactionId
      );
      if (
        documentsCountData === null ||
        documentsCountData?.productcategories <= 0 ||
        documentsCountData?.items <= 0
      ) {
        throw new Error('No Item/Department Information');
      }
      dispatch(mainActions.setDocumentsCount(documentsCountData));
    } catch (e) {
      DisplayToastMsg('No Item/Department Information');
      Logger?.error('[LoginValidation]:No Item/Department Information');
      throw new Error(e?.message);
    }
  };
  const retrieveConfiguration = async () => {
    let allowedToLogin = false;
    try {
      await Promise.all([
        getKeyBoardConfigIfNeeded(),
        getStoreProfileIfNeeded(),
        getDeviceInfoIfNeeded(),
        getDocumentsCountInfNeeded(),
      ]);
      allowedToLogin = true;
    } catch (error) {
      DisplayToastMsg('Failed to get POS Device Information');
      Logger?.error(
        `[LoginValidation]:Failed to get POS Device Information: ${JSON.stringify(
          error
        )}`
      );
    }
    return allowedToLogin;
  };

  const handleSubmit = async () => {
    const req = {
      userId: values.userId,
      password: values.password,
    };

    try {
      setApiCallInProcess(true);
      global?.Logger?.debug(`[7POS UI] : User logging to [7POS UI]`);
      const res = await loginApi(req, paymentTransactionId);
      if (res.data.status === '200 OK') {
        dispatch(authActions.setUserDetails(res.data.data));
        dispatch(cfdActions.setTransactionFinalize(false));
        if (res?.data?.data?.isSyncProgress) {
          dispatch(authActions.setIsDataSyncInProgress(true));
          Logger?.info(
            `[7POS UI] : User Login is successful, waiting for Sync Event`
          );
          return;
        }
        dispatch(authActions.setAppLogInStatus(true));
        global?.Logger?.debug(
          `[7POS UI] : User successfully Logged in [7POS UI]`
        );
        updateDeviceRegistrationStatus({ correlationId: paymentTransactionId });
        const allowedToLogin = await retrieveConfiguration();
        if (allowedToLogin) history.push('/home');
        setApiCallInProcess(false);
      }
    } catch (error) {
      dispatch(authActions.setRegistrationInvoke(0));
      // #6385 not tracing full log
      global?.Logger?.error(
        `Login Error and status code:${JSON.stringify(error?.response?.status)}`
      );
      setLoginError(true);
      toast({
        description: 'Failed to Authenticate Please try again',
        status: 'error',
        duration: 5000,
        position: 'top',
      });
      setApiCallInProcess(false);
    }
  };
  const { storeDetails, currencyConversion } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    currencyConversion: state.main.currencyConversion,
  }));
  const isCanadaStore = () => storeDetails?.address?.country === 'CA';

  useEffect(() => {
    setValues({ userId: '', password: '' });
    setCurrentField('');
    setLoginError(false);
    setCharAt(0);
  }, [tabIndex]);

  return (
    <form onSubmit={e => handleSubmit(e)}>
      <Stack spacing={5} py={3}>
        <Box className="floating-label" mb="13px" fontFamily="Robot-Regular">
          <Input
            type="text"
            name="userId"
            size="lg"
            fontFamily="Roboto-Regular"
            onFocus={() => {
              setCurrentField('userId');
            }}
            onChange={handleChange}
            onClick={updateCursorPosition(userIdRef)}
            focusBorderColor="input.borderColor"
            value={values.userId ? values.userId : ''}
            borderColor="#d3d3d3"
            placeholder=" "
            autoComplete="off"
            className={`floating-input ${
              currentField === 'userId' ? Styles.borderColorOnFocus : ''
            }`}
            ref={userIdRef}
            maxLength={2}
          />
          <label
            className={
              currentField === 'userId' ? Styles.labelColorOnFocus : ''
            }
          >
            User ID
          </label>
        </Box>
        <InputGroup
          className={`floating-label ${Styles.noMargin}`}
          size="lg"
          borderColor="#d3d3d3"
        >
          <Input
            type="password"
            name="password"
            placeholder=" "
            autoComplete="off"
            onFocus={() => setCurrentField('password')}
            onChange={handleChange}
            onClick={updateCursorPosition(passwordRef)}
            value={values.password ? values.password : ''}
            className={`floating-input ${
              isLoginError
                ? Styles.borderColorOnError
                : currentField === 'password'
                ? Styles.borderColorOnFocus
                : ''
            }`}
            focusBorderColor="input.borderColor"
            ref={passwordRef}
            errorBorderColor="rgb(236, 37, 38)"
            isInvalid={isLoginError}
            maxLength={6}
          />
          <label
            className={
              isLoginError
                ? Styles.labelColorOnError
                : currentField === 'password'
                ? Styles.labelColorOnFocus
                : ''
            }
          >
            Password
          </label>
        </InputGroup>
        <>
          {apiCallInProcess && (
            <InlineLoader
              className={Styles.signInLoader}
              size="sm"
              isLoading={apiCallInProcess}
            />
          )}
          {
            <label
              className={`${Styles.loginErrorMessage} ${Styles.pb30} ${
                !isLoginError || apiCallInProcess ? Styles.noOpacity : ''
              }`}
            >
              {loginErrorMessage}
            </label>
          }
        </>
        {currentField && !apiCallInProcess && (
          <DailPad
            handleSubmit={handleSubmit}
            currentValue={values[currentField] || ''}
            clearField={() => setCurrentField('')}
            onUpdateValue={onUpdateFieldValue}
            charAt={charAt}
          />
        )}
        {isCanadaStore() && currencyConversion && (
          <Box className={Styles.moneyExchange} shadow="sm" bg="#f1eeee">
            Money Exchange:{' '}
            <strong>1USD = {Number(currencyConversion).toFixed(2)}C$</strong>
          </Box>
        )}
      </Stack>
    </form>
  );
}

export default Signin;
