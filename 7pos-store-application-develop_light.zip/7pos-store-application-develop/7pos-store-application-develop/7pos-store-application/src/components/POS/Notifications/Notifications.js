import 'pure-react-carousel/dist/react-carousel.es.css';
import {
  Box,
  Flex,
  Text,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useDisclosure,
} from '@chakra-ui/react';
import React, { useState, useContext, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import {
  CarouselProvider,
  Slider,
  ButtonBack,
  ButtonNext,
} from 'pure-react-carousel';
import leftarrow from '../../../Icons/leftarrow.svg';
import rightarrow from '../../../Icons/rightarrow.svg';
import Styles from '../MenuBar/menubar.module.css';
import {
  dismissNotification,
  updateNotifications,
  setShowNotifications,
  setInstallTimer,
  setReceivedInstallNotification,
  hideInstallNotification,
} from '../../../slices/notifications.slice';
import { cartActions } from '../../../slices/cart.slice';
import { authActions } from '../../../slices/auth.slice';
import { Button } from '../../Common/Buttons';
import { appIntegrationRequest } from '../../../Utils/appUtils';
import { deleteFile } from '../../../Utils/fileUtils';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';
import { canShowNotifications } from '../../../Utils/notificationUtils';
import NotificationCard from './NotificationCard';
import { useSoundToast } from '../../../hooks';

const Notifications = () => {
  const [ws] = useContext(WebSocketContext);
  const location = useLocation();
  const history = useHistory();
  const isFuelScreen = location.pathname.startsWith('/fuel');
  const toast = useSoundToast();
  const dispatch = useDispatch();
  const {
    notifications,
    isShowNotifications,
    paymentTransactionId,
    isGradeSelectionOn,
    installTimer,
    cardStatus,
    posSystemStatus,
    transactionMemory,
    cartItems,
  } = useSelector(state => ({
    // Need to check forEach instead of filter here
    // eslint-disable-next-line array-callback-return
    notifications: state?.notifications?.notifications?.filter(i => {
      // FUel Screen Only Fuel Notifications
      if (isFuelScreen && i.isFuel) return i;
      // Main Screen Global Fuel notitication and global notifications
      if (
        !isFuelScreen &&
        ((i.isFuel && i.isGlobal) ||
          (i?.from === 'DeploymentsAgent' && !i?.hideNotification) ||
          (i?.sender === 'DeploymentsAgent' && !i?.hideNotification))
      )
        return i;
    }),
    isShowNotifications: state.notifications.isShowNotifications,
    paymentTransactionId: state.cart.paymentTransactionId,
    isGradeSelectionOn: state.fuel.isGradeSelectionOn,
    installTimer: state.notifications.installTimer,
    posSystemStatus: state.cart.posSystemStatus,
    cardStatus: state.socket.cardStatus,
    transactionMemory: state.cart.transactionMemory,
    cartItems: state.cart.cartItems,
  }));

  const [installNotification, setInstallNotificaton] = useState(null);
  const { isOpen, onOpen, onClose } = useDisclosure(false);
  useEffect(() => {
    const showNotifications = canShowNotifications({
      location,
      cardStatus,
      isGradeSelectionOn,
    });
    dispatch(setShowNotifications(showNotifications));
    return () => {};
  }, [location.pathname, location.search, isGradeSelectionOn]);

  const removeNotification = notification => () => {
    if (
      notification.action === 'install' &&
      notification.mode === 'interactive'
    ) {
      if (installTimer > 5) dispatch(hideInstallNotification(notification));
    } else dispatch(dismissNotification(notification));
  };

  const handleNotificationClick = notification => () => {
    /* if (
      notification.action === 'install' &&
      notification.mode === 'interactive'
    ) {
      setInstallNotificaton(notification);
      onOpen();
    } */
    console.log(notification);
  };

  const softwareUpdateTrigger = notification => () => {
    const triggeredEODEOS = localStorage.getItem('triggeredEODEOS') || false;
    if (
      notification.action === 'install' &&
      notification.mode === 'interactive'
    ) {
      if (
        posSystemStatus === 'StartedNewTransaction' ||
        transactionMemory?.items?.length > 0 ||
        cartItems?.length > 0 ||
        triggeredEODEOS
      ) {
        toast({
          description: 'Please complete transaction first',
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      } else {
        setInstallNotificaton(notification);
        onOpen();
      }
    }
  };

  const sendAction = actionReason => {
    const payload = {
      from: 'POS',
      action: installNotification.action,
      component: 'Middleware',
      deviceType: 'Pinpad',
      reason: actionReason,
      deploymentId: installNotification.deploymentId,
    };
    if (installNotification.packages) {
      payload.packages = installNotification.packages;
    }
    const request = appIntegrationRequest({
      type: 'Notification_Bar',
      payload,
      correlationId: paymentTransactionId,
    });
    ws.socket?.send('/app/7pos/appnotifications', {}, JSON.stringify(request));
    onClose();
  };

  const onSnooze = installNotification => () => {
    onClose();
    Logger.info(`User click No - Later option for Installation`);
    console.log(installNotification);
    // dispatch(dismissNotification(installNotification));
    // sendAction('Snooze');
  };

  const onConfirm = installNotification => () => {
    Logger.info(`User confirms for Installation`);
    dispatch(dismissNotification(installNotification));
    dispatch(setInstallTimer(0));
    dispatch(setReceivedInstallNotification(false));
    localStorage.removeItem('InstallRemainder');
    deleteFile({ fileName: 'InstallRemainder.json' });
    sendAction('UserConfirmed');
    dispatch(cartActions.setPOSSystemStatus('SoftwareInstallTriggered'));
    dispatch(authActions.setAppLogInStatus(false));
    history.replace('/');
  };

  useEffect(() => {
    if (!notifications.length) return;
    const updatedNotifcations = notifications.map(n => {
      const nt = n;
      if (n.isTimeout) return n;
      if (n.expiry) {
        setTimeout(() => removeNotification(nt)(), nt.expiry);
        return {
          ...n,
          isTimeout: true,
        };
      }
      return n;
    });
    dispatch(updateNotifications(updatedNotifcations));
  }, [notifications.length]);

  if (!isShowNotifications) return null;

  return (
    <>
      <Box
        background="rgb(255, 255, 255)"
        borderRadius="2px"
        boxShadow="0px 2px 4px 0px rgba(0, 0, 0, 0.06)"
        height={isFuelScreen ? '75px' : '127px'}
        mt={isFuelScreen ? '0' : '0.6rem'}
        mb="0.6rem"
        ml="0.5rem"
        mr="0.6rem"
      >
        <Flex
          direction="row"
          justifyContent="center"
          alignItems="center"
          height="100%"
        >
          <CarouselProvider
            naturalSlideWidth={100}
            naturalSlideHeight={60}
            totalSlides={notifications.length}
            orientation="horizontal"
            touchEnabled
            isIntrinsicHeight
            style={{
              width: '100%',
              padding: '15px 10px',
            }}
            visibleSlides={isFuelScreen ? 2 : 1}
          >
            <Flex direction="row" alignItems="center">
              <ButtonBack
                style={{
                  background: 'white',
                  padding: '2px 6px',
                  color: 'white',
                  marginTop: 7,
                }}
              >
                <img
                  src={leftarrow}
                  alt="leftArrow"
                  height="24px"
                  width="24px"
                />
              </ButtonBack>
              <Slider
                style={{
                  width: '100%',
                }}
              >
                {notifications &&
                  notifications.map((notification, index) => (
                    <NotificationCard
                      key={index}
                      index={index}
                      notification={notification}
                      removeNotification={removeNotification}
                      handleNotificationClick={handleNotificationClick}
                      softwareUpdateTrigger={softwareUpdateTrigger}
                      installTimer={installTimer}
                      isActiveTransaction={
                        posSystemStatus === 'StartedNewTransaction' ||
                        transactionMemory?.items?.length > 0 ||
                        cartItems?.length > 0 ||
                        localStorage.getItem('triggeredEODEOS')
                      }
                    />
                  ))}
              </Slider>
              <ButtonNext
                style={{
                  background: 'white',
                  padding: '2px 6px',
                  color: 'white',
                  marginTop: 7,
                }}
              >
                <img
                  src={rightarrow}
                  alt="leftArrow"
                  height="24px"
                  width="24px"
                />
              </ButtonNext>
            </Flex>
          </CarouselProvider>
        </Flex>
      </Box>
      {installNotification && (
        <Modal closeOnOverlayClick={false} isOpen={isOpen} onClose={onClose}>
          <ModalOverlay className={Styles.modalOverlay} onClick={onClose} />
          <ModalContent className={Styles.modalContainer}>
            <ModalHeader className={Styles.modalHeader}>
              <Text
                color="rgb(44, 47, 53)"
                fontsize="28px"
                fontFamily="Roboto-Bold"
                fontweight="bold"
                lineheight="30px"
                textalign="center"
              >
                Install Software Now ?
              </Text>
            </ModalHeader>
            <ModalBody className={Styles.modalBody} mx="30px">
              <Text
                color="rgb(44, 47, 53)"
                fontWeight="normal"
                lineHeight="28px"
                textAlign="center"
              >
                You are about to install software. Click Yes to continue or
                Postpone to install later
              </Text>
            </ModalBody>

            <ModalFooter
              justifyContent="center"
              marginBottom="40px"
              mx="30px"
              padding="0px"
            >
              <Button
                className={Styles.okButton}
                width="200px"
                onClick={onConfirm(installNotification)}
              >
                <Text>Yes - Install</Text>
              </Button>
              <Button
                ml={8}
                className={Styles.noButton}
                width="200px"
                onClick={onSnooze()}
              >
                <Text>Postpone</Text>
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      )}
    </>
  );
};

export default Notifications;
