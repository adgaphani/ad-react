/* eslint-disable  react/jsx-curly-brace-presence */
import React from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { Slide } from 'pure-react-carousel';
import { Button } from '../../Common';
import { useFuel } from '../../../hooks';
import Icon_confirm from '../../../Icons/Icon_confirm.svg';
import Icon_exclamation from '../../../Icons/Icon_exclamation.svg';
import closeIcon from '../../../Icons/close.svg';
import './NotificationCard.css';

const NotificationCard = ({
  index,
  notification = {},
  removeNotification,
  handleNotificationClick,
  softwareUpdateTrigger,
  installTimer,
  isActiveTransaction,
}) => {
  const { isFuelEnabled } = useFuel();
  const { messageType = 'success', message, icon, borderColor } = notification;

  return (
    <Slide index={index} onClick={() => handleNotificationClick(notification)}>
      <Flex
        borderRadius="4px"
        borderWidth="1px"
        borderStyle="solid"
        height="60px"
        direction="row"
        alignItems="center"
        position="relative"
        className={`notification-body p-${messageType}`}
        {...(borderColor ? { borderColor } : {})}
      >
        <Box m="10px">
          <img
            src={
              icon ||
              (messageType === 'success' ? Icon_confirm : Icon_exclamation)
            }
            alt=""
            height="24px"
            width="24px"
          />
        </Box>
        {notification.action === 'install' &&
        notification.mode === 'interactive' &&
        notification?.deploymentId ? (
          <>
            <Flex flexDirection="column">
              <Text
                color="rgb(44, 47, 53)"
                fontFamily="Roboto-Medium"
                fontSize="14px"
                fontWeight="bold"
              >
                Software update will begin in:{' '}
                {installTimer <= 5 ? (
                  <>
                    <span className={`installtimer`}>
                      {installTimer} minutes
                    </span>
                  </>
                ) : installTimer < 60 ? (
                  `${installTimer} minutes`
                ) : (
                  `1 hour`
                )}
              </Text>
              {isFuelEnabled && (
                <Text
                  color="rgb(44, 47, 53)"
                  fontFamily="Roboto-Medium"
                  fontSize="14px"
                  fontWeight="500"
                >
                  IF GASOLINE IS IMPACTED, ENSURE PUMPS ARE BAGGED
                </Text>
              )}
              {message?.length > 0 && (
                <Text
                  color="rgb(44, 47, 53)"
                  fontFamily="Roboto-Medium"
                  fontSize="14px"
                  fontWeight="500"
                >
                  {message}
                </Text>
              )}
            </Flex>
            <Button
              bg="#FFFFFF"
              ml={2}
              alignItems="center"
              size="sm"
              height="40px"
              width="90px"
              border="1px"
              borderColor="green.500"
              onClick={softwareUpdateTrigger(notification)}
              isDisabled={isActiveTransaction}
            >
              <Text
                color="rgb(16, 127, 98)"
                fontFamily="Roboto-Medium"
                fontSize="14px"
                fontWeight="500"
              >
                Install Now
              </Text>
            </Button>
          </>
        ) : (
          <>
            <Text
              color="rgb(44, 47, 53)"
              fontFamily="Roboto-Medium"
              fontSize="14px"
              fontWeight="500"
            >
              {message}
            </Text>
          </>
        )}
        <Box position="absolute" top="0" right="2px">
          <Button
            style={{ background: 'transparent' }}
            onClick={removeNotification(notification)}
          >
            <img src={closeIcon} alt="" height="12px" width="12px" />
          </Button>
        </Box>
      </Flex>
    </Slide>
  );
};
export default NotificationCard;
