import { Box, Flex, Text } from '@chakra-ui/react';
import React from 'react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import { Button } from '../../Common';
import * as Styles from './Restart.module.css';
import { redWarningIcon } from '../../../Icons';

const Restart = ({ appRestart }) => {
  const history = useHistory();
  const exit = () => {
    history.push('/home');
  };

  const confirm = () => {
    appRestart();

    global?.logger?.info(`[7POS UI] - App restart`);
  };

  return (
    <Box height="calc(100vh - 128px)" p="0.5rem" bg="rgb(255,255,255)">
      <Flex
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        className={Styles.container}
        height="90%"
        width="100%"
        px="0.5rem"
      >
        <img src={redWarningIcon} alt="warning-icon" className={Styles.image} />
        <Box textAlign="center" mb="2.5rem">
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Medium"
            fontSize="24px"
            fontWeight="500"
            mt=".75rem"
          >
            You have opted to RESTART THE POS APP.
            <br />
            Press “Yes” to continue
          </Text>
        </Box>

        <Button
          className="btn primaryButton"
          _hover={{ bg: 'primary' }}
          width="120px"
          onClick={confirm}
        >
          <Text
            fontsize="18px"
            fontFamily="Roboto-Bold"
            fontweight="bold"
            textalign="center"
          >
            YES
          </Text>
        </Button>
      </Flex>
      <Button className={Styles.exit} mr="1.0rem" onClick={exit}>
        <Text
          color="rgb(91, 97, 107)"
          fontsize="18px"
          fontFamily="Roboto-Bold"
          fontweight="bold"
          textalign="center"
        >
          EXIT
        </Text>
      </Button>
    </Box>
  );
};
Restart.propTypes = {
  appRestart: PropTypes.func.isRequired,
};

export default Restart;
