import React, { useContext } from 'react';
import { Box, Flex, Text, Heading } from '@chakra-ui/react';
import { useLocation, useHistory } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { cartActions } from '../../../slices/cart.slice';
import { verifyUserId, appIntegrationRequest } from '../../../Utils/appUtils';
import Shape from '../../../Icons/Shape.svg';
import { Button } from '../../Common/Buttons';
import { AppContext } from '../../../AppContext';
import { useCart, useSoundToast } from '../../../hooks';
import { Messages } from '../../../Messages';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';

const SharedUPC = props => {
  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const { keyPressSound } = useContext(AppContext);
  const items = location?.state?.items;
  const toast = useSoundToast();
  const { isFuelTransactionInProgress } = useCart();
  const [ws] = useContext(WebSocketContext);
  const {
    lookupCodes,
    saleHours,
    cartItems,
    storeDetails,
    paymentTransactionId,
  } = useSelector(state => ({
    lookupCodes: state.main.lookupCodes,
    saleHours: state.main.saleHours,
    cartItems: state.cart.items,
    storeDetails: state.main.storeDetails,
    paymentTransactionId: state.cart.paymentTransactionId,
  }));

  const { onExit, onSelectItem } = props;
  const handleOnSelectItem = (itemInfo, upc, location) => {
    const { tranAgeVerifyInfo } = location?.state?.extraData;
    const {
      citem,
      lookup,
      notVerified,
      underAged,
      restrictedHours,
    } = verifyUserId({
      data: itemInfo,
      lookupCodes,
      tranAgeVerifyInfo,
      saleHours,
      cartItems,
      storeDetails,
    });
    if (Number(citem.itemRestrictionCode) === 6) {
      // Multi item click should not trigger reHeat on top of ageVerification: RISPIN5069
      if (
        window?.location?.pathname.includes('verification') ||
        window?.location?.pathname.includes('manualEntry')
      ) {
        return;
      }
      // Reheat screen trigger for code 6 items
      history.push({
        pathname: '/home/itemReHeatScreen',
        state: {
          item: citem,
          upc,
        },
      });
      return;
    }
    // Passing selected upc into the age verification screen.
    if (isFuelTransactionInProgress && citem.negativeSalesFlag) {
      toast({
        description: Messages.invalid_action_fuel,
      });
      return;
    }
    if (restrictedHours && saleHours) {
      dispatch(cartActions.setRestrictedSale(true));
      return;
    }
    const state = { item: { ...citem, upc }, restriction: lookup };
    if (underAged) {
      // If Item Reheat already Triggered, Reheat item need to be add to cart first
      if (window?.location?.pathname.includes('itemReHeatScreen')) {
        return;
      }
      history.push({
        pathname: '/home/manualEntry',
        state: { ...state, underAged: true },
      });
      return;
    }
    if (notVerified) {
      // If Item Reheat Trigger, Reheat item need to be add to cart first
      if (window?.location?.pathname.includes('itemReHeatScreen')) {
        return;
      }
      const dlSwipeReq = appIntegrationRequest({
        type: 'Dlswipe_Req',
        correlationId: paymentTransactionId,
      });
      ws.socket?.send('/app/pinpad/swipeId', {}, JSON.stringify(dlSwipeReq));
      history.push({ pathname: '/home/verification', state });
      return;
    }
    itemInfo.forEach(item => {
      const updatedUPC = item.upc || upc;
      dispatch(
        cartActions.addToCart({
          ...item,
          requiredAge: citem.requiredAge,
          upc: updatedUPC,
        })
      );
    });
    history.push('/home');
  };

  const renderItems = () =>
    items?.map(i => {
      const upc = i.itemUPC.find(k => k.isDefaultUPC)?.UPC;
      const dept = i?.category?.id;
      return (
        <Flex
          height="75px"
          justifyContent="space-between"
          borderBottom="1px solid lightgray"
          onClick={() => {
            keyPressSound?.play?.().catch(e => console.log('Sound error', e));
            if (location?.state?.extraData) {
              handleOnSelectItem([i], upc, location);
              return;
            }
            if (location?.state?.saleHours) {
              onSelectItem([i], upc, saleHours);
              return;
            }
            onSelectItem([i], upc, undefined, onExit);
            // onExit();
          }}
          pt={4}
          pr={8}
        >
          <Box maxWidth="75%" mr="2rem">
            <Heading fontSize="20px">
              {' '}
              {`${i.name} - ${i.itemSize} - $${i.retailPrice}`}
            </Heading>
            <Text fontSize="13px">{`PLU: ${upc}`}</Text>
            <Text fontSize="13px">{`Dept: ${dept}`}</Text>
          </Box>
          <img src={Shape} alt="success" height="30px" width="30px" />
        </Flex>
      );
    });

  return (
    <Box
      bg="#ffffff"
      height="calc(100% - 187px)"
      mt="0.6rem"
      mb="o.6rem"
      ml="0.5rem"
      mr="0.6rem"
      background="rgb(255,255,255)"
      borderRadius="2px"
      boxShadow="0px 2px 4px 0px rgba(0,0,0,0.06)"
    >
      <Flex flexDirection="column" height="100%">
        <Flex
          justifyContent="flex-start"
          flexDirection="column"
          borderBottom="1px solid lightgray"
          pb={4}
          pt={4}
          pl="3rem"
          height="87%"
          maxHeight="87%"
          overflow="auto"
        >
          {renderItems()}
        </Flex>
        <Button
          alignSelf="flex-end"
          onClick={onExit}
          backgroundColor="#ffffff"
          borderRadius="3px"
          border="1px solid rgb(91, 97, 107)"
          height="40px"
          width="90px"
          mb={15}
          mr={15}
          mt={4}
        >
          <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
            EXIT
          </Text>
        </Button>
      </Flex>
    </Box>
  );
};

export default SharedUPC;
