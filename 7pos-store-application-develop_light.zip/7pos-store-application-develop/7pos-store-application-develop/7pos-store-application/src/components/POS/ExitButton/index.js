import { Text } from '@chakra-ui/react';
import React from 'react';
import { Button } from '../../Common/Buttons';

function ExitButton({ onClick, label = 'EXIT', isDisabled = false }) {
  return (
    <Button
      alignSelf="flex-end"
      onClick={onClick}
      width={label === 'EXIT' ? '90px' : '150px'}
      className="btn secondaryButton"
      height="40px"
      mt={15}
      isDisabled={isDisabled}
    >
      <Text
        fontSize="18px"
        fontFamily="Roboto-Bold"
        color="rgb(91, 97, 107)"
        fontWeight="bold"
      >
        {label}
      </Text>
    </Button>
  );
}

export default ExitButton;
