import { Box, Flex, Text } from '@chakra-ui/react';
import React from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import Icon_confirm from '../../../Icons/Error_Node.svg';
import ExitButton from '../ExitButton';
import Styles from './7RewardsMemberError.module.css';

export default function MemberError() {
  const dispatch = useDispatch();
  const { isSpeedyStore } = useSelector(state => ({
    isSpeedyStore: state.main.isSpeedyStore,
  }));
  const history = useHistory();
  const onExit = () => {
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(cfdActions.setUserActionScreenActive(false));
    global?.logger?.info(
      `[7POS UI] - Click exit from 7Rewards Member error screen`
    );
    history.push('/home');
  };

  const iMemberOfflineMsg =
    'Points and Purchase will be awarded<br />&nbsp;&nbsp;&nbsp;as soon as system is back online.<br />';

  return (
    <Box bg="#ffffff" h="calc(100vh - 275px)">
      <Flex flexDirection="column" justifyContent="space-between" height="100%">
        <Flex
          flexDirection="column"
          aliginItems="center"
          justifyContent="space-evenly"
          height="70%"
        >
          <Text
            fontSize="24px"
            fontWeight="bold"
            textAlign="center"
            font-family="Roboto-Bold"
          >
            {isSpeedyStore ? `SPEEDY REWARDS` : `7REWARDS`} IS CURRENTLY OFFLINE
          </Text>
          <Flex
            alignItems="center"
            justifyContent="center"
            flexDirection="column"
            mt="10%"
          >
            <img src={Icon_confirm} height="40px" width="40px" alt="success" />
            <Text
              fontSize="24px"
              fontWeight="bold"
              textAlign="center"
              padding="3px"
              font-family="Roboto-Bold"
            >
              Inform the Customer
            </Text>
            <Text
              className={Styles.OfflineMsg}
              dangerouslySetInnerHTML={{ __html: iMemberOfflineMsg }}
            />
          </Flex>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={onExit} />
        </Box>
      </Flex>
    </Box>
  );
}
