import React, { useEffect, useState, useRef, useContext } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Flex, Grid, Text } from '@chakra-ui/react';
import { useSoundToast } from '../../../hooks';
import ItemButton from './ItemButton';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { fetchDepartmentInfo } from '../../../api/app/fetchDepartmentInfo';
import Exit from '../../../Icons/Exit.svg';
import { getCartPayload } from '../../../Utils/otherDepartmentsUtils';
import { verifyUserId, appIntegrationRequest } from '../../../Utils/appUtils';
import { AppContext } from '../../../AppContext';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';

export default function OtherDepartments() {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const toast = useSoundToast();
  const [departmentAmount, setDepartmentAmount] = useState(0);
  const [selectedItem, setSelectedItem] = useState('');
  const [ws] = useContext(WebSocketContext);
  const {
    items,
    amount,
    tranAgeVerifyInfo,
    lookupCodes,
    config,
    paymentTransactionId,
    storeDetails,
    isTransactionFinalize,
    UserActionScreenActive,
    saleHours,
  } = useSelector(state => ({
    items: state.cart.items,
    amount: state.dailpad.keypad.value,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    lookupCodes: state.main.lookupCodes,
    config: state.main.configuration,
    paymentTransactionId: state.cart.paymentTransactionId,
    storeDetails: state.main.storeDetails,
    isTransactionFinalize: state.cart.isTransactionFinalize,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    saleHours: state.main.saleHours,
  }));
  const { keyPressSound } = useContext(AppContext);

  const amountFromLocation = useRef(location?.state?.departmentAmount || 0);
  const deptItems = location?.state?.items || [];
  const isNotFoundUPC = location?.state?.UPC || '';
  const totalItems =
    (deptItems?.length > 0 &&
      deptItems[0]?.subKeys?.length > 0 &&
      deptItems[0]?.subKeys?.length) ||
    0;
  const minItems = 23;
  let emptyGrid = [];
  if (totalItems === minItems) {
    emptyGrid = [];
  } else if (totalItems < minItems) {
    const noofEmptygrids = minItems - totalItems;
    emptyGrid = Array.from(Array(noofEmptygrids)).map((_, i) => ({
      value: i + 1,
    }));
  }

  useEffect(() => {
    setDepartmentAmount(amount);
    dispatch(dailpadActions.resetKeypadValue());
  }, []);

  useEffect(() => {
    if (amountFromLocation.current)
      setDepartmentAmount(amountFromLocation.current);
  }, [amountFromLocation.current]);

  const addDepartmentItemInCart = async (id, item = {}) => {
    try {
      // Cross verify any MIF associate to ring up department sale.
      if (config?.deptMifConfig && isNotFoundUPC === '') {
        const isMifDept = config?.deptMifConfig.filter(
          i => Number(i.productCategoryId) === Number(id)
        );
        if (isMifDept?.length > 0)
          return history.push({
            pathname: '/home/charity',
            search: `?itemId=${id}`,
            state: {
              items: deptItems,
              departmentAmount,
              id,
              isNotFoundUPC,
            },
          });
      }
      dispatch(cartActions.setFinalizePayStatus(true));
      let deptResponse = await fetchDepartmentInfo(id, paymentTransactionId);
      deptResponse = JSON.parse(deptResponse.data.data)?.map(i => ({
        ...i,
        itemRestrictionCode: Number(i.ageRestriction),
      }));
      deptResponse = deptResponse.length > 0 ? deptResponse[0] : {};
      global?.logger?.info(`[7POS UI] - fetch Department  Success`);
      const MaxallowedItemPrice =
        config?.storeConfig?.maxAllowedItemPrice !== undefined
          ? Number(config?.storeConfig?.maxAllowedItemPrice)
          : 0;
      if (
        deptResponse?.lowAmountLockout &&
        deptResponse?.lowAmountLockout > 0 &&
        Number(departmentAmount / 100) < deptResponse?.lowAmountLockout
      ) {
        toast({
          description: `Amount too small. Minimum is $${parseFloat(
            deptResponse?.lowAmountLockout
          ).toFixed(2)}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      } else if (
        (deptResponse?.highAmountLockout &&
          deptResponse?.highAmountLockout > 0 &&
          Number(departmentAmount) / 100 > deptResponse.highAmountLockout) ||
        Number(departmentAmount) / 100 > 999999 ||
        (MaxallowedItemPrice !== 0 &&
          Number(departmentAmount) / 100 > MaxallowedItemPrice)
      ) {
        const Amount = parseFloat(
          deptResponse.highAmountLockout < MaxallowedItemPrice ||
            MaxallowedItemPrice === 0
            ? deptResponse.highAmountLockout
            : MaxallowedItemPrice
        ).toFixed(2);
        toast({
          description: `Amount too large. Maximum is $${Amount}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      } else {
        const {
          citem,
          lookup,
          notVerified,
          underAged,
          restrictedHours,
        } = verifyUserId({
          data: deptResponse,
          lookupCodes,
          tranAgeVerifyInfo,
          saleHours,
          cartItems: items,
          storeDetails,
        });
        const payload = getCartPayload({
          productCategoryId: id,
          deptInfo: {
            ...deptResponse,
            requiredAge: citem.requiredAge,
          },
          selectedItem,
          departmentAmount,
          isNotFoundUPC,
        });
        dispatch(dailpadActions.resetKeypadValue());
        const state = {
          item: { ...item, otherDeptsCartPayload: payload },
          restriction: lookup,
        };
        if (restrictedHours && saleHours) {
          dispatch(cartActions.setRestrictedSale(true));
          return;
        }
        if (underAged) {
          history.push({
            pathname: '/home/manualEntry',
            state: { ...state, underAged: true },
          });
          dispatch(cartActions.setFinalizePayStatus(false));
          return;
        }
        if (notVerified) {
          const dlSwipeReq = appIntegrationRequest({
            type: 'Dlswipe_Req',
            correlationId: paymentTransactionId,
          });
          ws.socket?.send(
            '/app/pinpad/swipeId',
            {},
            JSON.stringify(dlSwipeReq)
          );
          history.push({ pathname: '/home/verification', state });
          dispatch(cartActions.setFinalizePayStatus(false));
          return;
        }
        if (!isTransactionFinalize && !UserActionScreenActive) {
          dispatch(cartActions.addToCart(payload));
          global?.logger?.info(`[7POS UI] - fetchDepartmentInfo successful`);
        } else {
          global?.logger?.error(
            `[7POS UI] - fetchDepartmentInfo Finalize inprogress ignore to add item.`
          );
        }
      }
    } catch (error) {
      toast({
        description: `Department Not Found`,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.error(
        `[7POS UI] - fetchDepartmentInfo details Error ${JSON.stringify(error)}`
      );
    }
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(dailpadActions.resetKeypadValue());
    history.push('/home');
  };

  const onItemClick = item => async () => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (item.name?.toLowerCase() === 'exit') {
      dispatch(dailpadActions.resetKeypadValue());
      history.push('/home');
      return;
    }
    if (
      departmentAmount === 0 ||
      departmentAmount === '0' ||
      departmentAmount === '' ||
      isTransactionFinalize ||
      (UserActionScreenActive && // #5304 added path name as well to bypass notification
        !location?.pathname.includes('otherDepartments'))
    ) {
      return;
    }
    dispatch(cfdActions.setUserActionScreenActive(false));
    setSelectedItem(item.name);
    if (item.name?.toLowerCase() === 'home') {
      dispatch(dailpadActions.resetKeypadValue());
      history.push('/home');
      return;
    }
    // Blocking Lotto/Lottery win when Fuel is in progress.
    // Not Blocking Lotto and Lotto Wins in Fuel Transaction
    /*
    if (isLottoOrLotteryWin(item) && isFuelTransactionInProgress) {
      return showToast({
        description: Messages.invalid_action_fuel,
        duration: 3000,
        position: 'top-left',
      });
    } */
    addDepartmentItemInCart(item.productCategoryId, item);
  };

  const keypadEnterHandler = val => {
    // Blocking Lotto/Lottery win when Fuel is in progress.
    // Not Blocking Lotto and Lotto Wins in Fuel Transaction
    /* if (
      isLottoOrLotteryWin({ productCategoryId: val }) &&
      isFuelTransactionInProgress
    ) {
      return showToast({
        description: Messages.invalid_action_fuel,
        duration: 3000,
        position: 'top-left',
      });
    } */
    addDepartmentItemInCart(val.toString());
  };

  return (
    <Box>
      <Grid templateColumns="50% 50%">
        <Box marginLeft="7px">
          <Keypad onEnter={keypadEnterHandler} disableDecimal />
        </Box>
        <Flex
          width="100%"
          borderRadius="2px"
          margin="0 auto"
          h="calc(100vh - 210px)"
          flexDirection="column"
          justifyContent="space-between"
        >
          <Flex flexDirection="row" justifyContent="flex-start" flexWrap="wrap">
            {deptItems?.map((dItem, dIndex) => {
              if (dIndex > 0) return '';
              const slicedData =
                dItem?.subKeys?.length > minItems
                  ? dItem?.subKeys?.slice(0, minItems)
                  : [].concat(dItem.subKeys);
              return slicedData.map((functionItem, index) => (
                <ItemButton
                  key={`${functionItem.name}_${index}`}
                  functionItem={functionItem}
                  selectedItem={selectedItem}
                  onItemClick={onItemClick}
                />
              ));
            })}
            {emptyGrid.map((eItem, index) => (
              <Flex
                key={`other-department-empty-${index}`}
                flexDirection="column"
                justifyContent="space-around"
                background="white"
                borderRadius="2px"
                height="75px"
                width="74px"
                alignItems="center"
                margin="0px 4px 9px 5px"
                padding="5px 0px"
              >
                <Box />
              </Flex>
            ))}
            <Flex
              key="other-department-exit-1"
              flexDirection="column"
              justifyContent="space-around"
              background="white"
              borderRadius="2px"
              height="75px"
              width="74px"
              alignItems="center"
              margin="0px 4px 9px 5px"
              onClick={onItemClick({ name: 'Exit' })}
              padding="5px 0px"
            >
              <Box>
                <img src={Exit} alt="Exit" height="24px" width="24px" />
              </Box>
              <Text
                color="rgb(91, 97, 107)"
                fontFamily="Roboto-Medium"
                fontSize="18px"
                fontWeight="500"
              >
                EXIT
              </Text>
            </Flex>
          </Flex>
        </Flex>
      </Grid>
    </Box>
  );
}
