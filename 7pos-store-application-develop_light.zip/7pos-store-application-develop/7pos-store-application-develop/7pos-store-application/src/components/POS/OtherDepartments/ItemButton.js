import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import PropTypes from 'prop-types';

import { getOtherDepartmentsIcons } from '../../../Utils/otherDepartmentsUtils';
import Styles from './charity.module.css';

const ItemButton = ({ functionItem, selectedItem, onItemClick }) => (
  <Flex
    flexDirection="column"
    justifyContent="space-around"
    background="white"
    borderRadius="2px"
    height="74px"
    width="74px"
    alignItems="center"
    margin="0px 4px 9px 5px"
    onClick={onItemClick(functionItem)}
    border={
      selectedItem && selectedItem === functionItem.name
        ? '2px solid #4a3991'
        : 'none'
    }
    borderBottom={functionItem.noBorderBottom ? 'none' : '2px solid #4a3991'}
    padding="5px 0px"
    overflow="hidden"
  >
    {functionItem.name && functionItem.name !== '' && (
      <img
        src={getOtherDepartmentsIcons(functionItem.name)}
        width="24px"
        height="25px"
        alt=""
      />
    )}
    <Text className={Styles.OtherDeptButtonTitle}>{functionItem.label}</Text>
  </Flex>
);

ItemButton.defaultProps = {
  functionItem: {},
  selectedItem: '',
  onItemClick: () => {},
};

ItemButton.propTypes = {
  functionItem: PropTypes.object,
  selectedItem: PropTypes.string,
  onItemClick: PropTypes.func,
};

export default ItemButton;
