import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { v1 as uuidv1 } from 'uuid';
import { useSoundToast } from '../../../hooks';
import { fetchDepartmentInfo } from '../../../api/app/fetchDepartmentInfo';
import { cartActions } from '../../../slices/cart.slice';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { getOtherDepartmentsIcons } from '../../../Utils/otherDepartmentsUtils';
import { verifyUserId, appIntegrationRequest } from '../../../Utils/appUtils';
import Exit from '../../../Icons/Exit.svg';
import Styles from './charity.module.css';
import { AppContext } from '../../../AppContext';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';
import { ITEM_TYPE } from '../../../constants';

let allFunctions = [
  {
    itemName: 'Big Brothers Big Sisters',
    image: '',
  },
  {
    itemName: 'Feeding America',
    image: '',
  },
  {
    itemName: 'Local/ Other Iniative',
    image: '',
  },
  {
    itemName: 'MDA',
    image: '',
  },
  {
    itemName: 'USO',
    image: '',
  },
];

export default function Charity() {
  const [selectedItem, setSelectedItem] = useState('');
  const history = useHistory();
  const dispatch = useDispatch();
  const location = useLocation();
  const toast = useSoundToast();
  const { keyPressSound } = useContext(AppContext);
  const [ws] = useContext(WebSocketContext);
  const {
    items,
    config,
    paymentTransactionId,
    isTransactionFinalize,
    UserActionScreenActive,
    tranAgeVerifyInfo,
    lookupCodes,
    storeDetails,
    saleHours,
  } = useSelector(state => ({
    items: state.cart.items,
    config: state.main.configuration,
    paymentTransactionId: state.cart.paymentTransactionId,
    isTransactionFinalize: state.cfd.isTransactionFinalize,
    UserActionScreenActive: state.cfd.UserActionScreenActive,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    lookupCodes: state.main.lookupCodes,
    storeDetails: state.main.storeDetails,
    saleHours: state.main.saleHours,
  }));

  const departmentAmount = location?.state?.departmentAmount || 0;
  const DeptID = location?.state?.id || 0;
  const isNotFoundUPC = location?.state?.UPC || '';

  if (config?.deptMifConfig)
    allFunctions = config?.deptMifConfig.filter(
      i => i.productCategoryId === DeptID
    );

  const totalItems = allFunctions.length;

  const minItems = 29;
  let emptyGrid = [];
  if (totalItems === minItems) {
    emptyGrid = [];
  } else if (totalItems < minItems) {
    const noofEmptygrids = minItems - totalItems;
    emptyGrid = Array.from(Array(noofEmptygrids)).map((_, i) => ({
      value: i + 1,
    }));
  }

  const getCartPayload = ({ productCategoryId, item, deptInfo }) => {
    const payload = {
      isFuel: false,
      itemTypeID: ITEM_TYPE.DEPT,
      requiredAge: deptInfo.requiredAge,
      arbitration: [],
      productCategoryId,
      familyId: productCategoryId,
      name:
        isNotFoundUPC !== '' &&
        isNotFoundUPC !== undefined &&
        isNotFoundUPC?.length > 0
          ? `${isNotFoundUPC}`
          : item.description.replace(/\./g, ''),
      description: deptInfo.description,
      mif: item.id,
      retailPrice: parseFloat(departmentAmount).toFixed(2) / 100,
      quantity: 1,
      category_id: productCategoryId, // productCategoryId.toString(),
      departmentId: productCategoryId, // productCategoryId.toString(),
      category: { id: productCategoryId },
      connexxusCode: deptInfo.connexxusCode || null,
      PSAGroupInfo: deptInfo.psaGroup,
      updatedAt: Date.now(),
      itemSeq: uuidv1(), // dont have item ID so make one unique identifier
      negativeSalesFlag:
        deptInfo.negativeSalesFlag === 'Y' ||
        deptInfo.negativeSalesFlag === true ||
        false,
      manufacturerCouponAllowed: deptInfo.manufacturerCouponAllowed,
      otherCouponAllowed: deptInfo.otherCouponAllowed,
      storeCouponAllowed: deptInfo.storeCouponAllowed,
      isFoodStampAllowed: deptInfo.foodStampAllowed === 'Y' ? 1 : 0,
      itemTaxes: {
        exciseTaxAmount: null,
        isItemLevelTaxOverride: false,
        taxId: deptInfo?.taxId,
      },
      itemRestrictionCode: deptInfo.itemRestrictionCode,
      restrictedMediaTypes: deptInfo.restrictedMediaTypes,
      highAmountLockout: deptInfo.highAmountLockout,
      lowAmountLockout: deptInfo.lowAmountLockout,
      upc:
        isNotFoundUPC !== '' &&
        isNotFoundUPC !== undefined &&
        isNotFoundUPC?.length > 0
          ? `${isNotFoundUPC}`
          : undefined,
    };
    return payload;
  };

  const onItemClick = item => async () => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    if (item.description === 'Exit') {
      dispatch(dailpadActions.resetKeypadValue());
      return history.push('/home');
    }
    if (
      departmentAmount === 0 ||
      departmentAmount === '0' ||
      departmentAmount === ''
    )
      return;
    setSelectedItem(item.description);
    try {
      dispatch(cartActions.setFinalizePayStatus(true));
      let deptResponse = await fetchDepartmentInfo(
        DeptID,
        paymentTransactionId
      );
      deptResponse = JSON.parse(deptResponse.data.data);
      deptResponse = deptResponse.length > 0 ? deptResponse[0] : {};
      global?.logger?.info(`[7POS UI] - fetch Department  Success`);
      const MaxallowedItemPrice =
        config?.storeConfig?.maxAllowedItemPrice !== undefined
          ? Number(config?.storeConfig?.maxAllowedItemPrice)
          : 0;
      if (
        deptResponse?.lowAmountLockout &&
        deptResponse?.lowAmountLockout > 0 &&
        Number(departmentAmount / 100) < deptResponse?.lowAmountLockout
      ) {
        toast({
          description: `Amount too small. Minimum is $${parseFloat(
            deptResponse?.lowAmountLockout
          ).toFixed(2)}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      } else if (
        (deptResponse?.highAmountLockout &&
          deptResponse?.highAmountLockout > 0 &&
          Number(departmentAmount) / 100 > deptResponse.highAmountLockout) ||
        Number(departmentAmount) / 100 > 999999 ||
        (MaxallowedItemPrice !== 0 &&
          Number(departmentAmount) / 100 > MaxallowedItemPrice)
      ) {
        const Amount = parseFloat(
          deptResponse.highAmountLockout < MaxallowedItemPrice ||
            MaxallowedItemPrice === 0
            ? deptResponse.highAmountLockout
            : MaxallowedItemPrice
        ).toFixed(2);
        toast({
          description: `Amount too large. Maximum is $${Amount}`,
          status: 'error',
          duration: 3000,
          position: 'top-left',
        });
      } else {
        const {
          citem,
          lookup,
          notVerified,
          underAged,
          restrictedHours,
        } = verifyUserId({
          data: deptResponse,
          lookupCodes,
          tranAgeVerifyInfo,
          saleHours,
          cartItems: items,
          storeDetails,
        });
        const payload = getCartPayload({
          productCategoryId: DeptID,
          item,
          deptInfo: {
            ...deptResponse,
            requiredAge: citem.requiredAge,
          },
        });
        dispatch(dailpadActions.resetKeypadValue());
        const state = {
          item: { ...item, otherDeptsCartPayload: payload },
          restriction: lookup,
        };
        if (restrictedHours && saleHours) {
          dispatch(cartActions.setRestrictedSale(true));
          return;
        }
        if (underAged) {
          history.push({
            pathname: '/home/manualEntry',
            state: { ...state, underAged: true },
          });
          dispatch(cartActions.setFinalizePayStatus(false));
          return;
        }
        if (notVerified) {
          const dlSwipeReq = appIntegrationRequest({
            type: 'Dlswipe_Req',
            correlationId: paymentTransactionId,
          });
          ws.socket?.send(
            '/app/pinpad/swipeId',
            {},
            JSON.stringify(dlSwipeReq)
          );
          history.push({ pathname: '/home/verification', state });
          dispatch(cartActions.setFinalizePayStatus(false));
          return;
        }
        if (!isTransactionFinalize && !UserActionScreenActive) {
          dispatch(cartActions.addToCart(payload));
          dispatch(
            cartActions.addCartItems([
              { ...payload, retailPrice: payload.retailPrice * 100 },
              ...items,
            ])
          );
        } else {
          global?.logger?.error(
            `[7POS UI] - fetchDepartmentInfo Finalize inprogress ignore to add item.`
          );
        }
      }
    } catch (error) {
      toast({
        description: `Department Not Found`,
        status: 'error',
        duration: 3000,
        position: 'top-left',
      });
      global?.logger?.error(
        `[7POS UI] - fetchDepartmentInfo details Error ${JSON.stringify(error)}`
      );
    }
    dispatch(cartActions.setFinalizePayStatus(false));
    dispatch(dailpadActions.resetKeypadValue());
    history.push('/home');
  };
  return (
    <Box>
      <Box>
        <Text className={Styles.charityLabel}>Charity</Text>
      </Box>
      <Flex
        width="100%"
        borderRadius="2px"
        margin="0 auto"
        h="calc(100vh - 210px)"
        flexDirection="column"
        justifyContent="space-between"
      >
        <Flex flexDirection="row" justifyContent="flex-start" flexWrap="wrap">
          {allFunctions.map((functionItem, index) => (
            <Flex
              key={`${functionItem.description}_${index}`}
              flexDirection="column"
              justifyContent="space-around"
              background="white"
              borderRadius="2px"
              height="100px"
              width="103px"
              alignItems="center"
              margin="0px 4px 9px 5px"
              onClick={onItemClick(functionItem)}
              border={
                selectedItem && selectedItem === functionItem.description
                  ? '2px solid #4a3991'
                  : 'none'
              }
              borderBottom={
                functionItem.noBorderBottom ? 'none' : '2px solid #4a3991'
              }
              padding="5px 0px"
            >
              {functionItem.description !== '' && (
                <img
                  src={getOtherDepartmentsIcons(functionItem.itemName)}
                  width="24px"
                  height="25px"
                  alt=""
                />
              )}
              <Text textAlign="center" color="#2c2f35e0">
                {functionItem.description.replace(/\./g, '')}
              </Text>
            </Flex>
          ))}
          {emptyGrid.map((eItem, index) => (
            <Flex
              key={`other-department-empty-${index}`}
              flexDirection="column"
              justifyContent="space-around"
              background="white"
              borderRadius="2px"
              height="100px"
              width="103px"
              alignItems="center"
              margin="0px 4px 9px 5px"
              border="none"
              borderBottom="none"
              padding="5px 0px"
            >
              <Box />
            </Flex>
          ))}
          <Flex
            key="other-department-exit-1"
            flexDirection="column"
            justifyContent="space-around"
            background="white"
            borderRadius="2px"
            height="100px"
            width="103px"
            alignItems="center"
            margin="0px 4px 9px 5px"
            onClick={onItemClick({ description: 'Exit' })}
            border="none"
            borderBottom="none"
            padding="5px 0px"
          >
            <Box>
              <img src={Exit} alt="Exit" height="24px" width="24px" />
            </Box>
            <Text
              color="rgb(91, 97, 107)"
              fontFamily="Roboto-Medium"
              fontSize="18px"
              fontWeight="500"
            >
              EXIT
            </Text>
          </Flex>
        </Flex>
      </Flex>
    </Box>
  );
}
