import React from 'react';
import { Flex, Image, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { ExitButton } from '../../Common';
import Styles from './InvalidKey.module.css';
import WarningIcon from '../../../Icons/Warning_Icon.svg';

export const InvalidKey = () => {
  const history = useHistory();
  const { state = {} } = useLocation();
  const onExit = () => {
    history.replace('/home');
  };
  const { title, description } = state;
  return (
    <Flex className={Styles.wrapper}>
      <Flex className={Styles.contentWrapper}>
        <Image className={Styles.image} src={WarningIcon} />
        <Text className={Styles.title}>{title}</Text>
        <Text className={Styles.description}>{description}</Text>
      </Flex>
      <Flex className={Styles.exitButtonWrapper}>
        <ExitButton onClick={onExit} />
      </Flex>
    </Flex>
  );
};
