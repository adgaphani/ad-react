import { Input, Grid } from '@chakra-ui/react';
import React, { memo, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { getPriceDetails } from '../../../Utils/cartUtils';
import ItemGroup from '../Items/ItemGroup';
import Styles from './CurrencyConverter.module.css';
import { USCurrencyIcon } from '../../../Icons';
import { getBalanceDue } from '../../../Utils/paymentUtils';

const CurrencyConverter = () => {
  const history = useHistory();
  const location = useLocation();
  const [caCash, setCACash] = useState('');
  const [conversion, setConversion] = useState('');
  const [usCash, setUSCash] = useState('');
  const [amount, setAmount] = useState(0);
  const {
    cartItems,
    taxInfo,
    currencyConversion,
    enteredCash,
    paymentHistory,
    paymentMediaList,
    allPayments,
    basketPromo,
  } = useSelector(state => ({
    cartItems: state.cart.cartItems,
    taxInfo: state.cart.taxInfo,
    currencyConversion: state.main.currencyConversion,
    enteredCash: state.cart.enteredCash,
    paymentHistory: state.cart.paymentHistory,
    paymentMediaList: state.cart.paymentMediaList,
    allPayments: state.cart.allPayments,
    basketPromo: state.cart.basketPromo,
  }));

  const getTotal = caCash =>
    `${Number(
      (
        Math.round(Number(((caCash || 0) * 1) / currencyConversion) * 1000) /
        1000
      ).toFixed(2)
    ) || 0} US CASH`;

  useEffect(() => {
    let { finalTotalPrice } = getPriceDetails(cartItems, taxInfo);
    if (basketPromo?.length) {
      const totalBasketPromotionPrice = basketPromo[0].item_discount / 100;
      finalTotalPrice =
        totalBasketPromotionPrice > 0
          ? Number((finalTotalPrice - totalBasketPromotionPrice).toFixed(2))
          : finalTotalPrice;
    }
    if (cartItems?.length === 0) {
      setAmount(0);
    } else {
      setAmount(finalTotalPrice);
    }
  }, [cartItems, taxInfo]);

  const input = ({ value, onChange = () => {} }) => (
    <Input
      className={Styles.input}
      placeholder=""
      onChange={onChange}
      readOnly
      pattern="[0-9]"
      value={value || '0.00'}
      focusBorderColor="primary"
      borderColor="primary"
    />
  );
  const renderConversion = () => (
    <div className={Styles.conversionGrid}>
      <div className={`${Styles.text} ${Styles.fs30}`}>Current Exchange</div>
      <div className={Styles.text}>{input({ value: caCash })}</div>
      <div className={`${Styles.text} ${Styles.fs30}`}>@</div>
      <div className={Styles.text}>
        {input({
          value: conversion,
        })}
      </div>
      <div className={`${Styles.text} ${Styles.fs30}`}>=</div>
      <div className={Styles.text}>{input({ value: usCash })}</div>
    </div>
  );
  const onExit = () => {
    history.push(location?.route);
  };

  const onItemClick = () => {
    let balanceDueValue = amount;
    if (paymentHistory.length > 0 || enteredCash) {
      balanceDueValue = getBalanceDue({
        allPayments,
        paymentMediaList,
        paymentHistory,
        finalTotalPrice: amount,
      }).balanceDue;
    }
    setCACash(`$${balanceDueValue || 0}`);
    setConversion(`${currencyConversion || 0}: 1`);
    setUSCash(getTotal(balanceDueValue || 0));
  };

  const renderCards = () => (
    <div className={Styles.cardGrid}>
      <ItemGroup
        minItems={12}
        isGroupView={false}
        onItemClick={onItemClick}
        items={[
          {
            id: 1,
            itemId: 1,
            label: 'US Dollar',
            name: 'US Dollar',
            subKeys: [],
            type: 'subgroup',
            thumbnail: USCurrencyIcon,
            isActive: true,
            // type: 'group',
          },
        ]}
        showExit
        onExit={onExit}
        borderClass={Styles.blueBottomBorder}
      />
    </div>
  );

  return (
    <Grid templateColumns="40% 60%">
      {renderConversion()}
      {renderCards()}
    </Grid>
  );
};

export default memo(CurrencyConverter);
