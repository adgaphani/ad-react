import React, { useEffect, useState } from 'react';

import moment from 'moment';
import store from '../../../store';

const PinpadResetTimerTst = () => {
  const [time, setTime] = useState('');

  const interval = 1000;
  let duration = moment.duration('00:05:00');

  const currentTime = () => {
    const disablePinpadForreset = store?.getState()?.main.disablePinpadForreset;
    duration = moment.duration(duration - interval, 'milliseconds');
    let minutes = duration.minutes();
    minutes = minutes <= 9 ? `0${minutes}` : minutes;
    let seconds = duration.seconds();
    seconds = seconds <= 9 ? `0${seconds}` : seconds;
    if (disablePinpadForreset) {
      return `Pinpad Reset in Progress. Pinpad & EBT buttons are disabled.`;
    }
    return `Pinpad Reset in ${minutes}:${seconds}. Pinpad & EBT buttons will be disabled.`;
  };

  useEffect(() => {
    const isTimer = setInterval(() => {
      setTime(currentTime());
    }, 1000);
    return () => {
      clearInterval(isTimer);
    };
  }, []);

  return <>{time}</>;
};

export default PinpadResetTimerTst;
