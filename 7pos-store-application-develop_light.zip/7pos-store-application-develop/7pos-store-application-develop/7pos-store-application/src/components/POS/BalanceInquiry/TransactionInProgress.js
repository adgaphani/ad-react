import React from 'react';
import { useHistory } from 'react-router-dom';
import { Box, Flex, Heading, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import Styles from './BalanceInquiry.module.css';
import Warning_icon from '../../../Icons/Warning_Icon.svg';

const TransactionInProgress = () => {
  const history = useHistory();
  const onExit = () => {
    history.push('/home');
  };
  return (
    <Box
      className={`${Styles.transactionInProgressContainer} ${Styles.hasBackground}`}
      h="calc(100vh - 275px)"
    >
      <Flex flexDirection="column" style={{ padding: '20% ' }}>
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
        >
          <img src={Warning_icon} alt="warning" />
        </Flex>
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          alignItems="center"
        >
          <Heading
            textAlign="center"
            justifyContent="center"
            // color="rgb(111, 110, 127)"
            mt={46}
            style={{
              width: '400px',
              height: '64px',
              color: 'rgb(44, 47, 53)',
              fontSize: '24px',
              fontFamily: 'Roboto-Bold',
              fontWeight: 'bold',
              textAlign: 'center',
              lineHeight: '32px',
            }}
          >
            You are in a Transaction
          </Heading>
          <Text> &quot;Balance inquiry&quot; is an invalid key</Text>
        </Flex>
      </Flex>
      <Flex justifyContent="flex-end">
        <Button onClick={onExit} className={Styles.exitButton} mb={15} mr={15}>
          <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
            EXIT
          </Text>
        </Button>
      </Flex>
    </Box>
  );
};

export default TransactionInProgress;
