import React, { memo, useContext, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Flex, Text, Box } from '@chakra-ui/react';
import moment from 'moment';
// import { updateCacheHardTotals } from '7pos-hardtotals';
import Styles from './BalanceInquiry.module.css';
import ExitButton from '../ExitButton';
import Carousal from '../Carousal/Carousal';
import Processing from '../../../screens/POS/Payment/PaymentMethod/Processing';
import { WebSocketContext } from '../../Common/WebSocket/WebSocketProvider';
import { appIntegrationRequest } from '../../../Utils/appUtils';
import {
  getNewTransactionId,
  handlePayRequest,
} from '../../../Utils/paymentUtils';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { socketActions } from '../../../slices/socket.slice';
import { balanceActions } from '../../../slices/balance.slice';
import {
  BALANCE_INQUIRY,
  BALANCE_INQUIRY_CARD_READ,
  BALANCE_INQUIRY_CANCEL,
} from '../../../constants';
import { AppContext } from '../../../AppContext';

const images = [
  {
    image: `${process.env.PUBLIC_URL}/assets/images/insert.png`,
    name: 'InsertCard',
  },
  {
    image: `${process.env.PUBLIC_URL}/assets/images/swipe.png`,
    name: 'Swipe Card',
  },
  {
    image: `${process.env.PUBLIC_URL}/assets/images/tap.png`,
    name: 'Tap card',
  },
];

const BalanceInquiryForCard = () => {
  const [ws] = useContext(WebSocketContext);
  const { keyPressSound } = useContext(AppContext);
  const dispatch = useDispatch();
  const history = useHistory();
  const {
    cardStatus,
    storeDetails,
    deviceInfo,
    user,
    member,
    paymentTransactionId,
    transactionId,
    hardTotal,
    transactionStartTime,
  } = useSelector(state => ({
    cardStatus: state.socket.cardStatus,
    storeDetails: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    user: state.auth.user,
    member: state.cart.member,
    paymentTransactionId: state.cart.paymentTransactionId,
    transactionId: state.cart.transactionId,
    hardTotal: state.cart.hardTotalSummary,
    transactionStartTime: state.cart.transactionStartTime,
  }));

  const paymentTransId = paymentTransactionId;
  const handleBalanceInq = () => {
    const handlepayLoadObj = handlePayRequest({
      storeDetails,
      user,
      deviceInfo,
      member,
      transactionId: transactionId || getNewTransactionId(),
      transactionStartTime,
      paymentTransactionId: paymentTransId,
    });
    handlepayLoadObj.transactionHeaderInfo.transactionType = BALANCE_INQUIRY;
    handlepayLoadObj.transactionDetails.totalAdjustmentAmount = 0;
    const hardTotalSummary = [];
    hardTotalSummary.push(hardTotal);
    hardTotalSummary.push({
      name: 'runningTotal',
      count: 0,
      amount: 0,
    });
    handlepayLoadObj.transactionDetails.hardTotalSummary = hardTotalSummary;
    const payload = JSON.stringify(handlepayLoadObj);
    // Added cache call to intiate/increment transaction seq in hardtotals(#RISPIN2755)
    // updateCacheHardTotals(payload);
    // updateCdbReport({ transactionRequest: payload }); // CDB Update Balance Enquiry Media
    const paymentRequest = {
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DDTHH:mm:ss'),
        messageType: BALANCE_INQUIRY,
        correlationId: paymentTransactionId,
        source: {
          sourceType: 'POS',
          sourceIdentifier: '1',
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'PINPAD',
          destinationIdentifier: '1',
        },
      },
      messageBody: {
        message: `${payload}`,
      },
    };

    global?.logger?.info(
      `[7POS UI] - pay request(Balance inquiry)  ${JSON.stringify(
        paymentRequest
      )}`
    );
    return { paymentRequest };
  };

  useEffect(() => {
    const { paymentRequest } = handleBalanceInq();
    dispatch(cartActions.setPOSSystemStatus('StartedNewTransaction'));
    dispatch(balanceActions.setBalanceInquiryTrigger(true));
    dispatch(cartActions.setPaymentMethod(BALANCE_INQUIRY));
    dispatch(cfdActions.setUserActionScreenActive(true));
    ws.socket?.send(
      '/app/pinpad/balanceInquiry',
      {},
      JSON.stringify(paymentRequest)
    );
  }, []);

  const goBack = () => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    // cancel PINPAD
    const paymentCancelReq = appIntegrationRequest({
      type: 'Payment_Cancel',
      correlationId: paymentTransactionId,
    });
    ws.socket?.send(
      '/app/payment/cancel',
      {},
      JSON.stringify(paymentCancelReq)
    );
    //
    dispatch(balanceActions.setBalanceActive(false));
    dispatch(balanceActions.setBalanceInquiryTrigger(false));
    history.replace('/home');
  };

  useEffect(() => {
    if (cardStatus === BALANCE_INQUIRY_CANCEL) {
      dispatch(cfdActions.setUserActionScreenActive(false));
      dispatch(socketActions.setCardStatus(null));
      goBack();
    }
  }, [cardStatus]);

  return cardStatus === BALANCE_INQUIRY_CARD_READ ? (
    <Box className={Styles.processingCard}>
      <Processing />
    </Box>
  ) : (
    <Box className={Styles.WaitingForCardContainer}>
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex
          flexDirection="column"
          alignItems="center"
          height="100%"
          justifyContent="center"
        >
          <Carousal images={images} />
          <Text
            mb={2}
            color="rgb(44, 47, 53)"
            fontSize="24px"
            fontFamily="Roboto-bold"
            fontWeight="bold"
            textAlign="center"
          >
            Please have customer
          </Text>
          <Text
            color="rgb(29, 137, 107)"
            fontFamily="Roboto-bold"
            fontWeight="bold"
            textAlign="center"
            fontSize="24px"
          >
            Swipe or Scan the Card for
          </Text>
          <Text
            color="rgb(29, 137, 107)"
            fontFamily="Roboto-bold"
            fontWeight="bold"
            textAlign="center"
            fontSize="24px"
          >
            Balance Inquiry
          </Text>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={goBack} />
        </Box>
      </Flex>
    </Box>
  );
};

export default memo(BalanceInquiryForCard);
