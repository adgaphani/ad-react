import React, { memo, useEffect, useRef } from 'react';
import { Flex, Text, Box, useToast } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import { balanceReceiptRequest } from '../../../Utils/balanceInquiryUtils';
import { fetchEmailReceipt } from '../../../api/payment/fetchEmailReceipt';
import Icon_confirm from '../../../Icons/Icon_confirm.svg';
import Styles from './BalanceInquiry.module.css';
import ExitButton from '../ExitButton';
import { balanceActions } from '../../../slices/balance.slice';
import { cartActions } from '../../../slices/cart.slice';
import { cfdActions } from '../../../slices/cfd.slice';
import { getNewTransactionId } from '../../../Utils/paymentUtils';
import { getCorrelationID, storeTranSeqNumber } from '../../../Utils/appUtils';
import { getDVR } from '../../../hardware/dvr';

const BalanceInquiryForCardResponse = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const toast = useToast();
  const interval = useRef(null);
  const {
    storeDetails,
    user,
    balanceInfo,
    transactionId,
    deviceInfo,
    MembertransactionId,
    paymentTransactionId,
    config,
    channel,
  } = useSelector(state => ({
    storeDetails: state.main.storeDetails,
    user: state.auth.user,
    balanceInfo: state.balance.balanceInfo,
    transactionId: state.cart.transactionId,
    deviceInfo: state.main.deviceInfo,
    MembertransactionId: state.cart.MembertransactionId,
    paymentTransactionId: state.cart.paymentTransactionId,
    config: state.main.configuration,
    channel: state.main.channel,
  }));

  const autoPrint = async paymentReqdata => {
    try {
      paymentReqdata.subject = 'Receipt';
      paymentReqdata.receiptType = 'PRINT';
      await fetchEmailReceipt(paymentReqdata, paymentTransactionId, channel);
    } catch (error) {
      if (error?.response?.data) {
        const errorMessage = JSON.parse(JSON.stringify(error?.response?.data));
        global?.logger?.error(
          `[7POS UI] - Print receipt API Failure Balance Enquiry`
        );
        toast({
          description: errorMessage.message,
          status: 'error',
          duration: 5000,
          position: 'top',
        });
      } else {
        toast({
          description: 'Receipt could not be printed. Please try again',
          status: 'error',
          duration: 5000,
          position: 'top',
        });
      }
    }
  };

  const goBack = () => {
    if (interval.current) clearTimeout(interval.current);
    storeTranSeqNumber({
      transactionId,
      MembertransactionId,
      correlationID: paymentTransactionId,
    });
    dispatch(cartActions.setTransactionId(getNewTransactionId()));
    dispatch(balanceActions.setBalanceActive(false));
    dispatch(balanceActions.setBalanceInquiryTrigger(false));
    dispatch(balanceActions.emptyBalanceInfo());
    dispatch(cartActions.setPaymentTransactionId(getCorrelationID()));
    history.replace('/home');
  };
  useEffect(() => {
    dispatch(cfdActions.setUserActionScreenActive(false));
    const paymentReqdata = balanceReceiptRequest({
      storeDetails,
      user,
      balanceInfo,
      transactionId,
      deviceInfo,
      config,
    });
    getDVR().sendBalanceRequest(
      false,
      config,
      user,
      transactionId,
      storeDetails,
      deviceInfo,
      paymentReqdata.lineItem.items
    );
    autoPrint(paymentReqdata);
    if (interval.current) clearTimeout(interval.current);
    interval.current = setTimeout(() => {
      clearTimeout(interval.current);
      goBack();
    }, 5000);
    return () => {
      if (interval.current) clearTimeout(interval.current);
    };
  }, []);

  return (
    <Box className={Styles.WaitingForCardContainer}>
      <Flex
        flexDirection="column"
        justifyContent="space-between"
        h="100%"
        background="rgb(255,255,255)"
      >
        <Flex
          flexDirection="column"
          alignItems="center"
          height="100%"
          justifyContent="center"
        >
          <Box m="10px">
            <img src={Icon_confirm} alt="" height="35px" width="35px" />
          </Box>
          <Text
            color="rgb(0, 0, 0)"
            fontSize="24px"
            fontFamily="Roboto-bold"
            textAlign="center"
          >
            Please give the Balance
          </Text>
          <Text
            color="rgb(0, 0, 0)"
            fontFamily="Roboto-bold"
            textAlign="center"
            fontSize="24px"
          >
            Inquiry Receipt to the Customer
          </Text>
        </Flex>
        <Box display="block" textAlign="right" p="1rem" w="100%">
          <ExitButton onClick={goBack} />
        </Box>
      </Flex>
    </Box>
  );
};

export default memo(BalanceInquiryForCardResponse);
