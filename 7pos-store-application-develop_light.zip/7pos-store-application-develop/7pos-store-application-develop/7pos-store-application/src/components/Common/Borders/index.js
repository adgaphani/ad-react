import React from 'react';
import { Text } from '@chakra-ui/react';

export const TextBorder = props => (
  <Text
    border="1px solid rgb(224, 32, 32)"
    height="1px"
    width="20px"
    pr={2}
    mr={2}
    {...props}
  />
);
