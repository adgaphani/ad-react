import {
  WAITING_FOR_CARD,
  CARD_READ,
  FLEET,
  FLEET_VOID,
  EBTCB,
  EBTSNAP,
  CASHBACK_AMOUNT,
} from '../../../constants';

export const CardStatus = {
  disableMenu: [
    WAITING_FOR_CARD,
    CARD_READ,
    FLEET,
    FLEET_VOID,
    EBTCB,
    EBTSNAP,
    CASHBACK_AMOUNT,
  ],
};
