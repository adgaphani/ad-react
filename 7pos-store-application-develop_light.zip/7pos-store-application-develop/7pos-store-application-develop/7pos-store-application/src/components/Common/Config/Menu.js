import { MenuBarIcons } from '../../../Icons/menuBarIcons';
import Styles from '../../POS/MenuBar/menubar.module.css';
import { checkMenuTabEnabled } from '../../../Utils/appUtils';

export const getMenuConfig = ({
  isTransHold = false,
  storeDetails,
  enableFuel = false,
  isFuelEnabled,
  isFuelIntegrated,
  isSpeedyStore,
  isSevenRewardsDisable,
}) => [
  {
    label: 'Home',
    link: '/home',
    routeid: 'home',
    icon: MenuBarIcons.home,
    activeClassName: 'menubar_is-active',
    className: Styles.navlink,
  },
  {
    label: 'Trans Hold',
    link: '/home',
    routeid: 'hold',
    icon: MenuBarIcons.payment,
    className: Styles.transholdlink,
    activeClassName: Styles.hold_active,
    isActive: () => isTransHold,
  },
  // #4176 depending fuel flags fuel menu will render on menu bar.
  ...(isFuelEnabled && isFuelIntegrated
    ? [
        {
          label: 'Fuel',
          link: '/fuel',
          routeid: 'fuel',
          icon: isFuelEnabled
            ? isFuelIntegrated
              ? MenuBarIcons.integrated_fuel
              : MenuBarIcons.non_integrated_fuel
            : MenuBarIcons.integrated_fuel,
          activeClassName: 'menubar_is-active',
          className: enableFuel ? Styles.navlink : Styles['disable-navlink'],
        },
      ]
    : []),
  // {
  //   label: 'Restaurant',
  //   link: '/',
  //   icon: MenuBarIcons.restaurant,
  //   routeid: 'food',
  //   activeClassName: 'menubar_is-active',
  //   className: checkMenuTabEnabled(storeDetails?.store || 0)
  //     ? Styles.navlink
  //     : Styles['disable-navlink'],
  // },
  // {
  //   label: 'LVT',
  //   link: '/',
  //   routeid: 'lvt',
  //   icon: MenuBarIcons.lvt,
  //   activeClassName: 'is-active',
  //   className: checkMenuTabEnabled(storeDetails?.store || 0)
  //     ? Styles.navlink
  //     : Styles['disable-navlink'],
  // },
  ...(!isSevenRewardsDisable
    ? [
        {
          label: isSpeedyStore ? '' : '7Rewards',
          link: '/home/7Rewards',
          icon: isSpeedyStore ? MenuBarIcons.speedyReward : '',
          iconHeight: '38.75px',
          iconWidth: '83.2px',
          className: `${Styles.navlink} ${Styles.sevenRewards}`,
          activeClassName: 'menubar_is-active',
          routeid: 'rewards',
        },
      ]
    : []),
  {
    label: 'SYS OK',
    link: '/',
    activeClassName: 'is-active',
    className: checkMenuTabEnabled(storeDetails?.store || 0)
      ? Styles.navlink
      : Styles['disable-navlink'],
    routeid: 'sysok',
  },
];
