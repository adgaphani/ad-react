import React from 'react';
import { Box, Text } from '@chakra-ui/react';

import { Progress } from '../Loader/Progress';
import { Processing } from '../Loader';
import Styles from './index.module.css';

export const ProgressContainer = ({ progress, step }) => (
  <Box className={Styles.progress}>
    {step === 1 && <Processing />}
    <Text className={Styles.boldText}>{Messages.setup_inprogress}</Text>
    <Text className={Styles.boldText}>Step {step} of 2</Text>
    {step === 2 && (
      <>
        <Progress
          cClass={Styles.progressbar}
          value={progress}
          hasStripe
          size="lg"
          colorScheme="green"
        />
        <Text className={Styles.percentage} ml={`${progress}%`}>
          {progress}%
        </Text>{' '}
      </>
    )}
    {step === 1 && (
      <Text fontSize="12px" mt="15px">
        {' '}
        {Messages.please_wait}
      </Text>
    )}
  </Box>
);
