import React from 'react';
import { Image } from '@chakra-ui/react';

import sevenElevenLogo from '@icons/launch_pos.svg';
// import speedyLogo from '@icons/speedway/speedy_logo.svg';
import Styles from './index.module.css';

export const ImageContainer = () => (
  <Image
    mt="44%"
    height="340px"
    width="334px"
    src={sevenElevenLogo}
    className={Styles.sevenEleven1}
    alt="sevenElevenLogo"
  />
);
