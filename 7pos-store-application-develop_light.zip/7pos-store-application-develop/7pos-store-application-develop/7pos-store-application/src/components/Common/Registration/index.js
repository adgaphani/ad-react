import React from 'react';
import { Flex, Box } from '@chakra-ui/react';

import { ImageContainer } from './ImageContainer';
import { ProgressContainer } from './ProgressContainer';
import { Processing } from '../Loader';
import { useRegistration } from '../../../hooks/useRegistration';

export const AutoRegistation = ({ setRegistered, isSpeedyStore }) => {
  const { isProcessing, step, progress, loadingMessage } = useRegistration(
    setRegistered
  );

  return (
    <Flex flexDirection="column" height="100vh">
      <Box height="50%" alignSelf="center" marginLeft="40px">
        <ImageContainer isSpeedyStore={isSpeedyStore} />
      </Box>
      <Box
        height="50%"
        width="50%"
        alignSelf="center"
        paddingTop={step === 2 && '2rem'}
        textAlign="center"
      >
        {isProcessing && (
          <Box>
            <Processing msg={loadingMessage} />
          </Box>
        )}
        {!isProcessing && <ProgressContainer progress={progress} step={step} />}
      </Box>
    </Flex>
  );
};
