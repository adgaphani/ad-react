import React from 'react';
import { Image, Box, Flex } from '@chakra-ui/react';
import sevenElevenLogo from '@icons/launch_pos.svg';

import { Processing } from '../Loader';
import Styles from './index.module.css';

export const NoCompanyScreen = () => (
  <>
    <Flex flexDirection="column" alignItems="center" height="100vh">
      <Image
        mt="15%"
        height="340px"
        width="360px"
        src={sevenElevenLogo}
        className={Styles.sevenEleven1}
        alt="sevenElevenLogo"
        ml="50px"
      />
      <Box transform=" translateY(-80px)" textAlign="center">
        <Processing msg="Awaiting for Store Profile" headerProps={{ mt: 0 }} />
      </Box>
    </Flex>
  </>
);
