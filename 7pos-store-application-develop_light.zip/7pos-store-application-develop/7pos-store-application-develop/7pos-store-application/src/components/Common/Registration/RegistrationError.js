import React from 'react';
import { Text, Box, Image } from '@chakra-ui/react';
import Styles from './index.module.css';
import warningIcon from '../../../Icons/warning_yellow.svg';
import retryIcon from '../../../Icons/refresh_white.svg';
import { Button } from '../Buttons';

export const RegistrationError = ({ onRetry }) => (
  <>
    <Box className={Styles.progress} padding="0px 20px">
      <Box border="1px solid" pb="2px">
        <Image className={Styles.image} src={warningIcon} />

        <Text> {Messages.pos_setup_failed_title} </Text>
        <Text> {Messages.select_retry}</Text>
        <Button
          mt={5}
          onClick={onRetry}
          bg="#3182ce"
          color="rgb(255, 255, 255)"
        >
          <Image height="20px" width="20px" src={retryIcon} mr="5px" />
          Re-try
        </Button>
      </Box>
    </Box>
  </>
);
