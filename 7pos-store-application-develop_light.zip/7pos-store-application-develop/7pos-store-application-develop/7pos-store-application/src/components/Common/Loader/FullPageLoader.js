import React from 'react';
import { Flex, Text } from '@chakra-ui/react';
import Styles from './FullPageLoader.module.css';
import loader from '../../../Icons/Icons_loader.svg';

export const FullPageLoader = ({ message }) => (
  <Flex className={`${Styles.wrapper} ${message ? Styles.column : ''}`}>
    <object type="image/svg+xml" data={loader}>
      svg-animation
    </object>

    {!!message && <Text className={Styles.message}> {message}</Text>}
  </Flex>
);
