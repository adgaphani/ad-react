import React from 'react';
import { Heading } from '@chakra-ui/react';

import loader from '../../../Icons/Icons_loader.svg';

export const Processing = ({ msg }) => (
  <>
    <object type="image/svg+xml" data={loader} style={{ width: '100px' }}>
      svg-animation
    </object>
    {msg && (
      <Heading
        textAlign="center"
        justifyContent="center"
        fontSize="18px"
        mt={5}
      >
        {msg}
      </Heading>
    )}
  </>
);
