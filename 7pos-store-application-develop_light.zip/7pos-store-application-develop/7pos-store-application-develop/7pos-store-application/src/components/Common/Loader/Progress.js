import React from 'react';
import { Progress as ChakraProgress } from '@chakra-ui/react';

export const Progress = ({ value, cClass }) => (
  <>
    <ChakraProgress value={value} hasStripe className={cClass} isAnimated />
  </>
);
