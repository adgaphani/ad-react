import React from 'react';
import loader from '../../../Icons/Icons_redeemreward_loader.svg';
import smallLoader from '../../../Icons/Icons_loader.svg';

const InlineLoader = ({ className, size = 'bg' }) => (
  <object
    type="image/svg+xml"
    data={size === 'bg' ? loader : smallLoader}
    className={className}
  >
    svg-animation
  </object>
);

export default InlineLoader;
