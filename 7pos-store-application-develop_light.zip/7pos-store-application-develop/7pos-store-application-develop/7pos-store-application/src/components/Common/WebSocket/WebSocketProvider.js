import React, { createContext, useEffect, useState } from 'react';
import SockJS from 'sockjs-client';
import { useDispatch } from 'react-redux';
import Stomp from 'stompjs';
import { socketActions } from '../../../slices/socket.slice';
import { BASE_URI } from '../../../constants';
// import { SOCKET_URI } from '../../../constants';

const WebSocketContext = createContext([{}, () => {}]);

const WebSocketProvider = ({ children }) => {
  const [ws, setWs] = useState({});
  const dispatch = useDispatch();

  const onConnected = () => {
    dispatch(socketActions.setSocketStatus('CONNECTED'));
    global?.Logger?.debug(`[7POS UI] websocket connected successfully.`);
  };

  const onDisconnected = () => {
    console.log('websocket Disconnected successfully');
    global?.logger?.info(
      `7POS-Application websocket Disconnected successfully.`
    );
  };

  const WebSocketConnect = () => {
    const sock = new SockJS(`http://${BASE_URI}:8080/ws`);
    const stompClient = Stomp.over(sock);
    stompClient.maxWebSocketFrameSize = 512 * 1024;
    stompClient.splitLargeFrames = true;
    setWs({
      socket: stompClient,
    });

    const onError = error => {
      dispatch(socketActions.setSocketStatus('DISCONNECTED'));
      global?.logger?.error(`7POS-Application websocket error.${error}`);
      const isConnected = stompClient.connected;
      // On Error app disconnect and try to reconnect
      if (isConnected) stompClient.disconnect(onDisconnected, {});
      const reconnectTimer = 30000;
      console.log(
        '7POS-Application schedule reconnect in  Seconds....',
        reconnectTimer / 1000
      );
      global?.logger?.info(
        `7POS-Application schedule reconnect in ${reconnectTimer /
          1000} seconds....`
      );
      setTimeout(() => {
        WebSocketConnect();
      }, reconnectTimer);
    };

    stompClient.debug = m => {
      if (m.indexOf('PING') !== -1 || m.indexOf('PONG') !== -1) return;
      console.log(m);
    };
    stompClient.connect(
      {
        application: '7pos-store-application',
      },
      onConnected,
      onError
    );
  };

  useEffect(() => {
    WebSocketConnect();
    return () => {};
  }, []);

  return (
    <WebSocketContext.Provider value={[ws]}>
      {children}
    </WebSocketContext.Provider>
  );
};

export { WebSocketContext, WebSocketProvider };
