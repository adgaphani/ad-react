import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Box, Divider, Flex } from '@chakra-ui/react';
import { useLocation } from 'react-router-dom';
import { Button } from '../../Buttons';
import { alphabeticEntries, emailSuggestions, numericEntries } from './Entries';
import Styles from './AlphaNumericDailpad.module.css';
import { dailpadActions } from '../../../../slices/dailpad.slice';

function AlphaNumericDailpad({
  dailpadValue = '',
  onEnter,
  onReturn,
  onKeyPress,
  defaultDailpadType = 'ALPHABETIC',
  style = {},
  hideSuggestion = false,
}) {
  const [dailpadType, setDailpadType] = useState(defaultDailpadType);
  const [isCapsLockOn, toggleCapsLock] = useState(false);
  const dispatch = useDispatch();
  const { pathname } = useLocation();
  const isNumbericDailpad = dailpadType === 'NUMERIC';
  const entries = isNumbericDailpad ? numericEntries : alphabeticEntries;
  const changeDailpadType = toType => {
    setDailpadType(toType === 'TO-LETTER' ? 'ALPHABETIC' : 'NUMERIC');
  };
  const handleButtonClick = ({ type, value }) => event => {
    let currentValue = [...dailpadValue].join('');
    if (value.toUpperCase() === 'ENTER' && onEnter) {
      return onEnter();
    }
    if (value.toUpperCase() === 'RETURN' && onReturn) {
      return onReturn();
    }
    if (
      value.toUpperCase() === 'TO-LETTER' ||
      value.toUpperCase() === 'TO-NUM'
    ) {
      return changeDailpadType(value);
    }
    if (value.toUpperCase() === 'SPACEBAR') {
      currentValue += ' ';
      return onKeyPress(currentValue, event);
    }
    if (value.toUpperCase() === 'BACKSPACE') {
      currentValue = currentValue.slice(0, currentValue.length - 1);
      return onKeyPress(currentValue, event);
    }
    if (value.toUpperCase() === 'CAPS-LOCK') {
      toggleCapsLock(!isCapsLockOn);
    }
    if (type === 'string') {
      currentValue += value;
      if (onKeyPress) {
        return onKeyPress(currentValue, event);
      }
      return dispatch(dailpadActions.setDailpadValue({ value: currentValue }));
    }
  };

  const getRow = (columnsStart, columnsEnd, neverShowWithCapsLock = false) => {
    const rowEntries = entries.slice(columnsStart, columnsEnd + 1);
    return rowEntries.map(entry => {
      const baseClass =
        entry.type === 'action' ? Styles.dailpadActions : Styles.dailpadNumbers;
      let buttonValue = entry.value;
      let buttonText = entry.type === 'action' ? entry.child : entry.value;
      const isStringType = entry.type === 'string';
      if (isStringType) {
        if (isCapsLockOn) {
          buttonText = buttonText.toUpperCase();
          buttonValue = buttonValue.toUpperCase();
        }
        if (!isCapsLockOn || neverShowWithCapsLock) {
          buttonText = buttonText.toLowerCase();
          buttonValue = buttonValue.toLowerCase();
        }
      }
      return (
        <Button
          key={buttonValue}
          className={`${baseClass} ${entry.className || ''}`}
          onClick={handleButtonClick({ type: entry.type, value: buttonValue })}
        >
          {pathname === '/CfdHome/Email' && buttonValue === 'ENTER'
            ? 'return'
            : buttonText}
        </Button>
      );
    });
  };

  return (
    <Box
      textAlign="center"
      style={style}
      padding="1px 1px"
      background="rgb(224, 227, 229)"
    >
      {!hideSuggestion && (
        <Flex justifyContent="center" mx="8%" height={49}>
          {emailSuggestions.map((suggestion, index) => {
            const { child } = suggestion;
            return (
              <>
                <Button
                  key={suggestion.id}
                  margin="5px 0px"
                  variant="ghost"
                  fontSize="24px"
                  className={Styles.emailSuggestion}
                  onClick={handleButtonClick({
                    type: suggestion.type,
                    value: child,
                  })}
                >
                  {child}
                </Button>
                {index !== emailSuggestions.length - 1 && (
                  <Divider
                    margin="10px 45px"
                    orientation="vertical"
                    borderColor="rgb(154, 154, 155)"
                  />
                )}
              </>
            );
          })}
        </Flex>
      )}
      <Box pl="5px">
        <Box className={Styles.row1}>{getRow(0, 9)}</Box>
        <Box className={Styles.row2}>
          {getRow(10, isNumbericDailpad ? 17 : 18)}
        </Box>
        <Box className={Styles.row3}>
          {getRow(isNumbericDailpad ? 18 : 19, isNumbericDailpad ? 23 : 27)}
        </Box>
        <Box className={Styles.row4}>
          {getRow(isNumbericDailpad ? 24 : 28, 33, true)}
        </Box>
      </Box>
    </Box>
  );
}

export default AlphaNumericDailpad;
