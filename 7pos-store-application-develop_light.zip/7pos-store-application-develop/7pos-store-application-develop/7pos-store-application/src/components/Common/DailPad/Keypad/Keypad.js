import { Box, Flex, Grid, Input, Text } from '@chakra-ui/react';
import React, { useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { useHistory } from 'react-router-dom';
import { KeypadUtil } from '../../../../Utils/dailpadUtils';
import Styles from './Keypad.module.css';
import { cartActions } from '../../../../slices/cart.slice';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { getMemberInfo } from '../../../../Utils/7rewardsUtils';
import { getMemberTransactionId } from '../../../../Utils/paymentUtils';
import { AppContext } from '../../../../AppContext';
import { Button } from '../../Buttons';
import { useSoundToast } from '../../../../hooks';

const symbols = ['.', '00'];

function Keypad({
  onEnter = null,
  dailpadValueCharLimit = null,
  defaultValue = '',
  showAmounts = true,
  disableDecimal = false,
  max = 99,
  isPassword = false,
}) {
  const [isLastAddedValueDollarAmount, setDollarAmountFlag] = useState(false);
  const [isError, setIsError] = useState(false);
  const dispatch = useDispatch();
  const { showLoader } = useContext(AppContext);
  const {
    dailpad,
    member,
    storeProfile,
    deviceInfo,
    paymentTransactionId,
    isSpeedyStore,
    MaxallowedItemQty,
  } = useSelector(state => ({
    dailpad: state.dailpad,
    member: state.cart.member,
    storeProfile: state.main.storeDetails,
    deviceInfo: state.main.deviceInfo,
    paymentTransactionId: state.cart.paymentTransactionId,
    isSpeedyStore: state.main.isSpeedyStore,
    MaxallowedItemQty: state.cart.iMaxallowedItemQty,
  }));

  const toast = useSoundToast();
  const DisplayToastMsg = ({
    description,
    duration = 3000,
    status = 'error',
  }) => {
    toast({
      description,
      status,
      duration,
      position: 'top-left',
    });
  };
  const history = useHistory();
  const dailPadValue =
    dailpad?.keypad?.value !== '' ? dailpad.keypad.value : defaultValue;
  const Keypad = showAmounts
    ? KeypadUtil.getKeypad(Styles)
    : KeypadUtil.getKeypad(Styles).filter(key => key.type !== 'amount');
  const currentPath = history.location.pathname.split('/');
  let currentScreen = currentPath[currentPath.length - 1].toLowerCase();
  let placeholder = '';
  if (currentPath.pop() === 'manualEntry') {
    currentScreen = 'date';
    placeholder = 'MM/DD/YYYY';
  }

  const [isMemberTrigger, setMemberTrigger] = useState(false);
  const getRewardDetails = async () => {
    let phoneNumber = dailPadValue;
    // Speedway testings
    if (!isSpeedyStore) {
      if (`${phoneNumber}`.length < 10) return;
    } else if (`${phoneNumber}`.length < 7) return;
    if (!phoneNumber || isMemberTrigger) return;
    if (phoneNumber > 10) phoneNumber = Number(`${phoneNumber}`.substr(0, 10));

    const transactionId = localStorage.getItem('transactionId');
    const MembertransactionId = getMemberTransactionId();
    dispatch(cartActions.setMemberTransactionId(MembertransactionId));
    const iBarcodeInfo = {
      BarCodeVersion: '000',
      BarCodeParam1: 'S',
      BarCodeParam2: 'NULL',
      BarCodeParam3: 'NULL',
      BarCodeParam4: 'NULL',
      BarCodeParam5: 'NULL',
      BarCodeParam6: 'NULL',
    };
    dispatch(cartActions.setMemberBarcodeInfo(iBarcodeInfo));
    const newRelicRequest = {
      storeProfile,
      terminalID: deviceInfo?.id,
      tranSeq: transactionId,
      dgetranSeq: MembertransactionId,
      MemberBarcodeInfo: iBarcodeInfo,
    };
    try {
      const isMemberTrigger = localStorage.getItem('isMemberTrigger');
      if (!isMemberTrigger) {
        setMemberTrigger(true);
        showLoader(true);
        const retValue = await getMemberInfo({
          memberId: phoneNumber?.toString(),
          dispatch,
          isActiveMember: member !== null || false,
          newRelicRequest,
          paymentTransactionId,
          ...(isSpeedyStore ? { queryParams: { idType: 'ALT_ID' } } : {}),
          isSpeedyStore,
        });
        showLoader(false);
        setMemberTrigger(false);
        dispatch(dailpadActions.resetDailpadState());
        if (!retValue) {
          history.push('/home/7PosAppError');
          return;
        }
      } else {
        global?.logger?.info(`[7POS UI] - Member Transaction inprogress`);
      }
      history.push('/home');
    } catch (error) {
      global.logger.error(
        `[7POS UI] - getMemeber call fail from keypad ${JSON.stringify(error)}`
      );
      showLoader(false);
      setMemberTrigger(false);
      dispatch(dailpadActions.resetDailpadState());
    }
  };
  const onEnterDefault = () => {
    switch (currentScreen) {
      case 'home':
        global?.logger?.info(`keypad enter pressed form home screen`);
        break;
      case 'date':
        global?.logger?.info(`date: --- keypad enter pressed form home screen`);
        break;

      case 'phone':
        return getRewardDetails();

      case 'payment':
        dispatch(dailpadActions.setKeypadValue({ value: '' }));
        return dispatch(cartActions.setVoidTransOGRefNumber(dailPadValue));

      default:
        break;
    }
  };

  const withMemberPhNumFormat = value => {
    const phoneFormat = /[^\d]/g;
    let unmask = value.replace(phoneFormat, '');
    unmask = unmask.slice(0, 10);
    const size = unmask.length;
    if (size) {
      if (size < 7) {
        unmask = `(${unmask.substring(0, 3)})${unmask.substring(3, 6)}`;
      } else {
        unmask = `(${unmask.substring(0, 3)})${unmask.substring(
          3,
          6
        )}-${unmask.substring(6, 10)}`;
      }
    }
    return unmask;
  };

  const dateDisplayFormat = value => {
    let date = value;
    if (value.length === 2 || value.length === 5) {
      date = `${value}/`;
    }
    return date;
  };

  const formatValueByScreen = value => {
    switch (currentScreen) {
      case 'home':
      case 'fuel':
      case 'date':
      case 'cardprocess':
      case 'vaultstart':
      case 'ofline':
      case 'envelop': // TODO: RENAME it to specific to funcationality
        return value;
      case 'phone':
        return withMemberPhNumFormat(value);
      case 'functionsecurity':
        return value;
      default:
        if (value === 0) return 0;
        return disableDecimal
          ? Number(value)
          : (Number(value) / 100).toFixed(2);
    }
  };

  const limitValueLengthByScreen = value => {
    switch (currentScreen) {
      case 'phone':
        return value.slice(0, 12);
      case 'date':
        return value.slice(0, 10);
      case 'payment':
        return value.slice(0, 14);
      case 'functionsecurity':
        return isPassword ? value.slice(0, 6) : value.slice(0, 2);
      default:
        return value;
    }
  };

  const setDailPadValue = value => {
    const formattedValue = limitValueLengthByScreen(value);
    dispatch(dailpadActions.setKeypadValue({ value: formattedValue }));
  };

  const resetError = () => {
    if (isError) setIsError(false);
  };

  const addToDailPadValue = number => event => {
    event.stopPropagation();
    resetError();
    let updatedValue = dailPadValue;
    if (number === '.') {
      number = '';
      return;
    }
    if (currentScreen === 'date') {
      updatedValue = dateDisplayFormat(updatedValue);
    }
    if (isLastAddedValueDollarAmount && !symbols.includes(number) && number) {
      updatedValue = number;
    } else {
      updatedValue += number;
    }
    setDailPadValue(
      dailpadValueCharLimit
        ? `${updatedValue.trim()}`.slice(0, dailpadValueCharLimit)
        : updatedValue?.trim()
    );
    setDollarAmountFlag(false);
  };

  const handleAction = action => event => {
    event.stopPropagation();
    setDollarAmountFlag(false);
    resetError();
    if (action === 'BACKSPACE') {
      return setDailPadValue(dailPadValue.substr(0, dailPadValue.length - 1));
    }
    if (action === 'CLEAR') {
      dispatch(cartActions.setItemQuantity(0));
      return setDailPadValue('');
    }
    if (action === 'ENTER') {
      if (currentScreen === 'date') {
        // if date not valid then set error true else ignore
        const isValidDOB = moment(dailPadValue, 'MM/DD/YYYY', true).isValid();
        const year = moment(dailPadValue, 'MM/DD/YYYY', true).year();
        if (!isValidDOB || year === 0) {
          setIsError(true);
          return;
        }
      }
      if (dailPadValue.length > max) {
        setIsError(true);
        return;
      }
      return onEnter ? onEnter(dailPadValue) : onEnterDefault();
    }
    if (
      action === 'QUANTITY' &&
      Number(dailPadValue) > 1 &&
      currentScreen === 'home'
    ) {
      if (MaxallowedItemQty < Number(dailPadValue)) {
        DisplayToastMsg({
          description: `Quantity too big. Number cannot be over ${MaxallowedItemQty}`,
        });
      } else {
        dispatch(cartActions.setItemQuantity(Number(dailPadValue)));
        dispatch(dailpadActions.resetDailpadState());
      }
      return;
    }
    console.warn(`Error in CustomDailPad: ${action} is not defined!`);
  };

  const setDailPadValueToDollarAmount = amount => event => {
    event.stopPropagation();
    setDollarAmountFlag(true);
    setDailPadValue(
      `${disableDecimal ? Number(amount) : Number(amount) * 100}`
    );
  };

  const formattedValue = dailPadValue ? formatValueByScreen(dailPadValue) : '';
  return (
    <Flex justify="space-between" className={Styles.customDailpad}>
      <Box className={Styles.numbersContainer}>
        <Grid templateColumns="repeat(4, 1fr)" gap={2}>
          <Input
            className={`${Styles.inputFullWidth} ${Styles.dailPadInput} ${
              isError ? Styles.showError : ''
            } ${dailPadValue !== '' ? Styles.dailpadActiveBorder : ''}`}
            isReadOnly
            value={formattedValue}
            placeholder={placeholder}
            type={
              isPassword
                ? 'password'
                : currentScreen === 'phone'
                ? 'tel'
                : 'text'
            }
          />
          {Keypad.map(k => (
            <Button
              key={k.id}
              className={k.className}
              onClick={event => {
                if (k.type === 'action') handleAction(k.value)(event);
                else if (k.type === 'amount')
                  setDailPadValueToDollarAmount(k.value)(event);
                else addToDailPadValue(k.value)(event);
              }}
            >
              {k.value === 'QUANTITY' ? (
                <Text
                  dangerouslySetInnerHTML={{
                    __html: `${k.child}<br/><span {Styles.dailapadQtymsg}>Qty</span>`,
                  }}
                />
              ) : k.type === 'action' ? (
                k.child
              ) : (
                k.value
              )}
            </Button>
          ))}
        </Grid>
      </Box>
    </Flex>
  );
}

export default Keypad;
