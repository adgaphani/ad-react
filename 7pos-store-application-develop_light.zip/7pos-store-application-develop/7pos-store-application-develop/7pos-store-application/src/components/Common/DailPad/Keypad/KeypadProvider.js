import React from 'react';
import { Box, Grid } from '@chakra-ui/react';

import Keypad from './Keypad';

export default function KeypadProvider({ children, showAmounts = true }) {
  return (
    <Grid templateColumns="50% 50%">
      <Box pr="0.5rem">
        <Keypad defaultValue="" showAmounts={showAmounts} />
      </Box>
      <Box>{children}</Box>
    </Grid>
  );
}
