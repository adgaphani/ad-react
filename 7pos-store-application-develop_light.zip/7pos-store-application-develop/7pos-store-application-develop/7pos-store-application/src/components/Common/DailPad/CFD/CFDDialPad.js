/* eslint-disable no-case-declarations */
/* eslint-disable react/prop-types */

import { Box, Grid, Icon } from '@chakra-ui/react';

import { MdBackspace } from 'react-icons/md';
import React, { useContext } from 'react';
import Styles from '../Dailpad.module.css';
import { AppContext } from '../../../../AppContext';

const dailPadButtons = [
  { value: 1, type: 'value' },
  { value: 2, type: 'value' },
  { value: 3, type: 'value' },
  { value: 4, type: 'value' },
  { value: 5, type: 'value' },
  { value: 6, type: 'value' },
  { value: 7, type: 'value' },
  { value: 8, type: 'value' },
  { value: 9, type: 'value' },
  { value: 'CLEAR', type: 'action', color: '#e0e3e5' },
  // { value: " ", type: "action", color: "#e0e3e5" },
  { value: 0, type: 'value' },
  {
    value: 'BACKSPACE',
    type: 'action',
    color: '#e0e3e5',
    icon: 'MdBackspace',
  },
];
const CFDDialPad = ({
  currentValue,
  onUpdateValue,
  clearField,
  isAltIDEntry,
  pattern,
}) => {
  const { keyPressSound } = useContext(AppContext);
  const updateCurrentInput = button => {
    const curchr = currentValue?.length;
    if (isAltIDEntry) {
      if (curchr === 14) {
        return;
      }
      const curval = currentValue;
      if (curchr === 3 && curval.indexOf('(') <= -1) {
        currentValue = `(${curval}) `;
      } else if (curchr === 4 && curval.indexOf('(') > -1) {
        currentValue = `${curval}) `;
      } else if (curchr === 5 && curval.indexOf(')') > -1) {
        currentValue = `${curval} `;
      } else if (curchr === 9) {
        currentValue = `${currentValue}-`;
      }
      const cVal = currentValue + button.value;
      onUpdateValue(cVal);
    } else if (pattern) {
      const cVal = currentValue + button.value;
      onUpdateValue(cVal);
    } else {
      if (curchr === 5) {
        return;
      }
      const cVal = currentValue + button.value;
      onUpdateValue(cVal);
    }
  };

  const dailPadActions = button => {
    const action = button.value.toLowerCase();
    switch (action) {
      case 'enter':
        clearField('');
        break;
      case 'backspace':
        let cVal = currentValue;
        cVal = cVal.substr(0, cVal.length - 1);
        onUpdateValue(cVal);
        break;
      case 'clear':
        onUpdateValue('');
        break;
      case 'error':
        console.log(button);
        break;
      default:
        break;
    }
  };

  const dailPadButtonHandler = (e, button) => {
    e.stopPropagation();
    switch (button.type) {
      case 'value':
        updateCurrentInput(button);
        break;
      case 'action':
        dailPadActions(button);
        break;

      default:
        break;
    }
  };
  return (
    <>
      <Box bg="#e0e3e5" p={3} ml="8%" mr="8%">
        <Grid
          templateColumns="repeat(3, 1fr)"
          templateRows="repeat(3, 1fr)"
          gap={2}
        >
          {dailPadButtons.map((button, i) => (
            <Box
              key={i}
              bg={button.color || '#fbfcfc'}
              m={1}
              px={3}
              py={5}
              data-name={`button-${button.value.toString().toLowerCase()}`}
              className={Styles.dailPadButton}
              onClick={e => {
                keyPressSound
                  ?.play?.()
                  .catch(e => console.log('Sound error', e));
                dailPadButtonHandler(e, button);
              }}
              textAlign="center"
              fontSize="1.87vw"
              fontWeight="bold"
              fontFamily="Roboto-Bold"
              shadow="sm"
            >
              {button.icon ? (
                button.icon === 'MdBackspace' ? (
                  <MdBackspace color="rgb(123, 134, 139)" />
                ) : (
                  <Icon name={button.icon} color="#ffffff" />
                )
              ) : (
                button.value
              )}
            </Box>
          ))}
        </Grid>
      </Box>
    </>
  );
};

export default CFDDialPad;
