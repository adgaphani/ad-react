/* eslint-disable import/order */
/* eslint-disable react/prop-types */

import { Box, Grid } from '@chakra-ui/react';

import { DailpadUtil } from '../../../Utils/dailpadUtils';
import React, { useContext } from 'react';
import Styles from './Dailpad.module.css';
import { AppContext } from '../../../AppContext';

const DailPad = ({
  currentValue,
  onUpdateValue,
  clearField,
  charAt = null,
  handleSubmit,
  hideKey = [],
}) => {
  const { keyPressSound } = useContext(AppContext);
  const updateCurrentInput = button => {
    let cVal = currentValue;
    if (charAt !== null || charAt !== undefined) {
      cVal =
        currentValue.substr(0, charAt) +
        button.value +
        currentValue.substr(charAt, currentValue.length);
    } else {
      cVal = currentValue + button.value;
    }
    onUpdateValue(cVal);
  };

  const dailPadActions = button => {
    const action = button.value.toLowerCase();
    switch (action) {
      case 'enter':
        clearField('');
        handleSubmit?.();
        break;
      case 'backspace':
        // eslint-disable-next-line no-case-declarations
        // if (!isCanadaStore) {
        //   let cVal = currentValue;
        //   if (charAt !== null && charAt !== undefined) {
        //     const cValArr = cVal.split('');
        //     cValArr.pop();
        //     cVal = cValArr.join('');
        //   } else {
        //     cVal = cVal.substr(0, cVal.length - 1);
        //   }
        //   onUpdateValue(cVal, true);
        //   break;
        // }
        onUpdateValue(currentValue.substr(0, currentValue.length - 1), true);
        break;
      case 'clear':
        onUpdateValue('');
        break;
      case 'error':
        console.log(button);
        break;
      default:
        break;
    }
  };

  const dailPadButtonHandler = (e, button) => {
    e.stopPropagation();
    switch (button.type) {
      case 'value':
        updateCurrentInput(button);
        break;
      case 'action':
        dailPadActions(button);
        break;

      default:
        break;
    }
  };
  return (
    <Box bg="#e0e3e5" p={1}>
      <Grid
        templateColumns="repeat(3, 1fr)"
        // templateRows="repeat(4, 1fr)"
      >
        {DailpadUtil.dailPadButtons(Styles).map((button, i) => (
          <Box
            key={i}
            shadow="sm"
            bg={button.color || '#fbfcfc'}
            m={1}
            px={3}
            py={5}
            display={hideKey.includes(button?.value) ? 'none' : 'block'}
            data-name={`button-${button.value.toString().toLowerCase()}`}
            className={`${Styles.dailPadButton} ${
              button?.value === 'ENTER' ? Styles.enterbtnTxt : ''
            }`}
            onClick={e => {
              keyPressSound?.play?.().catch(e => console.log('Sound error', e));
              dailPadButtonHandler(e, button);
            }}
          >
            {button.icon ? button.icon : button.value}
          </Box>
        ))}
      </Grid>
    </Box>
  );
};

export default DailPad;
