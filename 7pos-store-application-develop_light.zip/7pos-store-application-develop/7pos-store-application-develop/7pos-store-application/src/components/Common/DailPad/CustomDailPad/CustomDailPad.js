import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Flex, Grid, Input } from '@chakra-ui/react';
import { Button } from '../../Buttons';
import {
  CustomDailPadUtil,
  getActionRefByScreen,
} from '../../../../Utils/dailpadUtils';
import Styles from './CustomDailPad.module.css';
import { dailpadActions } from '../../../../slices/dailpad.slice';
import { cartActions } from '../../../../slices/cart.slice';
import { useSoundToast } from '../../../../hooks';

const symbols = ['.', '00'];

function CustomDailPad({
  onEnter = null,
  dailPadValue,
  setDailPadValue,
  showDollarAmounts = true,
  showSymbols = true,
  containerClassName = !showDollarAmounts ? Styles.dailpadPosition : '',
  dailpadValueCharLimit = null,
  dollarAmountContainerClassName = showDollarAmounts
    ? Styles.dollarAmountsBackground
    : '',
}) {
  const [isLastAddedValueDollarAmount, setDollarAmountFlag] = useState(false);
  const [isError, setIsError] = useState(false);
  const dispatch = useDispatch();
  const { dailpad, MaxallowedItemQty } = useSelector(state => ({
    dailpad: state.dailpad,
    MaxallowedItemQty: state.cart.iMaxallowedItemQty,
  }));
  const numbers = CustomDailPadUtil.getNumbers(showSymbols, Styles);
  const dollarAmounts = CustomDailPadUtil.getDollarAmounts(
    showDollarAmounts,
    Styles
  );
  const toast = useSoundToast();
  const DisplayToastMsg = MSG => {
    toast({
      description: MSG,
      status: 'error',
      duration: 3000,
      position: 'top-left',
    });
  };

  const onEnterDefault = () => {
    const maxCreditItems = localStorage.getItem('maxCreditItems');
    const [isError, actionRef, payload] = getActionRefByScreen(
      dailpad,
      MaxallowedItemQty,
      maxCreditItems
    );
    if (isError) {
      if (payload[0].appliedCouponQty > 0) {
        const ReqremoveQty = payload[0].appliedCouponQty - payload[0].quantity;
        dispatch(
          cartActions.removeAssociateCoupon({
            item: dailpad.currentActionPayload,
            removeQty: ReqremoveQty,
            itemQty: payload[0].quantity,
          })
        );
        return dispatch(dailpadActions.resetDailpadState());
      }
      if (dailpad.currentActionPayload.negativeSalesFlag) {
        DisplayToastMsg(
          `INVALID ENTRY - CREDIT ITEM SALES CANNOT HAVE A QUANTITY GREATER THAN ${maxCreditItems}`
        );
      }
      return setIsError(true);
    }
    if (actionRef && payload) {
      dispatch(actionRef(...payload));
      dispatch(dailpadActions.resetDailpadState());
    }
  };

  const resetError = () => {
    if (isError) setIsError(false);
  };

  const addToDailPadValue = number => event => {
    event.stopPropagation();
    resetError();
    let updatedValue = dailPadValue;
    if (isLastAddedValueDollarAmount && !symbols.includes(number) && number) {
      updatedValue = number;
    } else {
      updatedValue += number;
    }
    setDailPadValue(
      dailpadValueCharLimit
        ? `${updatedValue}`.slice(0, dailpadValueCharLimit)
        : updatedValue
    );
    setDollarAmountFlag(false);
  };

  const handleAction = action => event => {
    event.stopPropagation();
    setDollarAmountFlag(false);
    resetError();
    if (action === 'BACKSPACE') {
      return setDailPadValue(dailPadValue.substr(0, dailPadValue.length - 1));
    }
    if (action === 'CLEAR') {
      return setDailPadValue('');
    }
    if (action === 'ENTER') {
      return onEnter ? onEnter(dailPadValue) : onEnterDefault();
      // return setDailPadValue('')
    }
    console.warn(`Error in CustomDailPad: ${action} is not defined!`);
  };

  const setDailPadValueToDollarAmount = amount => event => {
    event?.stopPropagation();
    setDollarAmountFlag(true);
    setDailPadValue(`${amount}.00`);
  };

  return (
    <Flex
      justify="space-between"
      className={`${Styles.customDailpad} ${containerClassName}`}
    >
      <Box className={Styles.numbersContainer}>
        <Grid templateColumns="repeat(6, 1fr)" gap={2}>
          <Input
            className={`${Styles.inputFullWidth} ${Styles.dailPadInput} ${
              isError ? Styles.showError : ''
            }`}
            isReadOnly
            value={dailPadValue}
          />
          {numbers.map(number => (
            <Button
              key={number.id}
              className={number.className}
              onClick={addToDailPadValue(number.value)}
            >
              {number.value}
            </Button>
          ))}
          {CustomDailPadUtil.actions(Styles).map(action => (
            <Button
              key={action.id}
              className={action.className}
              onClick={handleAction(action.value)}
            >
              {action.child}
            </Button>
          ))}
        </Grid>
      </Box>
      <Box
        className={`${Styles.dollarAmountContainer} ${dollarAmountContainerClassName}`}
      >
        <Grid templateColumns="repeat(1, 1fr)" gap={2}>
          {dollarAmounts.map(amount => (
            <Button
              key={amount.id}
              className={amount.className}
              onClick={setDailPadValueToDollarAmount(amount.value)}
            >
              {amount.value}
            </Button>
          ))}
        </Grid>
      </Box>
    </Flex>
  );
}

export default CustomDailPad;
