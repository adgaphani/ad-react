/* eslint-disable react/prop-types */

import { Box, Grid, Icon } from '@chakra-ui/react';

import { MdBackspace } from 'react-icons/md';
import React from 'react';
import Styles from '../Dailpad.module.css';

const dailPadButtons = [
  { value: 1, type: 'value', color: '#cfd3d6' },
  { value: 2, type: 'value', color: '#cfd3d6' },
  { value: 3, type: 'value', color: '#cfd3d6' },
  { value: 4, type: 'value', color: '#cfd3d6' },
  { value: 5, type: 'value', color: '#cfd3d6' },
  { value: 6, type: 'value', color: '#cfd3d6' },
  { value: 7, type: 'value', color: '#cfd3d6' },
  { value: 8, type: 'value', color: '#cfd3d6' },
  { value: 9, type: 'value', color: '#cfd3d6' },
  { value: 0, type: 'value', color: '#cfd3d6' },
  { value: 'Q', type: 'value' },
  { value: 'W', type: 'value' },
  { value: 'E', type: 'value' },
  { value: 'R', type: 'value' },
  { value: 'T', type: 'value' },
  { value: 'Y', type: 'value' },
  { value: 'U', type: 'value' },
  { value: 'I', type: 'value' },
  { value: 'O', type: 'value' },
  { value: 'P', type: 'value' },
];
const dailPadButtonsSecondSet = [
  { value: 'A', type: 'value' },
  { value: 'S', type: 'value' },
  { value: 'D', type: 'value' },
  { value: 'F', type: 'value' },
  { value: 'G', type: 'value' },
  { value: 'H', type: 'value' },
  { value: 'J', type: 'value' },
  { value: 'K', type: 'value' },
  { value: 'L', type: 'value' },
];

const dailPadButtonsThirdSet = [
  { value: 'Z', type: 'value' },
  { value: 'X', type: 'value' },
  { value: 'C', type: 'value' },
  { value: 'V', type: 'value' },
  { value: 'B', type: 'value' },
  { value: 'N', type: 'value' },
  { value: 'M', type: 'value' },
  {
    value: 'BACKSPACE',
    type: 'action',
    color: '#e0e3e5',
    icon: 'MdBackspace',
  },
];

const PostalDialPad = ({ currentValue, onUpdateValue, clearField }) => {
  const updateCurrentInput = button => {
    const curchr = currentValue?.length;
    if (curchr === 7) {
      return;
    }
    const curval = currentValue;
    if (curchr === 3) {
      currentValue = `${curval} `;
    }
    const cVal = currentValue + button.value;
    onUpdateValue(cVal);
  };

  const dailPadActions = button => {
    const action = button.value.toLowerCase();
    switch (action) {
      case 'enter':
        clearField('');
        break;
      case 'backspace':
        // eslint-disable-next-line no-case-declarations
        let cVal = currentValue;
        cVal = cVal.substr(0, cVal.length - 1);
        onUpdateValue(cVal);
        break;
      case 'clear':
        onUpdateValue('');
        break;
      case 'error':
        console.log(button);
        break;
      case ' ':
        console.log(button);
        break;
      default:
        break;
    }
  };

  const dailPadButtonHandler = (e, button) => {
    e.stopPropagation();
    switch (button.type) {
      case 'value':
        updateCurrentInput(button);
        break;
      case 'action':
        dailPadActions(button);
        break;

      default:
        break;
    }
  };
  return (
    <>
      <Box bg="#e0e3e5" p={3}>
        <Grid
          templateColumns="repeat(10, 1fr)"
          templateRows="repeat(2, 1fr)"
          gap={2}
        >
          {dailPadButtons.map((button, i) => (
            <Box
              key={i}
              bg={button.color || '#fbfcfc'}
              m={1}
              px={3}
              py={5}
              textalign="center"
              data-name={`button-${button.value.toString().toLowerCase()}`}
              className={Styles.dailPadButton}
              onClick={e => dailPadButtonHandler(e, button)}
              fontSize="1.87vw"
              fontWeight="bold"
              fontFamily="Roboto-Bold"
              shadow="sm"
            >
              {button.value}
            </Box>
          ))}
        </Grid>
        <Grid
          templateColumns="repeat(9, 1fr)"
          templateRows="repeat(1, 1fr)"
          gap={2}
          px={8}
        >
          {dailPadButtonsSecondSet.map((button, i) => (
            <Box
              key={i}
              bg={button.color || '#fbfcfc'}
              m={1}
              px={3}
              py={5}
              textalign="center"
              data-name={`button-${button.value.toString().toLowerCase()}`}
              className={Styles.dailPadButton}
              onClick={e => dailPadButtonHandler(e, button)}
              fontSize="1.87vw"
              fontWeight="bold"
              fontFamily="Roboto-Bold"
              shadow="sm"
            >
              {button.value}
            </Box>
          ))}
        </Grid>
        <Grid
          templateColumns="repeat(8, 1fr)"
          templateRows="repeat(1, 1fr)"
          gap={2}
          px={12}
        >
          {dailPadButtonsThirdSet.map((button, i) => (
            <Box
              key={i}
              bg={button.color || '#fbfcfc'}
              m={1}
              px={3}
              py={5}
              textalign="center"
              data-name={`button-${button.value.toString().toLowerCase()}`}
              className={Styles.dailPadButton}
              onClick={e => dailPadButtonHandler(e, button)}
              fontSize="1.87vw"
              fontWeight="bold"
              fontFamily="Roboto-Bold"
              shadow={
                button.value !== ' ' && button.value !== 'MdBackspace'
                  ? 'sm'
                  : ''
              }
            >
              {button.icon ? (
                button.icon === 'MdBackspace' ? (
                  <MdBackspace color="#7f8b8f" />
                ) : (
                  <Icon name={button.icon} color="#ffffff" />
                )
              ) : (
                button.value
              )}
            </Box>
          ))}
        </Grid>
      </Box>
    </>
  );
};

export default PostalDialPad;
