/* eslint-disable import/order */
/* eslint-disable jsx-a11y/alt-text */

import CFD_AllCaps from '../../../../Icons/Icon_cfd_AllCaps.svg';
import Icon_Backspace from '../../../../Icons/Icon_Backspace.svg';
import React from 'react';
import Styles from './AlphaNumericDailpad.module.css';

export const numericEntries = [
  { type: 'string', value: '1' },
  { type: 'string', value: '2' },
  { type: 'string', value: '3' },
  { type: 'string', value: '4' },
  { type: 'string', value: '5' },
  { type: 'string', value: '6' },
  { type: 'string', value: '7' },
  { type: 'string', value: '8' },
  { type: 'string', value: '9' },
  { type: 'string', value: '0' },
  // { type: 'string', value: '#',  },
  { type: 'string', value: '$' },
  { type: 'string', value: '!' },
  { type: 'string', value: '~' },
  { type: 'string', value: '&' },
  { type: 'string', value: '=' },
  { type: 'string', value: '#' },
  { type: 'string', value: '[' },
  { type: 'string', value: ']' },
  { type: 'string', value: '#+=', className: Styles.symbols },
  { type: 'string', value: '.' },
  // { type: 'string', value: '^', className: Styles.actionBackground },
  // {
  //   type: 'action',
  //   value: 'CAPS-LOCK',
  //   child: 'CAPS',
  //   className: Styles.actionBackground
  // },
  { type: 'string', value: '_' },
  { type: 'string', value: '-' },
  { type: 'string', value: '+' },
  {
    type: 'action',
    value: 'BACKSPACE',
    child: <img src={Icon_Backspace} color="#7b868b" />,
    className: Styles.backSpace,
  },
  {
    type: 'action',
    value: 'TO-LETTER',
    child: 'ABC',
    className: Styles.toLetter,
  },
  {
    type: 'action',
    value: 'SPACEBAR',
    child: 'space',
    className: Styles.spaceBar,
  },
  { type: 'string', value: '@', className: Styles.actionBackground },
  // { type: "string", value: ".", className: Styles.actionBackground },
  {
    type: 'string',
    value: '.com',
    className: Styles.com,
  },
  {
    type: 'action',
    value: 'ENTER',
    child: 'ENTER',
    className: Styles.enter,
  },
  // {
  //   type: "action",
  //   value: "RETURN",
  //   child: "return",
  //   className: Styles.return
  // }
  // { type: 'string', value: '\'', },
  // { type: 'string', value: ':', },
  // { type: 'string', value: ';', },
  // { type: 'string', value: '?', },
  // { type: 'string', value: '/', },
  // ,,,{
  //   type: 'action',
  //   value: 'ASTERICK',
  //   child: '*',
  //   className: Styles.actionBackground
  // },
  // {
  //   type: 'action',
  //   value: "ENTER",
  //   child: 'ENTER',
  //   className: Styles.enter
  // },
];

export const alphabeticEntries = [
  { type: 'string', value: 'Q' },
  { type: 'string', value: 'W' },
  { type: 'string', value: 'E' },
  { type: 'string', value: 'R' },
  { type: 'string', value: 'T' },
  { type: 'string', value: 'Y' },
  { type: 'string', value: 'U' },
  { type: 'string', value: 'I' },
  { type: 'string', value: 'O' },
  { type: 'string', value: 'P' },
  { type: 'string', value: 'A' },
  { type: 'string', value: 'S' },
  { type: 'string', value: 'D' },
  { type: 'string', value: 'F' },
  { type: 'string', value: 'G' },
  { type: 'string', value: 'H' },
  { type: 'string', value: 'J' },
  { type: 'string', value: 'K' },
  { type: 'string', value: 'L' },
  // { type: 'string', value: ',', },
  // { type: 'string', value: '.', className: Styles.actionBackground },
  {
    type: 'action',
    value: 'CAPS-LOCK',
    child: <img src={CFD_AllCaps} color="#7b868b" />,
    className: Styles.capsLock,
  },
  { type: 'string', value: 'Z' },
  { type: 'string', value: 'X' },
  { type: 'string', value: 'C' },
  { type: 'string', value: 'V' },
  { type: 'string', value: 'B' },
  { type: 'string', value: 'N' },
  { type: 'string', value: 'M' },
  // { type: 'string', value: '!', },
  // { type: 'string', value: '?', },
  // { type: 'string', value: '@', className: Styles.actionBackground },
  {
    type: 'action',
    value: 'BACKSPACE',
    child: <img src={Icon_Backspace} color="#7b868b" />,
    className: Styles.backSpace,
  },
  {
    type: 'action',
    value: 'TO-NUM',
    child: '123',
    className: Styles.toNumber,
  },
  // {
  //   type: 'action',
  //   value: 'CLEAR',
  //   child: 'Clear',
  //   className: Styles.actionBackground
  // },
  {
    type: 'action',
    value: 'SPACEBAR',
    child: 'space',
    className: Styles.spaceBar,
  },
  { type: 'string', value: '@', className: Styles.at },
  // { type: "string", value: ".", className: Styles.actionBackground },
  {
    type: 'string',
    value: '.',
    className: Styles.com,
  },
  // {
  //   type: "action",
  //   value: "RETURN",
  //   child: "return",
  //   className: Styles.return
  // },
  {
    type: 'action',
    value: 'ENTER',
    child: 'ENTER',
    className: Styles.enter,
  },
];

export const emailSuggestions = [
  {
    id: 1,
    type: 'string',
    value: '@GMAIL.COM',
    child: '@gmail.com',
    className: '',
  },
  {
    id: 2,
    type: 'string',
    value: '@OUTLOOK.COM',
    child: '@outlook.com',
    className: '',
  },
  {
    id: 3,
    type: 'string',
    value: '@YAHOO.COM',
    child: '@yahoo.com',
    className: '',
  },
];
