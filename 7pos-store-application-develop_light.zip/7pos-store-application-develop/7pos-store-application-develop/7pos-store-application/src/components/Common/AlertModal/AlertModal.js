import React, { forwardRef, useImperativeHandle, useRef } from 'react';
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Button,
  Heading,
  useDisclosure,
} from '@chakra-ui/react';
import Styles from './AlertModal.module.css';

export const AlertModal = forwardRef(({ header, body }, ref) => {
  const {
    isOpen: isModalOpen,
    onOpen: onModalOpen,
    onClose: onModalClose,
  } = useDisclosure();
  const cancelModalRef = useRef();

  useImperativeHandle(ref, () => ({
    onModalOpen,
  }));

  return (
    <>
      <AlertDialog
        motionPreset="slideInBottom"
        leastDestructiveRef={cancelModalRef}
        onClose={onModalClose}
        isOpen={isModalOpen}
        isCentered
      >
        <AlertDialogOverlay />

        <AlertDialogContent className={Styles.alertDialogContainer}>
          <AlertDialogHeader className={Styles.alertDialogHeader}>
            <Heading as="h4" size="md" className={Styles.alertDialogHeaderText}>
              {header?.name || ''}
            </Heading>
            {!!header?.icon && <img src={header.icon} alt="" />}
          </AlertDialogHeader>
          <AlertDialogBody className={Styles.alertDialogBody}>
            {body}
          </AlertDialogBody>
          <AlertDialogFooter>
            <Button
              className={Styles.alertDialogCloseButton}
              ref={cancelModalRef}
              onClick={onModalClose}
            >
              <Heading
                className={Styles.alertDialogCloseButtonText}
                as="h4"
                size="sm"
              >
                CLOSE
              </Heading>
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
});
