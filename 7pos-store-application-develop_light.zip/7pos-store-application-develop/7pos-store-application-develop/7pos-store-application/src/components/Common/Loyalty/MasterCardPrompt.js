import React from 'react';
import { Flex, Text, Image } from '@chakra-ui/react';
import loyaltyMaster from '@icons/speedway/loyaltyMaster.svg';
import { SideContainer } from '../Containers';
import { Button } from '../Buttons';
import MemberInfo from '../../CFD/CFDALTID/MemberInfo';

export const MasterCardPrompt = ({
  isCfd,
  onCancel = () => {},
  onConfirm = () => {},
}) => {
  console.log('isCFD', isCfd);
  return (
    <SideContainer
      containerStyles={{ ...(!isCfd ? { height: 'calc(100vh - 210px)' } : {}) }}
    >
      {isCfd && <MemberInfo />}
      <Flex
        alignItems="center"
        justifyContent="center"
        width="100%"
        flexDirection="column"
        paddingX="2rem"
        height={isCfd && '100%'}
      >
        <Image
          height="250px"
          width="253px"
          src={loyaltyMaster}
          alt="sevenElevenLogo"
        />
        <Text fontSize="1.4rem" textAlign="center" p={4} paddingTop="18px">
          {isCfd
            ? Messages.speedy_master_card_title_cfd
            : Messages.speedy_master_card_title}
        </Text>
        <Text fontSize="1.4rem" textAlign="center">
          {' '}
          {isCfd
            ? Messages.speedy_master_card_desc_cfd
            : Messages.speedy_master_card_desc}
        </Text>
        <Flex width="100%" justifyContent="center" paddingTop="50px">
          <Button
            width="43%"
            mr="25px"
            height="45px"
            bg="default.posWhite"
            borderRadius={0}
            border="1px"
            onClick={onCancel}
          >
            <Text fontWeight="normal">NO</Text>
          </Button>
          <Button
            width="43%"
            bg="primary"
            height="45px"
            borderRadius={0}
            onClick={onConfirm}
          >
            <Text color="default.posWhite">YES</Text>
          </Button>
        </Flex>
      </Flex>
    </SideContainer>
  );
};
