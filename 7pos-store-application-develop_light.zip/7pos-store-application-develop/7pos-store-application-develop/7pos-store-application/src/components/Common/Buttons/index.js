/* eslint-disable */
import { Button as POSButton, Text } from '@chakra-ui/react';
import React, { useContext } from 'react';
import { AppContext } from '../../../AppContext';

export const Button = props => {
  const { keyPressSound } = useContext(AppContext) || {};
  return (
    <POSButton
      {...props}
      onClick={event => {
        keyPressSound?.play?.().catch(e => console.log('Sound error', e));
        props?.onClick?.(event);
      }}
    />
  );
};

export const ExitButton = ({ onClick, isDisabled }) => (
  <Button
    alignSelf="flex-end"
    onClick={onClick}
    width="90px"
    className="btn secondaryButton"
    height="40px"
    mt={15}
    isDisabled={isDisabled}
  >
    <Text
      fontSize="18px"
      fontFamily="Roboto-Bold"
      color="rgb(91, 97, 107)"
      fontWeight="bold"
    >
      EXIT
    </Text>
  </Button>
);

export const ContinueButton = ({ onClick, isDisabled }) => (
  <Button
    alignSelf="flex-end"
    onClick={onClick}
    width="90px"
    className="btn primaryButton"
    height="40px"
    mt={15}
    isDisabled={isDisabled}
  >
    <Text
      fontSize="18px"
      fontFamily="Roboto-Bold"
      color="rgb(91, 97, 107)"
      fontWeight="bold"
    >
      Continue
    </Text>
  </Button>
);
