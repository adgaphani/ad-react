import { Button as POSButton } from '@chakra-ui/react';
import React, { useContext } from 'react';
import { AppContext } from '../../../AppContext';

export const Button = props => {
  const { keyPressSound } = useContext(AppContext) || global;
  const { fontWeight, fontweight } = props;
  return (
    <POSButton
      {...props}
      fontWeight={fontWeight ?? fontweight}
      onClick={event => {
        keyPressSound?.play?.().catch(e => console.log('Sound error', e));
        // eslint-disable-next-line react/destructuring-assignment
        props?.onClick?.(event);
      }}
    />
  );
};
