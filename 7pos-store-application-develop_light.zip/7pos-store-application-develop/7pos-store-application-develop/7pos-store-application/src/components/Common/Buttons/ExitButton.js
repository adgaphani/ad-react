import { Text } from '@chakra-ui/react';
import React from 'react';
import { Button } from './Button';
import Styles from './ExitButton.module.css';

export const ExitButton = ({ onExit }) => (
  <Button onClick={onExit} className={Styles.exitButton}>
    <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
      EXIT
    </Text>
  </Button>
);
