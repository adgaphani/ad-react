import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import PropTypes from 'prop-types';
import Styles from './GridItem.module.css';
import { getItemIcon } from '../../../Utils/itemCardLogoUtils';

const GridItem = ({
  functionItem,
  selectedItem,
  onItemClick,
  isExit = false,
}) => {
  const onItemPress = () => {
    onItemClick(functionItem);
  };
  const { isActive = false, label, name } = functionItem || {};
  const { name: selectedName } = selectedItem || {};
  const isSelected = name && selectedName === name;

  const borderStyle = isSelected ? Styles.selected : '';
  const bottomBorderStyle = isExit || !name ? '' : Styles.bottomBorder;
  const inactiveSlot = isActive ? '' : Styles.inactive;
  const slotActiveStyle = !label ? Styles.emptySlot : inactiveSlot;

  return (
    <Flex
      className={`${Styles.container} ${borderStyle} ${bottomBorderStyle} ${slotActiveStyle}`}
      onClick={onItemPress}
    >
      {name && <img className={Styles.icon} src={getItemIcon(name)} alt="" />}
      <Text className={Styles.title}>{label || ''}</Text>
    </Flex>
  );
};

GridItem.defaultProps = {
  functionItem: {},
  selectedItem: {},
  onItemClick: () => {},
};

GridItem.propTypes = {
  functionItem: PropTypes.object,
  selectedItem: PropTypes.object,
  onItemClick: PropTypes.func,
};

export default GridItem;
