import React from 'react';
import CartHeader from '../../../screens/POS/Cart/cartHeader';

export const CHeader = ({ content, transactionId }) => (
  <>
    <CartHeader transactionId={transactionId} />
    {content || null}
  </>
);
