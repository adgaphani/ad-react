import React, { useEffect, useState } from 'react';
import { Flex, Box } from '@chakra-ui/react';
import { useSelector } from 'react-redux';

import Styles from './POSCart.module.css';
import { CHeader } from './CHeader';
import { CFooter } from './CFooter';
import { CBody } from './CBody';
import { CART_HEIGHTS, safeDrop } from '../../../constants';

export const POSCart = ({ body, footer, header, isFuelScreen }) => {
  const [cartHeight, setCartHeight] = useState(CART_HEIGHTS.BASE_CART);
  const {
    transactionId,
    isTransactionVoid,
    isTransactionRefund,
    isSafeDrop,
    safeDropResponse,
    safeDropType,
    isSafeOflineAbort,
    showSafeTransId,
    vaultUserEntries,
    isSafeAbortInProgress,
    isSafeCompleted,
    storeDetails,
  } = useSelector(state => ({
    transactionId: state.cart.transactionId,
    isTransactionRefund: state.cart.isTransactionRefund,
    isTransactionVoid: state.cart.isTransactionVoid,
    safeDropResponse: state.cart.safeDropResponse,
    isSafeDrop: state.cart.isSafeDrop,
    safeDropType: state.cart.safeDropType,
    isSafeOflineAbort: state.cart.isSafeOflineAbort,
    showSafeTransId: state.cart.showSafeTransId,
    vaultUserEntries: state.cart.vaultUserEntries,
    isSafeAbortInProgress: state.cart.isSafeAbortInProgress,
    isSafeCompleted: state.cart.isSafeCompleted,
    storeDetails: state.main.storeDetails,
  }));
  useEffect(() => {
    let h = cartHeight;
    if (isTransactionRefund || isTransactionVoid) {
      h = CART_HEIGHTS.VOID_CART;
      setCartHeight(CART_HEIGHTS.VOID_CART);
    } else if (isFuelScreen) {
      h = CART_HEIGHTS.FUEL_CART;
    }
    setCartHeight(h);
  }, [isTransactionVoid, isTransactionRefund]);
  const updatedElm = footer
    ? React.cloneElement(footer, {
        text: `SAFE TRANSACTION ${safeDrop?.[safeDropType]?.label}`,
      })
    : null;
  return (
    <>
      <Flex
        direction="column"
        justifyContent="space-between"
        className={Styles.cartContainer}
      >
        <Box pos="relative" h="100%">
          {showSafeTransId && (
            <CHeader transactionId={transactionId} content={header} />
          )}
          <CBody content={body} />
          <CFooter
            content={updatedElm}
            isSafeDrop={isSafeDrop}
            isVault={safeDropType === 'vaultDrop'}
            vaultUserEntries={vaultUserEntries}
            response={safeDropResponse}
            safeDropType={safeDropType}
            isSafeOflineAbort={isSafeOflineAbort}
            isSafeAbortInProgress={isSafeAbortInProgress}
            isSafeCompleted={isSafeCompleted}
            storeDetails={storeDetails}
          />
        </Box>
      </Flex>
    </>
  );
};
