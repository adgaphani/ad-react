// import React from 'react';
/* eslint-disable*/
export const CBody = ({}) => null;
