import React from 'react';
import { Text, Flex } from '@chakra-ui/react';
import { TextBorder } from '../Borders';

// eslint-disable-next-line arrow-body-style
export const TransactionTypeText = ({ msg }) => {
  return (
    <Flex
      flexDirection="row"
      justifyContent="center"
      alignItems="center"
      my={2}
    >
      <TextBorder />
      <Text
        color="rgb(224, 32, 32)"
        fontWeight="500"
        fontFamily="Roboto-Medium"
        fontSize="14px"
      >
        {msg}
      </Text>
      <TextBorder ml={2} />
    </Flex>
  );
};
