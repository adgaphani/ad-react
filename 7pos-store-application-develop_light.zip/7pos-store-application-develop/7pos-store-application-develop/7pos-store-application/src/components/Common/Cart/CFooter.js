import React from 'react';
import { Text, Flex, Box } from '@chakra-ui/react';
import { safeDrop } from '../../../constants';
import { Complete } from '../Transaction';
import { currencyFixed } from '../../../Utils/appUtils';
import { TransactionTypeText } from './TransactionTypeText';

export const CFooter = ({
  isSafeDrop,
  response,
  safeDropType,
  // content = null, TODO: need to remove not using anywhere
  isSafeOflineAbort,
  vaultUserEntries = {},
  isVault,
  isSafeAbortInProgress,
  isSafeCompleted,
  storeDetails,
}) => {
  const currencyCode =
    storeDetails.currencyCode === 'CAD' ? storeDetails.currencyCode : '';
  return (
    <>
      {isSafeDrop ? (
        <Box w="100%" top="auto" bottom={0} height={155} p={2} pos="absolute">
          <Flex justifyContent="center">
            <TransactionTypeText
              msg={`SAFE TRANSACTION ${safeDrop?.[
                safeDropType
              ]?.label?.toUpperCase()}`}
            />
          </Flex>
          <Flex justifyContent="center">
            {isSafeOflineAbort ||
              (isSafeAbortInProgress && isSafeCompleted && (
                <TransactionTypeText
                  msg={`${safeDrop?.[
                    safeDropType
                  ]?.label.toUpperCase()} CANCELLED`}
                />
              ))}
          </Flex>
          {isVault && vaultUserEntries?.amount && (
            <>
              <Flex justifyContent="space-between" my={2} color="#5B616B">
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  Cash
                </Text>
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  {`$${currencyFixed(vaultUserEntries?.amount / 100)}`}
                </Text>
              </Flex>
              <Flex justifyContent="space-between" my={2} color="#5B616B">
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  Total
                </Text>
                <Text
                  fontSize="15px"
                  fontWeight="normal"
                  fontFamily="Roboto-Regular"
                >
                  {`$${currencyFixed(vaultUserEntries?.amount / 100)}`}
                </Text>
              </Flex>
              {vaultUserEntries?.envelop && (
                <Flex justifyContent="space-between" my={2} color="#5B616B">
                  <Text
                    fontSize="15px"
                    fontWeight="bold"
                    fontFamily="Roboto-Regular"
                  >
                    {`Envelope Id ${vaultUserEntries.envelop}`}
                  </Text>
                </Flex>
              )}
            </>
          )}
          {response?.length ? (
            response?.map(res => (
              <>
                {!isVault && Number(res?.amount) > 0 && (
                  <>
                    <Flex justifyContent="space-between" my={2} color="#5B616B">
                      <Text
                        fontSize="15px"
                        fontWeight="normal"
                        fontFamily="Roboto-Regular"
                      >
                        Cash
                      </Text>
                      <Text
                        fontSize="15px"
                        fontWeight="normal"
                        fontFamily="Roboto-Regular"
                      >
                        {`${res.currencyCode ?? currencyCode}$${currencyFixed(
                          res?.amount / 100
                        )}`}
                      </Text>
                    </Flex>
                    <Flex justifyContent="space-between" my={2} color="#5B616B">
                      <Text
                        fontSize="15px"
                        fontWeight="bold"
                        fontFamily="Roboto-Regular"
                      >
                        Total
                      </Text>
                      <Text
                        fontSize="15px"
                        fontWeight="bold"
                        fontFamily="Roboto-Regular"
                      >
                        {`$${currencyFixed(res?.amount / 100)}`}
                      </Text>
                    </Flex>
                  </>
                )}
                <Complete />
              </>
            ))
          ) : isSafeOflineAbort || isSafeCompleted ? (
            <Complete />
          ) : null}
        </Box>
      ) : null}
    </>
  );
};
