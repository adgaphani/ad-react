import React, { forwardRef, useImperativeHandle } from 'react';
import { Stack, Alert, Box, Text, useToast } from '@chakra-ui/react';
import {
  InfoIcon,
  SuccessIcon,
  WarningIcon,
} from '../../../Icons/operatorMenu';
import Styles from './Toast.module.css';

export const Toast = forwardRef((props, ref) => {
  const toast = useToast();
  const getIcon = status => {
    switch (status) {
      case 'info':
        return InfoIcon;
      case 'warning':
        return WarningIcon;
      default:
        return SuccessIcon;
    }
  };
  const getColor = status => {
    switch (status) {
      case 'info':
        return '#367BB5';
      case 'warning':
        return '#F58220';
      default:
        return '#41A44B';
    }
  };

  const render = ({ status, messages }) => (
    <Stack spacing={3}>
      <Alert
        status={status}
        className={Styles.toastContainer}
        backgroundColor={getColor(status)}
      >
        <img src={getIcon(status)} alt="" className={Styles.toastIcon} />
        <Box>
          {messages.map(message => (
            <Text className={Styles.toastText}>{message}</Text>
          ))}
        </Box>
      </Alert>
    </Stack>
  );

  useImperativeHandle(ref, () => ({
    showToast: ({ status = '', messages = [] }) => {
      toast({
        status,
        duration: 2000,
        position: 'top-left',
        render: () => render({ status, messages }),
      });
    },
  }));

  return <></>;
});
