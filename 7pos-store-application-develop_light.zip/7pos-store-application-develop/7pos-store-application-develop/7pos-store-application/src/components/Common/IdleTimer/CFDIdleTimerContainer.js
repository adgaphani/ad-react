/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/prop-types */

import React, { useEffect, useState } from 'react';

import IdleTimer from 'react-idle-timer';
import { SendMessageToPOS } from '../../../Communication';

const CFDIdleTimerContainer = props => {
  const [CFDActivityStatus, setCFDActivityStatus] = useState(false);
  let logoutTime = Number(props.config?.storeConfig?.idleTimeout) || 3;
  logoutTime = Number(logoutTime);

  const onIdelHandler = () => {
    setCFDActivityStatus(false);
  };
  const onActiveHandler = () => {
    setCFDActivityStatus(true);
  };

  useEffect(() => {
    if (!CFDActivityStatus) {
      const iTransactionMessage = {
        CMD: 'CFDActivityStatus',
        Status: 'Idle',
      };
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - Idle timeout set @CFD:${logoutTime} and CFD is Idle`
      );
    } else {
      const iTransactionMessage = {
        CMD: 'CFDActivityStatus',
        Status: 'Active',
      };
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - Idle timeout set @CFD:${logoutTime} and CFD is Active`
      );
    }
    return () => {};
  }, [CFDActivityStatus]);

  return (
    <IdleTimer
      timeout={1000 * logoutTime * 60}
      onIdle={onIdelHandler}
      onAction={onActiveHandler}
    >
      {props.children}
    </IdleTimer>
  );
};

export default CFDIdleTimerContainer;
