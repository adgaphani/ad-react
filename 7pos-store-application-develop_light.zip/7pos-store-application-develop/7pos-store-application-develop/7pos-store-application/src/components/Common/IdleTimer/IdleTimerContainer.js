/* eslint-disable react/destructuring-assignment */
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import IdleTimer from 'react-idle-timer';
import { cartActions } from '../../../slices/cart.slice';
import { MO_FLG_INSALE } from '../../../constants';
import { useCartCleanup } from '../../../hooks';

const IdleTimerContainer = props => {
  const {
    items,
    taxInfo,
    member,
    UserActivityOnCFD,
    fuel,
    isTransactionVoid,
    isTransactionRefund,
    cartChangeTrial,
    runningTotal,
    balanceInquiryIsActive,
    preCartItems,
    loadCardMediaList,
    allPayments,
    EODEOSDetails,
    safeDropType,
    isSafeActionInProgress,
    isTransHold,
    transactionMemory,
    showTransHoldText,
    isPaymentTriggered,
    tenderSequenceNumber,
    transactionStartTime,
    tranAgeVerifyInfo,
    MemberBarcodeInfo,
    isPromoInProgress,
    disableFinalizePay,
    tranItemSeqNumber,
    isEndofDayorShift,
    isMoMAllowed,
    iscannedBarcode,
  } = useSelector(state => ({
    items: state.cart.items,
    taxInfo: state.cart.taxInfo,
    member: state.cart.member,
    UserActivityOnCFD: state.cfd.UserActivityOnCFD,
    fuel: state.cart.fuel,
    isTransactionVoid: state.cart.isTransactionVoid,
    isTransactionRefund: state.cart.isTransactionRefund,
    cartChangeTrial: state.cart.cartChangeTrial,
    runningTotal: state.cart.runningTotal,
    balanceInquiryIsActive: state.balance.isActive,
    preCartItems: state.cart.preCartItems,
    loadCardMediaList: state.cart.loadCardMediaList,
    allPayments: state.cart.allPayments,
    EODEOSDetails: state.cart.EODEOSDetails,
    safeDropType: state.cart.safeDropType,
    isSafeActionInProgress: state.cart.isSafeActionInProgress,
    isTransHold: state.cart.isTransHold,
    transactionMemory: state.cart.transactionMemory,
    showTransHoldText: state.cart.showTransHoldText,
    isPaymentTriggered: state.cart.isPaymentTriggered,
    tenderSequenceNumber: state.cart.tenderSequenceNumber,
    transactionStartTime: state.cart.transactionStartTime,
    tranAgeVerifyInfo: state.cart.tranAgeVerifyInfo,
    MemberBarcodeInfo: state.cart.MemberBarcodeInfo,
    isPromoInProgress: state.cart.isPromoInProgress,
    disableFinalizePay: state.cart.disableFinalizePay,
    tranItemSeqNumber: state.cart.tranItemSeqNumber,
    isEndofDayorShift: state.cart.isEndofDayorShift,
    isMoMAllowed: state.cart.isMoMAllowed,
    iscannedBarcode: state.main.iscannedBarcode,
  }));
  const dispatch = useDispatch();
  let refidleTimer = null;
  let logoutTime = Number(props.config?.storeConfig?.idleTimeout) || 3;
  logoutTime = Number(logoutTime);
  const location = useLocation();
  const {
    creditTaxOverrideCleanup,
    cleanUpTransactionItems,
  } = useCartCleanup();

  const [POSActivityStatus, setPOSActivityStatus] = useState(true);
  const [isLogoutTriggerEvent, setLogoutEvent] = useState(false);

  useEffect(() => {
    if (isLogoutTriggerEvent) {
      localStorage.setItem(
        'cartInfo',
        JSON.stringify({
          cartItems: items,
          preCartItems,
          taxInfo,
          member,
          fuel,
          isTransactionVoid,
          isTransactionRefund,
          cartChangeTrial,
          runningTotal,
          loadCardMediaList,
          EODEOSDetails,
          isTransHold,
          transactionMemory,
          showTransHoldText,
          tenderSequenceNumber,
          transactionStartTime,
          tranAgeVerifyInfo,
          MemberBarcodeInfo,
          tranItemSeqNumber,
          isMoMAllowed,
        })
      );
      global?.logger?.info(`[7POS UI] - Store cartInfo to local store `);
      setLogoutEvent(false);
      props.logout();
    }
  }, [isLogoutTriggerEvent]);

  const onIdelHandler = () => {
    setPOSActivityStatus(false);
  };

  const onActiveHandler = () => {
    setPOSActivityStatus(true);
  };

  const cleanUpTransaction = async () => {
    await cleanUpTransactionItems();
    setLogoutEvent(true);
  };

  useEffect(() => {
    if (POSActivityStatus || UserActivityOnCFD) return;
    if (
      isPaymentTriggered ||
      (!location.pathname.includes('/payment/success') &&
        !location.pathname.includes('/payment/emailReceipt') &&
        (allPayments?.length > 0 ||
          items?.some(
            item => item.isMoneyOrder && item.MoneyOrderFlag !== MO_FLG_INSALE
          ))) || // allow only all MO are in sale
      balanceInquiryIsActive || // if your in mid of balance inquiry should not logout
      safeDropType ||
      isSafeActionInProgress ||
      location.pathname === '/home/safeDrop/processing' ||
      location.pathname === '/home/balance_success' ||
      location.pathname === '/home/functionSecurity' || // #5627 defect fix
      items?.some(item => item.isRoundUpCharityItem) || // check round up charity item present
      disableFinalizePay || // #3490 added item promo/tax API inprogress check before logoff
      isPromoInProgress ||
      location.pathname.includes('manualEntry') ||
      location.pathname.includes('verification') ||
      location.pathname.includes('loadnotification') ||
      location.pathname.includes('cardProcess') || // #7998 added card look up process
      isEndofDayorShift
    ) {
      setPOSActivityStatus(true);
      refidleTimer?.reset();
      global?.logger?.info(
        `[7POS UI] - Mid of payment/Balance inquiry/Safe/DLSwipeEnabled actions POS couldnt logout durinng Idle`
      );
      return;
    }
    if (!UserActivityOnCFD && !POSActivityStatus) {
      global?.logger?.info(`[7POS UI] -  POS idle and logout ${logoutTime}`);
      if (
        location.pathname.includes('/payment/success') ||
        location.pathname.includes('/payment/emailReceipt')
      ) {
        dispatch(cartActions.emptyCart());
        props.logout();
      } else if (items.length) {
        creditTaxOverrideCleanup();
        cleanUpTransaction();
      } else {
        global?.logger?.info(`[7POS UI] - Logout Intiated. `);
        props.logout();
      }
    }
    return () => {};
  }, [POSActivityStatus, UserActivityOnCFD]);

  useEffect(() => {
    // #8038 reset idle timer each scan
    if (iscannedBarcode) {
      // console.log(refidleTimer?.getRemainingTime());
      refidleTimer?.reset();
      // console.log(refidleTimer?.getRemainingTime());
    }
    return () => {};
  }, [iscannedBarcode]);

  return (
    <IdleTimer
      ref={ref => {
        refidleTimer = ref;
      }}
      timeout={1000 * logoutTime * 60}
      onIdle={onIdelHandler}
      onAction={onActiveHandler}
    >
      {props.children}
    </IdleTimer>
  );
};

export default IdleTimerContainer;
