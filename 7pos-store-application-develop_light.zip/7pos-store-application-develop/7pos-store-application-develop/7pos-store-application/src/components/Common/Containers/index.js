import React from 'react';

import { Box, Flex, Text } from '@chakra-ui/react';
import { Button } from '../Buttons';

export const SideContainer = ({ children, onExit, containerStyles = {} }) => (
  <Box
    background="rgb(255, 255, 255)"
    h="calc(100vh - 135px)"
    {...containerStyles}
  >
    <Flex flexDirection="column" justifyContent="space-between" height="100%">
      {children}

      {onExit && (
        <Button
          alignSelf="flex-end"
          onClick={onExit}
          borderRadius="3px !important"
          width="90px"
          height="40px"
          background="rgb(255, 255, 255)"
          border="1px solid rgb(91, 97, 107)"
          mr="5px"
        >
          <Text fontFamily="Roboto-Bold" color="rgb(91, 97, 107, 0.9)">
            EXIT
          </Text>
        </Button>
      )}
    </Flex>
  </Box>
);
