import React from 'react';
import { Grid, Box, Text, Flex } from '@chakra-ui/react';

import Keypad from '../DailPad/Keypad/Keypad';
import { SPayment } from '../../POS/Safe/ofline';

export const EnterAmount = ({ onEnterValue, amount = false, content }) => (
  <Grid templateColumns="50% 50%" width="100%">
    <Box marginLeft="7px" pr="0.5rem">
      <Keypad onEnter={onEnterValue} {...(amount ? { max: 4 } : {})} />
    </Box>
    <Flex
      h="100%"
      flexDirection="column"
      justifyContent="space-between"
      bg="rgb(255, 255, 255)"
      mr="0.5rem"
    >
      {amount && (
        <>
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Bold"
            fontSize="24px"
            fontWeight="bold"
            my="1.75rem"
            ml="2.5rem"
            dangerouslySetInnerHTML={{ __html: content?.header }}
          />
          <Text
            color="rgb(44, 47, 53)"
            fontFamily="Roboto-Regular"
            fontSize="16px"
            fontWeight="normal"
            mx="2.5rem"
          >
            {content?.text}
          </Text>
        </>
      )}
      {!amount && (
        <SPayment isCashOnly onSafePaymentSelect={() => onEnterValue()} />
      )}
    </Flex>
  </Grid>
);
