import React from 'react';
import { Text, Box } from '@chakra-ui/react';

export const Complete = () => (
  <Box
    position="absolute"
    bottom="4px"
    top="auto"
    display="flex"
    justifyContent="center"
    width="100%"
  >
    <Text textAlign="center">---- TRANSACTION COMPLETE ----</Text>
  </Box>
);
