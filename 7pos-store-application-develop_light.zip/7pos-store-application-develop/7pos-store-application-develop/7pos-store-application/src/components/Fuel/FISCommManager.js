import moment from 'moment';
import store from '../../store';

export class FISCommManager {
  static getPayloadForPump = (pumpNumber, messageConfig) => {
    const deviceId = store.getState().main?.deviceInfo?.id || '1';
    return JSON.stringify({
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DD'),
        messageType: 'transaction',
        source: {
          sourceType: 'POS',
          sourceIdentifier: deviceId,
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'pump',
          destinationIdentifier: pumpNumber,
          version: '01.01',
        },
      },
      messageDetails: { ...messageConfig },
    });
  };

  static getpayloadForCarwash = (config = {}) => {
    const deviceId = store.getState().main?.deviceInfo?.id || '1';
    return JSON.stringify({
      messageHeader: {
        timeStamp: moment.utc().format('YYYY-MM-DD'),
        messageType: 'transaction',
        source: {
          sourceType: 'POS',
          sourceIdentifier: deviceId,
          version: process.env.REACT_APP_VERSION,
        },
        destination: {
          destinationType: 'pump',
          destinationIdentifier: '1',
          version: '01.01',
        },
      },
      messageDetails: { ...config.body },
    });
  };

  static getMessageDetails = payload => payload?.messageDetails || {};

  static getErrorCode = payload => payload.messageDetails.errorCode;

  static getRedbarMessage = payload => payload.messageDetails.message;

  static processFuelPumpState = payload => {
    if (!payload?.messageHeader) {
      console.log(typeof payload, payload.source);
      console.log('Invalid FIS payload', payload);
      return {};
    }
    const {
      messageHeader: { source },
      messageDetails,
    } = payload;
    return {
      ...messageDetails,
      pumpNumber: source?.sourceIdentifier,
    };
  };

  static processMultiPumpState = pumpConfigs =>
    pumpConfigs.map(FISCommManager.processFuelPumpState);

  /*
  If we need any further transformation, we can add the logic here.
   */
  static processFISResponse = payload => {
    const {
      messageHeader: { source },
      messageDetails = {},
    } = payload;
    return {
      ...messageDetails,
      pumpNumber: source?.sourceIdentifier,
    };
  };
}
