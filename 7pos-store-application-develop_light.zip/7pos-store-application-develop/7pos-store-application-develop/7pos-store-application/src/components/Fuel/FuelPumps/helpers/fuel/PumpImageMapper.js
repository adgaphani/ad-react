import OutOfCommitionIcon from '@fuelIcons/out-of-commission.svg';
import PumpAvailableIcon from '@fuelIcons/pump-available.svg';
import PumpErrorIcon from '@fuelIcons/pump-error.svg';
import PumpFuelingIcon from '@fuelIcons/pump-fueling.svg';
import PumpNotWorkingIcon from '@fuelIcons/pump-not-working.svg';
import PumpPrepayIcon from '@fuelIcons/pump-prepay.svg';
import ReplaceNozzleIcon from '@fuelIcons/replace-nozzle.svg';
import { FuelPumpStatus as PumpStates } from '../FuelPumpStatus';

export const PumpImageMapper = {
  [PumpStates.outOfCommission]: OutOfCommitionIcon,
  [PumpStates.closed]: PumpNotWorkingIcon,
  [PumpStates.deAuth]: PumpNotWorkingIcon,
  [PumpStates.error]: PumpErrorIcon,
  [PumpStates.idle]: PumpAvailableIcon,
  [PumpStates.locked]: PumpPrepayIcon,
  [PumpStates.preAuth]: PumpPrepayIcon,
  [PumpStates.approved]: PumpPrepayIcon,
  [PumpStates.pumping]: PumpFuelingIcon,
  [PumpStates.replaceNozzle]: ReplaceNozzleIcon,
  [PumpStates.refund]: PumpAvailableIcon,
  [PumpStates.authConfirm]: PumpPrepayIcon,
};
