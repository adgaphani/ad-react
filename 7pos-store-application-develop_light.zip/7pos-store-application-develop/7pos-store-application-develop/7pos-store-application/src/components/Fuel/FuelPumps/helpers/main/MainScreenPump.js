import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import Styles from './MainScreenPump.module.css';

export const MainScreenPump = ({ pump = {} }) => {
  const { pumpNumber, currentState = {} } = pump;
  const { fuelState } = currentState;
  const error = fuelState === PumpStates.error;
  return (
    <Flex className={`${Styles.wrapper} ${Styles[fuelState]}`}>
      <Text className={`${Styles.text} ${Styles[fuelState]}`}>
        {error ? 'E' : pumpNumber}
      </Text>
    </Flex>
  );
};
