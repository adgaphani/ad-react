import { Flex, Text } from '@chakra-ui/react';
import React from 'react';
import Styles from './PumpAmount.module.css';

const getDisplayLabel = ({
  fuelInfo: { displayIcon: label, amount, fuelState },
  refundOnly,
}) => {
  // If not refund label, handle all the states.
  // if (!isRefundLabel && fuelState === PumpStates.refund) {
  //   return '';
  // }

  // If explicit refund label, do not handle other states.
  if (refundOnly && fuelState !== PumpStates.refund) {
    return '';
  }

  if (fuelState === PumpStates.error) {
    return 'ERROR';
  }
  if (amount) {
    return `${label} $${(amount / 100).toFixed(2)}`;
  }
  return label;
};

export const PumpAmount = props => {
  const {
    fuelInfo: { fuelState },
    refundOnly,
  } = props;
  const wrapperClass = `${Styles.wrapper} ${refundOnly ? Styles.refund : ''} ${
    fuelState ? Styles[fuelState] : ''
  }`;
  return (
    <Flex className={wrapperClass}>
      <Text className={`${Styles.text} ${Styles[fuelState]}`}>
        {getDisplayLabel(props)}
      </Text>
    </Flex>
  );
};
