import { useSelector } from 'react-redux';
import React, { useContext } from 'react';
import { Flex } from '@chakra-ui/react';
import { AppContext } from '../../../../../AppContext';
import { PumpAmount } from './PumpAmount';
import Styles from './FuelScreenPump.module.css';
import { useFuel } from '../../../../../hooks';
import { PumpNumberDisplay } from './PumpNumberDisplay';

export const FuelScreenPump = ({ pump = {}, onSelectPump, gridSize = '' }) => {
  const { pumpNumber, currentState = {}, previousState = {} } = pump;
  // Returning empty UI and not processing any imports.
  if (!pumpNumber) {
    return <Flex className={`${Styles.wrapper}`} />;
  }

  const { deselectPump } = useFuel();
  const { fuelState: pumpState } = currentState;
  const { selectedPump } = useSelector(state => ({
    selectedPump: state.fuel.selectedPump,
  }));
  const { keyPressSound } = useContext(AppContext);
  const isPumpSelected = pumpNumber === selectedPump;
  const { showToast } = useContext(AppContext);

  const onClickPump = () => {
    keyPressSound?.play().catch(e => console.log('Sound error', e));
    const { fuelState } = currentState;
    if (!fuelState || fuelState === PumpStates.outOfCommission) {
      console.log('No selectable as the current state of the pump is unknown');
      showToast({ description: Messages.unknown_pump_state });
      deselectPump();
      return;
    }
    onSelectPump(pump);
  };

  /*
  1. C: I, P: R
  2. C: I, P: I
  3. C: P, P: I
  4: C: L, P: I
  5: C: L, P: R
  6. C: R, P: R
  7. C: A, P: R
  8: C: ~, P: R
  9: C: P, P: R
  10: C: A, P: R
  // Need to work on replace nozzle.
   */

  return (
    <Flex
      className={`${Styles.wrapper} ${Styles[pumpState] ?? ''} ${
        isPumpSelected ? Styles.selected : ''
      }`}
      selected={isPumpSelected}
      onClick={onClickPump}
    >
      <PumpAmount fuelInfo={currentState} />
      <PumpNumberDisplay
        pumpNumber={pumpNumber}
        gridSize={gridSize}
        pumpState={pumpState}
      />
      <PumpAmount refundOnly fuelInfo={previousState} />
    </Flex>
  );
};
