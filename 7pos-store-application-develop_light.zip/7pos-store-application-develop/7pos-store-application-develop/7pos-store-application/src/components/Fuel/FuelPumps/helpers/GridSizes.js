const Sizes = {
  small: 'small',
  medium: 'medium',
  large: 'large',
};
Object.freeze(Sizes);
export const GridSizes = Sizes;
