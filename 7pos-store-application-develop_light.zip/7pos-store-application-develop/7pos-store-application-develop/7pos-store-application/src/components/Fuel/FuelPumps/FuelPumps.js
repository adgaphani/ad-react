/* eslint-disable no-unused-vars */
import { Grid } from '@chakra-ui/react';
import React from 'react';
import { useSelector } from 'react-redux';
import { MainScreenPump, FuelScreenPump, GridSizes } from './helpers';
import Styles from './FuelPumps.module.css';
import { FuelUtils } from '../../../Utils';

export const FuelPumps = ({ isFuelScreen = false, onPumpSelected }) => {
  const { fuelPumps, config } = useSelector(state => ({
    fuelPumps: state.fuel.fuelPumps,
    config: state.main.configuration,
  }));

  const isFuelEnabled = FuelUtils.isIntegratedFuelStore(config);
  if (!isFuelEnabled || !fuelPumps.length) {
    return null;
  }

  const onSelectPump = pump => {
    onPumpSelected({ ...pump });
  };

  const getGridSize = () => {
    if (fuelPumps.length <= 8) {
      return GridSizes.small;
    }
    return fuelPumps.length > 16 ? GridSizes.large : GridSizes.medium;
  };

  const pumpGridStyle = () => {
    const gridStyle = `${Styles.pumpsGrid} ${
      isFuelScreen ? Styles.fuel : Styles.main
    }`;
    return `${gridStyle} ${Styles[getGridSize()]}`;
  };

  return (
    <Grid className={pumpGridStyle()}>
      {fuelPumps.map((pump, index) =>
        isFuelScreen ? (
          <FuelScreenPump
            pump={pump}
            gridSize={getGridSize()}
            key={index.toString()}
            onSelectPump={onSelectPump}
          />
        ) : (
          <MainScreenPump pump={pump} key={index.toString()} />
        )
      )}
    </Grid>
  );
};
