const FuelPumpStatus = {
  outOfCommission: 'O',
  closed: 'N', // ~
  preAuth: 'P',
  deAuth: 'D',
  pumping: 'U',
  approved: 'A',
  idle: 'I',
  error: 'E',
  replaceNozzle: 'H',
  refund: 'R',
  locked: 'L',
  authConfirm: 'C', // ?
};

const FuelPumpDescription = {
  [FuelPumpStatus.outOfCommission]: 'Pump Out of Commission',
  [FuelPumpStatus.closed]: 'Pump Closed',
  [FuelPumpStatus.preAuth]: 'Pre Auth',
  [FuelPumpStatus.deAuth]: 'De Auth',
  [FuelPumpStatus.pumping]: 'Pumping',
  [FuelPumpStatus.approved]: 'Approved',
  [FuelPumpStatus.idle]: 'Ready for use',
  [FuelPumpStatus.replaceNozzle]: 'Replace Nozzle',
  [FuelPumpStatus.error]: 'Pump Not Working',
  [FuelPumpStatus.refund]: 'Refund',
  [FuelPumpStatus.locked]: 'Pump Locked',
  [FuelPumpStatus.authConfirm]: 'Need Confirmation',
};

const FuelRedBarMsgs = {
  stacked_pay: 'Rejected: Stacked Prepay Not Allowed',
  updating_car_wash: 'Updating Carwash Prices',
  price_change_completed: 'Fuel price update completed.',
  dex_printer_issue: 'PRINTER-MISC-ERROR',
  printer_not_working: `PRINTER AT PUMP #$ IS MALFUNCTIONING`,
  new_fuel_prices: `New Fuel Prices`,
  carwash_price_update: 'Updating Car wash prices',
};

const FuelPumpMsgTypes = {
  [FuelPumpStatus.outOfCommission]: 'error',
  [FuelPumpStatus.closed]: 'error',
  [FuelPumpStatus.preAuth]: 'success',
  [FuelPumpStatus.deAuth]: 'success',
  [FuelPumpStatus.pumping]: 'success',
  [FuelPumpStatus.approved]: 'success',
  [FuelPumpStatus.idle]: 'success',
  [FuelPumpStatus.replaceNozzle]: 'warning',
  [FuelPumpStatus.error]: 'error',
  [FuelPumpStatus.refund]: 'success',
  [FuelPumpStatus.locked]: 'warning',
  [FuelRedBarMsgs.stacked_pay]: 'error',
  [FuelRedBarMsgs.updating_car_wash]: 'warning',
  [FuelRedBarMsgs.price_change_completed]: 'success',
  [FuelRedBarMsgs.dex_printer_issue]: 'error',
  [FuelRedBarMsgs.new_fuel_prices]: 'warning',
  [FuelRedBarMsgs.carwash_price_update]: 'success',
};

export {
  FuelPumpStatus,
  FuelPumpDescription,
  FuelPumpMsgTypes,
  FuelRedBarMsgs,
};

/*
A-Approved
P-Prepay
I-Idle
L-Lock
U-Handle Up
 */
