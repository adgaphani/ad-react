import { Flex, Image, Text } from '@chakra-ui/react';
import React from 'react';
import Styles from './PumpNumberDisplay.module.css';
import { PumpImageMapper } from './PumpImageMapper';

export const PumpNumberDisplay = ({ pumpNumber, gridSize = '', pumpState }) => {
  const getStyle = componentStyle => `${componentStyle} ${Styles[gridSize]}`;
  return (
    <Flex className={getStyle(Styles.pumpStateWrapper)}>
      <Flex className={getStyle(Styles.textWrapper)}>
        <Text className={getStyle(Styles.text)}>{pumpNumber}</Text>
      </Flex>
      <Flex className={getStyle(Styles.imageWrapper)}>
        <Image
          className={getStyle(Styles.image)}
          src={PumpImageMapper[pumpState]}
        />
      </Flex>
    </Flex>
  );
};
