import RestartPump from '@fuelIcons/RestartPump.svg';

export const maintenanceIcons = {
  fuelPrices: RestartPump,
  pumpIcon: RestartPump,
  beepSetting: RestartPump,
};

const staticActions = [
  {
    label: 'Set Pump Prices',
    name: 'SetPumpPrices',
    sequenceNumber: 1,
  },
  {
    label: 'Beep On/Off',
    name: 'BeepSetting',
    sequenceNumber: 2,
  },
  {
    label: 'EXIT',
    name: 'exit',
    sequenceNumber: 24,
  },
];

export const getMaintenanceActions = () =>
  new Array(24).fill(0).map(
    (_, i) =>
      staticActions.find(({ sequenceNumber }) => sequenceNumber === i + 1) || {
        sequenceNumber: i + 1,
      }
  );
