import React, { useContext } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import { Button } from '../../../Common';
import Styles from './MPSPriceApproval.module.css';
import MPS_WarningIcon from '../../../../Icons/fuelIcons/mps_title.svg';
import Icon_confirm from '../../../../Icons/Icon_confirm.svg';
import MPS_Reject_Icon from '../../../../Icons/mps_price_reject.svg';
import {
  useFuel,
  useFuelPrices,
  useFuelRequest,
  useNotifications,
} from '../../../../hooks';
import { FISActions } from '../../FuelActions';
import { AppContext } from '../../../../AppContext';
import { Messages } from '../../../../Messages';
import { FuelConstants } from '../../../../screens/Fuel/FuelConstants';

const Title = ({ isPendingMPSApproval }) => (
  <Flex className={Styles.titleContainer}>
    <img
      alt="warning-icon"
      src={isPendingMPSApproval ? MPS_WarningIcon : Icon_confirm}
    />
    <Text className={Styles.titleText}>
      {isPendingMPSApproval
        ? Messages.new_prices_title
        : Messages.current_prices_title}
    </Text>
  </Flex>
);

const PriceElement = ({ text = '', position = 0, newPricesRow }) => {
  const baseStyle = position ? Styles.grade : Styles.hspace;
  const fontStyle = newPricesRow || !position ? Styles.boldFont : '';
  return (
    <Flex className={`${baseStyle} ${fontStyle}`}>
      <Text>{text}</Text>
    </Flex>
  );
};

export const MPSPriceApproval = () => {
  const history = useHistory();
  const { processFuelRequestAsPromise } = useFuelRequest();
  const { dismissNotification } = useNotifications();
  const { resetFuelSelections } = useFuel();
  const { showToast: showAppToast } = useContext(AppContext);
  const showToast = (message, status = 'error') => {
    showAppToast({
      description: message,
      status,
      duration: 600,
      position: 'top',
    });
  };

  const showGenericFailure = e =>
    showToast(e?.message || Messages.request_failed);

  const {
    isPendingMPSApproval,
    getGrades,
    getCashPrices,
    getCardPrices,
    getNewPrices,
  } = useFuelPrices();

  const getRows = () => {
    const grades = ['', '', ...getGrades()];
    const cardPricesRow = [Messages.card_prices, 'SELF', ...getCardPrices()];
    const cashPricesRow = [Messages.cash_prices, 'SELF', ...getCashPrices()];
    const rows = [grades, cardPricesRow, cashPricesRow];
    const newPrices = getNewPrices();
    if (isPendingMPSApproval && newPrices.length)
      rows.push([Messages.new_prices, 'SELF', ...newPrices]);
    return rows;
  };
  const priceData = getRows();

  const ButtonActions = {
    accept: 'Accept',
    reject: 'Reject',
    exit: 'Ext',
  };

  const ConfirmationConfigs = {
    accept: {
      icon: Icon_confirm,
      title: Messages.mps_price_accepted_message,
    },
    reject: {
      icon: MPS_Reject_Icon,
      title: Messages.mps_price_rejected_message,
      description: Messages.mps_contact_support_message,
    },
  };

  const onButtonClick = action => {
    if (action === ButtonActions.exit) {
      return history.push('/home');
    }
    if (IS_DEV) {
      return history.push(
        '/home/mpsPriceChangeConfirmation',
        action === ButtonActions.accept
          ? ConfirmationConfigs.accept
          : ConfirmationConfigs.reject
      );
    }
    const command =
      action === ButtonActions.accept
        ? FISActions.mpsPriceAccept
        : FISActions.mpsPriceReject;
    processFuelRequestAsPromise(command)
      .then(() => {
        Logger.info(`[Fuel] MPS Response From DEX`);
        dismissNotification(FuelConstants.newPricesNotificationId);
        history.push(
          '/home/mpsPriceChangeConfirmation',
          action === ButtonActions.accept
            ? ConfirmationConfigs.accept
            : ConfirmationConfigs.reject
        );
      })
      .catch(showGenericFailure)
      .finally(resetFuelSelections);
  };

  return (
    <Flex className={Styles.wrapper}>
      <Flex className={Styles.contentWrapper}>
        <Title {...{ isPendingMPSApproval }} />
        <Flex className={Styles.pricesTable}>
          {priceData.map((rowData, index) => (
            <Flex className={Styles.row} key={index.toString()}>
              {rowData.map((displayText, i) => (
                <PriceElement
                  text={displayText}
                  key={i.toString()}
                  position={i}
                  newPricesRow={
                    index === priceData.length - 1 && isPendingMPSApproval
                  }
                />
              ))}
            </Flex>
          ))}
        </Flex>
        {isPendingMPSApproval && (
          <Flex className={Styles.labelGroup}>
            <Text className={Styles.priceWarning}>
              {Messages.price_update_warning_line1}
            </Text>
            <Text className={Styles.priceWarning}>
              {Messages.price_update_warning_line2}
            </Text>
          </Flex>
        )}
      </Flex>
      <Flex
        className={`${Styles.buttonGroup}  ${
          isPendingMPSApproval ? '' : Styles.exitEnd
        }`}
      >
        <Button
          className={`${Styles.buttonCommon} ${Styles.exit}`}
          onClick={() => onButtonClick(ButtonActions.exit)}
        >
          {Messages.exit}
        </Button>
        {isPendingMPSApproval && (
          <Flex>
            <Button
              className={`${Styles.buttonCommon} ${Styles.reject}`}
              onClick={() => onButtonClick(ButtonActions.reject)}
            >
              {Messages.reject_prices}
            </Button>
            <Button
              className={`${Styles.buttonCommon} ${Styles.accept}`}
              onClick={() => onButtonClick(ButtonActions.accept)}
            >
              {Messages.accept_prices}
            </Button>
          </Flex>
        )}
      </Flex>
    </Flex>
  );
};
