import React, { useContext, useState } from 'react';
import { Flex, Grid } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import MaintenanceItem from '../../Common/grid-item/GridItem';
import { dailpadActions } from '../../../slices/dailpad.slice';
import { AppContext } from '../../../AppContext';
import Styles from './PumpMaintenance.module.css';
import { KeysUtil } from '../../../Utils';
import { usePrivileges } from '../../../hooks';

export const PumpMaintenance = () => {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const { keyPressSound } = useContext(AppContext);
  const [selectedItem, setSelectedItem] = useState({});
  const { isValidUserFunction } = usePrivileges();
  const allItems = location?.state?.items || [];
  console.log('PumpMaintenance ----> ', allItems);
  const actions = KeysUtil.getAllKeysFromInput({
    inputKeys: allItems,
    maxKeyCount: 24,
  });
  const onItemClick = item => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    setSelectedItem(item);
    const uItem = item.name?.toLowerCase();
    switch (uItem) {
      case 'setpumpprices':
        if (!isValidUserFunction(uItem)) {
          // #5538 corrected the condition and passing function Name to FS screen
          history.push({
            pathname: '/home/functionSecurity',
            redirectionData: {
              pathname: '/home/mpsPriceApproval',
            },
            iFunctionName: 'setpumpprices',
          });
          return;
        }
        history.push('/home/mpsPriceApproval');
        break;
      case 'exit':
        dispatch(dailpadActions.resetKeypadValue());
        history.push('/home');
        break;
      default:
        console.log('Not a valid action');
    }
  };

  return (
    <Flex className={Styles.container}>
      <Flex className={Styles.keypadContainer}>
        <Keypad disableDecimal />
      </Flex>
      <Grid className={Styles.gridView}>
        {actions.map((functionItem, index) => (
          <MaintenanceItem
            key={`${functionItem.name}_${index}`}
            functionItem={functionItem}
            selectedItem={selectedItem}
            onItemClick={onItemClick}
            isExit={functionItem?.name?.toLowerCase() === 'exit'}
          />
        ))}
      </Grid>
    </Flex>
  );
};
