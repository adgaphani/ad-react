import React from 'react';
import { Box, Image, Text } from '@chakra-ui/react';
import fuelPump from '@icons/speedway/pump@speedy.png';

export const Grade = ({ grade, onGradeSelect }) => (
  <Box
    p={4}
    m={1}
    width="32%"
    height={200}
    bg="default.posWhite"
    onClick={() => onGradeSelect(grade)}
  >
    <Image height="125px" width="150px" src={fuelPump} alt="fuelPumpLogo" />
    <Box
      border="1px solid rgb(91, 97, 107)"
      width="100%"
      textAlign="center"
      p="6px"
      borderRadius={2}
    >
      <Text>{grade.productName}</Text>
    </Box>
  </Box>
);
