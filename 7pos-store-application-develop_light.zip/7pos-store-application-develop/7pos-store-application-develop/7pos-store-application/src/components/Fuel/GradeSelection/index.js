import React from 'react';
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Flex } from '@chakra-ui/react';

import { SideContainer } from '../../Common/Containers';
import { Grade } from './Grade';

export const GradeSelection = ({ onExit, onGradeSelect }) => {
  const history = useHistory();
  const { fuelGrades } = useSelector(state => ({
    fuelGrades: state.fuel.fuelPrices,
  }));
  return (
    <SideContainer
      onExit={() => {
        if (onExit) {
          return onExit();
        }
        return history.replace('/fuel');
      }}
      containerStyles={{
        h: '577px',
        margin: '0 7px',
        background: 'transparent',
      }}
    >
      <Flex justifyContent="space-between" flexWrap="wrap">
        {fuelGrades.map((grade, i) => (
          <Grade
            grade={grade}
            onGradeSelect={onGradeSelect}
            key={`${grade.storeProductName} ${i + 1}`}
          />
        ))}
      </Flex>
    </SideContainer>
  );
};
