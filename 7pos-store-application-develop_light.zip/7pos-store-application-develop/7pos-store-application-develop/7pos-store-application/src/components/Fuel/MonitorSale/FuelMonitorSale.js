import React, { useContext, useEffect, useState } from 'react';
import { Flex, Image, Text } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import Styles from './FuelMonitorSale.module.css';
import { ExitButton } from '../../Common';
import { FISActions } from '../FuelActions';
import { AppContext } from '../../../AppContext';
import fuelPumpIcon from '../../../Icons/fuelIcons/fuel_pump.svg';
import { useFuel, useFuelCache, useFuelRequest } from '../../../hooks';
import { FuelPumpDescription } from '../FuelPumps/helpers/FuelPumpStatus';

export const FuelMonitorSale = () => {
  const history = useHistory();
  const { toFixedDigits, getSelectedPumpFuelState } = useFuel();
  const { resetFuelSelections } = useFuelCache();
  const {
    processFuelRequestAsMultiResolve,
    processFuelRequest,
    stopListeningToFuelResponse,
  } = useFuelRequest();
  const { showToast } = useContext(AppContext);
  const [saleInfo, setSaleInfo] = useState({
    current: { amountPumped: 0, gallonVolume: 0 },
    previous: { amountPumped: 0, gallonVolume: 0 },
  });
  const fuelState = getSelectedPumpFuelState();
  const onExit = () => {
    history.replace('/fuel');
  };

  const handleMonitorSaleResponse = response => {
    console.log('RESPONSE: ', response);
    const { previousSale, currentSale } = response;
    setSaleInfo({
      current: {
        amountPumped: currentSale?.amountPumped || 0.0,
        gallonVolume: currentSale?.volume || 0.0,
      },
      previous: {
        amountPumped: previousSale?.amountPumped || 0.0,
        gallonVolume: previousSale?.volume || 0.0,
      },
    });
  };

  const sendMonitorSaleRequest = startMonitor => {
    try {
      if (startMonitor) {
        return processFuelRequestAsMultiResolve(
          FISActions.monitorSale,
          handleMonitorSaleResponse
        );
      }
      processFuelRequest(FISActions.stopMonitor);
    } catch (e) {
      showToast({ description: e.message || Messages.connection_error });
    }
  };

  useEffect(() => {
    sendMonitorSaleRequest(true);
    return () => {
      sendMonitorSaleRequest(false);
      stopListeningToFuelResponse();
      resetFuelSelections();
    };
  }, []);

  const {
    current: { gallonVolume: cVolume, amountPumped: cAmountPumped },
    previous: { gallonVolume: pVolume, amountPumped: pAmountPumped },
  } = saleInfo;
  const costText = `$${toFixedDigits(cAmountPumped || pAmountPumped || 0, 2)}`;
  const volumeText = `${toFixedDigits(cVolume || pVolume || 0, 3)} G`;
  return (
    <Flex className={Styles.wrapper}>
      <Flex className={Styles.space}>
        <Image
          src={fuelPumpIcon}
          className={`${Styles.pumpImage} ${Styles[fuelState]}`}
        />
        <Flex className={Styles.textWrapper}>
          <Text className={Styles.text}>{`${costText}`}</Text>
          <Text className={Styles.text}>{volumeText}</Text>
        </Flex>
        <Text className={Styles.pumpDescription}>
          {FuelPumpDescription[fuelState]}
        </Text>
      </Flex>
      <Flex className={Styles.exitWrapper}>
        <ExitButton onClick={onExit} />
      </Flex>
    </Flex>
  );
};
