import React from 'react';
import { Button } from '../../Common';
import Styles from './RefundButton.module.css';

export const RefundButton = ({ refund, onClick }) => (
  <Button className={Styles.button} onClick={() => onClick(refund)}>
    {`$${((refund?.amount || 0.0) / 100).toFixed(2)}`}
  </Button>
);
