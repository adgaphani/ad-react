import React, { useContext, useEffect } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useHistory } from 'react-router-dom';
import Styles from './FuelMultiRefund.module.css';
import { ExitButton } from '../../Common';
import { RefundButton } from './RefundButton';
import { useFuel, useFuelCache, useSharedFuelRequest } from '../../../hooks';
import { AppContext } from '../../../AppContext';

export const FuelMultiRefund = () => {
  const history = useHistory();
  const { getPumpRefunds } = useFuel();
  const { resetFuelSelections } = useFuelCache();
  const { processRefundRequest } = useSharedFuelRequest();
  const refunds = getPumpRefunds();
  const { showToast } = useContext(AppContext);

  const showGenericToast = e =>
    showToast({
      description: e?.message || Messages.request_failed,
      duration: 600,
      status: 'error',
    });

  const processRefund = refund => {
    processRefundRequest(refund)
      .then(() => history.replace('/home'))
      .catch(showGenericToast);
  };

  const onExit = () => {
    history.replace('/fuel');
  };

  useEffect(
    () => () => {
      resetFuelSelections();
    },
    []
  );

  return (
    <Flex className={Styles.wrapper}>
      <Flex className={Styles.space}>
        <Text className={Styles.title}>{Messages.select_refund}</Text>
        {refunds.map((refund, idx) => (
          <RefundButton
            key={idx.toString()}
            refund={refund}
            onClick={processRefund}
          />
        ))}
      </Flex>
      <Flex className={Styles.exitWrapper}>
        <ExitButton onClick={onExit} />
      </Flex>
    </Flex>
  );
};
