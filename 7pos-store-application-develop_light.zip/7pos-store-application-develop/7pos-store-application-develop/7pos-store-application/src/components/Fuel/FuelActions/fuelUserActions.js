import CoinBox from '@fuelIcons/CoinBox.svg';
import stopAllIcon from '@fuelIcons/StopAllPumps.svg';
import authAllIcon from '@fuelIcons/AuthAllPumps.svg';
import PrepayPump from '@fuelIcons/PrepayPump.svg';
import TransferPrepay from '@fuelIcons/TransferPrepay.svg';
import FinishPump from '@fuelIcons/FinishPump.svg';
import PumpStat from '@fuelIcons/PumpStat.svg';
import RestartPump from '@fuelIcons/RestartPump.svg';
import CancelPump from '@fuelIcons/CancelPump.svg';
import AuthPump from '@fuelIcons/AuthPump.svg';
import StopPump from '@fuelIcons/StopPump.svg';
import CrindDenial from '@fuelIcons/CrindDenial.svg';
import ReceiptReprint from '@fuelIcons/ReceiptReprint.svg';
import OpenPump from '@fuelIcons/OpenPump.svg';
import ClosePump from '@fuelIcons/ClosePump.svg';
import CarWash from '@fuelIcons/CarWash.svg';
import RestInFuel from '@fuelIcons/RestInFuel.svg';
import Exit from '@icons/Exit.svg';
import OpenAll from '@fuelIcons/fuelgreen.svg';
import CloseAll from '@fuelIcons/fuelred.svg';

import { FuelActionTypes } from './FuelActionTypes';

const {
  prepayPump,
  transferPrepay,
  finishPump,
  pumpStat,
  resumePump,
  cancelPump,
  authPump,
  stopPump,
  crindDenial,
  receiptReprint,
  openPump,
  closePump,
  carwash,
  promoCarwash,
  coinBox,
  authAll,
  stopAll,
  restInFuel,
  unknownSequence,
  openAll,
  closeAll,
} = FuelActionTypes;

export const fuelUserActions = [
  {
    sequenceNumber: prepayPump,
    displayLabel: 'Prepay Pump',
    thumbnail: PrepayPump,
    active: true,
    restrictions: {
      allowCreditItem: false,
      allowRefund: false,
    },
  },
  {
    sequenceNumber: transferPrepay,
    displayLabel: 'Transfer Prepay',
    thumbnail: TransferPrepay,
    active: true,
  },
  {
    sequenceNumber: finishPump,
    displayLabel: 'Finish Pump',
    thumbnail: FinishPump,
    active: true,
    restrictions: {
      allowCreditItem: false,
      allowRefund: false,
    },
  },
  {
    sequenceNumber: pumpStat,
    displayLabel: 'Pump Stat',
    thumbnail: PumpStat,
    active: true,
  },
  {
    sequenceNumber: resumePump,
    displayLabel: 'Resume Pump',
    thumbnail: RestartPump,
    active: true,
  },
  {
    sequenceNumber: cancelPump,
    displayLabel: 'Cancel Pump',
    thumbnail: CancelPump,
    active: true,
    restrictions: {
      allowCreditItem: false,
      allowRefund: false,
    },
  },
  {
    sequenceNumber: authPump,
    displayLabel: 'Auth Pump',
    thumbnail: AuthPump,
    active: true,
  },
  {
    sequenceNumber: stopPump,
    displayLabel: 'Stop Pump',
    thumbnail: StopPump,
    active: true,
  },
  {
    sequenceNumber: crindDenial,
    displayLabel: 'Crind Denial',
    thumbnail: CrindDenial,
    active: false,
  },
  {
    sequenceNumber: receiptReprint,
    displayLabel: 'Receipt Reprint',
    thumbnail: ReceiptReprint,
    active: true,
  },
  {
    sequenceNumber: openPump,
    displayLabel: 'Open Pump',
    thumbnail: OpenPump,
    active: true,
  },
  {
    sequenceNumber: closePump,
    displayLabel: 'Close Pump',
    thumbnail: ClosePump,
    active: true,
  },
  {
    sequenceNumber: carwash,
    displayLabel: 'Car Wash',
    thumbnail: CarWash,
    active: true,
  },
  {
    sequenceNumber: promoCarwash,
    displayLabel: 'Car Wash Promo',
    thumbnail: CarWash,
    active: true,
  },
  {
    sequenceNumber: coinBox,
    displayLabel: 'Coin Box',
    thumbnail: CoinBox,
    active: false,
  },
  {
    sequenceNumber: restInFuel,
    displayLabel: 'Rest In Fuel',
    thumbnail: RestInFuel,
    active: true,
    restrictions: {
      allowCreditItem: false,
      allowRefund: false,
    },
  },
  {
    sequenceNumber: openAll,
    displayLabel: 'Open All Pumps',
    thumbnail: OpenAll,
    active: true,
  },
  {
    sequenceNumber: closeAll,
    displayLabel: 'Close All Pumps',
    thumbnail: CloseAll,
    active: true,
  },
  {
    sequenceNumber: authAll,
    displayLabel: 'Auth All Pumps',
    thumbnail: authAllIcon,
    active: true,
  },
  {
    sequenceNumber: stopAll,
    displayLabel: 'Emer Stop All',
    thumbnail: stopAllIcon,
    active: true,
  },
  {
    sequenceNumber: unknownSequence,
    displayLabel: '',
    thumbnail: null,
    active: true,
  },
  {
    sequenceNumber: unknownSequence,
    displayLabel: '',
    thumbnail: null,
    active: true,
  },
  {
    sequenceNumber: unknownSequence,
    displayLabel: '',
    thumbnail: null,
    active: true,
  },
  {
    sequenceNumber: 24,
    displayLabel: 'Exit',
    thumbnail: Exit,
    active: true,
  },
];
