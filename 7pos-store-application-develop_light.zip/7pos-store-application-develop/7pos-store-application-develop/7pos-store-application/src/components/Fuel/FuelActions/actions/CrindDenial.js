import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Text, Box } from '@chakra-ui/react';
import { SideContainer } from '../../../Common/Containers';
import error_outline from '../../../../Icons/Icon_exclamation.svg';
import { CrindDenialList } from './CrindDenialList';
import { FuelApi } from '../../../../api/fuel';
import { useFuel } from '../../../../hooks';

export const CrindDenial = () => {
  const [list, setList] = useState([]);

  const history = useHistory();

  const { setCrindDenialReason } = useFuel();

  const { paymentTransactionId, selectedPump } = useSelector(state => ({
    paymentTransactionId: state.cart.paymentTransactionId,

    selectedPump: state.fuel.selectedPump,
  }));

  async function getList() {
    try {
      const denials = await FuelApi.fetchCrindDenials({
        correlationID: paymentTransactionId,
        selectedPump,
      });
      setList(denials);
      if (denials.length) {
        setCrindDenialReason(Messages.crind_denial_reason);
      }
    } catch (e) {
      Logger.info(
        `[7POS UI] : Crind Denials - getList error ::-${JSON.stringify(e)}`
      );
    }
  }

  useEffect(() => {
    getList();
    return () => {
      setCrindDenialReason(undefined);
    };
  }, [selectedPump]);

  return (
    <SideContainer
      onExit={() => {
        history.replace('/fuel');
        // setCrindDenialReason(undefined);
      }}
      containerStyles={{ h: '577px', margin: '0 7px' }}
    >
      <Box mt="25%" textAlign="center">
        <img
          src={error_outline}
          height="40px"
          width="40px"
          alt="Error_outline"
        />

        <Text fontWeight="bold" fontSize="28px">
          {Messages.crind_denial_title}
        </Text>

        <CrindDenialList list={list} />
      </Box>
    </SideContainer>
  );
};
