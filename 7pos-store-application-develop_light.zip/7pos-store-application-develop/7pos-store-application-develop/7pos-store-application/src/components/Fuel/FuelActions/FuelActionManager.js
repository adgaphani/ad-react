import React, { useContext, useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Grid } from '@chakra-ui/react';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import { fuelUserActions } from './fuelUserActions';
import { FISActions } from './actions/FISActions';
import { FuelUtils } from '../../../Utils';
import { FuelActions } from './actions/FuelActions';
import { AppContext } from '../../../AppContext';
import {
  useCart,
  useFuel,
  useFuelCache,
  useFuelRequest,
  useSharedFuelRequest,
  useCarWash,
  useKeyPad,
} from '../../../hooks';
import { TransactionTypes } from '../../../TransactionTypes';
import { Messages } from '../../../Messages';
import { FuelActionTypes } from './FuelActionTypes';
import { GradeSelection } from '../GradeSelection';

export const FuelActionManager = ({ fuelAmount, finalTotalPrice }) => {
  const history = useHistory();
  const {
    addItemToCart,
    currentTransactionId,
    getFullTransactionId,
    paymentTransactionId,
    isTransactionInProgress,
    addVoidFuelCartItem,
    isCreditItemInCart,
    isFuelTransactionInProgress,
    isCardLoadTransaction,
    isTransactionRefund,
    isTransactionVoid,
  } = useCart();
  const {
    currentAction,
    selectAction,
    selectedPump,
    deselectPump,
    deselectAction,
    currentPumpConfig = {},
    checkIfPumpIsAvailable,
    getPumpRefunds,
    checkIfPumpIsLocked,
    checkIfAuthInProgress,
    checkIfPumpCanBeStopped,
    checkIfPumpCanBeRestarted,
    checkIfPumpIsClosed,
    fuelParams,
    isGradeSelectionOn,
    setGradeSelection,
    setSelectedGrade,
    checkifAuthIsAllowed,
    setOpenAllResponse,
    setCloseAllResponse,
    openAllResponse,
    closeAllResponse,
    dexComFormat,
  } = useFuel();

  const [isRestInFuel, setRestInFuel] = useState(false);
  console.log('Rest In Fuel State', isRestInFuel);
  const { resetKeypadValue } = useKeyPad();
  const { isCarWashEnabled, handleCarwash } = useCarWash();
  const { processFuelRequestAsPromise, processFuelRequest } = useFuelRequest();
  const { processRefundRequest } = useSharedFuelRequest();
  const {
    resetFuelSelections,
    setPrepayCache,
    scheduleResetFuelSelections,
  } = useFuelCache();
  const { showToast: showAppToast, isSpeedyStore } = useContext(AppContext);
  const showToast = (message, status = 'error') => {
    showAppToast({
      description: message,
      status,
      duration: 600,
      position: 'top-left',
    });
  };

  const processOneWayFuelRequest = (messageDetails, includePump = true) => {
    // check the Prepay inProgress, show the toaster and return
    if (checkifAuthIsAllowed()) {
      return showToast(Messages.invalid_action_fuel);
    }
    processFuelRequest(messageDetails, selectedPump, {
      includePump,
      clearSelections: true,
    });
  };

  const showGenericFailure = e =>
    showToast(e?.message || Messages.request_failed);

  const handleTransferPrepay = () => {
    /* Handle Transfer Prepay */
    if (
      selectedPump &&
      currentAction?.fromPump &&
      currentAction?.sequenceNumber === 2 &&
      currentAction?.fromPump !== selectedPump
    ) {
      const { fromPump } = currentAction;
      const toPump = selectedPump;
      if (checkIfPumpIsAvailable()) {
        const {
          currentState: { sequenceNumber },
        } = currentPumpConfig;
        const transferAuthMessage = FISActions.transferAuth({
          toPump,
          sequenceNumber,
        });
        processFuelRequestAsPromise(transferAuthMessage, fromPump)
          .then(() => {
            showAppToast({
              description: Messages.transfer_successful,
              status: 'success',
              position: 'top-left',
            });
            resetFuelSelections();
          })
          .catch(showGenericFailure);
      } else {
        showToast(Messages.pump_not_available(selectedPump));
        // Deselecting the pump
        deselectPump();
      }
    }
  };

  useEffect(handleTransferPrepay, [currentAction?.fromPump, selectedPump]);

  const handleClearSale = () => {
    const refunds = getPumpRefunds();
    if (!refunds.length) {
      showToast(Messages.no_sale_in_progress(selectedPump));
      return;
    }
    const { sequenceNumber } = refunds[0]; // As this is DEV only feature, clearing the first refund.
    processFuelRequestAsPromise(FISActions.clearSale(sequenceNumber))
      .then(response => {
        console.log(response);
      })
      .catch(showGenericFailure);
  };

  const handlePrepay = ({
    fuelAction,
    lockOnly = false,
    grade,
    isRestInFuel,
  }) => {
    // #7324 adjusted the fuel amount
    const fAmount = Number.parseFloat(fuelAmount) / 100;
    const actualFuelAMount = fAmount;
    if (isRestInFuel && fAmount > 0 && fAmount > finalTotalPrice) {
      // #8774 modified conversion logic
      fuelAmount = parseFloat(
        parseFloat((fAmount - finalTotalPrice) * 100).toFixed(2)
      );
      // fuelAmount = parseFloat(fAmount - finalTotalPrice) * 100;
    }
    processFuelRequestAsPromise(
      FISActions.authLock({
        transactionId: paymentTransactionId,
      })
    )
      .then(response => {
        if (lockOnly) {
          return;
        }
        const { sequenceNumber, displayLabel } = fuelAction;
        const cartItemObj = FuelUtils.getPrepayCartItem({
          selectedPumpNumber: selectedPump,
          sequenceNumber,
          displayLabel,
          fuelAmount,
          selectedGrade: grade,
        });
        cartItemObj.metaInfo = {
          fuelDispenserId: selectedPump?.toString(),
          fuelAmount: Number.parseFloat(fuelAmount) / 100,
          prepayAmount: Number.parseFloat(fuelAmount) / 100,
          transactionType: TransactionTypes.preAuth,
          isRestInFuel,
          actualFuelAMount,
        };
        addItemToCart(cartItemObj);

        const prepayDetails = {
          pumpNumber: selectedPump,
          sequenceNumber: response?.tranSeq, // From Auth Lock.
          fuelAmount,
          transactionId: getFullTransactionId() || currentTransactionId,
          paymentTransactionId,
        };
        setPrepayCache(prepayDetails);
        history.replace('/home');
      })
      .catch(showGenericFailure);
  };

  const handleFinishPump = fuelAction => {
    /*
    Perform validations here to see if a sale is in progress.
     */
    const refunds = getPumpRefunds();
    if (!refunds.length) {
      showToast(Messages.no_sale_in_progress(selectedPump));
      deselectAction();
      return;
    }
    if (refunds.length > 1) {
      history.push(`fuel/multiRefund`, { fuelAction });
      return;
    }

    processRefundRequest(refunds[0]).catch(showGenericFailure);
  };

  const handleDeauthPump = fuelAction => {
    if (isTransactionInProgress) {
      scheduleResetFuelSelections(1000);
      return showToast(Messages.deauth_sale_in_progress);
    }

    /*
    Perform validations here to see if a sale is in progress.
     */
    if (!checkIfAuthInProgress()) {
      scheduleResetFuelSelections(1000);
      return showToast(Messages.no_sale_in_progress(selectedPump));
    }
    const { sequenceNumber: cartSequenceNumber } = fuelAction; // we will need the sequenceNumber to prepare cart item.
    const {
      currentState: { sequenceNumber },
    } = currentPumpConfig;
    processFuelRequestAsPromise(FISActions.deauthPump(sequenceNumber))
      .then(response => {
        Logger.info(`[Fuel] DEAUTH : Response Received from DEX `);
        const {
          currentSale: {
            refundAmount,
            prepayAmount,
            mediaNumber,
            originalSequenceNumber,
            originalTransactionId,
            originalPaymentTenderId,
          },
        } = response;
        addVoidFuelCartItem({
          pumpNumber: selectedPump,
          sequenceNumber: cartSequenceNumber,
          fuelAmount: refundAmount,
          mediaNumber,
          originalTransactionId,
          originalPaymentTenderId,
          originalTransactionSequenceId: originalSequenceNumber?.toString(),
        });
        // Process Cash Refund automatically. tapi call will be made like a regular cash flow
        // For CARD -> We need to only print the receipt. Should not call vanguard.
        history.push('/payment', {
          preauthCancelFlow: true,
          metaInfo: {
            mediaNumber,
            prepayAmount,
          },
        });
      })
      .catch(showGenericFailure);
  };
  const clearAndDisplayToast = () => {
    deselectAction();
    deselectPump();
    showToast(Messages.invalid_action);
  };

  const handleStopPump = (isStopAll = false) => {
    let action = FISActions.stopPump;
    if (!checkIfPumpCanBeStopped()) {
      return clearAndDisplayToast();
    }
    if (isStopAll) {
      action = FISActions.stopAllPumps;
      deselectPump();
      showToast(Messages.stop_all_message, 'success');
    }
    return processOneWayFuelRequest(action, true);
  };

  const handleOpenAll = () => {
    deselectPump();
    showToast(Messages.open_all_message, 'success');
    return processFuelRequestAsPromise(FISActions.openAllPumps, 0, {
      resetActions: false,
    })
      .then(response => {
        setCloseAllResponse(null); // for toggling the close all button when open all is disabled
        setOpenAllResponse(response);
      })
      .catch(showGenericFailure)
      .finally(resetFuelSelections);
  };

  const handleCloseAll = () => {
    deselectPump();
    showToast(Messages.close_all_message, 'success');
    return processFuelRequestAsPromise(FISActions.closeAllPumps, 0, {
      resetActions: false,
    })
      .then(response => {
        setOpenAllResponse(null); // for toggling the open all button when close all is disabled
        setCloseAllResponse(response);
      })
      .catch(showGenericFailure)
      .finally(resetFuelSelections);
  };

  const handleUnlockPump = () => {
    if (!checkIfPumpIsLocked()) {
      return showToast(Messages.cannot_process_unlock(selectedPump));
    }
    const {
      currentState: { sequenceNumber },
    } = currentPumpConfig || {};
    processFuelRequestAsPromise(FISActions.unlockPump(sequenceNumber))
      .then(response => {
        console.log(response);
      })
      .catch(showGenericFailure)
      .finally(resetFuelSelections);
  };

  const clearActionAndShowToast = msg => {
    deselectAction();
    showToast(msg);
  };

  const isValidAction = action => {
    const { restrictions } = action;
    if (!restrictions) {
      return true;
    }
    if (isCreditItemInCart && !restrictions?.allowCreditItem) {
      return false;
    }
    if (
      (isTransactionRefund || isTransactionVoid) &&
      !restrictions?.allowRefund
    ) {
      return false;
    }
    return true;
  };

  const handleNewPricesCommand = () => {
    processFuelRequestAsPromise(FISActions.getPrices)
      .then(response => {
        console.log(response);
      })
      .catch(e => {
        console.log(e);
      });
  };

  const performFuelAction = action => {
    Logger.info(`[Fuel] Selected Fuel function :- ${action?.displayLabel}`);
    switch (action.sequenceNumber) {
      case 24:
        return history.replace('./home'); // EXIT
      case FuelActionTypes.carwash:
        return handleCarwash();
      case FuelActionTypes.promoCarwash:
        return handleCarwash(true);
      case FuelActionTypes.stopAll:
        selectAction(action);
        return handleStopPump(true);
      case FuelActionTypes.authAll: {
        selectAction(action);
        return processOneWayFuelRequest(FISActions.authAllPumps, false);
      }
      case FuelActionTypes.receiptReprint: // Receipt Reprint
        return history.push(`fuel/reprint`);
      case 18: {
        return handleNewPricesCommand();
      }
      case FuelActionTypes.crindDenial:
        return history.push('fuel/crinddenial', {
          isCrindDenialScreen: true,
        });
      case FuelActionTypes.openAll:
        selectAction(action);
        return handleOpenAll();
      case FuelActionTypes.closeAll:
        selectAction(action);
        return handleCloseAll();
      default:
        Logger.debug('Not a Global Action. Proceeding --->');
        break;
    }
    if (!selectedPump) {
      showToast(Messages.pump_not_selected);
      console.log('Pump Not Selected.');
      return;
    }
    selectAction(action);
    let fisActionPayload;
    let requestMessageDetails;
    let fAmount = Number.parseFloat(fuelAmount) / 100;
    switch (action.sequenceNumber) {
      case FuelActionTypes.prepayPump: // Prepay
      case FuelActionTypes.restInFuel: {
        if (isCardLoadTransaction) {
          deselectPump();
          resetKeypadValue();
          return clearActionAndShowToast(Messages.invalid_action);
        }
        // Check Amount
        if (isFuelTransactionInProgress) {
          return clearActionAndShowToast('More than one Prepay is not allowed');
        }
        if (!fuelAmount) {
          return clearActionAndShowToast('Enter Amount');
        }
        // #7324 Rest In Fuel Implementation
        let isRestInFuel = false;
        if (action.sequenceNumber === FuelActionTypes.restInFuel) {
          if (fAmount <= finalTotalPrice)
            return clearActionAndShowToast('Invalid Amount for Rest In Fuel');
          setRestInFuel(true);
          isRestInFuel = true;
        } else setRestInFuel(false);
        Logger.info(
          `[Fuel] HALO_LALO_COMPARISON. fuelAmount: ${fAmount}, HALO: ${fuelParams?.fuelAmountHalo}, LALO: ${fuelParams?.fuelAmountLalo}`
        );

        // #8915 recalculate fuel price for rest in fuel to comapre LALO and HALO check
        if (isRestInFuel && fAmount > 0 && fAmount > finalTotalPrice) {
          fAmount = parseFloat(fAmount - finalTotalPrice).toFixed(2);
        }

        if (fuelParams?.fuelAmountHalo < fAmount) {
          return clearActionAndShowToast(Messages.fuel_halo);
        }
        if (fuelParams?.fuelAmountLalo > fAmount) {
          return clearActionAndShowToast(Messages.fuel_lalo);
        }
        if (isSpeedyStore) {
          return setGradeSelection(true);
        }
        return handlePrepay({
          fuelAction: action,
          lockOnly: false,
          isRestInFuel,
        });
      }
      case FuelActionTypes.transferPrepay: // Transfer Prepay
        if (!checkIfAuthInProgress()) {
          deselectAction();
          return showToast(Messages.no_sale_in_progress(selectedPump));
        }
        return selectAction({ ...action, fromPump: selectedPump });
      case FuelActionTypes.finishPump: // Finish Pump
        if (isCardLoadTransaction) {
          deselectPump();
          resetKeypadValue();
          return clearActionAndShowToast(Messages.invalid_action);
        }
        if (isFuelTransactionInProgress) {
          return clearActionAndShowToast(Messages.invalid_action_fuel);
        }
        return handleFinishPump(action);
      case FuelActionTypes.pumpStat: // Pump Stat
        return history.push(`fuel/monitorSale`);
      case FuelActionTypes.resumePump: // Restart Pump
        if (!checkIfPumpCanBeRestarted()) {
          return clearAndDisplayToast();
        }
        return processOneWayFuelRequest(FISActions.resumePump, true);
      case FuelActionTypes.cancelPump: // Cancel Pump
        return handleDeauthPump(action);
      case FuelActionTypes.authPump: // Auth Pump
        return processOneWayFuelRequest(FISActions.authSinglePump, true);
      case FuelActionTypes.stopPump: // Stop Pump
        return handleStopPump();

      case FuelActionTypes.releasePump: // Release Pump
        requestMessageDetails = FISActions.releasePump;
        break;
      case FuelActionTypes.crindDenial: // Crind Denial
        break;
      case FuelActionTypes.openPump: // Open Pump
        if (!checkIfPumpIsClosed()) {
          return clearAndDisplayToast();
        }
        requestMessageDetails = FISActions.openPump;
        break;
      case FuelActionTypes.closePump: // Close Pump
        if (checkIfPumpIsClosed()) {
          return clearAndDisplayToast();
        }
        requestMessageDetails = FISActions.closePump;
        break;
      case 17: // ClearSale: Just for DEV purpose.
        return handleClearSale();
      case 18: // Lock Pump. Just for DEV purpose
        return handlePrepay({ fuelAction: action, lockOnly: true });
      case 19: // Unlock Pump. Just for DEV purpose
        return handleUnlockPump();
      default:
        console.log('Sequence is not matching with any actions');
        return;
    }
    Logger.info(
      '[FISActionPayload]: ',
      fisActionPayload
        ? JSON.parse(fisActionPayload)
        : `Not Defined Yet for Action: ${action.sequenceNumber}: ${action.displayLabel}`
    );
    processFuelRequestAsPromise(requestMessageDetails)
      .then(response => {
        console.log('SUCCESS RESPONSE: ', response);
      })
      .catch(showGenericFailure)
      .finally(resetFuelSelections);
  };

  const getFuelActions = fuelUserActions?.map(action => {
    // SCALE-1824 display open all & close for JSON dex stores
    if (
      dexComFormat !== 'JSON' &&
      (action.sequenceNumber === FuelActionTypes.openAll ||
        action.sequenceNumber === FuelActionTypes.closeAll)
    ) {
      return {
        sequenceNumber: FuelActionTypes.unknownSequence,
        displayLabel: '',
        thumbnail: null,
        active: true,
      };
    }

    return {
      ...action,
      ...(action.sequenceNumber === FuelActionTypes.carwash ||
      action.sequenceNumber === FuelActionTypes.promoCarwash
        ? { active: isCarWashEnabled && action.active }
        : {}),
      ...((action.sequenceNumber === FuelActionTypes.openAll &&
        openAllResponse?.status === 1) ||
      (action.sequenceNumber === FuelActionTypes.closeAll &&
        closeAllResponse?.status === 1)
        ? { active: false }
        : {}),
    };
  });

  const onGradeSelect = grade => {
    setSelectedGrade(grade);
    setGradeSelection(false);
    let fuelAction = fuelUserActions[0];
    if (isRestInFuel) {
      fuelAction = fuelUserActions.find(
        action => action.sequenceNumber === FuelActionTypes.restInFuel
      );
    }
    handlePrepay({
      fuelAction,
      lockOnly: false,
      grade,
      isRestInFuel,
    });
    console.log('Selected Grade', grade);
  };

  return (
    <>
      {!isGradeSelectionOn && (
        <Grid templateColumns="50% 50%" ml="7px">
          <Keypad />
          <FuelActions
            items={getFuelActions}
            onItemClick={action => {
              deselectAction();
              if (isValidAction(action)) {
                return performFuelAction(action);
              }
              return showToast(Messages.invalid_action_fuel);
            }}
            fuelAmount={parseFloat(fuelAmount).toFixed(2) / 100}
          />
        </Grid>
      )}
      {isGradeSelectionOn && (
        <GradeSelection
          onExit={() => setGradeSelection()}
          onGradeSelect={onGradeSelect}
        />
      )}
    </>
  );
};
