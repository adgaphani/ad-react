import { Flex, Text } from '@chakra-ui/react';
import React, { useContext } from 'react';
import Styles from './FuelActionItem.module.css';
import { AppContext } from '../../../../AppContext';

export const FuelActionItem = ({ item = {}, onItemClick, selected }) => {
  const { keyPressSound } = useContext(AppContext);
  const { displayLabel = '', active = false, isDev = false, thumbnail } = item;
  const isValidAction = !!displayLabel;
  return (
    <Flex
      className={`${Styles.actionItem}  ${isValidAction ? Styles.valid : ''}
      ${selected ? Styles.selected : ''} ${active ? '' : Styles.inactive}
      ${isDev ? Styles.dev : ''}
      `}
      onClick={() => {
        if (!isValidAction) return;
        keyPressSound?.play().catch(e => console.log('Sound error', e));
        isValidAction && onItemClick(item);
      }}
    >
      {thumbnail && (
        <img src={thumbnail} alt={displayLabel || ''} className={Styles.icon} />
      )}
      <Text className={Styles.itemTitle}>{displayLabel}</Text>
    </Flex>
  );
};
