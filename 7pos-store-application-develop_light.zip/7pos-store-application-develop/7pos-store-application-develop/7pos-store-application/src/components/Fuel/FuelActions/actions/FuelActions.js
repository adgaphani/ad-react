import React from 'react';
import { Grid } from '@chakra-ui/react';
import { useSelector } from 'react-redux';
import Styles from './FuelActions.module.css';
import { FuelActionItem } from './FuelActionItem';

export const FuelActions = ({ items = [], onItemClick }) => {
  const { currentAction } = useSelector(state => ({
    currentAction: state.fuel.fisAction,
  }));
  const isSelectedAction = anyAction =>
    anyAction.sequenceNumber === currentAction?.sequenceNumber;
  return (
    <Grid className={Styles.itemGrid}>
      {items.map((item, index) => (
        <FuelActionItem
          item={item}
          index={index}
          key={index}
          onItemClick={onItemClick}
          selected={isSelectedAction(item)}
        />
      ))}
    </Grid>
  );
};
