import React from 'react';

import { Box, Text } from '@chakra-ui/react';
import { Messages } from '../../../../Messages';

export const CrindDenialList = ({ list }) => (
  <Box maxH="200px" overflow="auto" pt={2} fontSize="20px">
    {!list?.length && <Text>{Messages.no_crind_denials}</Text>}
    {list?.map((l, i) => (
      <Text p={1} key={i}>
        {l.maskedPan}
      </Text>
    ))}
  </Box>
);
