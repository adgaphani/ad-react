import React from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useHistory, useLocation } from 'react-router-dom';
import { ExitButton } from '../../Common';
import Styles from './MPSPriceChangeConfirmation.module.css';
import Icon_confirm from '../../../Icons/Icon_confirm.svg';

export const MPSPriceChangeConfirmation = () => {
  const history = useHistory();
  const location = useLocation();
  const { icon, title, description = '' } = location.state || {};
  const onExit = () => {
    history.push('/home');
  };
  return (
    <Flex className={Styles.container}>
      <Flex className={Styles.infoWrapper}>
        <img
          className={Styles.icon}
          alt="warning-icon"
          src={icon || Icon_confirm}
        />
        <Text className={Styles.title}>{title}</Text>
        <Flex className={Styles.descriptionWrapper}>
          {description.split('\n').map((text, i) => (
            <Text className={Styles.description} key={i.toString()}>
              {text}
            </Text>
          ))}
        </Flex>
      </Flex>
      <Flex className={Styles.exitWrapper}>
        <ExitButton onClick={onExit} />
      </Flex>
    </Flex>
  );
};
