import React from 'react';
import { useHistory } from 'react-router-dom';
import { Box, Grid, Heading, Flex } from '@chakra-ui/react';
import { useCarWash } from '../../../hooks';
import Keypad from '../../Common/DailPad/Keypad/Keypad';
import { ExitButton } from '../../Common/Buttons';

export const EnterCode = props => {
  console.log('carwash config', props);
  const history = useHistory();
  const { validateCode } = useCarWash();
  return (
    <Grid templateColumns="50% 50%" width="100%">
      <Box marginLeft="7px">
        <Keypad
          onEnter={validateCode}
          showAmounts={false}
          max={7}
          disableDecimal
        />
      </Box>
      <Flex
        marginLeft="7px"
        p="1em"
        bg="rgb(255, 255, 255)"
        justifyContent="space-between"
        flexDirection="column"
      >
        <Heading
          justifyContent="center"
          mb="30px"
          color="rgb(44, 47, 53)"
          fontSize="24px"
          fontWeight="bold"
          fontFamily="Roboto-Bold"
        >
          Enter Car Wash Code
        </Heading>
        <Box display="block" textAlign="right" w="100%">
          <ExitButton onClick={() => history.replace('/fuel/carwash')} />
        </Box>
      </Flex>
    </Grid>
  );
};
