import React from 'react';
import { Flex, Box, Text } from '@chakra-ui/react';

import { useCarWash } from '../../../hooks';
import error_outline from '../../../Icons/Icon_exclamation.svg';
import Styles from './Carwash.module.css';
import ExitButton from '../../POS/ExitButton';

export const NoCarwash = () => {
  const { onExit } = useCarWash();
  return (
    <Flex className={Styles.noCarwashWrapper}>
      <Box mt="32%" textAlign="center">
        <img
          src={error_outline}
          height="40px"
          width="40px"
          alt="Error_outline"
        />
        <Text fontWeight="bold" fontSize="25px">
          {Messages.carwash_unavailable}
        </Text>
      </Box>

      <Box className={Styles.noCarwashExit}>
        <ExitButton onClick={onExit} />
      </Box>
    </Flex>
  );
};
