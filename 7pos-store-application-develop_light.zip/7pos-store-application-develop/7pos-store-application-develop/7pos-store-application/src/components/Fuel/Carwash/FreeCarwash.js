import React from 'react';
import { Flex, Box } from '@chakra-ui/react';
import { useLocation, useHistory } from 'react-router-dom';
import { useCarWash, useCart } from '../../../hooks';
import Styles from './Carwash.module.css';
import { CwPackages } from './CwPackages';
import ExitButton from '../../POS/ExitButton';
import { packages as freePacks } from './packages';

export const FreeCarwash = () => {
  const { onPackageSelect, showToast } = useCarWash();
  const location = useLocation();
  const history = useHistory();
  const { items } = useCart();
  const { selected } = location?.state || {};

  const onSelect = promoPack => {
    if (items?.length) {
      showToast({
        msg: Messages.invalid_key_transaction,
        position: 'top-left',
        duration: 3000,
      });
      return history.replace('/home');
    }
    onPackageSelect({ ...selected, reason: promoPack.reason }, true);
  };
  return (
    <Flex className={Styles.wrapper}>
      <CwPackages
        packages={freePacks}
        selectedPackage={selected}
        onPackageSelect={onSelect}
        isPromo
      />
      <Box textAlign="right" mr="10px">
        <ExitButton onClick={() => history.replace('/fuel/promocarwash')} />
      </Box>
    </Flex>
  );
};
