import React from 'react';
import { Flex, Box } from '@chakra-ui/react';

import { useCarWash } from '../../../hooks';
import Styles from './Carwash.module.css';
import { CwPackages } from './CwPackages';
import ExitButton from '../../POS/ExitButton';

export const Carwash = () => {
  const { onPackageSelect, onExit, packages } = useCarWash();
  return (
    <Flex className={Styles.wrapper}>
      <CwPackages
        packages={packages}
        onPackageSelect={cw =>
          onPackageSelect({ ...cw, reason: 'REGULAR_WASH' })
        }
      />
      <Box textAlign="right" mr="10px">
        <ExitButton onClick={onExit} />
      </Box>
    </Flex>
  );
};
