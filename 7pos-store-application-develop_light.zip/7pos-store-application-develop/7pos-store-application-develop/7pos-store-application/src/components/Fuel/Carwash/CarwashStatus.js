import { Messages } from '../../../Messages';

export const cwStatus = {
  busy: 10,
  expired: 21,
  invalid: 24,
  valid: 1,
  timeout: 10,
  used: 20,
  voided: 23,
};

export const cwStatusMapper = {
  [cwStatus.busy]: Messages.cw_controller_busy,
  [cwStatus.expired]: Messages.cw_expired_code,
  [cwStatus.invalid]: Messages.cw_invalid_code,
  [cwStatus.used]: Messages.cw_used_code,
};
