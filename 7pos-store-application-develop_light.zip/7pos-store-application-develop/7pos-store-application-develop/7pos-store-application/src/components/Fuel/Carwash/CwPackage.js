import React from 'react';
import { Text } from '@chakra-ui/react';
import Styles from './CwPackages.module.css';
import { Button } from '../../Common/Buttons';

export const CwPackage = ({ item, onSelect }) => (
  <Button
    size="lg"
    className={`btn optionButton ${Styles.cwPackage}`}
    color="rgb(255, 255, 255)"
    border="1px solid rgb(16, 127, 98)"
    width="260px"
    h="50px"
    m={3}
    onClick={() => onSelect(item)}
  >
    <Text fontFamily="Roboto-bold" fontSize="18px" fontWeight="bold">
      {`${item?.name} $${parseFloat(item?.price).toFixed(2)}`}
    </Text>
  </Button>
);
