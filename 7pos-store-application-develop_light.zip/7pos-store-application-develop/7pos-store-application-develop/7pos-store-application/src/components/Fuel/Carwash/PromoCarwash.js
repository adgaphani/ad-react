import React from 'react';
import { useSelector } from 'react-redux';
import { Flex, Box } from '@chakra-ui/react';

import { useCarWash } from '../../../hooks';
import Styles from './Carwash.module.css';
import { CwPackages } from './CwPackages';
import ExitButton from '../../POS/ExitButton';

export const PromoCarwash = () => {
  const { onExit, handlePromoCarwash } = useCarWash();
  const { packages } = useSelector(state => ({
    packages: state.fuel?.carwash?.packages,
  }));

  return (
    <Flex className={Styles.wrapper}>
      <CwPackages packages={packages} onPackageSelect={handlePromoCarwash} />
      <Box textAlign="right" mr="10px">
        <ExitButton onClick={onExit} />
      </Box>
    </Flex>
  );
};
