export const packages = [
  {
    name: 'Free Car Wash',
    status: true,
    price: 0,
    id: '1 Fw',
    reason: 'FREE_WASH',
  },
  {
    name: 'Redo Car Wash',
    status: true,
    price: 0,
    id: '2 Rw',
    reason: 'REDO_WASH',
  },
];
