import React from 'react';
import { Flex, Heading } from '@chakra-ui/react';
import Styles from './CwPackages.module.css';
import { CARWASH_TITLE } from '../../../constants';
import { CwPackage } from './CwPackage';

export const CwPackages = ({
  packages,
  onPackageSelect,
  selectedPackage = {},
  isPromo,
}) => (
  <Flex className={Styles.pContainer}>
    <Heading className={Styles.pHeader}>
      {isPromo ? `${selectedPackage.name} Car Wash` : CARWASH_TITLE}
    </Heading>
    <Flex className={isPromo ? Styles.pwBody : Styles.cwBody}>
      {packages?.map(p => (
        <Flex
          width={packages.length > 1 ? '50%' : '100%'}
          key={`${p.id} ${p.name}`}
        >
          <CwPackage item={p} onSelect={onPackageSelect} />
        </Flex>
      ))}
    </Flex>
  </Flex>
);
