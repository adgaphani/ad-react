/* eslint-disable import/order */
import { Box, Flex, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import AlphaNumericDailpad from '../../Common/DailPad/AlphaNumericDailpad/AlphaNumericDailpad';
import InputFeild from '../CFDRegistration/emailinput';
import { SendMessageToPOS } from '../../../Communication';
import { getMaskedEmail } from '../../../Utils/appUtils';
import Styles from '../CFDRegistration/Terms.module.css';
import { useLocation } from 'react-router-dom';
import Icon_conf from '../../../Icons/Icon_conf.svg';
import MemberInfo from '../CFDALTID/MemberInfo';

export default function EmailIDScreenReceipt() {
  const location = useLocation();
  const { member, isSevenRewardsDisable } = useSelector(state => ({
    member: state.cart.member,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
  }));
  const [email, setEmail] = useState('');
  const [emailError, setEmailErrors] = useState({
    isError: false,
    emailErrMsg: '',
  });
  const [isEmailSubmitted, setEmailTrigger] = useState(false);
  const [isValidEmail, setValidEmail] = useState(false);
  const [isEmailSent, setEmailSentStatus] = useState(false);
  const isEmailValid = () => {
    // eslint-disable-next-line no-useless-escape
    const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailRegex.test(email)) {
      setValidEmail(true);
      return true;
    }
    setValidEmail(false);
    return false;
  };

  const onSendEmailReceipt = () => {
    if (isEmailValid()) {
      const iTransactionMessage = {
        CMD: 'EmailReceipt',
        ReceiptOpt: 'YES',
        Email: email,
      };
      SendMessageToPOS(iTransactionMessage);
      setValidEmail(false);
      setEmailTrigger(true);
      global?.logger?.info(`[7POS UI] - User opt email receipt @CFD`);
    } else {
      setEmailErrors({
        isError: true,
        emailErrMsg: 'Incorrect email. please try again.',
      });
      global?.logger?.error(
        `[7POS UI] - Incorrect email. please try again. @CFD`
      );
    }
  };

  const onSkipEmail = () => {
    const iTransactionMessage = {
      CMD: 'EmailReceipt',
      ReceiptOpt: 'NO',
      Email: 'NORECEIPT',
    };
    SendMessageToPOS(iTransactionMessage);
    setEmailTrigger(true);
    global?.logger?.info(`[7POS UI] - User opt No Receipt  @CFD`);
  };

  const onClearInputValue = () => {
    if (isEmailSubmitted) return;
    setEmail('');
    if (emailError.isError) {
      setEmailErrors({
        isError: false,
        emailErrMsg: '',
      });
    }
  };

  const handleKeyPress = dailpadValue => {
    if (isEmailSubmitted) return;
    setEmail(dailpadValue);
    if (emailError.isError) {
      setEmailErrors({
        isError: false,
        emailErrMsg: '',
      });
    }
  };

  useEffect(() => {
    if (member && member.email && !isEmailSubmitted) {
      setEmail(member.email);
      setValidEmail(true);
    }
  }, [member]);

  useEffect(() => {
    if (!isEmailSubmitted) {
      isEmailValid();
      return () => {};
    }
  }, [email]);

  useEffect(() => {
    const iTransactionMessage = {
      CMD: 'EmailReceipt',
      ReceiptOpt: 'YES',
      Email: 'EMAILTRIGGER',
    };
    SendMessageToPOS(iTransactionMessage);
  }, []);

  useEffect(() => {
    if (location?.state?.Status === 'Success') {
      setEmailSentStatus(true);
      global?.logger?.info(`[7POS UI] - Email receipt send successfully`);
    } else if (location?.state?.Status === 'Failed') {
      setEmailTrigger(false);
      setEmail(location?.state?.Email);
      setEmailErrors({
        isError: true,
        emailErrMsg: 'Incorrect email. please try again.',
      });
      global?.logger?.error(`[7POS UI] - Email receipt send failed`);
    } else if (location?.state?.Status === 'Trigger') {
      setEmailSentStatus(false);
      setEmailTrigger(false);
      setValidEmail(false);
      if (member && member.email) {
        setEmail(member.email);
        setValidEmail(true);
      } else setEmail('');
      global?.logger?.info(`[7POS UI] - CFD Landing to Email Screen`);
    }
  }, [location?.state]);

  const iEmailMsg = 'Please Enter Your Email';

  return (
    <>
      {!isEmailSent ? (
        <>
          <Flex
            fontSize="2.81vw"
            width="100%"
            textAlign="center"
            height="61px"
            alignItems="center"
            justifyContent="center"
            fontWeight="bold"
            border-radius="0px"
            background={emailError.isError ? 'rgb(236, 37, 38)' : 'none'}
            color={
              emailError.isError ? 'rgb(255, 255, 255)' : 'rgb(44, 47, 53)'
            }
          >
            {emailError.isError ? (
              <Text>{emailError.emailErrMsg}</Text>
            ) : (
              <Text>{iEmailMsg}</Text>
            )}
          </Flex>
          <InputFeild
            Value={member ? getMaskedEmail(email) : email}
            placeHolder="EMAIL"
            errorMsgDisplay={emailError.isError}
            onClearInputValue={onClearInputValue}
          />
          <Box className={Styles.dailpadContainer} padding="2px 0px">
            <AlphaNumericDailpad
              dailpadValue={email}
              onKeyPress={handleKeyPress}
            />
          </Box>
          <Flex
            flexDirection="row"
            justifyContent="space-between"
            textAlign="center"
            height="80px"
            fontWeight="bold"
            // pb={4}
          >
            <Button
              className={Styles.skipBtn}
              onClick={onSkipEmail}
              isDisabled={isEmailSubmitted}
            >
              NO RECEIPT
            </Button>
            <Button
              className={Styles.submitBtn}
              bg={isValidEmail ? '#107f62' : '#e9e9e9'}
              color={isValidEmail ? '#ffffff' : '#5b616b'}
              onClick={onSendEmailReceipt}
              isDisabled={!!(isEmailSubmitted && !isValidEmail)}
              _hover={{ bg: 'none' }}
            >
              SUBMIT
            </Button>
          </Flex>
        </>
      ) : (
        <Box>
          {member && <MemberInfo />}
          {!isSevenRewardsDisable && (
            <>
              {!member && (
                <Flex
                  fontSize="3.3vw"
                  textAlign="center"
                  color="#2c2f35"
                  height="61px"
                  fontWeight="bold"
                  border-radius="0px"
                  flexDirection="row"
                  width="100%"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Text>Earn Points. Get Free Stuff!</Text>
                </Flex>
              )}
              <Flex
                flexDirection="column"
                justifyContent="center"
                textAlign="center"
                width="100%"
                mt="3%"
                maxH="30px"
              >
                <img
                  src={require('../../../screens/CFD/images/RedeemScreen/Stripes.png')}
                  alt=""
                />
              </Flex>
            </>
          )}
          <Flex
            flexDirection="column"
            justifyContent="center"
            textAlign="center"
            fontWeight="bold"
            mt={!isSevenRewardsDisable ? '10%' : '25%'}
            mb="2%"
            pb={4}
          >
            <Text
              font-family="Roboto-Bold"
              fontSize="3.8vw"
              fontWeight="bold"
              height="51px"
              p={1}
            >
              Receipt Successfully Sent!
            </Text>
            <Flex
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              mt="3%"
              ml="45%"
              height="60px"
              width="60px"
            >
              <img src={Icon_conf} alt="success" />
            </Flex>
            <Text
              mt="20px"
              color="rgb(16, 127, 98)"
              fontSize="2vw"
              fontWeight="bold"
              alignItems="center"
              justifyContent="center"
            >
              The receipt has been sent to
            </Text>
            <Text
              color="rgb(16, 127, 98)"
              fontSize="2vw"
              fontWeight="bold"
              alignItems="center"
              justifyContent="center"
            >
              the email address
            </Text>
          </Flex>
        </Box>
      )}
    </>
  );
}
