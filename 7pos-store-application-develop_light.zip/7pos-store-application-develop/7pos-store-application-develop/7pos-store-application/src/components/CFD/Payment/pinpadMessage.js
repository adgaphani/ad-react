/* eslint-disable react/destructuring-assignment */
import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import useInterval from '@use-it/interval';
import { imageDimensions, loadImage } from '../../../Utils/fileUtils';

function PinpadMessage(props) {
  const [imageindex, setImageIndex] = useState(0);
  const [imagelist, setImageList] = useState([]);
  const IntialTimer = 500;
  const RotationTimeout = 10000;
  const [imageRotationTimer, setImageRotationTimer] = useState(IntialTimer);
  const isSevenRewardsDisable = useSelector(
    state => state.main.isSevenRewardsDisable
  );

  const updateImageIndex = async () => {
    const imagelistArray = await loadImage(props.fbImg).catch(e => {
      global?.logger?.info(
        `[7POS UI] - Error Loading images:${JSON.stringify(e)})`
      );
    });
    if (imagelist.length !== imagelistArray.length) {
      setImageList(imagelistArray);
      global?.Logger?.debug(
        `[7POS UI] - CFD markieting Images are refreshed(Image Count:${imagelistArray.length})`
      );
    }
    const dimensions = await imageDimensions(imagelist[imageindex]);
    // Display advertisement screen timer depending on resolution
    if (dimensions.width <= 900) {
      setImageRotationTimer(RotationTimeout);
    } else {
      setImageRotationTimer(IntialTimer);
    }
    if (imageindex + 1 <= imagelistArray.length - 1) {
      setImageIndex(imageindex => imageindex + 1);
    } else {
      setImageIndex(imageindex => imageindex - imageindex);
    }
  };

  useInterval(() => {
    updateImageIndex();
  }, imageRotationTimer);

  useEffect(() => {
    loadImage(props.fbImg).then(res => {
      if (imagelist.length !== res?.length) {
        setImageList(res);
        global?.Logger?.debug(
          `[7POS UI] - CFD markieting Images are refreshed(Image Count:${res?.length})`
        );
      }
    });
  }, []);

  return (
    <Box maxH="800px">
      <Flex
        flexDirection="column"
        justifyContent="center"
        textAlign="center"
        fontWeight="bold"
        pb={4}
      >
        <Text
          mt="1%"
          fontSize="2vw"
          fontWeight="normal"
          alignItems="center"
          justifyContent="center"
          font-family="Roboto-Bold"
          as="i"
        >
          Please follow the instructions On the Pinpad to complete the
          Transaction.
        </Text>
      </Flex>
      {!isSevenRewardsDisable && (
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          width="100%"
          mt="1%"
          mb="1%"
          maxH="30px"
        >
          <img
            src={require('../../../screens/CFD/images/RedeemScreen/Stripes.png')}
            alt=""
          />
        </Flex>
      )}
      <Flex>
        <img
          src={imagelist[imageindex]}
          // background="no-repeat center center fixed"
          // background-size="cover"
          alt=""
          height="600px"
          width="100%"
        />
      </Flex>
    </Box>
  );
}

export default PinpadMessage;
