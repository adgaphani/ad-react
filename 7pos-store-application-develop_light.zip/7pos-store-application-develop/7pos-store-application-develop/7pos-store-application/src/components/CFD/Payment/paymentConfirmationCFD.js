import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { Button } from '../../Common/Buttons';
import Icon_conf from '../../../Icons/Icon_conf.svg';
import MemberInfo from '../CFDALTID/MemberInfo';
import { SendMessageToPOS } from '../../../Communication';
import { cfdActions } from '../../../slices/cfd.slice';
import { cartActions } from '../../../slices/cart.slice';
import Styles from './paymentConfirmationCFD.module.css';

function PaymentConfirmationCFD() {
  const location = useLocation();
  const dispatch = useDispatch();
  const history = useHistory();
  const {
    member,
    iLandingPage,
    isSevenRewardsDisable,
    isSpeedyStore,
  } = useSelector(state => ({
    member: state.cart.member,
    iLandingPage: state.cfd.iLandingPage,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
    isSpeedyStore: state.main.isSpeedyStore,
  }));
  console.log('isSevenRewardsDisable', isSevenRewardsDisable);

  const onEmailReceipt = () => {
    global?.logger?.info(`[7POS UI] - User opt email receipt @CFD`);
    history.push({
      pathname: '/CfdHome/EmailReceipt',
      search: '?view=viewB',
      state: location?.state,
    });
  };

  const onNoEmailReceipt = () => {
    const iTransactionMessage = {
      CMD: 'EmailReceipt',
      ReceiptOpt: 'NO',
      Email: 'NORECEIPT',
    };
    SendMessageToPOS(iTransactionMessage);
    global?.logger?.info(`[7POS UI] - User opt No Receipt  @CFD`);
  };

  useEffect(() => {
    // Redirect to Advertisement screen
    if (iLandingPage === 'AdvertisementPage') {
      dispatch(cartActions.removeMemberDetails());
      dispatch(cfdActions.ResetMemberStatus(true));
      dispatch(cfdActions.setTransactionFinalize(false));
      dispatch(cfdActions.setRegistrationScreenBtnClicked(false));
      dispatch(cfdActions.setTransactionStatus(''));
      dispatch(cfdActions.setTransactionType(''));
      history.push({
        pathname: '/',
        search: '?view=viewB',
      });
    } else if (iLandingPage === 'EmailReceiptScreen') {
      history.push({
        pathname: '/CfdHome/EmailReceipt',
        search: '?view=viewB',
        state: {
          CMD: 'EmailReceipt',
          Status: 'Trigger',
        },
      });
    }
  }, [iLandingPage]);

  return (
    <Box>
      {member && <MemberInfo />}
      {!isSevenRewardsDisable && (
        <>
          {!member && (
            <Flex
              fontSize="3.3vw"
              textAlign="center"
              color="#2c2f35"
              height="61px"
              fontWeight="bold"
              border-radius="0px"
              flexDirection="row"
              width="100%"
              alignItems="center"
              justifyContent="center"
            >
              <Text>Earn Points. Get Free Stuff!</Text>
            </Flex>
          )}
          {!isSpeedyStore && (
            <Flex
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              width="100%"
              mt="3%"
              maxH="30px"
            >
              <img
                src={require('../../../screens/CFD/images/RedeemScreen/Stripes.png')}
                alt=""
              />
            </Flex>
          )}
        </>
      )}
      <Flex
        flexDirection="column"
        justifyContent="center"
        textAlign="center"
        fontWeight="bold"
        mt={!isSevenRewardsDisable ? '10%' : '25%'}
        mb="2%"
        pb={4}
      >
        <Text
          font-family="Roboto-Bold"
          fontSize="3.8vw"
          fontWeight="bold"
          height="51px"
          p={1}
        >
          Payment confirmed!
        </Text>
        <Flex
          flexDirection="column"
          justifyContent="center"
          textAlign="center"
          mt="3%"
          ml="45%"
          height="60px"
          width="60px"
        >
          <img src={Icon_conf} alt="success" />
        </Flex>
        <Text
          mt="20px"
          color="rgb(16, 127, 98)"
          fontSize="2vw"
          fontWeight="bold"
          alignItems="center"
          justifyContent="center"
          font-family="Roboto-Bold"
        >
          Have a nice day!
        </Text>

        <Text
          mt="12%"
          fontSize="2vw"
          fontWeight="normal"
          alignItems="center"
          justifyContent="center"
          font-family="Roboto-Bold"
          as="i"
        >
          Please ask the Store Associate if you need a printed receipt
        </Text>
      </Flex>
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        textAlign="center"
        height="80px"
        fontWeight="bold"
        mt="5%"
        pb={4}
      >
        <Button onClick={onEmailReceipt} className={Styles.EmailReceipt}>
          EMAIL RECEIPT
        </Button>
        <Button
          className={[
            Styles.NoReceipt,
            isSpeedyStore ? Styles.NoReceiptSpeedy : '',
          ].join(' ')}
          bg="primary"
          color="#ffffff"
          _hover={{ bg: 'primary' }}
          onClick={onNoEmailReceipt}
        >
          NO RECEIPT
        </Button>
      </Flex>
    </Box>
  );
}

export default PaymentConfirmationCFD;
