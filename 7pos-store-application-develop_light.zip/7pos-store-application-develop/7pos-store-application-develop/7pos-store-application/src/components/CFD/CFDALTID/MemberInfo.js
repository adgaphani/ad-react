import React from 'react';
import { useSelector } from 'react-redux';
import { Flex, Text } from '@chakra-ui/react';
import Styles from './AltIDScreen.module.css';

function MemberInfo() {
  const { member, isSpeedyStore } = useSelector(state => ({
    member: state.cart.member,
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  let messageTextAlign = 'center';
  let messageFontSize = '2VW';
  let pointsStyle = Styles.altidpoints;
  let showHR = true;
  let youEarned = 'YOU';
  if (isSpeedyStore) {
    messageTextAlign = 'right';
    messageFontSize = '1.56VW';
    pointsStyle = Styles.altidpointsSpeedy;
    showHR = false;
    youEarned = `YOU'VE`;
  }

  return (
    <>
      {member && (
        <>
          {showHR && (
            <Flex
              mt="1%"
              flexDirection="column"
              justifyContent="center"
              textAlign="center"
              ml="2%"
            >
              <hr border="1px solid" color="#d3d3d3" height="1px" width="98%" />
            </Flex>
          )}
          <Flex
            flexDirection="column"
            justifyContent="center"
            textAlign={messageTextAlign}
            height="42px"
            fontWeight="bold"
            my="1.5%"
            pb={4}
            pr={5}
          >
            <Text
              fontWeight="bold"
              fontSize={messageFontSize}
              width="100%"
              height="26px"
              p={1}
            >
              {member?.iMemberStatus !== 'Unknown' ? (
                <>
                  <span className={Styles.altidmsg}>
                    WELCOME {member?.first_name?.toUpperCase()}
                    !&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span>
                  <span className={Styles.altidline}>
                    |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </span>
                  <span className={Styles.altidmsg}>{youEarned} EARNED</span>
                  <span className={pointsStyle}>
                    &nbsp;{member?.rewards_points}&nbsp;
                  </span>
                  <span className={Styles.altidmsg}>POINTS</span>
                </>
              ) : (
                <span className={Styles.altidmsg}>
                  Member Transaction !&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span>
              )}
            </Text>
          </Flex>
        </>
      )}
    </>
  );
}

export default MemberInfo;
