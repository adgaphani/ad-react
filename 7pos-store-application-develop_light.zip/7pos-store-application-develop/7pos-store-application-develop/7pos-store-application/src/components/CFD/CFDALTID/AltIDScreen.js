import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import useInterval from '@use-it/interval';
import CFDDialPad from '../../Common/DailPad/CFD/CFDDialPad';
import DisplayActionImage from '../CFDOffer/DisplayActionImage';
import InputFeild from '../inputfeild';
import MemberInfo from './MemberInfo';

import { SendMessageToPOS } from '../../../Communication';
import Styles from './AltIDScreen.module.css';
import { cfdActions } from '../../../slices/cfd.slice';
import { AppContext } from '../../../AppContext';
import { Button } from '../../Common/Buttons';
import { imageDimensions, loadImage } from '../../../Utils/fileUtils';
import {
  SEVENELEVEN_ALT_BANNER,
  SPEEDWAY_ALT_BANNER,
  SEVENREWARDS_APP_ERROR,
  SPEEDWAYREWARDS_APP_ERROR,
} from '../../../constants';

function AltIDScreen({ fbImg }) {
  const dispatch = useDispatch();
  const location = useLocation();
  const {
    member,
    isTransactionFinalize,
    isMemberReset,
    Country,
    RegistrationScreenBtnClicked,
    PhoneNumberValidationFailed,
    AltIDEntryIntiate,
    isSpeedyStore,
    isSevenRewardsDisable,
  } = useSelector(state => ({
    member: state.cart.member,
    isTransactionFinalize: state.cfd.isTransactionFinalize,
    isMemberReset: state.cfd.isMemberReset,
    Country: state.cfd.Country,
    RegistrationScreenBtnClicked: state.cfd.RegistrationScreenBtnClicked,
    PhoneNumberValidationFailed: state.cfd.PhoneNumberValidationFailed,
    AltIDEntryIntiate: state.cfd.AltIDEntryIntiate,
    isSpeedyStore: state.main.isSpeedyStore,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
  }));
  const [ContinueBtnState, setBtnState] = useState(true);
  const [Formrequest, setFormState] = useState(false);
  const [value, setValue] = useState({ AltID: '' });
  const [errorMsgDisplay, setErrorMsgStatus] = useState(false);
  const [ClearMemOfflineMsg, setClearMemOfflineMsg] = useState(false);
  const [imageindex, setImageIndex] = useState(0);
  const [imagelist, setImageList] = useState([]);
  const { keyPressSound } = useContext(AppContext);
  const IntialTimer = 500;
  const RotationTimeout = 10000;
  const [imageRotationTimer, setImageRotationTimer] = useState(IntialTimer);

  // Speedway testings
  const bannerMsg = isSpeedyStore
    ? SPEEDWAY_ALT_BANNER
    : SEVENELEVEN_ALT_BANNER;
  const appError = isSpeedyStore
    ? SPEEDWAYREWARDS_APP_ERROR
    : SEVENREWARDS_APP_ERROR;
  const onUpdateFieldValue = cVal => {
    if (!Formrequest) {
      setValue({
        ...value,
        AltID: cVal,
      });
    } else if (isMemberReset) {
      setValue({
        ...value,
        AltID: '',
      });
    }
    if (errorMsgDisplay) {
      setErrorMsgStatus(false);
    }
  };

  useEffect(() => {
    if (isMemberReset) {
      setFormState(false);
      onUpdateFieldValue('');
      dispatch(cfdActions.ResetMemberStatus(false));
      dispatch(cfdActions.setAltIDUserTrigger(false));
      setClearMemOfflineMsg(false);
      global?.logger?.info(`[7POS UI] - Clear AltID entry screen`);
    } else if (!Formrequest) {
      const enableContinue = isSpeedyStore
        ? value?.AltID?.length >= 11
        : value?.AltID?.length >= 14;
      if (enableContinue) {
        setBtnState(false);
      } else {
        setBtnState(true);
      }
      if (!AltIDEntryIntiate && value?.AltID?.length === 1) {
        const iTransactionMessage = {
          CMD: 'AltIDEntryIntiated',
        };
        SendMessageToPOS(iTransactionMessage);
        dispatch(cfdActions.setAltIDUserTrigger(true));
      } else if (AltIDEntryIntiate && value?.AltID?.length === 0) {
        const iTransactionMessage = {
          CMD: 'AltIDEntryReset',
        };
        SendMessageToPOS(iTransactionMessage);
        dispatch(cfdActions.setAltIDUserTrigger(false));
      }
    }
    if (PhoneNumberValidationFailed) {
      const iAltID = `${location?.state?.AltID}`;
      if (iAltID.length === 10) {
        const iFormattedAltID = `(${iAltID?.slice(0, 3)}) ${iAltID?.slice(
          3,
          6
        )}-${iAltID?.slice(6, 10)}`;
        global?.logger?.info(`[7POS UI] - Formatted AltID`);
        onUpdateFieldValue(iFormattedAltID);
      }
      setErrorMsgStatus(true);
      dispatch(cfdActions.setPhoneNumberValidationFailedStatus(false));
    }
  });

  useEffect(() => {
    let isTimer = null;
    if (member?.iMemberStatus === 'Unknown' && !ClearMemOfflineMsg) {
      isTimer = setTimeout(() => {
        setClearMemOfflineMsg(true);
        global?.logger?.info(`[7POS UI] - Clear offline Member message @CFD`);
      }, 5000);
    }
    return () => {
      if (isTimer) clearTimeout(isTimer);
    };
  }, [member]);

  const updateImageIndex = async () => {
    const imagelistArray = await loadImage(fbImg).catch(e => {
      global?.logger?.info(
        `[7POS UI] - Error Loading images:${JSON.stringify(e)})`
      );
    });
    if (imagelist.length !== imagelistArray.length) {
      setImageList(imagelistArray);
      global?.Logger?.debug(
        `[7POS UI] - CFD markieting Images are refreshed(Image Count:${imagelistArray.length})`
      );
    }
    const dimensions = await imageDimensions(imagelist[imageindex]);
    // Display advertisement screen timer depending on resolution
    if (dimensions.width <= 900) {
      setImageRotationTimer(RotationTimeout);
    } else {
      setImageRotationTimer(IntialTimer);
    }
    if (imageindex + 1 <= imagelistArray.length - 1) {
      setImageIndex(imageindex => imageindex + 1);
    } else {
      setImageIndex(imageindex => imageindex - imageindex);
    }
  };

  useInterval(() => {
    updateImageIndex();
  }, imageRotationTimer);

  useEffect(() => {
    loadImage(fbImg)
      .then(res => {
        if (imagelist.length !== res?.length) {
          setImageList(res);
          global?.Logger?.debug(
            `[7POS UI] - CFD markieting Images are refreshed(Image Count:${res?.length})`
          );
        }
      })
      .catch(() => {});
  }, []);

  const onClearInputValue = () => {
    setValue({
      ...value,
      AltID: '',
    });
    setErrorMsgStatus(false);
  };

  const handleChange = (e, prop) => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    setValue({
      ...value,
      [prop]: e.target.value,
    });
  };
  const handleSubmit = async e => {
    e.stopPropagation();
    e.preventDefault();
    const iphonenumber = value.AltID;
    const phonenumber = iphonenumber.replace(/[^\d]/g, '');
    if (!phonenumber) return;
    if (!isSpeedyStore && phonenumber.toString().length < 10) {
      return;
    }
    if (isSpeedyStore && phonenumber.toString().length < 7) return;
    setBtnState(true);
    setFormState(true);
    dispatch(cfdActions.ResetMemberStatus(false));
    global?.logger?.info(`[7POS UI] - Send AltID to POS`);
    try {
      const iTransactionMessage = {
        CMD: 'AltID',
        ALTID: phonenumber,
        ...(isSpeedyStore ? { queryParams: { idType: 'ALT_ID' } } : {}),
      };
      SendMessageToPOS(iTransactionMessage);
    } catch (error) {
      console.error(error);
    }
  };

  const OfflineNotification = () => {
    setClearMemOfflineMsg(true);
  };
  const iMemberOfflineMsg =
    'As soon as system is back online your award will<br />be immediately applied!';

  return (
    <Box maxH="800px" maxW="900px">
      {member && !RegistrationScreenBtnClicked && !isSevenRewardsDisable ? (
        <>
          {member?.iMemberStatus === 'Unknown' && !ClearMemOfflineMsg ? (
            <>
              {!isSpeedyStore && (
                <Flex
                  my="1%"
                  fontSize="3.3vw"
                  textAlign="center"
                  color="#2c2f35"
                  height="61px"
                  fontWeight="bold"
                  border-radius="0px"
                  flexDirection="row"
                  width="100%"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Text>Earn Points. Get Free Stuff!</Text>
                </Flex>
              )}
              <Flex
                mt={isSpeedyStore ? '6%' : '1%'}
                fontSize="2.2vw"
                width="100%"
                height="50px"
                textAlign="center"
                color="#ffffff"
                backgroundColor="rgb(237, 28, 36)"
                alignItems="center"
                justifyContent="center"
                fontWeight="bold"
                border-radius="0px"
              >
                <Text>{appError}</Text>
              </Flex>
              <Flex
                alignItems="center"
                justifyContent="center"
                flexDirection="column"
                mt="15%"
              >
                <Text
                  fontSize="24px"
                  fontWeight="bold"
                  textAlign="center"
                  padding="3px"
                  font-family="Roboto-Bold"
                >
                  We have run into a little problem
                </Text>
                <Text
                  className={Styles.OfflineMsg}
                  dangerouslySetInnerHTML={{ __html: iMemberOfflineMsg }}
                />
                <Button
                  alignSelf="center"
                  onClick={OfflineNotification}
                  width="90px"
                  height="40px"
                  mt={15}
                  bg="primary"
                  color="#ffffff"
                  _hover={{ bg: 'primary' }}
                >
                  <Text
                    fontSize="18px"
                    fontFamily="Roboto-Bold"
                    fontWeight="bold"
                  >
                    OK
                  </Text>
                </Button>
              </Flex>
            </>
          ) : (
            <Box>
              <MemberInfo />
              {Country === 'US' ? (
                <>
                  {member.rewards_points > 800 ? (
                    isSpeedyStore ? (
                      <div style={{ height: '630px' }}>
                        <DisplayActionImage
                          ImageName={require('../../../screens/CFD/images/WelcomeScreen/WelcomeMsg-speedway.png')}
                        />
                      </div>
                    ) : (
                      <DisplayActionImage
                        ImageName={require('../../../screens/CFD/images/WelcomeScreen/WelcomeMsg-USAx1200.png')}
                      />
                    )
                  ) : isSpeedyStore ? (
                    <DisplayActionImage
                      ImageName={require('../../../screens/CFD/images/WelcomeScreen/SpeedwayWelcome.png')}
                    />
                  ) : (
                    <DisplayActionImage
                      ImageName={require('../../../screens/CFD/images/WelcomeScreen/WelcomeMsg-USAx800.png')}
                    />
                  )}
                </>
              ) : (
                <>
                  {member.rewards_points > 800 ? (
                    <DisplayActionImage
                      ImageName={require('../../../screens/CFD/images/WelcomeScreen/WelcomeMsg-CAx1200.png')}
                    />
                  ) : (
                    <DisplayActionImage
                      ImageName={require('../../../screens/CFD/images/WelcomeScreen/WelcomeMsg-CAx800.png')}
                    />
                  )}
                </>
              )}
            </Box>
          )}
        </>
      ) : !member &&
        !isTransactionFinalize &&
        !RegistrationScreenBtnClicked &&
        !isSevenRewardsDisable ? (
        // eslint-disable-next-line react/jsx-indent
        <form onSubmit={e => handleSubmit(e)} width="100%">
          <Box>
            {!errorMsgDisplay && !isSevenRewardsDisable && (
              <>
                {!isSpeedyStore && (
                  <Flex
                    my="1%"
                    fontSize="3.3vw"
                    textAlign="center"
                    color="#2c2f35"
                    height="61px"
                    fontWeight="bold"
                    border-radius="0px"
                    flexDirection="row"
                    width="100%"
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Text>Earn Points. Get Free Stuff!</Text>
                    {/* <Text></Text> */}
                  </Flex>
                )}
                <Flex
                  mt={isSpeedyStore ? '6%' : '1%'}
                  fontSize="2.2vw"
                  width="100%"
                  height="50px"
                  textAlign="center"
                  color="#ffffff"
                  backgroundColor={
                    isSpeedyStore ? '#0065B6' : 'rgb(51, 194, 140)'
                  }
                  alignItems="center"
                  justifyContent="center"
                  fontWeight="bold"
                  border-radius="0px"
                >
                  <Text>{bannerMsg}</Text>
                </Flex>
              </>
            )}
            {errorMsgDisplay && (
              <Flex
                mt="3%"
                mb="3%"
                fontSize="2.2vw"
                width="100%"
                textAlign="center"
                height="70px"
                alignItems="center"
                justifyContent="center"
                fontWeight="bold"
                border-radius="0px"
                background="rgb(236, 37, 38)"
                color="rgb(255, 255, 255)"
              >
                <Text>
                  Sorry! Registration did not complete. <br />
                  Please enter a valid Mobile Phone Number.
                </Text>
              </Flex>
            )}
            <InputFeild
              onClick={handleChange}
              Value={value.AltID}
              placeHolder="MOBILE NUMBER"
              errorMsgDisplay={errorMsgDisplay}
              onClearInputValue={onClearInputValue}
              feildname="AltID"
            />
            <CFDDialPad
              currentValue={value.AltID}
              clearField={() => setValue('')}
              onUpdateValue={onUpdateFieldValue}
              isAltIDEntry
            />
            <Button
              className={Styles.ContinueBtn}
              type="submit"
              value="Submit"
              bg={!ContinueBtnState ? 'primary' : '#e9e9e9'}
              color={!ContinueBtnState ? 'btn.text.default' : '#5b616b'}
              isDisabled={ContinueBtnState}
            >
              CONTINUE
            </Button>
          </Box>
        </form>
      ) : RegistrationScreenBtnClicked && !isSevenRewardsDisable ? (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/Registration/nextbtnclick.png')}
          />
        </Box>
      ) : (
        <Flex>
          <img
            src={imagelist[imageindex]}
            // background="no-repeat center center fixed"
            // background-size="cover"
            alt=""
            height="799px"
            width="900px"
          />
        </Flex>
      )}
    </Box>
  );
}

export default AltIDScreen;
