import React, { useRef, useState, useEffect } from 'react';
import { Box, Flex, Button, Text } from '@chakra-ui/react';
import { useSelector, useDispatch } from 'react-redux';
import SignatureCanvas from 'react-signature-canvas';
import Styles from './CFDSignatureCapture.module.css';
import { SendMessageToPOS } from '../../../Communication';
import { cfdActions } from '../../../slices/cfd.slice';

const CFDSignatureCapture = () => {
  const sigPad = useRef({});
  const [submitBtnState, setSubmitBtnState] = useState(true);
  const { clearSign, member } = useSelector(state => ({
    clearSign: state.cfd.clearSign,
    member: state.cart.member,
  }));
  const dispatch = useDispatch();

  // function clears the sign pad
  const clearSigpad = () => {
    if (!submitBtnState) return;
    sigPad.current.clear();
  };

  // Captured Signature Data
  const trimSigpad = () => {
    if (sigPad.current?.isEmpty()) return;
    if (!submitBtnState) return;
    setSubmitBtnState(false);
    try {
      const trimmmedSign = sigPad.current
        .getTrimmedCanvas()
        .toDataURL('image/png');
      SendMessageToPOS({
        CMD: 'SignatureCapture',
        imgUrl: trimmmedSign,
      });
    } catch (error) {
      console.error(error);
    }
  };

  // cancel and go to payment confirmation
  const handleCancel = () => {
    if (!submitBtnState) return;
    SendMessageToPOS({
      CMD: 'CancelSignature',
    });
  };

  // This trigger on Re sign click from POS
  useEffect(() => {
    if (!clearSign) return;
    sigPad.current.clear();
    dispatch(cfdActions.setClearSign(false));
    setSubmitBtnState(true);
    return () => {};
  }, [clearSign]);

  return (
    <Box>
      <>
        <Flex className={Styles.header}>
          <Text>Earn Points. Get Free Stuff!</Text>
        </Flex>
        <Flex className={Styles.banner}>
          <Text>Please sign to complete transaction</Text>
        </Flex>
      </>
      <>
        <Box m="1%" borderBottom="1px solid rgb(211, 211, 211)">
          <Box textAlign="center" border="1px solid rgb(211, 211, 211)">
            <Text my="2rem" className={Styles.cSigText}>
              CUSTOMER SIGNATURE
            </Text>
            <SignatureCanvas
              canvasProps={{
                height: !member ? '440px' : '375px',
                width: '820px',
              }}
              className={Styles.canvas}
              penColor="black"
              ref={sigPad}
            />
          </Box>
        </Box>
      </>
      <Flex className={Styles.btnWrap}>
        <Button
          className={Styles.cancelBtn}
          color="#5b616b"
          _hover={{ bg: 'none' }}
          onClick={handleCancel}
        >
          CANCEL
        </Button>
        <Button
          className={Styles.cancelBtn}
          color="#5b616b"
          _hover={{ bg: 'none' }}
          onClick={clearSigpad}
        >
          CLEAR
        </Button>
        <Button
          className={Styles.submitBtn}
          onClick={trimSigpad}
          bg={!submitBtnState ? '#107f62' : '#e9e9e9'}
          color="#ffffff"
          isDisabled={!submitBtnState}
        >
          SUBMIT
        </Button>
      </Flex>
    </Box>
  );
};

export default CFDSignatureCapture;
