import React, { useEffect, useState } from 'react';
import { Flex, Text } from '@chakra-ui/react';
import { useLocation, useHistory } from 'react-router-dom';
import { Button } from '../../Common/Buttons';
import Styles from './CFDPrepaidLoadConfrimation.module.css';
import { SendMessageToPOS } from '../../../Communication';

const CFDPrepaidLoadConfirmation = () => {
  const history = useHistory();
  const location = useLocation();
  const [ContinueBtnState, setBtnState] = useState(false);
  const loadAmount = location?.state?.loadedAmount;
  const loadAccountNumber = location?.state?.loadAccountNumber;
  const cancelLoadFromPos = location?.state?.cancelLoadFromPos || false;
  const cardLookUpReceived = location?.state?.cardLookUpReceived || false;

  const [iDisplayText, setDisplayText] = useState('');
  const [isAccountConfirmation, setAccountConfirmation] = useState(false);

  const onYesClick = () => {
    if (isAccountConfirmation) {
      setAccountConfirmation(false);
      setDisplayText(`Prepaid amount entered is ${loadAmount}`);
      return;
    }
    setBtnState(true);
    global?.logger?.info(`[7POS UI] - Send Load Confirm to POS`);
    try {
      SendMessageToPOS({
        CMD: 'PrepaidLoadConfirm',
        status: true,
      });
    } catch (error) {
      console.error(error);
    }
  };
  const onNoClick = () => {
    global?.logger?.info(`[7POS UI] - Send Load Cancel to POS`);
    SendMessageToPOS({
      CMD: 'PrepaidLoadConfirm',
      status: false,
      cancelLoad: true,
    });
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
  };

  useEffect(() => {
    if (cancelLoadFromPos || cardLookUpReceived) {
      setBtnState(false);
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    }
    return () => {};
  }, [cancelLoadFromPos, cardLookUpReceived]);

  useEffect(() => {
    if (loadAccountNumber) {
      setAccountConfirmation(true);
      setDisplayText(`You entered ID is ${loadAccountNumber}`);
    } else {
      setDisplayText(`Prepaid amount entered is ${loadAmount}`);
    }
  }, [loadAccountNumber]);

  return (
    <>
      <Flex direction="column" height="calc(100% - 100px)" padding="0 1em">
        <Flex direction="column" height="100%" justifyContent="center">
          <Text
            color="rgb(65, 67, 73)"
            fontFamily="Roboto-Bold"
            fontSize="28px"
            fontWeight="bold"
            textAlign="center"
          >
            {iDisplayText}
          </Text>
          <Text
            color="rgb(65, 67, 73)"
            fontFamily="Roboto-Bold"
            fontSize="28px"
            fontWeight="bold"
            textAlign="center"
          >
            Do you want to continue?
          </Text>
        </Flex>
        <Flex direction="row">
          <Button
            className={Styles.YesBtn}
            bg={!ContinueBtnState ? '#107f62' : '#e9e9e9'}
            color={!ContinueBtnState ? '#ffffff' : '#5b616b'}
            _hover={{ bg: 'none' }}
            isDisabled={ContinueBtnState}
            onClick={onYesClick}
          >
            <Text>YES</Text>
          </Button>
          <Button
            className={Styles.NoBtn}
            bg={!ContinueBtnState ? '#107f62' : '#e9e9e9'}
            color={!ContinueBtnState ? '#ffffff' : '#5b616b'}
            _hover={{ bg: 'none' }}
            isDisabled={ContinueBtnState}
            onClick={onNoClick}
          >
            <Text>CANCEL</Text>
          </Button>
        </Flex>
      </Flex>
    </>
  );
};

export default CFDPrepaidLoadConfirmation;
