import React, { useEffect, useState, useRef } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { Flex, Text, Box } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import InputFeild from '../inputfeild';
import CFDDialPad from '../../Common/DailPad/CFD/CFDDialPad';
import Styles from './CFDPrepaidAccNumberScreen.module.css';
import { SendMessageToPOS } from '../../../Communication';

const MAX_TRY_COUNT = 3;

const CFDPrepaidAccNumberScreen = () => {
  const [accNumber, setAccNumber] = useState('');
  const [errorMsgDisplay, setErrorMsgStatus] = useState(false);
  const [ContinueBtnState, setBtnState] = useState(true);
  const maxTryCountRef = useRef();

  const history = useHistory();
  const location = useLocation();

  const handleChange = e => {
    setAccNumber(e.target.value);
  };

  const onUpdateFieldValue = cVal => {
    // #7909 added validation length check
    const { customerIdLength } = location?.state || {};
    if (cVal?.length <= customerIdLength) setAccNumber(cVal);
  };

  const handleSubmit = e => {
    e.stopPropagation();
    e.preventDefault();
    const { customerIdLength } = location?.state || {};
    if (!accNumber) {
      setErrorMsgStatus(true);
    }
    if (
      customerIdLength &&
      String(accNumber).length !== Number(customerIdLength)
    ) {
      if (maxTryCountRef.current === MAX_TRY_COUNT) {
        const iTransactionMessage = {
          CMD: 'MaxTryReached',
          value: maxTryCountRef.current,
        };
        SendMessageToPOS(iTransactionMessage);
        history.push({
          pathname: '/CfdHome',
          search: '?view=viewB',
        });
        return;
      }
      maxTryCountRef.current = maxTryCountRef.current
        ? maxTryCountRef.current + 1
        : 1;

      setErrorMsgStatus(true);
      return;
    }
    const iTransactionMessage = {
      CMD: 'PrepaidAccNumberValue',
      value: accNumber,
    };
    SendMessageToPOS(iTransactionMessage);
    history.push({
      pathname: '/CfdHome/PrepaidLoadConfirm',
      search: '?view=viewB',
      state: {
        loadedAmount: location.state?.loadedAmount,
        loadAccountNumber: accNumber,
      },
    });
  };
  const onClearInputValue = () => {
    setAccNumber('');
    setErrorMsgStatus(false);
  };
  useEffect(() => {
    if (accNumber.length >= 1) {
      setBtnState(false);
    } else {
      setBtnState(true);
    }
  }, [accNumber]);
  return (
    <form onSubmit={e => handleSubmit(e)} width="100%">
      <Box>
        {!errorMsgDisplay && (
          <Flex flexDirection="column">
            <Flex
              my="1%"
              fontSize="3.3vw"
              textAlign="center"
              color="#2c2f35"
              height="61px"
              fontWeight="bold"
              border-radius="0px"
              flexDirection="row"
              width="100%"
              alignItems="center"
              justifyContent="center"
            >
              <Text>Earn Points. Get Free Stuff!</Text>
            </Flex>
            <Flex
              mt="1%"
              fontSize="2.2vw"
              width="100%"
              height="50px"
              textAlign="center"
              color="#ffffff"
              backgroundColor="rgb(51, 194, 140)"
              alignItems="center"
              justifyContent="center"
              fontWeight="bold"
              border-radius="0px"
            >
              <Text>Account number / Mobile Number</Text>
            </Flex>
          </Flex>
        )}
        {errorMsgDisplay && (
          <Flex
            mt="3%"
            mb="3%"
            fontSize="2.2vw"
            width="100%"
            textAlign="center"
            height="70px"
            alignItems="center"
            justifyContent="center"
            fontWeight="bold"
            border-radius="0px"
            background="rgb(236, 37, 38)"
            color="rgb(255, 255, 255)"
          >
            <Text>Incorrect input!</Text>
          </Flex>
        )}
        <InputFeild
          onClick={handleChange}
          Value={accNumber}
          placeHolder="Account Number / Mobile Number"
          errorMsgDisplay={errorMsgDisplay}
          onClearInputValue={onClearInputValue}
        />
        <CFDDialPad
          currentValue={accNumber}
          clearField={onClearInputValue}
          onUpdateValue={onUpdateFieldValue}
          pattern
        />
        <Button
          className={Styles.ContinueBtn}
          type="submit"
          value="Submit"
          bg={!ContinueBtnState ? '#107f62' : '#e9e9e9'}
          color={!ContinueBtnState ? '#ffffff' : '#5b616b'}
          _hover={{ bg: 'none' }}
        >
          CONTINUE
        </Button>
      </Box>
    </form>
  );
};

export default CFDPrepaidAccNumberScreen;
