import { Input, InputGroup, InputRightElement } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import React from 'react';
import { Button } from '../../Common/Buttons';
import Styles from '../CFDALTID/AltIDScreen.module.css';

const emailinputfeild = props => {
  const { Value, placeHolder, errorMsgDisplay, onClearInputValue } = props;
  return (
    <InputGroup>
      <Input
        ml="5%"
        mr="5%"
        my="2%"
        height="85px"
        width="90%"
        alignSelf="center"
        autoComplete="off"
        textAlign="center"
        fontSize="3.7vw"
        fontWeight="bold"
        type="text"
        value={Value}
        placeholder={placeHolder}
        borderColor={errorMsgDisplay ? '#ec2526' : '#d3d3d3'}
        isReadOnly
        color="#3a3d46"
      />
      {errorMsgDisplay && (
        <InputRightElement my="5vh" mr="5vw">
          <Button
            background="rgb(255, 255, 255)"
            fontSize="2.2vw"
            onClick={onClearInputValue}
            className={Styles.clearbtn}
            _hover={{ bg: 'none' }}
          >
            X
          </Button>
        </InputRightElement>
      )}
    </InputGroup>
  );
};

emailinputfeild.defaultProps = {
  Value: '',
  placeHolder: '',
  errorMsgDisplay: '',
  onClearInputValue: '',
};

emailinputfeild.propTypes = {
  Value: PropTypes.string,
  placeHolder: PropTypes.string,
  errorMsgDisplay: PropTypes.func,
  onClearInputValue: PropTypes.func,
};

export default emailinputfeild;
