import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Button } from '../../Common/Buttons';

import { SendMessageToPOS } from '../../../Communication';
import Styles from './Terms.module.css';
import { caTerms } from './NewJoinT&C_CA';
import { cfdActions } from '../../../slices/cfd.slice';
import { usTerms } from './NewJoinT&C_US';

export default function TermsAndConditions() {
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();
  const {
    Country,
    AltIDEntryIntiate,
    member,
    iTermsAndConditions,
    isSpeedyStore,
  } = useSelector(state => ({
    Country: state.cfd.Country,
    AltIDEntryIntiate: state.cfd.AltIDEntryIntiate,
    member: state.cart.member,
    iTermsAndConditions: state.cfd.iTermsAndConditions,
    isSpeedyStore: state.main.isSpeedyStore,
  }));
  const terms =
    iTermsAndConditions.length > 0
      ? iTermsAndConditions
      : Country === 'US'
      ? usTerms
      : caTerms;

  const [UpdateMemberTrigger, setUpdateMemberTrigger] = useState(false);

  const onAltIDScreen = () => {
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
    if (AltIDEntryIntiate) {
      const iTransactionMessage = {
        CMD: 'AltIDEntryReset',
      };
      SendMessageToPOS(iTransactionMessage);
      dispatch(cfdActions.setAltIDUserTrigger(false));
    }
    global?.logger?.info(
      `[7POS UI] - CFD redirect to AltID screen from Terms and Condition screen`
    );
  };

  const onNextTimeScreen = () => {
    dispatch(cfdActions.setRegistrationScreenBtnClicked(true));
    history.push({
      pathname: '/CfdHome',
      search: '?view=viewB',
    });
    if (AltIDEntryIntiate) {
      const iTransactionMessage = {
        CMD: 'AltIDEntryReset',
      };
      SendMessageToPOS(iTransactionMessage);
      dispatch(cfdActions.setAltIDUserTrigger(false));
    }
    global?.logger?.info(
      `[7POS UI] - CFD redirect to AltID next timescreen from Terms and Condition screen`
    );
  };

  const DisplayEmailID = () => {
    if ((member && !member.email) || !member) {
      history.push({
        pathname: '/CfdHome/Email',
        search: '?view=viewB',
        state: location?.state,
      });
    } else if (!isSpeedyStore) {
      setUpdateMemberTrigger(true);
      const iTransactionMessage = {
        CMD: member ? 'UpdateMember' : 'AddMember',
        EMAIL: '',
        AltID: location?.state?.AltID,
        Country,
        loyaltyId: member ? member.loyalty_id : '',
        terms_id: location?.state?.termsid,
        privacy_id: location?.state?.privacyid,
      };
      SendMessageToPOS(iTransactionMessage);
      dispatch(cfdActions.setRegistrationScreenBtnClicked(true));
    }
    global?.logger?.info(
      `[7POS UI] - CFD redirect to Email ID creen from Terms and Condition screen`
    );
  };

  return (
    <>
      <Flex
        fontSize="3.28vw"
        width="100%"
        textAlign="center"
        color="#2c2f35"
        height="61px"
        alignItems="center"
        justifyContent="center"
        fontWeight="bold"
        border-radius="0px"
        fontFamily="Roboto-Bold"
      >
        {!member ? (
          <Text>Join Now to Earn and Redeem!</Text>
        ) : (
          <Text>Continue to Earn and Redeem!</Text>
        )}
      </Flex>
      <Box className={Styles.termsContainer}>
        <Box className={Styles.terms}>
          <Text
            fontWeight="bold"
            fontSize="1.56vw"
            mb={5}
            fontFamily="Roboto-Bold"
          >
            Terms and Conditions
          </Text>
          <Text fontSize="1.56vw" dangerouslySetInnerHTML={{ __html: terms }} />
        </Box>
      </Box>
      <Button
        className={Styles.agreeBtn}
        background="buttons.primary.background"
        color="buttons.primary.color"
        _hover={{ bg: 'buttons.primary.background' }}
        _active={{ bg: 'buttons.primary.background' }}
        onClick={DisplayEmailID}
        isDisabled={!!UpdateMemberTrigger}
      >
        {!member ? 'AGREE AND JOIN' : 'ACCEPT UPDATED T&C'}
      </Button>
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        textAlign="center"
        height="80px"
        fontWeight="bold"
        mt="2%"
        pb={4}
      >
        <Button
          className={Styles.skipBtn}
          onClick={onAltIDScreen}
          isDisabled={!!member}
        >
          BACK
        </Button>
        <Button
          className={Styles.skipBtn}
          onClick={onNextTimeScreen}
          isDisabled={!!UpdateMemberTrigger}
        >
          NEXT TIME
        </Button>
      </Flex>
    </>
  );
}
