/* eslint-disable import/order */

import { Box, Flex, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import AlphaNumericDailpad from '../../Common/DailPad/AlphaNumericDailpad/AlphaNumericDailpad';
import InputFeild from './emailinput';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './Terms.module.css';
import { cfdActions } from '../../../slices/cfd.slice';
import { useLocation } from 'react-router-dom';

export default function EmailIDScreen() {
  const { Country, member } = useSelector(state => ({
    Country: state.cfd.Country,
    member: state.cart.member,
  }));
  const location = useLocation();
  const dispatch = useDispatch();

  const [email, setEmail] = useState('');
  const [emailError, setEmailErrors] = useState({
    isError: false,
    emailErrMsg: '',
  });

  const [isAddMemberSubmitted, setMemberTrigger] = useState(false);
  const [isValidEmail, setValidEmail] = useState(false);
  const isEmailValid = () => {
    // eslint-disable-next-line no-useless-escape
    const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (emailRegex.test(email)) {
      setValidEmail(true);
      return true;
    }
    setValidEmail(false);
    return false;
  };

  const onRegistration = () => {
    if (isEmailValid()) {
      const iTransactionMessage = {
        CMD: member ? 'UpdateMember' : 'AddMember',
        EMAIL: email,
        AltID: location?.state?.AltID,
        Country,
        loyaltyId: member ? member.loyalty_id : '',
        terms_id: location?.state?.termsid,
        privacy_id: location?.state?.privacyid,
      };
      SendMessageToPOS(iTransactionMessage);
      dispatch(cfdActions.setRegistrationScreenBtnClicked(true));
      setValidEmail(false);
      setMemberTrigger(true);
      global?.logger?.info(`[7POS UI] - Member registration triggered`);
    } else {
      global?.logger?.error(`[7POS UI] - entered invalid email ID`);
      setEmailErrors({
        isError: true,
        emailErrMsg: 'Incorrect email. Please try again.',
      });
    }
  };

  const onSkipEmail = () => {
    const iTransactionMessage = {
      CMD: member ? 'UpdateMember' : 'AddMember',
      EMAIL: '',
      AltID: location?.state?.AltID,
      Country,
      loyaltyId: member ? member.loyalty_id : '',
      terms_id: location?.state?.termsid,
      privacy_id: location?.state?.privacyid,
    };
    SendMessageToPOS(iTransactionMessage);
    setMemberTrigger(true);
    dispatch(cfdActions.setRegistrationScreenBtnClicked(true));
    global?.logger?.info(
      `[7POS UI] - Member registration triggered(user skipped email)`
    );
  };

  const onClearInputValue = () => {
    setEmail('');
    if (emailError.isError) {
      setEmailErrors({
        isError: false,
        emailErrMsg: '',
      });
    }
  };

  const handleKeyPress = dailpadValue => {
    setEmail(dailpadValue);
    if (emailError.isError) {
      setEmailErrors({
        isError: false,
        emailErrMsg: '',
      });
    }
  };

  useEffect(() => {
    if (!isAddMemberSubmitted) {
      isEmailValid();
      return () => {};
    }
  }, [email]);

  const iUSAEmailMsg = 'Please Enter Your Email To Join Our A-List';

  const iCanadaMsg =
    'By entering your email address and clicking SUBMIT you will be' +
    '<br />' +
    'automatically signed up to receive promotional information from 7-Eleven&#0174;';

  return (
    <>
      <Flex
        fontSize={
          emailError.isError ? '2.18vw' : Country === 'US' ? '2.81vw' : '1.56vw'
        }
        width="100%"
        textAlign="center"
        height="61px"
        alignItems="center"
        justifyContent="center"
        fontWeight="bold"
        border-radius="0px"
        background={emailError.isError ? 'rgb(236, 37, 38)' : 'none'}
        color={emailError.isError ? 'rgb(255, 255, 255)' : 'rgb(44, 47, 53)'}
        mt="3px"
      >
        {emailError.isError ? (
          <Text>{emailError.emailErrMsg}</Text>
        ) : Country === 'US' ? (
          <Text>{iUSAEmailMsg}</Text>
        ) : (
          <Text dangerouslySetInnerHTML={{ __html: iCanadaMsg }} />
        )}
      </Flex>
      <InputFeild
        Value={email}
        placeHolder="EMAIL"
        errorMsgDisplay={emailError.isError}
        onClearInputValue={onClearInputValue}
      />
      <Box className={Styles.dailpadContainer} padding="2px 0px">
        <AlphaNumericDailpad dailpadValue={email} onKeyPress={handleKeyPress} />
      </Box>
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        textAlign="center"
        height="80px"
        fontWeight="bold"
        // pb={4}
      >
        <Button
          className={Styles.skipBtn}
          onClick={onSkipEmail}
          isDisabled={isAddMemberSubmitted}
        >
          SKIP
        </Button>
        <Button
          className={Styles.submitBtn}
          bg={isValidEmail ? 'primary' : '#e9e9e9'}
          color={isValidEmail ? 'btn.text.default' : '#5b616b'}
          onClick={onRegistration}
          isDisabled={!!(isAddMemberSubmitted && !isValidEmail)}
          _hover={{ bg: 'none' }}
        >
          SUBMIT
        </Button>
      </Flex>
    </>
  );
}
