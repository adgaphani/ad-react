import React, { useEffect, useState } from 'react';
import { Box } from '@chakra-ui/react';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import DisplayActionImage from '../CFDOffer/DisplayActionImage';

function MemberStatusScreen() {
  const imgPath = {
    speedySuccess: require('../../../screens/CFD/images/Registration/thanks-for-joining-transaction.png'),
    sevenElevenSuccess: require('../../../screens/CFD/images/Registration/USASuccess.png'),
    sevenElevenTC: require('../../../screens/CFD/images/Registration/UpdateT&C-USA.png'),
    sevenElevenCASuccess: require('../../../screens/CFD/images/Registration/CASuccess.png'),
    sevenElevenCATC: require('../../../screens/CFD/images/Registration/UpdateT&C-CA.png'),
    speedyFailure: require('../../../screens/CFD/images/speedwayImages/speedyRedeemError.png'),
    sevenElevenFailure: require('../../../screens/CFD/images/Registration/CAFailure.png'),
    sevenElevenCAFailure: require('../../../screens/CFD/images/Registration/USAFailure.png'),
    sevenElevenEmailErr: require('../../../screens/CFD/images/Registration/EmailErrorImg.png'),
  };
  const location = useLocation();

  const [AddMemberStatus, setAddmemberStatus] = useState(0);

  const { Country, isSpeedyStore } = useSelector(state => ({
    Country: state.cfd.Country,
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  useEffect(() => {
    global?.logger?.info(
      `[7POS UI] - Member registration status screen(${location?.state?.Status})`
    );
    if (
      location?.state?.Status === 'ADDED' ||
      location?.state?.Status === 'Updated'
    ) {
      setAddmemberStatus(0);
    } else if (
      location?.state?.Status === 'Failed' ||
      location?.state?.Status === 'UpdateFailed'
    ) {
      setAddmemberStatus(1);
    } else if (location?.state?.Status === 'EmailFailed') {
      setAddmemberStatus(2);
    }
  }, [location?.state]);

  return (
    <Box>
      {AddMemberStatus === 0 ? (
        Country === 'US' ? (
          location?.state?.Status === 'ADDED' ? (
            isSpeedyStore ? (
              <DisplayActionImage ImageName={imgPath.speedySuccess} />
            ) : (
              <DisplayActionImage ImageName={imgPath.sevenElevenSuccess} />
            )
          ) : (
            <DisplayActionImage ImageName={imgPath.sevenElevenTC} />
          )
        ) : location?.state?.Status === 'ADDED' ? (
          <DisplayActionImage ImageName={imgPath.sevenElevenCASuccess} />
        ) : (
          <DisplayActionImage ImageName={imgPath.sevenElevenCATC} />
        )
      ) : AddMemberStatus === 1 ? (
        Country === 'US' ? (
          isSpeedyStore ? (
            <DisplayActionImage ImageName={imgPath.speedyFailure} />
          ) : (
            <DisplayActionImage ImageName={imgPath.sevenElevenFailure} />
          )
        ) : isSpeedyStore ? (
          <DisplayActionImage ImageName={imgPath.speedyFailure} />
        ) : (
          <DisplayActionImage ImageName={imgPath.sevenElevenCAFailure} />
        )
      ) : isSpeedyStore ? (
        <DisplayActionImage ImageName={imgPath.speedyFailure} />
      ) : (
        <DisplayActionImage ImageName={imgPath.sevenElevenEmailErr} />
      )}
    </Box>
  );
}

export default MemberStatusScreen;
