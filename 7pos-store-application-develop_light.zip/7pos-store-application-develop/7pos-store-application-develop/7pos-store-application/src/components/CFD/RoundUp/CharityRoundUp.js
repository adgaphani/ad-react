import { Box, Button, Flex, Text } from '@chakra-ui/react';
import React, { useState, useEffect, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import DisplayActionImage from '../CFDOffer/DisplayActionImage';
import MemberInfo from '../CFDALTID/MemberInfo';
import NonMemberInfo from './NonMemberHeader';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './CharityRoundUp.module.css';

function RoundUpCharity() {
  const location = useLocation();
  const [isUserBtnClick, setUserBtnAction] = useState(0);

  const DollarAmount = parseFloat(location?.state?.Amount / 100).toFixed(2);
  const ImageUrl = location?.state?.ImageURL; // `file://C:\\7POS\\7POSApp\\Images\\Charity\\RoundUpCharity.png`;

  const { member, isSpeedyStore } = useSelector(state => ({
    member: state.cart.member,
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  const onNotToday = () => {
    setUserBtnAction(1);
    const iTransactionMessage = {
      CMD: 'AcceptRoundUp',
      RoundUpOpt: 'NO',
    };
    SendMessageToPOS(iTransactionMessage);
  };

  const onUserOptRoundUp = () => {
    setUserBtnAction(2);
    const iTransactionMessage = {
      CMD: 'AcceptRoundUp',
      RoundUpOpt: 'YES',
    };
    SendMessageToPOS(iTransactionMessage);
  };

  useEffect(() => {
    const status = location?.state?.status || '';
    if (status === 'Canceled') setUserBtnAction(1);
  }, [location?.state]);

  const getImages = useCallback(() => {
    if (isUserBtnClick === 2) {
      return (
        <DisplayActionImage
          ImageName={
            isSpeedyStore
              ? require('../../../screens/CFD/images/RoundUp/speedy_roundup.png')
              : require('../../../screens/CFD/images/RoundUp/DonateRoundUp.png')
          }
        />
      );
    }
    if (isSpeedyStore) {
      return (
        <>
          <Flex
            flexDirection="column"
            justifyContent="center"
            textAlign="center"
            height="100%"
            width="100%"
            ml="0%"
            mt="1%"
          >
            <Text
              alignContent="center"
              fontWeight="bold"
              fontSize="45px"
              marginBottom={10}
            >
              {Messages.speedy_rc_next_time}
            </Text>
            <Text alignContent="center" fontSize="36px" padding="0px 100px">
              {Messages.speedy_rc_declined}
            </Text>
          </Flex>
        </>
      );
    }
    return (
      <DisplayActionImage
        ImageName={require('../../../screens/CFD/images/RoundUp/NextTimeRoundUp.png')}
      />
    );
  }, [isSpeedyStore, isUserBtnClick]);

  return (
    <Box height="90%">
      {isUserBtnClick === 0 ? (
        <>
          {member && (
            <>
              <MemberInfo />
              <Flex
                flexDirection="column"
                justifyContent="center"
                textAlign="center"
                width="100%"
                mt="3%"
                maxH="30px"
              >
                <img
                  src={require('../../../screens/CFD/images/RedeemScreen/Stripes.png')}
                  alt=""
                />
              </Flex>
            </>
          )}
          {!member && (
            <>
              <NonMemberInfo />
              <Flex
                mt="1%"
                fontSize="2.2vw"
                width="100%"
                height="50px"
                textAlign="center"
                color="#ffffff"
                backgroundColor="rgb(80, 36, 92)"
                alignItems="center"
                justifyContent="center"
                fontWeight="bold"
                border-radius="0px"
              >
                <Text>
                  Join {isSpeedyStore ? 'Speedway' : '7Rewards'} to Earn and
                  Redeem Points
                </Text>
              </Flex>
            </>
          )}
          <Flex mt="0.5%">
            <img
              src={ImageUrl}
              // background="no-repeat center center fixed"
              // background-size="cover"
              alt=""
              height="500px"
              width="900px"
            />
          </Flex>
          <Flex
            flexDirection="row"
            justifyContent="space-between"
            textAlign="center"
            height="80px"
            fontWeight="bold"
            mt="1%"
            mb="1%"
            pb={4}
          >
            <Button onClick={onNotToday} className={Styles.NotTodayBtn}>
              NOT TODAY
            </Button>
            <Button
              className={Styles.DonateBtn}
              bg="primary"
              color="#ffffff"
              _hover={{ bg: '#107f62' }}
              onClick={onUserOptRoundUp}
            >
              DONATE ${DollarAmount}
            </Button>
          </Flex>
        </>
      ) : (
        getImages()
      )}
    </Box>
  );
}

export default RoundUpCharity;
