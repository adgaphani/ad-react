/* eslint-disable import/order */

import { Flex, Text } from '@chakra-ui/react';

import React from 'react';
import Styles from '../CFDALTID/AltIDScreen.module.css';

function NonMemberInfo() {
  return (
    <>
      <Flex
        mt="1%"
        flexDirection="column"
        justifyContent="center"
        textAlign="center"
        ml="2%"
      >
        <hr border="1px solid" color="#d3d3d3" height="1px" width="98%" />
      </Flex>
      <Flex
        flexDirection="column"
        justifyContent="center"
        textAlign="center"
        height="42px"
        fontWeight="bold"
        my="1.5%"
        pb={4}
      >
        <Text fontWeight="bold" fontSize="2vw" width="100%" height="26px" p={1}>
          <span className={Styles.nonaltidmsg}>
            EARN POINTS!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </span>
          <span className={Styles.altidline}>
            |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </span>
          <span className={Styles.nonaltidmsg}>GET FREE STUFF!</span>
        </Text>
      </Flex>
    </>
  );
}

export default NonMemberInfo;
