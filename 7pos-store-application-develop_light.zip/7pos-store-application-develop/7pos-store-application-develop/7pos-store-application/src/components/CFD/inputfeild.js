import { Input, InputGroup, InputRightElement } from '@chakra-ui/react';
import PropTypes from 'prop-types';
import React from 'react';
import { Button } from '../Common/Buttons';
import Styles from './CFDALTID/AltIDScreen.module.css';

const inputfeild = props => {
  const {
    onClick,
    Value,
    placeHolder,
    errorMsgDisplay,
    onClearInputValue,
    feildname,
    type = 'text',
  } = props;

  return (
    <InputGroup>
      <Input
        ml="8%"
        mr="8%"
        my="3%"
        height="85px"
        width="84%"
        alignSelf="center"
        autoComplete="off"
        textAlign="center"
        fontSize="3.7vw"
        fontWeight="bold"
        type={type}
        onChange={e => onClick(e, feildname)}
        value={Value}
        placeholder={placeHolder}
        borderColor={errorMsgDisplay ? '#ec2526' : '#d3d3d3'}
        isReadOnly
        color="#3a3d46"
      />
      {errorMsgDisplay && (
        <InputRightElement my="6vh" mr="10vw">
          <Button
            background="rgb(255, 255, 255)"
            fontSize="2.2vw"
            onClick={onClearInputValue}
            className={Styles.clearbtn}
            _hover={{ bg: 'none' }}
          >
            X
          </Button>
        </InputRightElement>
      )}
    </InputGroup>
  );
};

inputfeild.defaultProps = {
  onClick: '',
  Value: '',
  placeHolder: '',
  errorMsgDisplay: false,
  onClearInputValue: '',
  feildname: '',
};

inputfeild.propTypes = {
  onClick: PropTypes.func,
  Value: PropTypes.string,
  placeHolder: PropTypes.string,
  errorMsgDisplay: PropTypes.bool,
  onClearInputValue: PropTypes.func,
  feildname: PropTypes.string,
};

export default inputfeild;
