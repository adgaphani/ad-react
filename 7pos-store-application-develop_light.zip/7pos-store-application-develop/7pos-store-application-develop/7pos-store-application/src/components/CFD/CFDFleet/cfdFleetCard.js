import React, { useEffect, useState, useRef } from 'react';
import { Box, Flex, Text } from '@chakra-ui/react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { Button } from '../../Common/Buttons';
import InputFeild from '../inputfeild';
import CFDDialPad from '../../Common/DailPad/CFD/CFDDialPad';
import { cfdActions } from '../../../slices/cfd.slice';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './cfdFleetCard.module.css';
// import { camelCase } from '../../Utils/appUtils';

const messagesMap = {
  DRIVER_NUMBER: {
    message: 'Please Enter Driver Number',
    placeholder: 'DRIVER NUMBER',
    fieldName: 'driverNumber',
  },
  FLEET_NUMBER: {
    message: 'Please Enter Fleet Number',
    placeholder: 'FLEET NUMBER',
    fieldName: 'fleetNumber',
  },
  MOBILE_NUMBER: {
    message: 'Please Enter Mobile Number',
    placeholder: 'MOBILE NUMBER',
    fieldName: 'mobileNumber',
  },
  VEHICLE_ID: {
    message: 'Please Enter Vehicle Id',
    placeholder: 'VEHICLE ID',
    fieldName: 'vehicleId',
  },
  ODOMETER_VALUE: {
    message: 'Please Enter Odometer Value',
    placeholder: 'ODOMETER VALUE',
    fieldName: 'odometerValue',
  },
  JOB_NUMBER: {
    message: 'Please Enter Job Number',
    placeholder: 'JOB NUMBER',
    fieldName: 'jobNumber',
  },
  FLEET_ID: {
    message: 'Please Enter Fleet Id',
    placeholder: 'FLEET ID',
    fieldName: 'fleetId',
  },
  DATA: {
    message: 'Please Enter Data',
    placeholder: 'DATA',
    fieldName: 'data',
  },
  DEPARTMENT: {
    message: 'Please Enter Department',
    placeholder: 'DEPARTMENT',
    fieldName: 'department',
  },
};

const CFDFleetCard = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useHistory();
  const params = new URLSearchParams(location.search);
  const { fleetPrompts, reason = '' } = location?.state || {};
  const promptList = fleetPrompts
    .replace(/[[|\]]/gm, '')
    .split(',')
    .map(i => i.trim());

  let promptIndex = params.get('prompt')
    ? promptList.indexOf(params.get('prompt'))
    : 0;
  promptIndex = promptIndex < 0 ? 0 : promptIndex;
  const {
    isMemberReset,
    PhoneNumberValidationFailed,
    isSevenRewardsDisable,
  } = useSelector(state => ({
    isMemberReset: state.cfd.isMemberReset,
    PhoneNumberValidationFailed: state.cfd.PhoneNumberValidationFailed,
    isSevenRewardsDisable: state.main.isSevenRewardsDisable,
  }));
  const [prompt, setPrompt] = useState(
    () => messagesMap[promptList[promptIndex]]
  );
  const promptValueRef = useRef({});

  const [errorMsgDisplay, setErrorMsgStatus] = useState(false);
  const [ContinueBtnState, setBtnState] = useState(true);
  const [Formrequest, setFormState] = useState(false);
  const setErrorReason = useState(reason)[1];
  const [value, setValue] = useState({
    [prompt.fieldName]: '',
  });

  const handleChange = (e, prop) => {
    setValue({
      ...value,
      [prop]: e.target.value,
    });
  };

  const onClearInputValue = () => {
    setValue({
      ...value,
      [prompt.fieldName]: '',
    });
    setErrorMsgStatus(false);
  };
  const handleSubmit = async e => {
    e.stopPropagation();
    e.preventDefault();
    promptValueRef.current = {
      ...promptValueRef.current,
      [prompt.fieldName]: value[prompt.fieldName],
    };
    if (Object.keys(promptValueRef.current).length === promptList.length) {
      const iTransactionMessage = {
        CMD: 'FleetCardPromptsValue',
        promptValues: promptValueRef.current,
      };
      SendMessageToPOS(iTransactionMessage);
      history.push({
        pathname: '/CfdHome',
        search: '?view=viewB',
      });
    } else if (promptList[promptIndex + 1]) {
      history.push({
        pathname: '/CfdHome/FleetCard',
        search: `?view=viewB&prompt=${promptList[promptIndex + 1]}`,
        state: location?.state,
      });
    }
  };

  const onUpdateFieldValue = cVal => {
    if (!Formrequest) {
      setValue({
        ...value,
        [prompt.fieldName]: cVal,
      });
    } else if (isMemberReset) {
      setValue({
        ...value,
        [prompt.fieldName]: '',
      });
    }
    if (errorMsgDisplay) {
      setErrorMsgStatus(false);
    }
  };

  useEffect(() => {
    if ([prompt.fieldName].length >= 1) {
      setBtnState(false);
    } else {
      setBtnState(true);
    }
    if (PhoneNumberValidationFailed) {
      const iAltID = location?.state?.AltID;
      onUpdateFieldValue(iAltID);
      setErrorMsgStatus(true);
      dispatch(cfdActions.setPhoneNumberValidationFailedStatus(false));
    }
    return () => {};
  }, [PhoneNumberValidationFailed]);

  useEffect(() => {
    const newPrompt = messagesMap[promptList[promptIndex]];
    if (!newPrompt) return;
    setPrompt({ ...newPrompt });
    setValue({ [newPrompt.fieldName]: '' });
    setFormState(false);
    SendMessageToPOS({
      CMD: 'FleetPrompt',
      prompt: { ...newPrompt, error: '' },
    });
    return () => {};
  }, [promptIndex]);

  useEffect(() => {
    if (reason) {
      global?.logger?.error(`[7POS UI] - Fleet prompt failed:${reason}`);
      setErrorReason(reason);
      setErrorMsgStatus(true);
      SendMessageToPOS({
        CMD: 'FleetPrompt',
        prompt: { error: reason },
      });
    }
  }, [reason]);

  return (
    <form onSubmit={e => handleSubmit(e)} width="100%">
      <Box>
        {!errorMsgDisplay && (
          <>
            {!isSevenRewardsDisable && (
              <Flex
                my="1%"
                fontSize="3.3vw"
                textAlign="center"
                color="#2c2f35"
                height="61px"
                fontWeight="bold"
                border-radius="0px"
                flexDirection="row"
                width="100%"
                alignItems="center"
                justifyContent="center"
              >
                <Text>Earn Points. Get Free Stuff!</Text>
              </Flex>
            )}
            <Flex
              mt={!isSevenRewardsDisable ? '1%' : '10%'}
              fontSize="2.2vw"
              width="100%"
              height="50px"
              textAlign="center"
              color="#ffffff"
              backgroundColor="rgb(51, 194, 140)"
              alignItems="center"
              justifyContent="center"
              fontWeight="bold"
              border-radius="0px"
            >
              <Text>{prompt.message}</Text>
            </Flex>
          </>
        )}
        {errorMsgDisplay && (
          <Flex
            mt="3%"
            mb="3%"
            fontSize="2.2vw"
            width="100%"
            textAlign="center"
            height="70px"
            alignItems="center"
            justifyContent="center"
            fontWeight="bold"
            border-radius="0px"
            background="rgb(236, 37, 38)"
            color="rgb(255, 255, 255)"
          >
            <Text>Incorrect input!</Text>
          </Flex>
        )}
        <InputFeild
          onClick={handleChange}
          Value={value[prompt.fieldName]}
          placeHolder={prompt.placeholder}
          errorMsgDisplay={errorMsgDisplay}
          onClearInputValue={onClearInputValue}
          fieldName={prompt.fieldName}
        />
        <CFDDialPad
          currentValue={value[prompt.fieldName]}
          clearField={onClearInputValue}
          onUpdateValue={onUpdateFieldValue}
          pattern
        />
        <Button
          className={Styles.ContinueBtn}
          type="submit"
          value="Submit"
          bg={!ContinueBtnState ? '#107f62' : '#e9e9e9'}
          color={!ContinueBtnState ? '#ffffff' : '#5b616b'}
          _hover={{ bg: 'none' }}
        >
          CONTINUE
        </Button>
      </Box>
    </form>
  );
};

export default CFDFleetCard;
