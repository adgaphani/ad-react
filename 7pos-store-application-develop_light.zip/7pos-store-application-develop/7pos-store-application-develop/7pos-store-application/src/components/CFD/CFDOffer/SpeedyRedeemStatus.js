import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import RedemptionSuccessFuelSPW from '../../../screens/CFD/images/RedeemScreen/RedemptionSuccessFuelSPW.png';
import RedemptionSuccessSpeedway from '../../../screens/CFD/images/RedeemScreen/RedemptionSuccessSpeedway.png';
import MemberInfo from '../CFDALTID/MemberInfo';
import DisplayActionImage from './DisplayActionImage';

const pwdImage = require(`../../../screens/CFD/images/speedwayImages/speedRedeemPwdError.png`);
// TODO: Add Speedway Image once received from Product
const declinedImage = require(`../../../screens/CFD/images/RedeemScreen/PayFullPrice-Speedway.png`);
const networkError = require(`../../../screens/CFD/images/speedwayImages/speedyRedeemError.png`);

function SpeedyRedeemStatus() {
  const location = useLocation();
  const history = useHistory();

  const {
    ItemRedemptionAmount,
    isSpeedyStore,
    bestFuelReward,
    processPaymentAsMCLoyalty,
  } = useSelector(state => ({
    ItemRedemptionAmount: state.cfd.ItemRedemptionAmount,
    bestFuelReward: state.cfd.bestFuelReward,
    isSpeedyStore: state.main.isSpeedyStore,
    processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
  }));
  useEffect(() => {
    if (
      location?.state?.Status === 'Success' &&
      !bestFuelReward &&
      ItemRedemptionAmount &&
      ItemRedemptionAmount <= 0 &&
      !processPaymentAsMCLoyalty
    ) {
      history.push({ pathname: '/CFDHome', search: '?view=viewB' });
    }
  }, []);

  let redeemImage;
  if (location?.state?.isPassCodeIncorrect) {
    redeemImage = pwdImage;
  } else if (location?.state?.Status === 'No_Reward') {
    redeemImage = declinedImage;
  } else {
    redeemImage = networkError;
  }
  if (location?.state?.Status === 'Success') {
    if (isSpeedyStore && bestFuelReward) {
      return (
        <Box>
          <DisplayActionImage ImageName={RedemptionSuccessFuelSPW} />
        </Box>
      );
    }
    return (
      <Box>
        <DisplayActionImage ImageName={RedemptionSuccessSpeedway} />
        <Flex
          flexDirection="coulmn"
          justifyContent="center"
          textAlign="center"
          height="100%"
          width="100%"
          mt="-80%"
        >
          <Text mt="34%" fontSize="4.68vw" fontWeight="bold" color="white">
            ${ItemRedemptionAmount}
          </Text>
        </Flex>
      </Box>
    );
  }
  return (
    <Box>
      <MemberInfo />
      <DisplayActionImage ImageName={redeemImage} />
    </Box>
  );
}

export default SpeedyRedeemStatus;
