import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import DisplayActionImage from './DisplayActionImage';

function RedemptionStatusScreen() {
  const location = useLocation();
  const [RedemptionStatus, setRedemptionStatus] = useState(false);

  const {
    ItemRedemptionAmount,
    Country,
    processPaymentAsMCLoyalty,
  } = useSelector(state => ({
    ItemRedemptionAmount: state.cfd.ItemRedemptionAmount,
    Country: state.cfd.Country,
    processPaymentAsMCLoyalty: state.cart.processPaymentAsMCLoyalty,
  }));

  useEffect(() => {
    if (location?.state?.Status === 'Success') {
      global?.logger?.info(
        `[7POS UI] - Redeem/SWP success screen - ${ItemRedemptionAmount}`
      );
      setRedemptionStatus(true);
    } else {
      global?.logger?.info(`[7POS UI] - Redeem/SWP failed screen`);
      setRedemptionStatus(false);
    }
  });
  useEffect(() => {
    if (
      location?.state?.Status === 'Success' &&
      ItemRedemptionAmount &&
      ItemRedemptionAmount <= 0 &&
      !processPaymentAsMCLoyalty
    ) {
      history.push({ pathname: '/CFDHome', search: '?view=viewB' });
    }
  }, []);

  return (
    <>
      {RedemptionStatus ? (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/RedeemScreen/RedemptionSuccess.png')}
          />
          <Flex
            flexDirection="coulmn"
            justifyContent="center"
            textAlign="center"
            height="100%"
            width="100%"
            mt="-80%"
          >
            <Text mt="34%" fontSize="4.68vw" fontWeight="bold" color="white">
              ${ItemRedemptionAmount}
            </Text>
          </Flex>
        </Box>
      ) : Country === 'US' ? (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/RedeemScreen/RedemtionFailure.png')}
          />
        </Box>
      ) : (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/RedeemScreen/CanadaRedemptionFailure.png')}
          />
        </Box>
      )}
    </>
  );
}

export default RedemptionStatusScreen;
