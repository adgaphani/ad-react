import { Box, Flex, Text } from '@chakra-ui/react';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory, useLocation } from 'react-router-dom';
import { Button } from '../../Common/Buttons';

import DisplayActionImage from './DisplayActionImage';
import MemberInfo from '../CFDALTID/MemberInfo';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './CFDOffer.module.css';
import { cfdActions } from '../../../slices/cfd.slice';
import { SWItemRedemption } from './SWItemRedemption';
import PayfullSpeedwayImg from '../../../screens/CFD/images/RedeemScreen/PayFullPrice-Speedway.png';

function ItemRedemption() {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();

  const [Points, setPoints] = useState(0);
  const [RedeemItemDescription, setItemDescription] = useState('');
  const [ImageUrl, setImageUrl] = useState('');
  const [isPayFullPriceFlag, setPayFullPriceFlag] = useState(false);
  const [DollarAmount, setBtnAmount] = useState('');
  const [BTNNAME, setBtnName] = useState('');

  const {
    member,
    Country,
    isItemRedemptionIntiated,
    isSWPIntiated,
    isSpeedyStore,
  } = useSelector(state => ({
    member: state.cart.member,
    Country: state.cfd.Country,
    isItemRedemptionIntiated: state.cfd.isItemRedemptionIntiated,
    isSWPIntiated: state.cfd.isSWPIntiated,
    isSpeedyStore: state.main.isSpeedyStore,
  }));

  const onPayFullPrice = () => {
    setPayFullPriceFlag(true);
    const iTransactionMessage = {
      CMD: 'AcceptReward',
      RewardOpt: 'NO',
    };
    SendMessageToPOS(iTransactionMessage);
    dispatch(cfdActions.IntiatedItemRedemption(false));
    dispatch(cfdActions.IntiatedSWP(false));
    global?.logger?.info(`[7POS UI] - User didnt opt itemRedeem/SWP`);
  };
  // const { AuthCode, catalogId } = location?.state || {};
  const DisplayPostOrZipCode = (id, type) => {
    if (isSpeedyStore && type === 'fuel') {
      dispatch(cfdActions.setBestFuelRewardStatus(true));
    } else {
      dispatch(cfdActions.setBestFuelRewardStatus(undefined));
    }
    const { AuthCode, catalogId } = location?.state || {};
    if (Country === 'US') {
      global?.logger?.info(`[7POS UI] - CFD redirect to zipcode screen`);
      history.push({
        pathname: '/CfdHome/ZipCodeScreen',
        search: '?view=viewB',
        state: {
          AuthCode,
          catalogId,
          authCode: AuthCode,
          ...(isSpeedyStore
            ? {
                selectedReward: id,
                reward_type: type,
              }
            : {}),
        },
      });
    } else {
      global?.logger?.info(`[7POS UI] - CFD redirect to postal code screen`);
      history.push({
        pathname: '/CfdHome/PostalCodeScreen',
        search: '?view=viewB',
        state: {
          AuthCode,
          catalogId,
        },
      });
    }
  };

  useEffect(() => {
    if (isItemRedemptionIntiated) {
      setPoints(location?.state?.PointsForItemRedeem);
      setItemDescription(location?.state?.ItemName);
      setBtnAmount(location?.state?.Amount);
      if (location?.state?.ImageURL) {
        setImageUrl(location?.state?.ImageURL);
      }
      setPayFullPriceFlag(false);
      setBtnName('PAY FULL PRICE');
      dispatch(cfdActions.setItemRedemptionAmount(location?.state?.Amount));
      global?.logger?.info(`[7POS UI] - CFD redirect to Item Redeem screen`);
    }
    return () => {};
  }, [isItemRedemptionIntiated]);

  useEffect(() => {
    if (isSWPIntiated) {
      setPoints(location?.state?.PointsForItemRedeem);
      setBtnAmount(location?.state?.Amount);
      setPayFullPriceFlag(false);
      setBtnName('NO THANKS');
      dispatch(cfdActions.setItemRedemptionAmount(location?.state?.Amount));
      global?.logger?.info(`[7POS UI] - CFD redirect to SWP screen`);
    }
    return () => {};
  }, [isSWPIntiated]);
  if (isSpeedyStore && member && !isPayFullPriceFlag) {
    return (
      <>
        <MemberInfo />
        <SWItemRedemption
          rewards={{
            best_reward: location.state?.meta?.best_reward,
            best_fuel_reward: location.state?.meta?.best_fuel_reward,
          }}
          onOfferCancel={onPayFullPrice}
          onOfferConfirm={DisplayPostOrZipCode}
        />
        ;
      </>
    );
  }

  return (
    <>
      {member && (
        <Box>
          <MemberInfo />
          {!isPayFullPriceFlag ? (
            <>
              <Flex
                flexDirection="column"
                justifyContent="center"
                textAlign="center"
                width="100%"
                mt="3%"
                maxH="30px"
              >
                <img
                  src={require('../../../screens/CFD/images/RedeemScreen/Stripes.png')}
                  alt=""
                />
              </Flex>
              {isItemRedemptionIntiated && (
                <>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="51px"
                    fontWeight="bold"
                    mt="4%"
                    pb={4}
                  >
                    <Text
                      color="#4a245f"
                      font-family="Helvetica-Bold"
                      fontSize="3.8vw"
                      fontWeight="bold"
                      height="51px"
                      p={1}
                    >
                      GET THIS ITEM FREE
                    </Text>
                  </Flex>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="40px"
                    fontWeight="bold"
                    mt="1%"
                    pb={4}
                  >
                    <Text
                      color="#008060"
                      font-family="Helvetica-Bold"
                      fontSize="2.6vw"
                      fontWeight="bold"
                      height="40px"
                      p={1}
                    >
                      USE {Points} POINTS TO REDEEM
                    </Text>
                  </Flex>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    maxW="200px"
                    mt="5%"
                    maxH="180px"
                    ml="40%"
                  >
                    <img src={ImageUrl} alt="" />
                  </Flex>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="23px"
                    fontWeight="bold"
                    mt="4%"
                    pb={4}
                  >
                    <Text
                      color="#4a245f"
                      font-family="TrasandinaBold"
                      fontSize="1.56vw"
                      fontWeight="bold"
                      height="23px"
                      p={1}
                    >
                      {RedeemItemDescription}
                    </Text>
                  </Flex>
                </>
              )}
              {isSWPIntiated && (
                <>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="51px"
                    fontWeight="bold"
                    mt="13%"
                    pb={4}
                  >
                    <Text
                      color="#168a6b"
                      font-family="Roboto-Bold"
                      fontSize="4.68vw"
                      fontWeight="bold"
                      height="60px"
                      p={1}
                      letterSpacing="-0.05px"
                    >
                      WANT TO GET ${DollarAmount} OFF
                    </Text>
                  </Flex>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="51px"
                    fontWeight="bold"
                    mt="2%"
                    pb={4}
                  >
                    <Text
                      color="#168a6b"
                      font-family="Roboto-Bold"
                      fontSize="4.68vw"
                      fontWeight="bold"
                      height="60px"
                      p={1}
                      letterSpacing="-0.05px"
                    >
                      YOUR PURCHASE ?
                    </Text>
                  </Flex>
                  <Flex
                    flexDirection="column"
                    justifyContent="center"
                    textAlign="center"
                    height="40px"
                    fontWeight="bold"
                    mt="5%"
                    pb={4}
                  >
                    <Text
                      color="#5b616b"
                      font-family="Roboto-Bold"
                      fontSize="3.12vw"
                      fontWeight="bold"
                      height="47px"
                      letterSpacing="-0.44px"
                      p={1}
                    >
                      REDEEM {Points} POINTS AND SAVE {DollarAmount}
                    </Text>
                  </Flex>
                </>
              )}
              <Flex
                flexDirection="row"
                justifyContent="space-between"
                textAlign="center"
                height="80px"
                fontWeight="bold"
                mt={isSWPIntiated ? '10%' : '6%'}
                pb={4}
              >
                <Button onClick={onPayFullPrice} className={Styles.PayFullBtn}>
                  {BTNNAME}
                </Button>
                <Button
                  className={Styles.SaveBtn}
                  bg="#107f62"
                  color="#ffffff"
                  _hover={{ bg: '#107f62' }}
                  onClick={DisplayPostOrZipCode}
                >
                  SAVE ${DollarAmount}
                </Button>
              </Flex>
            </>
          ) : (
            <>
              {isSpeedyStore ? (
                <DisplayActionImage ImageName={PayfullSpeedwayImg} />
              ) : Country === 'US' ? (
                <DisplayActionImage
                  ImageName={require('../../../screens/CFD/images/RedeemScreen/PayFullPrice-USA.png')}
                />
              ) : (
                <DisplayActionImage
                  ImageName={require('../../../screens/CFD/images/RedeemScreen/PayFullPrice-Canada.png')}
                />
              )}
            </>
          )}
        </Box>
      )}
    </>
  );
}

export default ItemRedemption;
