import { Flex, Image } from '@chakra-ui/react';

import React from 'react';

function DisplayActionImage(props) {
  const { ImageName } = props;
  return (
    <Flex
      flexDirection="column"
      justifyContent="center"
      textAlign="center"
      height="100%"
      width="100%"
      ml="0%"
      mt="1%"
    >
      <Image src={ImageName} width="100%" height="100%" />
    </Flex>
  );
}

export default DisplayActionImage;
