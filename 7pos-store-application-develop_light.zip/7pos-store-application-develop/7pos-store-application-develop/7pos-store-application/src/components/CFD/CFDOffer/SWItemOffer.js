import React from 'react';
import { Flex, Text, Image, Box } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons/Button';

export const SWItemOffer = ({
  reward = {},
  multpleRewards,
  onOfferCancel,
  onOfferConfirm,
}) => (
  <Flex
    justifyContent="space-between"
    flexDirection="column"
    m={2}
    minWidth="45%"
    maxWidth="100%"
    width="100%"
  >
    <Flex
      textAlign="center"
      boxShadow="0px 5px 7px grey"
      borderRadius="11px"
      height="40%"
      justifyContent="center"
      alignItems="center"
    >
      <Image
        height="170px"
        width="184px"
        src={reward?.image_thumb}
        alt="sevenElevenLogo"
      />
    </Flex>
    <Flex
      background="primary"
      flexDirection="column"
      alignItems="center"
      padding={10}
      height="60%"
      borderRadius="11px"
    >
      <Box textAlign="center" width="100%">
        <Text
          fontSize="1.5rem"
          color="default.posWhite"
          fontWeight={700}
          mb="30px"
        >
          {' '}
          {reward?.title}
        </Text>
        <Text color="default.posWhite" mb="30px">
          {' '}
          {reward?.long_description}
        </Text>
      </Box>
      <Flex
        justifyContent="center"
        width="100%"
        marginBottom="5%"
        marginTop="auto"
      >
        {!multpleRewards && (
          <Button
            color="default.posWhite"
            background="primary"
            variant="outline"
            width="30%"
            onClick={onOfferCancel}
          >
            NO THANKS
          </Button>
        )}
        <Button
          ml={!multpleRewards ? 10 : 0}
          background="buttons.primary.background"
          color="buttons.primary.color"
          width={!multpleRewards ? '30%' : '70%'}
          onClick={() => onOfferConfirm(reward?.id, reward?.REWARD_TYPE)}
        >
          REDEEM REWARD
        </Button>
      </Flex>
    </Flex>
  </Flex>
);
