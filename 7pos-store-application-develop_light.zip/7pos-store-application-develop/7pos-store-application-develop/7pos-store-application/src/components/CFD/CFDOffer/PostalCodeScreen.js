import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { Box, Flex, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons';
import DisplayActionImage from './DisplayActionImage';
import InputFeild from '../inputfeild';
import MemberInfo from '../CFDALTID/MemberInfo';
import PostalDialPad from '../../Common/DailPad/CFD/PostalDialPad';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './CFDOffer.module.css';
import { cfdActions } from '../../../slices/cfd.slice';

function PostalCodeScreen() {
  const location = useLocation();
  const dispatch = useDispatch();
  const IntialPostalcodeMsg =
    'For verification, enter Postal Code attached to your account.';

  const [value, setValue] = useState({ PostalCode: '' });
  const [PostalCodeMsg, setPostalCodeMsg] = useState(IntialPostalcodeMsg);
  const [isPostalCodeErr, setPostalCodeErr] = useState(false);
  const [isPostalcodeSubmitted, setPostalcodeSubmittionStatus] = useState(
    false
  );
  const [ContinueBtnState, setContinueBtnState] = useState(true);
  const [isPayFullPriceFlag, setPayFullPriceFlag] = useState(false);
  const [iPostalcodeRetryCount, setPostalcodeRetryCount] = useState(0);
  const [BTNNAME, setBtnName] = useState('');

  const {
    member,
    isItemRedemptionIntiated,
    isSWPIntiated,
    config,
  } = useSelector(state => ({
    member: state.cart.member,
    isItemRedemptionIntiated: state.cfd.isItemRedemptionIntiated,
    isSWPIntiated: state.cfd.isSWPIntiated,
    config: state.main.configuration,
  }));
  const iRetryCount = Number(config?.storeConfig?.ZipCodeRetryLimit) || 3;

  useEffect(() => {
    if (isItemRedemptionIntiated || isSWPIntiated) {
      setContinueBtnState(true);
      setPostalCodeMsg(IntialPostalcodeMsg);
      setPostalcodeRetryCount(0);
      setPostalcodeSubmittionStatus(false);
      setPostalCodeErr(false);
      setPayFullPriceFlag(false);
      if (isSWPIntiated) {
        setBtnName('NO THANKS');
      } else setBtnName('PAY FULL PRICE');
      dispatch(cfdActions.IntiatedItemRedemption(false));
      dispatch(cfdActions.IntiatedSWP(false));
      global?.logger?.info(`[7POS] - Postal code screen intialized`);
      const iTransactionMessage = {
        CMD: 'TriggerReward',
      };
      SendMessageToPOS(iTransactionMessage);
    }
    return () => {};
  }, [isItemRedemptionIntiated, isSWPIntiated]);

  useEffect(() => {
    if (!isPostalcodeSubmitted) {
      if (value?.PostalCode?.length >= 7) {
        if (!isPostalCodeErr) setContinueBtnState(false);
      } else {
        setContinueBtnState(true);
        if (isPostalCodeErr) {
          setPostalCodeMsg(IntialPostalcodeMsg);
          setPostalCodeErr(false);
        }
      }
    }
  });

  const onPayFullPrice = () => {
    setPayFullPriceFlag(true);
    const iTransactionMessage = {
      CMD: 'AcceptReward',
      RewardOpt: 'NO',
    };
    SendMessageToPOS(iTransactionMessage);
    global?.logger?.info(`[7POS UI] - User didnt opt itemRedeem/SWP`);
  };

  const ValidatePostalCode = () => {
    setContinueBtnState(true);
    setPostalcodeRetryCount(previouscount => previouscount + 1);
    const iPostalCode = value.PostalCode.replace(/ /g, '');
    let Authcode = location?.state?.AuthCode;
    Authcode = Authcode?.replace(/ /g, '');
    // #8270 added code validation as well along retry count
    if (iRetryCount <= iPostalcodeRetryCount + 1 && iPostalCode !== Authcode) {
      const iTransactionMessage = {
        CMD: 'AcceptReward',
        RewardOpt: 'NO',
      };
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - invalid postalcode for redeem/SWP(retryCount:${iPostalcodeRetryCount})`
      );
    } else if (iPostalCode === Authcode) {
      setPostalcodeSubmittionStatus(true);
      const iTransactionMessage = {
        CMD: 'AcceptReward',
        RewardOpt: 'YES',
        catalogId: location.state.catalogId,
      };
      dispatch(cfdActions.setCatlogID(location?.state?.catalogId));
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - Reward reedem for Id : ${location?.state?.catalogId}`
      );
    } else {
      setPostalCodeErr(true);
      setPostalCodeMsg(
        `Postal Code does not match our records, please try again!`
      );
    }
  };

  const onUpdateFieldValue = cVal => {
    if (!isPostalcodeSubmitted) {
      setValue({
        ...value,
        PostalCode: cVal,
      });
    }
  };

  const onClearInputValue = () => {
    setValue({
      ...value,
      PostalCode: '',
    });
  };

  const handleChange = (e, prop) => {
    setValue({
      ...value,
      [prop]: e.target.value,
    });
  };

  return (
    <>
      {iPostalcodeRetryCount !== iRetryCount || isPostalcodeSubmitted ? (
        <>
          {member && (
            <Box>
              <MemberInfo />
              {!isPayFullPriceFlag ? (
                <>
                  <Flex
                    mt="1%"
                    fontSize="2.18vw"
                    width="100%"
                    height="50px"
                    textAlign="center"
                    color="#ffffff"
                    backgroundColor={
                      isPostalCodeErr ? '#ff0000' : 'rgb(51, 194, 140)'
                    }
                    alignItems="center"
                    justifyContent="center"
                    fontWeight="bold"
                    border-radius="0px"
                  >
                    <Text>{PostalCodeMsg}</Text>
                  </Flex>
                  <InputFeild
                    onClick={handleChange}
                    Value={value.PostalCode}
                    placeHolder="POSTAL CODE"
                    errorMsgDisplay={isPostalCodeErr}
                    onClearInputValue={onClearInputValue}
                    feildname="PostalCode"
                  />
                  <PostalDialPad
                    currentValue={value.PostalCode}
                    clearField={() => setValue('')}
                    onUpdateValue={onUpdateFieldValue}
                  />
                  <Flex
                    flexDirection="row"
                    justifyContent="space-between"
                    textAlign="center"
                    height="80px"
                    fontWeight="bold"
                    mt="3%"
                    pb={4}
                  >
                    <Button
                      className={Styles.PayFullBtn}
                      onClick={onPayFullPrice}
                      isDisabled={isPostalcodeSubmitted}
                    >
                      {BTNNAME}
                    </Button>
                    <Button
                      className={Styles.SaveBtn}
                      bg={!ContinueBtnState ? '#107f62' : '#e9e9e9'}
                      color={!ContinueBtnState ? '#ffffff' : '#5b616b'}
                      isDisabled={ContinueBtnState}
                      onClick={ValidatePostalCode}
                    >
                      CONTINUE
                    </Button>
                  </Flex>
                </>
              ) : (
                <DisplayActionImage
                  ImageName={require('../../../screens/CFD/images/RedeemScreen/PayFullPrice-Canada.png')}
                />
              )}
            </Box>
          )}
        </>
      ) : (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/RedeemScreen/PostalCodeErrScreen.png')}
          />
        </Box>
      )}
    </>
  );
}

export default PostalCodeScreen;
