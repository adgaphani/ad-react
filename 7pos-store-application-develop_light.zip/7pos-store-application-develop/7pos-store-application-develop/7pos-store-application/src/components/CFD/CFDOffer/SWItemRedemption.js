import React from 'react';
import { Flex, Box, Text } from '@chakra-ui/react';
import { Button } from '../../Common/Buttons/Button';

import { SWItemOffer } from './SWItemOffer';

export const SWItemRedemption = props => {
  console.log('SW', props);

  const {
    rewards: { best_reward, best_fuel_reward },
    onOfferCancel,
    onOfferConfirm,
  } = props;
  const multpleRewards = !!best_fuel_reward && !!best_reward;
  return (
    <>
      <Flex padding="20px" justifyContent="space-between" height="75%">
        <SWItemOffer
          key="best_merch"
          multpleRewards={multpleRewards}
          reward={best_reward ?? best_fuel_reward}
          onOfferCancel={onOfferCancel}
          onOfferConfirm={onOfferConfirm}
        />
        {!!best_fuel_reward && !!best_reward && (
          <SWItemOffer
            key="best_fuel"
            multpleRewards={multpleRewards}
            reward={best_fuel_reward}
            onOfferCancel={onOfferCancel}
            onOfferConfirm={onOfferConfirm}
          />
        )}
      </Flex>
      {multpleRewards && (
        <Flex justifyContent="center">
          <Button
            background="transparent"
            border="1px solid #5B616B"
            width="30%"
            borderRadius="3px"
            onClick={onOfferCancel}
          >
            NO THANKS
          </Button>
        </Flex>
      )}
      {multpleRewards && (
        <Box
          background="white"
          width="60px"
          height="60px"
          textAlign="center"
          borderRadius="42px"
          position="absolute"
          top="48%"
          left="62.5%"
          padding="10px"
        >
          <Box
            borderRadius="20px"
            boxShadow="2px 2px 15px"
            textAlign="center"
            width="100%"
            height="100%"
          >
            <Text position="relative" top="27%">
              OR
            </Text>
          </Box>
        </Box>
      )}
    </>
  );
};
