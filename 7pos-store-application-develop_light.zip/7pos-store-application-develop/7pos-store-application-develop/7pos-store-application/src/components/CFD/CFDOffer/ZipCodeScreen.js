import { Box, Flex, Text } from '@chakra-ui/react';
import { useLocation } from 'react-router-dom';
import React, { useEffect, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import CFDDialPad from '../../Common/DailPad/CFD/CFDDialPad';
import DisplayActionImage from './DisplayActionImage';
import InputFeild from '../inputfeild';
import MemberInfo from '../CFDALTID/MemberInfo';
import { SendMessageToPOS } from '../../../Communication';
import Styles from './CFDOffer.module.css';
import { cfdActions } from '../../../slices/cfd.slice';
import { AppContext } from '../../../AppContext';
import { Button } from '../../Common/Buttons';
import PayfullSpeedwayImg from '../../../screens/CFD/images/RedeemScreen/PayFullPrice-Speedway.png';

function ZipCodeScreen(props) {
  const location = useLocation();
  const dispatch = useDispatch();
  const { keyPressSound } = useContext(AppContext);

  const [value, setValue] = useState({ ZipCode: '' });

  const [isZipCodeErr, setZipCodeErr] = useState(false);
  const [isZipcodeSubmitted, setZipcodeSubmittionStatus] = useState(false);
  const [ContinueBtnState, setContinueBtnState] = useState(true);
  const [isPayFullPriceFlag, setPayFullPriceFlag] = useState(false);
  const [iZipcodeRetryCount, setZipcodeRetryCount] = useState(0);
  const [BTNNAME, setBtnName] = useState('');

  const {
    member,
    isItemRedemptionIntiated,
    isSWPIntiated,
    config,
    isSpeedyStore,
    speedyRedeemFailed,
  } = useSelector(state => ({
    member: state.cart.member,
    isItemRedemptionIntiated: state.cfd.isItemRedemptionIntiated,
    isSWPIntiated: state.cfd.isSWPIntiated,
    config: state.main.configuration,
    isSpeedyStore: state.main.isSpeedyStore,
    speedyRedeemFailed: state.cfd.speedyRedeemFailed,
  }));
  const IntialZipcodeMsg = `For verification, enter ${
    isSpeedyStore ? 'passcode' : 'Zip Code'
  } attached to your account.`;
  const [ZipCodeMsg, setZipCodeMsg] = useState(IntialZipcodeMsg);
  const iRetryCount = Number(config?.storeConfig?.ZipCodeRetryLimit) || 3;
  useEffect(() => {
    if (isItemRedemptionIntiated || isSWPIntiated) {
      setContinueBtnState(true);
      setZipCodeMsg(IntialZipcodeMsg);
      setZipcodeRetryCount(0);
      setZipcodeSubmittionStatus(false);
      setZipCodeErr(false);
      setPayFullPriceFlag(false);
      if (isSWPIntiated) {
        setBtnName('NO THANKS');
      } else setBtnName('PAY FULL PRICE');
      dispatch(cfdActions.IntiatedItemRedemption(false));
      dispatch(cfdActions.IntiatedSWP(false));
      global?.logger?.info(`[7POS UI] - zip code screen intialized`);
      const iTransactionMessage = {
        CMD: 'TriggerReward',
      };
      SendMessageToPOS(iTransactionMessage);
    }
    return () => {};
  }, [isItemRedemptionIntiated]);

  useEffect(() => {
    if (!isZipcodeSubmitted) {
      const zipcodeLength = value?.ZipCode?.length ?? 0;
      if (
        (isSpeedyStore && zipcodeLength >= 4 && zipcodeLength <= 8) ||
        (!isSpeedyStore && zipcodeLength >= 5)
      ) {
        if (!isZipCodeErr) setContinueBtnState(false);
      } else {
        setContinueBtnState(true);
        if (isZipCodeErr) {
          setZipCodeMsg(IntialZipcodeMsg);
          setZipCodeErr(false);
        }
      }
    }
  });
  // Handling Speedy Redemption failure
  useEffect(() => {
    if (!speedyRedeemFailed) return;
    const { setShowLoader } = props;
    setShowLoader(false);
    setZipCodeMsg('Passcode does not match our records. Please try again');
    setZipCodeErr(true);
    dispatch(cfdActions.setSpeedyRedeemFailed(false));
    setZipcodeSubmittionStatus(false);
  }, [speedyRedeemFailed]);

  const onPayFullPrice = () => {
    setPayFullPriceFlag(true);
    const iTransactionMessage = {
      CMD: 'AcceptReward',
      RewardOpt: 'NO',
    };
    SendMessageToPOS(iTransactionMessage);
    global?.logger?.info(`[7POS UI] - User didnt opt itemRedeem/SWP`);
  };

  const ValidateZipCode = () => {
    setContinueBtnState(true);
    setZipcodeRetryCount(previouscount => previouscount + 1);
    // #8270 added code validation as well along retry count
    if (
      !isSpeedyStore &&
      iRetryCount <= iZipcodeRetryCount + 1 &&
      value.ZipCode !== location?.state?.AuthCode
    ) {
      const iTransactionMessage = {
        CMD: 'AcceptReward',
        RewardOpt: 'NO',
      };
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - User not entered valid zipcode for redeem/SWP(retryCount:${iZipcodeRetryCount})`
      );
    } else if (isSpeedyStore) {
      setZipcodeSubmittionStatus(true);
      const iTransactionMessage = {
        CMD: 'AcceptSpeedyReward',
        RewardOpt: 'YES',
        ...(location.state.selectedReward
          ? { selectedReward: location.state.selectedReward }
          : {}),
        zipcode: value.ZipCode,
        catalogId: location.state.catalogId,
        reward_type: location.state.reward_type,
      };
      dispatch(cfdActions.setCatlogID(location?.state?.catalogId));
      dispatch(cfdActions.setRedeemOfferInProgress(true));
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(`[7POS UI] SpeedyReward- Zip code validation`);
    } else if (value.ZipCode === location?.state?.AuthCode) {
      setZipcodeSubmittionStatus(true);
      const iTransactionMessage = {
        CMD: 'AcceptReward',
        RewardOpt: 'YES',
        ...(location.state.selectedReward
          ? { selectedReward: location.state.selectedReward }
          : {}),
        catalogId: location.state.catalogId,
      };
      dispatch(cfdActions.setCatlogID(location?.state?.catalogId));
      SendMessageToPOS(iTransactionMessage);
      global?.logger?.info(
        `[7POS UI] - Reward Accepted Reward Id : ${location.state.catalogId}`
      );
    } else {
      setZipCodeErr(true);
      setZipCodeMsg(`Zip Code does not match our records, please try again!`);
    }
  };

  const onUpdateFieldValue = cVal => {
    if (!isZipcodeSubmitted) {
      setValue({
        ...value,
        ZipCode: cVal,
      });
    }
  };

  const onClearInputValue = () => {
    setValue({
      ...value,
      ZipCode: '',
    });
  };

  const handleChange = (e, prop) => {
    keyPressSound?.play?.().catch(e => console.log('Sound error', e));
    setValue({
      ...value,
      [prop]: e.target.value,
    });
  };

  return (
    <>
      {iZipcodeRetryCount !== iRetryCount || isZipcodeSubmitted ? (
        <>
          {member && (
            <Box>
              <MemberInfo />
              {!isPayFullPriceFlag ? (
                <>
                  <Flex
                    mt="1%"
                    fontSize="2.18vw"
                    width="100%"
                    height="50px"
                    textAlign="center"
                    color="#ffffff"
                    backgroundColor={
                      isZipCodeErr
                        ? 'backgrounds.bannerSecondary'
                        : 'backgrounds.bannerPrimary'
                    }
                    alignItems="center"
                    justifyContent="center"
                    fontWeight="bold"
                    border-radius="0px"
                  >
                    <Text>{ZipCodeMsg}</Text>
                  </Flex>
                  <InputFeild
                    onClick={handleChange}
                    Value={value.ZipCode}
                    placeHolder={isSpeedyStore ? 'PASSCODE' : 'ZIP CODE'}
                    errorMsgDisplay={isZipCodeErr}
                    onClearInputValue={onClearInputValue}
                    feildname="ZipCode"
                    type={isSpeedyStore ? 'password' : 'text'}
                  />
                  <CFDDialPad
                    currentValue={value.ZipCode}
                    clearField={() => setValue('')}
                    onUpdateValue={onUpdateFieldValue}
                    isAltIDEntry={false}
                    pattern={isSpeedyStore}
                  />
                  <Flex
                    flexDirection="row"
                    justifyContent="space-between"
                    textAlign="center"
                    height="80px"
                    fontWeight="bold"
                    mt="3.5%"
                    pb={4}
                  >
                    <Button
                      onClick={onPayFullPrice}
                      isDisabled={isZipcodeSubmitted}
                      className={Styles.PayFullBtn}
                    >
                      {isSpeedyStore ? 'PAY FULL PRICE' : BTNNAME}
                    </Button>
                    <Button
                      className={Styles.SaveBtn}
                      bg={
                        !ContinueBtnState
                          ? 'buttons.primary.background'
                          : 'buttons.disable.background'
                      }
                      color={
                        !ContinueBtnState
                          ? 'buttons.primary.color'
                          : 'buttons.disable.color'
                      }
                      _hover={{ bg: '#none' }}
                      isDisabled={ContinueBtnState}
                      onClick={ValidateZipCode}
                    >
                      CONTINUE
                    </Button>
                  </Flex>
                </>
              ) : isSpeedyStore ? (
                <DisplayActionImage ImageName={PayfullSpeedwayImg} />
              ) : (
                <DisplayActionImage
                  ImageName={require('../../../screens/CFD/images/RedeemScreen/PayFullPrice-USA.png')}
                />
              )}
            </Box>
          )}
        </>
      ) : (
        <Box>
          <DisplayActionImage
            ImageName={require('../../../screens/CFD/images/RedeemScreen/ZipCodeErrScreen.png')}
          />
        </Box>
      )}
    </>
  );
}

export default ZipCodeScreen;
