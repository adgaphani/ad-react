import moment from 'moment';
import { TransactionStates } from '../../constants';
import { getHeader, getLoadCardDetails } from '../../Utils/paymentUtils';
import {
  createSafeFooter,
  createSafeHeaderLines,
} from '../../Utils/receiptUtil';
import { currencyFixed } from '../../Utils/appUtils';

const { ipcRenderer } = window.require('electron');

let dvrCartChangeTrail = null;

const sendMessage = jsonPayload => {
  ipcRenderer.send('DVR-send-message', JSON.stringify(jsonPayload));
};

const sendCardLoad = cardLoad => {
  const loadCardDetails = getLoadCardDetails([cardLoad]);
  if (loadCardDetails && loadCardDetails.length > 0) {
    const items = loadCardDetails[0]?.items || [];
    if (items.length > 0) {
      sendMessage({ cardLoadSummary: items });
    }
  }
};

const sendStartTransaction = (
  config,
  transactionSeqNumber,
  storeDetails,
  terminalNumber,
  timeStamp,
  transactionType,
  operator
) => {
  sendMessage({ CMD: 'StartTransaction' });
  sendMessage({
    metaData: {
      storeNumber: storeDetails?.storeId,
      terminalNumber,
      timeStamp: moment(timeStamp).format('MM/DD/YYYY hh:mm A'),
      transactionSeqNumber,
      transactionType,
      operator: `OP${operator}`,
    },
  });
  sendMessage({ transactionHeader: getHeader(storeDetails, config) });
};

class DVR {
  owner;

  endTransaction = ({ footer }) => {
    sendMessage({ transactionFooter: footer });
    sendMessage({ CMD: 'EndTransaction' });
    dvrCartChangeTrail = null;
  };

  endPIPOTransaction = ({ footer, transactionStatus }) => {
    if (transactionStatus !== TransactionStates.aborted) {
      sendMessage({
        paymentSummary: [
          {
            description: 'CASH',
          },
        ],
      });
    }

    this.endTransaction({ footer });
  };

  handleCardLoad = ({ cardLoad }) => {
    sendCardLoad(cardLoad);
  };

  handleCartChange = ({ cartChangePayload }) => {
    sendMessage({ cartChangeTrail: cartChangePayload });
  };

  handlePayment = ({ itemList }) => {
    sendMessage({ paymentSummary: itemList });
  };

  handleTransactionSummary = ({ items }) => {
    sendMessage({ transactionSummary: items });
  };

  sendBalanceRequest = ({ footer, items }) => {
    sendMessage({ transactionSummary: items });
    sendMessage({
      transactionFooter: {
        memberDetails: [],
        footer,
      },
    });
    sendMessage({ CMD: 'EndTransaction' });
    dvrCartChangeTrail = null;
  };

  sendEOSEOD = ({
    config,
    data,
    footer,
    storeDetails,
    terminalNumber,
    timeStamp,
    transactionSeqNumber,
    transactionType,
    user,
  }) => {
    const operator = user?.userId?.toString() || '';
    this.startTransaction({
      config,
      storeDetails,
      terminalNumber,
      timeStamp,
      transactionSeqNumber,
      transactionType,
      operator,
    });
    sendMessage({ endOfSD: data });
    this.endTransaction({ footer });
  };

  sendSafe = ({
    amount,
    config,
    deviceInfo,
    isAbort,
    storeDetails,
    transactionSeqNumber,
    uLabel,
    user,
  }) => {
    const operator = user?.userId?.toString() || '';
    sendMessage({ CMD: 'StartTransaction' });
    this.owner.transactionActive = true;

    sendMessage({
      metaData: {
        storeNumber: storeDetails?.storeId,
        terminalNumber: deviceInfo?.id,
        timeStamp: moment.utc().format('MM/DD/YYYY hh:mm A'),
        transactionSeqNumber,
        transactionType: 'SAFEACTION',
        operator: `OP${operator}`,
      },
    });
    const header = getHeader(storeDetails, config, 'SAFEACTION');
    header.headerLines = createSafeHeaderLines(
      header.headerLines,
      isAbort,
      uLabel
    );

    sendMessage({
      transactionHeader: header,
    });

    if (!isAbort) {
      (dvrCartChangeTrail || []).forEach(cartChangePayload => {
        this.handleCartChange(cartChangePayload);
      });

      const value = currencyFixed(amount / 100);
      this.owner.handleTransactionSummary(
        0,
        false,
        false,
        {
          SUBTOTAL: `${value}`,
          'TOTAL DUE': `${value}`,
        },
        []
      );

      sendMessage({
        paymentSummary: [
          {
            description: 'CASH',
            details: `${value}`,
          },
        ],
      });
    }

    sendMessage({
      transactionFooter: {
        memberDetails: [],
        footer: createSafeFooter(deviceInfo, user, transactionSeqNumber),
      },
    });

    sendMessage({ CMD: 'EndTransaction' });
    this.owner.transactionActive = false;

    dvrCartChangeTrail = null;
  };

  sendTransactionHold = () => {
    sendMessage({
      transactionFooter: {
        footerLines: [],
        memberDetails: [],
        footer: [],
        transactionStatus: 'TransHold',
      },
    });
    sendMessage({ CMD: 'EndTransaction' });
    dvrCartChangeTrail = null;
  };

  setSafeCartChangeTrail = ({ cartChangeTrail }) => {
    dvrCartChangeTrail = cartChangeTrail;
  };

  startTransaction = ({
    config,
    transactionSeqNumber,
    storeDetails,
    terminalNumber,
    timeStamp,
    transactionType,
    operator,
  }) => {
    sendStartTransaction(
      config,
      transactionSeqNumber,
      storeDetails,
      terminalNumber,
      timeStamp,
      transactionType,
      operator
    );
  };
}

export const DVR_ClickIt = new DVR();
