import moment from 'moment';

const electron = window.require('electron');

let dvrCashDrawerOpenTime;
let dvrCashDrawerStatus;
let dvrChangeAmount;
let dvrIsCashTransaction = null;
let dvrItemPrices = {};
let dvrItemTotals = {};
let dvrShiftNumber;
let dvrTerminalNumber;
let dvrTransactionNumber;
let dvrTransactionType;

const getItemId = item => item?.itemId || 0;

const getItemNumber = item => item?.transactionLineId || item?.eventSeq || 0;

const getMOPDescription = description => description;

const getMOPId = description => {
  description = (description || '').toLowerCase();
  if (description.includes('cash')) {
    return 1;
  }

  if (description.includes('ebt')) {
    return 3;
  }

  if (description.includes('debit')) {
    return 4;
  }

  if (description.includes('tax deduction')) {
    return 5;
  }

  if (description.includes('svc') || description.includes('fleet')) {
    return 6;
  }

  return 2;
};

const getTransactionType = transType => {
  switch (transType.toLowerCase()) {
    case 'nosale':
      return 'No Sale';
    case 'paidin':
      return 'Pay In';
    case 'paidout':
      return 'Pay Out';
    case 'safeaction':
      return 'Safe Drop';
    case 'sale':
      return 'Sales';
    default:
      return transType;
  }
};

const createEventTime = () => `${moment().format('YYYY-MM-DDTHH:mm:ss.SSS')}`;

const durationInSeconds = startDate =>
  parseInt(Math.abs(new Date() - startDate) / 1000, 10);

const getBusinessDate = () => {
  const str = createEventTime();
  return str.substring(0, 10);
};

const sendMessage = payload => {
  try {
    const msg = Object.keys(payload).reduce((value, key) => {
      if (value.length > 0) {
        value += ',';
      }
      value += `${key}=${payload[key]}`;
      return value;
    }, '');

    electron.ipcRenderer.send('DVR-send-message', msg);
  } catch (e) {
    global?.logger?.error(`NCR DVR send exception ::- ${e}`);
  }
};

const notifyAgeVerification = (isVisual, age) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1010,
  // TerminalNumber=1,
  // EventTime=2015-08-19T11:56:53.522,
  // TransactionNumber=207144,
  // VerifiedAge=40,
  // VerificationType=Instant Approval
  const payload = {
    EventId: 1010,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    VerifiedAge: age || 40,
    VerificationType: isVisual ? 'Instant Approval' : 'Verified Age',
  };

  sendMessage(payload);
};

const notifyCoupon = (item, added) => {
  let payload;
  if (added) {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1015,
    // TerminalNumber=1,
    // EventTime=2015-08-19T09:10:53.881,
    // TransactionNumber=207053,
    // ItemNumber=2,
    // Id=75000000005,
    // Description=HOC Coupon,
    // Amount=0.89
    payload = {
      EventId: 1015,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
      Id: getItemId(item),
      Description: item?.itemName,
      Amount: parseFloat(item?.price || 0.0).toFixed(2),
    };
  } else {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1017,
    // TerminalNumber=4,
    // EventTime=2022-08-29T13:44:03.916,
    // TransactionNumber=1138534,
    // ItemNumber=3,
    // Id=1000255,
    // Description=LOY FREE FOUNT
    payload = {
      EventId: 1017,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
      Id: getItemId(item),
      Description: item?.itemName,
    };
  }
  sendMessage(payload);
};

const notifyDiscount = (item, added) => {
  let payload;
  if (added) {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1016,
    // TerminalNumber=1,
    // EventTime=2015-08-19T09:10:53.881,
    // TransactionNumber=207053,
    // ItemNumber=2,
    // Id=75000000005,
    // Description=HOC Coupon,
    // Amount=0.89
    payload = {
      EventId: 1016,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
      Id: getItemId(item),
      Description: item?.itemName,
      Amount: parseFloat(item?.price || 0.0).toFixed(2),
    };
  } else {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1018,
    // TerminalNumber=4,
    // EventTime=2022-08-29T13:44:03.916,
    // TransactionNumber=1138534,
    // ItemNumber=3,
    // Id=1000255,
    // Description=LOY FREE FOUNT
    payload = {
      EventId: 1018,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
      Id: getItemId(item),
      Description: item?.itemName,
    };
  }
  sendMessage(payload);
};

const notifyItemAdd = item => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1011,
  // TerminalNumber=3,
  // EventTime=2022-10-16T19:34:15.825,
  // TransactionNumber=3042422,
  // ItemNumber=2,
  // ItemId=1076237,
  // Modifier1Id=1000009,
  // Modifier2Id=0,
  // Modifier3Id=0,
  // ItemType=Regular Sales Item,
  // Description=SINGLE DONUT CAFɠSINGLE,
  // UnitPrice=1.09,
  // ExtendedPrice=1.09,
  // Quantity=1.000,
  // AgeMinimum=0,
  const payload = {
    EventId: 1011,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    ItemNumber: getItemNumber(item),
    ItemId: getItemId(item),
    Modifier1Id: 0,
    Modifier2Id: 0,
    Modifier3Id: 0,
    ItemType: 'Regular Sales Item',
    Description: item?.itemName,
    UnitPrice: parseFloat(item?.price || 0.0).toFixed(2),
    ExtendedPrice: parseFloat(item?.price || 0.0).toFixed(2),
    Quantity: parseFloat(item?.quantity || 1.0).toFixed(3),
    AgeMinimum: item?.itemRestrictionCode || 0,
  };
  dvrItemTotals[payload.ItemNumber] = parseFloat(payload.Quantity);
  dvrItemPrices[payload.ItemNumber] = payload.UnitPrice;

  sendMessage(payload);
};

const notifyItemChange = (item, newQuantity, oldQuantity) => {
  dvrItemTotals[getItemNumber(item)] = parseFloat(newQuantity);

  let payload;
  if (newQuantity > 0) {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1014,
    // TerminalNumber=1,
    // EventTime=2015-08-19T05:51:33.017,
    // TransactionNumber=206910,
    // ItemNumber=1,
    // ItemId=990000003638,
    // Modifier1Id=990000000019,
    // Modifier2Id=0,
    // Modifier3Id=0,
    // Description=15ozJavaMeanBean,
    // OldQuantity=1.000,
    // NewQuantity=2.000
    payload = {
      EventId: 1014,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
      ItemId: getItemId(item),
      Modifier1Id: 0,
      Modifier2Id: 0,
      Modifier3Id: 0,
      Description: item?.itemName,
      OldQuantity: parseFloat(oldQuantity).toFixed(3),
      NewQuantity: parseFloat(newQuantity).toFixed(3),
    };
  } else {
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // IMPORTANT - The order of these attributes must be maintained when sending
    // to DVR
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    // EventId=1012,
    // TerminalNumber=1,
    // EventTime=2015-08-19T11:32:35.787,
    // TransactionNumber=207130,
    // ItemNumber=1
    payload = {
      EventId: 1012,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      ItemNumber: getItemNumber(item),
    };
  }
  sendMessage(payload);
};

const notifyPriceOverride = item => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1013,
  // TerminalNumber=1,
  // EventTime=2022-11-04T02:38:56.486,
  // TransactionNumber=3087786,
  // ItemNumber=3,
  // ItemId=1000317,
  // Modifier1Id=1000009,
  // Modifier2Id=0,
  // Modifier3Id=0,
  // Description=3 MUSKETEERS REG SINGLE,
  // OldUnitPrice=1.99,
  // NewUnitPrice=1.00
  const payload = {
    EventId: 1013,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    ItemNumber: getItemNumber(item),
    ItemId: getItemId(item),
    Modifier1Id: 0,
    Modifier2Id: 0,
    Modifier3Id: 0,
    Description: item?.itemName,
    OldUnitPrice: parseFloat(
      dvrItemPrices[item?.transactionLineId] || 0.0
    ).toFixed(2),
    NewUnitPrice: parseFloat(item?.price || 0.0).toFixed(2),
  };
  dvrItemPrices[item?.transactionLineId] = payload.NewUnitPrice;

  sendMessage(payload);
};

const notifyCartChange = item => {
  if (item) {
    const type = (item.eventType || '').toLowerCase();
    const isModifier = !!((item?.transactionLineId || 1.0) % 1);
    const isCoupon = item?.itemName?.startsWith('MC ');
    if (isModifier) {
      item = JSON.parse(JSON.stringify(item));
      item.transactionLineId = Math.trunc(parseFloat(item?.transactionLineId));
    }

    switch (type) {
      case 'addlineitem':
        if (isModifier) {
          if (isCoupon) {
            notifyCoupon(item, true);
          } else {
            notifyDiscount(item, true);
          }
        } else {
          notifyItemAdd(item);
        }
        break;
      case 'updatelineitem':
      case 'voidlineitem':
        if (
          type === 'updatelineitem' &&
          (item?.eventResult || '').toLowerCase() === 'priceoverride'
        ) {
          notifyPriceOverride(item);
        } else if (isModifier) {
          if (isCoupon) {
            notifyCoupon(item, false);
          } else {
            notifyDiscount(item, false);
          }
        } else {
          const removed = type === 'voidlineitem';
          const newQuantity =
            (dvrItemTotals[getItemNumber(item)] || 1.0) +
            (removed ? -1.0 : 1.0);
          const oldQuantity = parseFloat(newQuantity + (removed ? 1.0 : -1.0));

          notifyItemChange(item, newQuantity, oldQuantity);
        }
        break;
      default:
        break;
    }
  }
};

const notifyChange = cashBackAmount => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1008,
  // TerminalNumber=1,
  // EventTime=2015-08-19T11:41:25.147,
  // TransactionNumber=207135,
  // MOPId=12,
  // MOPDescription=Cash,
  // Amount=16.75
  const changeAmount = dvrIsCashTransaction ? dvrChangeAmount : cashBackAmount;
  if (changeAmount && changeAmount !== '$0.00') {
    const payload = {
      EventId: 1008,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      TransactionNumber: dvrTransactionNumber,
      MOPId: getMOPId('CASH'),
      MOPDescription: getMOPDescription('CASH'),
      Amount: changeAmount.replace('$', ''),
    };
    sendMessage(payload);

    dvrChangeAmount = null;
  }
};

const notifyCashDrawerAlarm = (operatorId, firstName, lastName) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=4004,
  // TerminalNumber=1,
  // EventTime=2015-08-18T12:01:06.833,
  // DrawerOpenReasonType=Opened as Part of Tender,
  // CashDrawerId=1,
  // OperatorId=70000000409,
  // OperatorName=Last,, 2-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-18,
  // OpenDuration=120
  const payload = {
    EventId: 4004,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    DrawerOpenReasonType: `Opened as part of ${
      dvrTransactionType === 'Sales' ? 'Tender' : dvrTransactionType
    }`,
    CashDrawerId: 1,
    OperatorId: operatorId,
    OperatorName: `${lastName},, ${firstName}`,
    OperatorShiftNumber: dvrShiftNumber,
    BusinessDate: getBusinessDate(),
    OpenDuration: durationInSeconds(dvrCashDrawerOpenTime),
  };
  sendMessage(payload);
};

const notifyCashDrawerClosed = (operatorId, firstName, lastName) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=4003
  // TerminalNumber=1,
  // EventTime=2015-08-16T13:57:23.331,
  // DrawerOpenReasonType=Opened as Part of No Sale,
  // CashDrawerId=1,
  // OperatorId=70000000403,
  // OperatorName=Last,, 8-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-16,
  // OpenDuration=81
  if (dvrCashDrawerOpenTime) {
    const payload = {
      EventId: 4003,
      TerminalNumber: dvrTerminalNumber,
      EventTime: createEventTime(),
      DrawerOpenReasonType: `Opened as part of ${
        dvrTransactionType === 'Sales' ? 'Tender' : dvrTransactionType
      }`,
      CashDrawerId: 1,
      OperatorId: operatorId,
      OperatorName: `${lastName},, ${firstName}`,
      OperatorShiftNumber: dvrShiftNumber,
      BusinessDate: getBusinessDate(),
      OpenDuration: durationInSeconds(dvrCashDrawerOpenTime),
    };
    sendMessage(payload);
  }
};

const notifyCashDrawerOpen = (operatorId, firstName, lastName) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=4002
  // TerminalNumber=1,
  // EventTime=2015-08-16T13:57:23.331,
  // DrawerOpenReasonType=Opened as Part of No Sale,
  // CashDrawerId=1,
  // OperatorId=70000000403,
  // OperatorName=Last,, 8-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-16
  const payload = {
    EventId: 4002,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    DrawerOpenReasonType: `Opened as part of ${
      dvrTransactionType === 'Sales' ? 'Tender' : dvrTransactionType
    }`,
    CashDrawerId: 1,
    OperatorId: operatorId,
    OperatorName: `${lastName},, ${firstName}`,
    OperatorShiftNumber: dvrShiftNumber,
    BusinessDate: getBusinessDate(),
  };
  sendMessage(payload);
};

const notifyMOP = (description, amount) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1007
  // TerminalNumber=1
  // EventTime=2015-08-19T11:32:54.037
  // TransactionNumber=207130
  // MOPId=12
  // MOPDescription=Cash
  // Amount=6.00
  const mopId = getMOPId(description);
  dvrIsCashTransaction = dvrIsCashTransaction || mopId === 1;

  const payload = {
    EventId: 1007,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    MOPId: mopId,
    MOPDescription: getMOPDescription(description),
    Amount: amount.replace('$', ''),
  };
  sendMessage(payload);
};

const notifyOnline = online => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=5001,
  // TerminalNumber=2,
  // EventTime=2015-08-20T06:11:34.461,
  // DeviceStatusType=Offline

  // EventId=5001,
  // TerminalNumber=2,
  // EventTime=2015-08-20T06:11:34.946,
  // DeviceStatusType=Online
  const payload = {
    EventId: 5001,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    DeviceStatusType: online ? 'Online' : 'Offline',
  };
  sendMessage(payload);
};

const notifySignOn = (operatorId, firstName, lastName) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=2002,
  // TerminalNumber=1,
  // EventTime=2015-08-19T05:50:17.876,
  // OperatorId=70000000409,
  // OperatorName=Last,, 2-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-19
  const payload = {
    EventId: 2002,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    OperatorId: operatorId,
    OperatorName: `${lastName},, ${firstName}`,
    OperatorShiftNumber: dvrShiftNumber,
    BusinessDate: getBusinessDate(),
  };
  sendMessage(payload);
};

const notifyTimeSync = () => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1,
  // TerminalNumber=1,
  // EventTime=2015-08-19T05:50:17.876,
  const payload = {
    EventId: 1,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
  };
  sendMessage(payload);
};

const notifyTransactionType = () => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1009,
  // TerminalNumber=1,
  // EventTime=2015-08-19T11:32:54.490,
  // TransactionNumber=207130,
  // TransactionType=Sales,
  const payload = {
    EventId: 1009,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    TransactionType:
      dvrTransactionType === 'No Sale'
        ? 'Open Drawer/No Sale'
        : dvrTransactionType,
  };
  sendMessage(payload);
};

const notifyTransactionEnd = (
  cashBackAmount,
  subtotalAmount,
  taxAmount,
  totalAmount,
  transactionStatus
) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1002,
  // TerminalNumber=1,
  // EventTime=2015-08-19T11:32:54.490,
  // TransactionNumber=207130,
  // TransactionType=Sales,
  // TransactionCompletionType=Completed,
  // SubtotalAmount=5.27,
  // TaxAmount=0.08,
  // TotalAmount=5.35
  const payload = {
    EventId: 1002,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: dvrTransactionNumber,
    TransactionType: dvrTransactionType,
    TransactionCompletionType: (transactionStatus || '')
      .toLowerCase()
      .startsWith('abort')
      ? 'Cancelled'
      : transactionStatus,
    SubtotalAmount: subtotalAmount.replace('$', ''),
    TaxAmount: taxAmount.replace('$', ''),
    TotalAmount: totalAmount.replace('$', ''),
  };

  if (payload.TransactionCompletionType !== 'Cancelled') {
    notifyChange(cashBackAmount);
  }

  sendMessage(payload);
};

const notifyTransactionRestored = (
  operatorId,
  firstName,
  lastName,
  transactionNumber
) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1004,
  // TerminalNumber=1,
  // EventTime=2015-08-18T16:45:12.173,
  // TransactionNumber=206659,
  // OperatorId=70000000408,
  // OperatorName=Last,, 4-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-18,
  // StoredTransactionNumber=206659
  const payload = {
    EventId: 1004,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: transactionNumber,
    OperatorId: operatorId,
    OperatorName: `${lastName},, ${firstName}`,
    OperatorShiftNumber: dvrShiftNumber,
    BusinessDate: getBusinessDate(),
    StoredTransactionNumber: transactionNumber,
  };
  sendMessage(payload);
};

const notifyTransactionStart = (
  operatorId,
  firstName,
  lastName,
  transactionNumber
) => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1001,
  // TerminalNumber=1,
  // EventTime=2015-08-18T16:44:23.220,
  // TransactionNumber=206659
  // OperatorId=70000000408,
  // OperatorName=Last,, 4-First,
  // OperatorShiftNumber=1,
  // BusinessDate=2015-08-01
  dvrItemTotals = {};
  dvrItemPrices = {};
  const payload = {
    EventId: 1001,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: transactionNumber,
    OperatorId: operatorId,
    OperatorName: `${lastName},, ${firstName}`,
    OperatorShiftNumber: dvrShiftNumber,
    BusinessDate: getBusinessDate(),
  };

  sendMessage(payload);
  notifyTransactionType();
};

const notifyTransactionStored = transactionNumber => {
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // IMPORTANT - The order of these attributes must be maintained when sending
  // to DVR
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  // EventId=1003,
  // TerminalNumber=1,
  // EventTime=2015-08-18T16:44:23.220,
  // TransactionNumber=206659
  const payload = {
    EventId: 1003,
    TerminalNumber: dvrTerminalNumber,
    EventTime: createEventTime(),
    TransactionNumber: transactionNumber,
  };
  sendMessage(payload);
};

const notifyDrawerStatus = (cashDrawerStatus, user) => {
  if (
    dvrCashDrawerStatus !== cashDrawerStatus ||
    cashDrawerStatus === 'CD_ALARM_ON'
  ) {
    dvrCashDrawerStatus = cashDrawerStatus;
    switch ((cashDrawerStatus || '').toUpperCase()) {
      case 'CD_ALARM_OFF':
        // No operation needed - skipping
        break;
      case 'CD_ALARM_ON':
        notifyCashDrawerAlarm(
          user?.userId || '',
          user?.firstName || '',
          user?.lastName || ''
        );
        break;
      case 'CD_IS_OPEN':
      case 'CD_OPEN_OK':
        dvrCashDrawerOpenTime = new Date();
        notifyCashDrawerOpen(
          user?.userId || '',
          user?.firstName || '',
          user?.lastName || ''
        );
        break;
      case 'CD_CLOSED':
      default:
        notifyCashDrawerClosed(
          user?.userId || '',
          user?.firstName || '',
          user?.lastName || ''
        );
        dvrCashDrawerOpenTime = null;
        break;
    }
  }
};

const initialize = deviceInfo => {
  dvrTerminalNumber = parseInt(deviceInfo?.id || 0, 10);
  notifyOnline(true);
  notifyTimeSync();
};

class DVR {
  owner;

  endTransaction = ({ amount, cashBack, summaryItems, transactionStatus }) => {
    const cashBackAmount = cashBack
      ? `$${parseFloat(cashBack).toFixed(2)}`
      : '$0.00';

    summaryItems = summaryItems || [];
    const subtotalAmount =
      summaryItems.find(v => v?.description?.startsWith('SUBTOTAL'))?.details ||
      '0.00';
    const taxAmount =
      summaryItems.find(v => v?.description?.startsWith('TAX ON'))?.details ||
      '0.00';
    const totalAmount =
      summaryItems.find(
        v =>
          v?.description?.startsWith('REFUND DUE') ||
          v?.description?.startsWith('TOTAL DUE')
      )?.details || '0.00';
    const isRefundOrVoid = summaryItems.find(v =>
      v?.description?.startsWith('REFUND DUE')
    )?.details;
    if (
      isRefundOrVoid &&
      dvrIsCashTransaction &&
      (!dvrChangeAmount || dvrChangeAmount === '$0.00')
    ) {
      this.setChangeAmount(`$${totalAmount}`);
    }

    notifyTransactionEnd(
      cashBackAmount,
      subtotalAmount,
      taxAmount,
      amount || totalAmount,
      transactionStatus
    );
  };

  endPIPOTransaction = ({
    amount,
    cashBack,
    summaryItems,
    transactionStatus,
  }) => {
    amount = `${parseFloat(amount).toFixed(2)}`;
    this.endTransaction({ amount, cashBack, summaryItems, transactionStatus });
  };

  handleAgeVerification = ({ isVisual, age }) => {
    notifyAgeVerification(isVisual, age);
  };

  handleCartChange = ({ cartChangePayload }) => {
    notifyCartChange(cartChangePayload);
  };

  handlePayment = ({ itemList }) => {
    itemList.forEach(item => {
      if (item?.details && item?.description) {
        notifyMOP(item.description, item.details);
      }
    });
  };

  handleSignOn = ({ user }) => {
    notifySignOn(
      user?.userId || '',
      user?.firstName || '',
      user?.lastName || ''
    );
  };

  init = deviceInfo => {
    initialize(deviceInfo);
  };

  shutdown = () => {
    notifyOnline(false);
  };

  sendBalanceRequest = ({ footer }) => {
    this.endTransaction({
      summaryItems: [],
      transactionStatus: footer.transactionStatus,
    });
  };

  sendTransactionHold = ({ transactionSeqNumber }) => {
    notifyTransactionStored(transactionSeqNumber);
  };

  sendTransactionRelease = ({ user, transactionSeqNumber }) => {
    notifyTransactionRestored(
      user?.userId || '',
      user?.firstName || '',
      user?.lastName || '',
      transactionSeqNumber
    );
  };

  setChangeAmount = ({ changeAmount }) => {
    dvrChangeAmount = changeAmount;
  };

  setDayShift = ({ dayNumber, shiftNumber }) => {
    dvrShiftNumber = shiftNumber;
    console.log('NCR DVR day/shift', dayNumber, dvrShiftNumber);
  };

  setDrawerStatus = ({ cashDrawerStatus, user }) => {
    notifyDrawerStatus(cashDrawerStatus, user);
  };

  startTransaction = ({ transactionSeqNumber, transactionType, user }) => {
    dvrTransactionNumber = transactionSeqNumber;
    dvrTransactionType = getTransactionType(transactionType);
    dvrChangeAmount = null;
    dvrIsCashTransaction = null;

    notifyTransactionStart(
      user?.userId || '',
      user?.firstName || '',
      user?.lastName || '',
      transactionSeqNumber
    );
  };
}

export const DVR_3xLogic = new DVR();
