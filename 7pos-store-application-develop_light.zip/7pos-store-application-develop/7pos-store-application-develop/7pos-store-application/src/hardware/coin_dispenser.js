import { getTransDetails, getPaymentDetails } from '../Utils/paymentUtils';

const { ipcRenderer } = window.require('electron');

let cashbackAmount = null;
let changeAmount = null;
let isCashTransaction = false;
let isEnabled = false;

const setCashbackAmount = amount => {
  cashbackAmount = amount ? `$${parseFloat(amount).toFixed(2)}` : '$0.00';
};

export const setChangeAmount = amount => {
  if (isEnabled) {
    changeAmount = amount;
  }
};

export const setEnabled = enabled => {
  isEnabled = enabled;
};

export const processPayment = (
  allPayments,
  paymentHistory,
  transDetails,
  isTransactionVoid,
  isTransactionRefund,
  mediaAbortedPaymentList,
  isPrintChargeReversalMessage,
  chargeReversalMediaPaymentList
) => {
  if (isEnabled && !isCashTransaction) {
    const paymentDetails = getPaymentDetails(
      null,
      '',
      [paymentHistory[paymentHistory.length - 1]],
      [allPayments[allPayments.length - 1]],
      transDetails,
      null,
      isTransactionVoid,
      isTransactionRefund,
      mediaAbortedPaymentList,
      isPrintChargeReversalMessage,
      chargeReversalMediaPaymentList
    );

    let paymentList = [];
    (paymentDetails || []).forEach(i => {
      paymentList = paymentList.concat(i.items);
    });
    isCashTransaction = paymentList.find(
      i => (i?.description || '').toLowerCase() === 'cash'
    );
  }
};

export const processSummary = (cashBack, isRefundOrVoid, transInfo, items) => {
  if (isEnabled) {
    setCashbackAmount(cashBack);

    if (isRefundOrVoid && (!changeAmount || changeAmount === '$0.00')) {
      const details = getTransDetails(
        transInfo,
        cashBack,
        isRefundOrVoid,
        isRefundOrVoid,
        items
      );
      const summaryItems = details?.items || [];
      const totalAmount =
        summaryItems.find(
          v =>
            v?.description?.startsWith('REFUND DUE') ||
            v?.description?.startsWith('TOTAL DUE')
        )?.details || '$0.00';
      setChangeAmount(`${totalAmount}`);
    }
  }
};

export const dispenseChange = () => {
  if (isEnabled) {
    const amount = isCashTransaction ? changeAmount : cashbackAmount;
    if (amount && amount !== '$0.00') {
      ipcRenderer.send('CoinDispenser-dispense-amount', amount);
    }
    isCashTransaction = false;
    changeAmount = null;
    cashbackAmount = null;
  }
};
