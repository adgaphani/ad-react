import moment from 'moment';
import {
  getFooter,
  getPaymentDetails,
  getTransDetails,
} from '../Utils/paymentUtils';
import {
  BALANCE_INQUIRY,
  BALANCE_INQUIRY_CANCEL,
  TransactionStates,
} from '../constants';

const dvrTypes = {
  DVR_3xLogic: '3x_logic',
  DVR_ClickIt: 'click_it',
  DVR_None: 'none',
};

class DVR {
  constructor(dvrInstance) {
    this.dvrInstance = dvrInstance;
    this.transactionActive = false;
  }

  endTransaction = (
    allPayments,
    cashBack,
    config,
    deviceInfo,
    items,
    loadCardMediaList,
    member,
    paymentDetails,
    transactionId,
    transactionStatus,
    transactionType,
    user
  ) => {
    if (this.dvrInstance && this.transactionActive) {
      const cardPayment = allPayments?.filter(
        paymentDetails => paymentDetails?.receiptDetails?.cardName !== 'CASH'
      );
      const isAgreementRequired =
        (cardPayment?.length > 0 && transactionType !== 'abort') || false;
      const findFuelTotal = (total, current) =>
        total + current?.metaInfo?.fuelAmount || 0;
      const footer = getFooter(
        paymentDetails,
        deviceInfo,
        user,
        cashBack,
        transactionId,
        member,
        isAgreementRequired,
        config,
        transactionType,
        loadCardMediaList,
        items?.filter(i => i.isFuel).reduce(findFuelTotal, 0) > 0
      );
      footer.transactionStatus = transactionStatus;
      if (footer.loadCardDetails) {
        delete footer.loadCardDetails;
      }

      const summaryItems = JSON.parse(this.lastSummary || '[]');
      this.dvrInstance?.endTransaction?.({
        cashBack,
        footer,
        summaryItems,
        transactionStatus,
      });
      this.transactionActive = false;
      this.lastSummary = null;
    }
  };

  endPIPOTransaction = (
    allPayments,
    amount,
    cashBack,
    config,
    deviceInfo,
    items,
    member,
    paymentDetails,
    targetTransactionState,
    transactionId,
    user
  ) => {
    if (this.dvrInstance && this.transactionActive) {
      const cardPayment = allPayments?.filter(
        paymentDetails => paymentDetails?.receiptDetails?.cardName !== 'CASH'
      );
      const transactionType =
        targetTransactionState === TransactionStates.aborted ? 'abort' : '';
      const isAgreementRequired =
        (cardPayment?.length > 0 && transactionType !== 'abort') || false;
      const transactionStatus =
        targetTransactionState === TransactionStates.aborted
          ? 'Aborted'
          : targetTransactionState;
      const footer = getFooter(
        paymentDetails,
        deviceInfo,
        user,
        cashBack,
        transactionId,
        member,
        isAgreementRequired,
        config,
        transactionType,
        [],
        items
      );
      footer.transactionStatus = transactionStatus;
      if (footer.loadCardDetails) {
        delete footer.loadCardDetails;
      }

      const summaryItems = JSON.parse(this.lastSummary || '[]');
      this.dvrInstance?.endPIPOTransaction?.({
        cashBack,
        amount,
        footer,
        summaryItems,
        transactionStatus,
      });
      this.transactionActive = false;
      this.lastSummary = null;
    }
  };

  handleAgeVerification = (isVisual, age) => {
    this.dvrInstance?.handleAgeVerification?.({ isVisual, age });
  };

  handleCardLoad = cardLoad => {
    if (this.dvrInstance && this.transactionActive) {
      this.dvrInstance?.handleCardLoad?.({ cardLoad });
    }
  };

  handleCartChange = cartChangePayload => {
    if (this.dvrInstance && this.transactionActive) {
      this.dvrInstance?.handleCartChange?.({ cartChangePayload });
    }
  };

  handlePayment = (
    allPayments,
    paymentHistory,
    transDetails,
    isTransactionVoid,
    isTransactionRefund,
    mediaAbortedPaymentList,
    isPrintChargeReversalMessage,
    chargeReversalMediaPaymentList
  ) => {
    if (this.dvrInstance && this.transactionActive) {
      const paymentDetails = getPaymentDetails(
        null,
        '',
        [paymentHistory[paymentHistory.length - 1]],
        [allPayments[allPayments.length - 1]],
        transDetails,
        null,
        isTransactionVoid,
        isTransactionRefund,
        mediaAbortedPaymentList,
        isPrintChargeReversalMessage,
        chargeReversalMediaPaymentList
      );

      let itemList = [];
      (paymentDetails || []).forEach(i => {
        itemList = itemList.concat(i.items);
      });

      this.dvrInstance?.handlePayment?.({ itemList });
    }
  };

  handleSignOn = user => {
    this.dvrInstance?.handleSignOn?.({ user });
  };

  handleTransactionSummary = (
    cashBack,
    isTransactionRefund,
    isTransactionVoid,
    transInfo,
    items
  ) => {
    if (this.dvrInstance && this.transactionActive) {
      const details = getTransDetails(
        transInfo,
        cashBack,
        isTransactionRefund,
        isTransactionVoid,
        items
      );

      const summaryItems = details?.items || [];
      const currentSummary = JSON.stringify(summaryItems);
      if (!this.lastSummary || this.lastSummary !== currentSummary) {
        this.lastSummary = currentSummary;
        this.dvrInstance?.handleTransactionSummary?.({
          items: summaryItems,
        });
      }
    }
  };

  init = deviceInfo => {
    this.dvrInstance?.init?.(deviceInfo);
  };

  sendBalanceRequest = (
    isCancel,
    config,
    user,
    transactionSeqNumber,
    storeDetails,
    deviceInfo,
    items
  ) => {
    if (this.dvrInstance) {
      const operator = user?.userId?.toString() || '';
      this.startTransaction(
        config,
        transactionSeqNumber,
        storeDetails,
        deviceInfo?.id,
        moment().utc(),
        isCancel ? BALANCE_INQUIRY_CANCEL : BALANCE_INQUIRY,
        operator,
        user
      );
      const footer = getFooter(
        null,
        deviceInfo,
        user,
        null,
        transactionSeqNumber,
        null,
        null
      );
      footer.transactionStatus = TransactionStates.completed;
      this.dvrInstance?.sendBalanceRequest?.({ footer, items });

      this.transactionActive = false;
      this.lastSummary = null;
    }
  };

  sendEOSEOD = (
    config,
    data,
    deviceInfo,
    storeDetails,
    terminalNumber,
    timeStamp,
    transactionSeqNumber,
    transactionType,
    user
  ) => {
    if (this.dvrInstance) {
      const footer = getFooter(
        [],
        deviceInfo,
        user,
        0,
        transactionSeqNumber,
        null,
        false,
        config,
        transactionType,
        [],
        []
      );
      footer.transactionStatus = 'Completed';
      if (footer.loadCardDetails) {
        delete footer.loadCardDetails;
      }
      this.dvrInstance?.sendEOSEOD?.({
        config,
        data,
        deviceInfo,
        footer,
        storeDetails,
        terminalNumber,
        timeStamp,
        transactionSeqNumber,
        transactionType,
        user,
      });
    }
  };

  sendNoSale = (
    config,
    deviceInfo,
    storeDetails,
    timeStamp,
    transactionSeqNumber,
    user
  ) => {
    this.startTransaction(
      config,
      transactionSeqNumber,
      storeDetails,
      deviceInfo?.id,
      timeStamp,
      'NoSale',
      user?.userId?.toString() || '',
      user
    );
    this.handleTransactionSummary(
      0,
      false,
      false,
      {
        SUBTOTAL: '0.00',
        'TOTAL DUE': '0.00',
      },
      []
    );
    this.endTransaction(
      [],
      0,
      config,
      deviceInfo,
      [],
      [],
      null,
      null,
      transactionSeqNumber,
      'Completed',
      'noSale',
      user
    );
  };

  sendSafe = (
    amount,
    config,
    deviceInfo,
    isAbort,
    storeDetails,
    transactionSeqNumber,
    uLabel,
    user
  ) => {
    if (this.dvrInstance) {
      this.dvrInstance?.sendSafe?.({
        amount,
        config,
        deviceInfo,
        isAbort,
        storeDetails,
        transactionSeqNumber,
        uLabel,
        user,
      });
    }
  };

  sendTransactionHold = transactionSeqNumber => {
    if (this.dvrInstance && this.transactionActive) {
      this.dvrInstance?.sendTransactionHold?.({ transactionSeqNumber });
      this.transactionActive = false;
      this.lastSummary = null;
    }
  };

  sendTransactionRelease = (
    cartChangeTrail,
    config,
    operator,
    storeDetails,
    terminalNumber,
    timeStamp,
    transactionSeqNumber,
    transactionType,
    user
  ) => {
    if (this.dvrInstance) {
      this.startTransaction(
        config,
        transactionSeqNumber,
        storeDetails,
        terminalNumber,
        timeStamp,
        transactionType,
        operator,
        user
      );
      (cartChangeTrail || []).forEach(cartChangePayload => {
        this.handleCartChange(cartChangePayload);
      });
      this.dvrInstance?.sendTransactionRelease?.({
        user,
        transactionSeqNumber,
      });
    }
  };

  setChangeAmount = changeAmount => {
    this.dvrInstance?.setChangeAmount?.({ changeAmount });
  };

  setDayShift = (dayNumber, shiftNumber) => {
    this.dvrInstance?.setDayShift?.({ dayNumber, shiftNumber });
  };

  setDrawerStatus = (cashDrawerStatus, user) => {
    this.dvrInstance?.setDrawerStatus?.({ cashDrawerStatus, user });
  };

  setSafeCartChangeTrail = cartChangeTrail => {
    this.dvrInstance?.setSafeCartChangeTrail?.({ cartChangeTrail });
  };

  shutdown = () => {
    this.dvrInstance?.shutdown?.();
    this.dvrInstance = null;
  };

  startTransaction = (
    config,
    transactionSeqNumber,
    storeDetails,
    terminalNumber,
    timeStamp,
    transactionType,
    operator,
    user
  ) => {
    if (this.dvrInstance) {
      this.transactionActive = true;
      this.lastSummary = null;
      this.dvrInstance?.startTransaction?.({
        config,
        transactionSeqNumber,
        storeDetails,
        terminalNumber,
        timeStamp,
        transactionType,
        operator,
        user,
      });
    }
  };
}

let dvr = new DVR();
export const createDVR = async (deviceInfo, dvrType) => {
  let dvrInstance;
  switch (dvrType) {
    case dvrTypes.DVR_3xLogic: {
      // eslint-disable-next-line import/extensions
      const module = await import('./3x_logic/dvr.js');
      dvrInstance = module.DVR_3xLogic;
      break;
    }
    case dvrTypes.DVR_ClickIt: {
      // eslint-disable-next-line import/extensions
      const module = await import('./click_it/dvr.js');
      dvrInstance = module.DVR_ClickIt;
      break;
    }
    default:
      dvrInstance = null;
      break;
  }

  dvr = new DVR(dvrInstance);
  if (dvrInstance) {
    dvrInstance.owner = dvr;
  }
  dvr.init(deviceInfo);

  return dvr;
};

export const DVRTypes = dvrTypes;

export const getDVR = () => dvr;
