const { ipcRenderer } = window.require('electron');

let showToast = () => {};

ipcRenderer.on('hardware-log-message', (_, data) => {
  try {
    const log = data.is_error ? global?.logger?.error : global?.logger?.info;
    if (log) {
      log(`[7POS UI] - hardware-log-message ${data.msg}`);
    }
  } catch (e) {
    global?.logger?.error(
      `[7POS UI] - hardware-log-message ${JSON.stringify(e)}`
    );
  }
});

ipcRenderer.on('hardware-log-result', (_, data) => {
  try {
    if (data.module === 'CoinDispenser') {
      if (data.exception) {
        showToast({ description: 'Coin dispenser failed' });
      } else if (data.opos_error) {
        showToast({ description: 'Coin dispenser internal error' });
      } else if (data.http_error) {
        showToast({ description: 'Coin dispenser communication error' });
      }
    }
  } catch (e) {
    global?.logger?.error(
      `[7POS UI] - hardware-log-result ${JSON.stringify(e)}`
    );
  }
});

ipcRenderer.on('hardware-log-status', (_, data) => {
  try {
    if (data.module === 'CoinDispenser') {
      if (data.status.status_code !== 1) {
        let msg;
        const status = 'error';
        switch (data.status.status_code) {
          case 1:
            break;
          case 2:
            msg = 'Coin dispenser is empty';
            break;
          case 3:
            msg = 'Coin dispenser is low';
            break;
          case 4:
            msg = 'Coin dispenser is jammed';
            break;
          default:
            break;
        }

        if (msg) {
          showToast({ description: msg, status });
        }
      }
    }
  } catch (e) {
    global?.logger?.error(
      `[7POS UI] - hardware-log-status ${JSON.stringify(e)}`
    );
  }
});

export const setShowToast = st => {
  showToast = st;
};
