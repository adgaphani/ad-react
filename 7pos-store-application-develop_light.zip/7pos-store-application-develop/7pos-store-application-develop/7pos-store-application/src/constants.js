// PINPAD appQueue/pinpad Events
// Common Events
export const CARD_READ = 'CARD_READ';
export const CAPTURE_HARDTOTALS = 'CAPTURE_HARDTOTALS';
export const WAITING_FOR_CARD = 'WAITING_FOR_CARD';
export const CARD_LOOKUP_PROMPTS = 'CARD_LOOKUP_PROMPTS';
export const WAITING_FOR_EBT_MANUAL_ENTRY = 'WAITING_FOR_EBT_MANUAL_ENTRY';
export const DECLINE = 'DECLINED';
export const CANCEL_PINPAD = 'CANCEL_PINPAD';
export const APPROVED = 'APPROVED';
export const TIMEOUT = 'TIMEOUT';
export const PROMPT_REFERENCE_NUMBER = 'PROMPT_REFERENCE_NUMBER';
export const DEVICE_DISCONNECTED = 'DEVICE_DISCONNECTED';
export const PAYMENT_TERMINATED = 'PAYMENT_TERMINATED';
export const DECLINED_TRANSACTION_NOT_ALLOWED =
  'DECLINED - TRANSACTION NOT ALLOWED';
export const PAYMENT_CANCEL = 'PAYMENT_CANCEL';
export const SWIPE_ID_DATA = 'SWIPE_ID_DATA';
export const BAD_SWIPE = 'BAD_SWIPE';
export const TRANSACTION_RESPONSE = 'TRANSACTION_RESPONSE';
export const PIN_ENTRY_START = 'PIN_ENTRY_START';
export const CMD_NOT_AVAILABLE = 'CMD_NOT_AVAILABLE';
export const ONLINE_REQUEST_TIMER = 'ONLINE_REQUEST_TIMER';
export const PIN_ENTRY_END = 'PIN_ENTRY_END';
export const PAYMENT_PROCESS = 'PAYMENT_PROCESS';
export const PINPAD_RESET_TIMER = 'PINPAD_RESET_TIMER';
export const PINPAD_RESET_START = 'PINPAD_RESET_START';
export const PINPAD_RESET_REMINDER = 'PINPAD_RESET_REMINDER';
export const PINPAD_RESET_START_TOASTER = 'PINPAD RESET STARTED';
export const PINPAD_RESET_SUCCESS_TOASTER = 'PINPAD RESET WAS SUCCESSFUL';
export const DEVICE_INITIALIZED = 'DEVICE_INITIALIZED';
export const PINPAD_UNAVAILABLE = 'PINPAD_UNAVAILABLE';
export const USB_DEVICE_NOT_FOUND = 'USB_DEVICE_NOT_FOUND';

// EBT Events
export const EBT = 'EBT';
export const EBT_ACCOUNT = 'EBT_ACCOUNT';
export const EBTCB = 'EBTCB';
export const EBTSNAP = 'EBTSNAP';
export const INVALID_EBT_ACCOUNT = 'INVALID_EBT_ACCOUNT';

// Fleet Events
export const FLEET = 'FLEET_PROMPTS';
export const FLEET_VOID = 'FLEET_VOID_PROMPTS';

// Cashback Events
export const CASHBACK_RESTRICTION = 'CASHBACK_RESTRICTION';
export const CASHBACK_AMOUNT = 'CASHBACK_AMOUNT';
export const CASHBACK_START = 'CASHBACK_START';

// Refund Events
export const DECLINED_ORIGINALCARD_NOTFOUND = 'DECLINED_ORIGINALCARD_NOTFOUND';
export const DECLINED_ORIGINALSALE_NOTFOUND = 'DECLINED_ORIGINALSALE_NOTFOUND';
export const DECLINED_INVALID_PAYMENT_REQUEST =
  'DECLINED_INVALID_PAYMENT_REQUEST';

// Balance Inquiry
export const BALANCE_INQUIRY = 'BALANCE_INQUIRY';
export const BALANCE_INQUIRY_WAITING_FOR_CARD =
  'BALANCE_INQUIRY_WAITING_FOR_CARD';
export const BALANCE_INQUIRY_TIMEOUT = 'BALANCE_INQUIRY_TIMEOUT';
export const BALANCE_INQUIRY_CANCEL = 'BALANCE_INQUIRY_CANCEL';
export const BALANCE_INQUIRY_CARD_READ = 'BALANCE_INQUIRY_CARD_READ';
export const BALANCE_INQUIRY_INVALID_CARD = 'BALANCE_INQUIRY_INVALID_CARD';

// Signature Capture
export const SIGNATURE_CAPTURE = 'SIGNATURE_CAPTURE';
// Lock Events
// MOM
export const MOM_NOT_INTEGRATED = 'MOM_NOT_INTEGRATED';
export const WAITING_FOR_SC_MOM_LOCK_RESPONSE =
  'WAITING_FOR_SC_MOM_LOCK_RESPONSE';
export const WAITING_FOR_MOM_PING_RESPONSE = 'WAITING_FOR_MOM_PING_RESPONSE';
export const SC_MOM_LOCK_ACQUIRED = 'SC_MOM_LOCK_ACQUIRED';
export const SC_MOM_LOCK_FAILED = 'SC_MOM_LOCK_FAILED';
export const MOM_PING_SUCCESS = 'MOM_PING_SUCCESS';
export const MOM_PING_FAILED = 'MOM_PING_FAILED';
// Safe
export const SAFE_NOT_ENABLED = 'SAFE_NOT_ENABLED';
export const WAITING_FOR_SAFE_LOCK_RESPONSE = 'WAITING_FOR_SAFE_LOCK_RESPONSE';
export const WAITING_FOR_SC_SAFE_LOCK_RESPONSE =
  'WAITING_FOR_SC_SAFE_LOCK_RESPONSE';
export const SC_SAFE_LOCK_ACQUIRED = 'SC_SAFE_LOCK_ACQUIRED';
export const SC_SAFE_LOCK_FAILED = 'SC_SAFE_LOCK_FAILED';
export const SAFE_LOCK_FAILED = 'SAFE_LOCK_FAILED';
export const SAFE_LOCK_SUCCESS = 'SAFE_LOCK_SUCCESS';

export const LOGIN_ERROR = 'Wrong user id or password. Please try again.';
export const MEMBER_NOT_FOUND = 'NOT FOUND';
export const NON_RECOMMENDED_ITEM = 'Non Recommended Item';
export const NUMBER_TYPE = 'number';
export const STRING_TYPE = 'string';
export const STORE_COUPON_CONTENT = `If a coupon does not have an amount or the amount on the coupon
                is greater than the item's selling price, enter the item's
                retail selling price. You cannot enter zero (0) as the amount.`;
export const iNotificationMsg =
  'Please wait for the customer to<br />finish Member Phone Number entry<br /> or press exit to cancel.';

export const iNonMemberMsg =
  'in 2 easy steps<br /><br />Not interested, Force Finalize';

export const momRestrictionMsg =
  'I certify that this is my true and correct name.<br>I am AML/Fraud Trained and will comply with all <br>laws when processing transactions.';

export const momRestrictionNameHeadingMsg =
  'Employee first or last name is missing<br/>on user maintaince record';

export const momRestrictionNameMsg =
  'Contact store operator to request user<br/>ID record be updated.';

export const momRestrictionDeclineHeadingMsg = 'Money Order Sale not allowed';

export const momRestrictionDeclineMsg =
  'You must logoff and log back in using your own<br/>ID to complete a money order sale.';

export const iMemberMsg =
  'Allow customer to enter phone<br />number or scan app/card<br /><br /><br />';
export const MANUFACTURE_COUPON_CONTENT =
  "If a coupon does not have an amount or the amount on the coupon is greater than the item's selling price, enter the item's retail selling price. You cannot enter zero (0) as the amount. ";
export const MANUAL_ENTRY_CONTENT = 'Please enter date of birth.';
export const PARTIAL_PAYMENT_HEADING = 'Partial Payment';
export const INSUFFICENT_PAYMENT_HEADING = 'Available balance on this card is';
export const MONEYORDER_SALE_CONTENT =
  'Please note that customer may only use cash as payment for money orders.';
export const CARWASH_TITLE = 'Select Car Wash';
export const ACCOUNT_LOCKED =
  'Exceeded number of incorrect attempts. Account locked for 24 hours';

export const LOAD_FLG_INVALID = 0;
export const LOAD_FLG_INSALE = 1;

export const MO_FLG_INVALID = 0;
export const MO_FLG_INSALE = 1;
export const MO_FLG_PRINTING = 2;
export const MO_FLG_PRINTED = 3;

export const WSTopics = {
  cashPayment: '/app/payment',
  fis: {
    initiate: '/app/fis/initiate',
    sendCommand: '/app/message/send',
    commandResponse: '/topic/fis/get',
    statusMessage: '/topic/fis/status',
    // initiate: '/topic/fis/initiate',
    // sendCommand: '/topic/app/command/send',
    // commandResponse: '/topic/app/response/receive',
    // statusMessage: '/topic/fis/status',
  },
  cashdrawer: {
    initiate: '/app/cashdrawer',
    listenStatus: '/controlQueue/cashdrawer',
    open: '/app/cashdrawer/openCashDrawer',
  },
};

export const WSSubscriptions = {
  fis: {
    response: 'fis-response-subscription',
    statusMessages: 'fis-status-subscription',
    carwashResponse: 'fis-carwashpresponse-subscription',
  },
};

export const TransactionStates = {
  completed: 'COMPLETED',
  cancelled: 'CANCELLED',
  aborted: 'ABORTED',
  approved: 'APPROVED',
};

export const WorkflowStates = {
  completed: 'COMPLETED',
  cancelled: 'CANCELLED',
};
export const socketStatus = {
  connected: 'CONNECTED',
  disconnected: 'DISCONNECTED',
  error: 'ERROR',
};

export const safeDrop = {
  goodStatus: 'SafeServerStatusGood',
  insertBills: {
    label: 'Insert Bills',
    action: 'safeActionCashDrop',
    type: 'insertBills',
    uLabel: 'INSERT BILLS',
  },
  loadTube: {
    label: 'Load Tube',
    action: 'safeActionTubeLoad',
    type: 'loadTube',
    uLabel: 'LOAD TUBE',
  },
  vendTube: {
    label: 'Vend Tube',
    action: 'safeActionTubeVend',
    type: 'vendTube',
    uLabel: 'VEND TUBE',
  },
  vaultDrop: {
    label: 'Vault Drop Cash',
    action: 'safeActionVaultCash',
    type: 'vaultDrop',
    uLabel: 'VAULT DROP CASH',
  },
  abortTime: 3000,
  statusCode: ['safeHeartbeat', 'safeOffline', 'SafeServerStatusGood'],
  needCashDrawer: ['loadTube', 'vaultDrop'],
  initializeAfter: 30000,
  channels: {
    appQueue: '/appQueue/safe',
    controlQueue: '/controlQueue/safe',
    talkToSafe: '/app/safe/sendRequestToSafe',
    setDayShift: '/app/safe/setDayShift',
    init: '/app/safe',
  },
};

export const CART_HEIGHTS = {
  BASE_CART: 295,
  VOID_CART: 320,
  FUEL_CART: 390,
};
export const STORE_COORDINATOR = {
  config: {
    sender: '7pos-app',
    target: '7pos-store-coordinator',
    serviceName: 'SAFE',
    message: 'LOCK_REQUEST',
  },
  services: {
    safe: 'SAFE',
    moneyOrder: 'MONEY_ORDER',
    start: 'SERVICE_STARTED',
    lock: 'LOCK_REQUEST',
    complete: 'SERVICE_COMPLETED',
    approved: 'LOCK_REQUEST_APPROVED',
    released: 'LOCK_RELEASED',
    completed: 'SERVICE_COMPLETED',
  },
};

export const ChargeReversalFailedMsg = [
  '--------------------------------------',
  '---=== TRANSACTION ABORTED ===---',
  '',
  'STORE OPERATOR: CALL RIS HELP DESK',
  'TO REVERSE THE CHARGES BELOW.',
  '',
  'CUSTOMER: IF YOU ARE UNABLE TO RESOLVE',
  'THESE CHARGES, PLEASE CONTACT 7-ELEVEN',
  'CUSTOMER RELATIONS 1-800-255-0711 WITH',
  'THE INFORMATION BELOW.',
  '',
];

export const print_failure_message =
  'Receipt could not be printed. Please try again';

export const NETWORK_TIMEOUT = 20000;
export const LOCAL_TIMEOUT = 10000;
export const PAYMENT_ERROR = 'PAYMENT_ERROR';
export const RESET_PROMPT_VALUE = 0;

export const ACCOUNT_NBR_PROMPT = 1;
export const AMOUNT_RANGE_PROMPT = 2;
export const AMOUNT_CONFIRM_PROMPT = 3;
export const STTN_ENTRY_PROMPT = 4;
export const RESET_REQUEST_STATUS = 0;
export const LOAD_REQUEST_INPROGRESS = 1;
export const BASE_URI = process.env.BASE_URL || 'localhost';
// export const BASE_URI = '172.26.132.69';
// Adjust to line number for card load fee item in tax call
// set the card load base as 1000
export const CARD_LOAD_BASE_INDEX = 1000;
export const ECO_FEE_BASE_INDEX = 2000;
// PAPI below status code map to Invalid Media for card load
export const PAYMENTDECLINE_INVALIDMEDIA = 252;

/*
When we want to display item in multiple lines, please use this string as a line break.
 */
export const cartItemDelimiter = '::';
export const SAFE_IN_USE = 'Safe in communication. Try again later';
export const FUEL_NOTIFICATION_EXPIRY = 3000;
export const FUEL_RED_BAR_NOTIFICATION_EXPIRY = 1000 * 60;
export const FUEL_STATUS_FOR_NOTIFICATION = ['H', 'E', 'I'];

export const SKIP_PROMO = 1;
export const SKIP_PROMO_TAX = 2;
export const SKIP_PROMO_VALIDATION = 3;
export const EBT_BAG_FEE_DEPT_NUM = '5301'; // Bag fee department 005301xx department number

// Errors

export const SEVENREWARDS_APP_ERROR = '7REWARDS Application Error';

/* SPEEDWAY CONSTANTS */

// banners
export const SEVENELEVEN_ALT_BANNER = 'Enter Your 7REWARDS Phone Number.';
export const SPEEDWAY_ALT_BANNER = 'Enter YOUR SPEEDWAY REWARDS Phone Number.';

// Errors
export const SPEEDWAYREWARDS_APP_ERROR = 'SPEEDY REWARDS Application Error';
// PROD require to disable functional Security
export const isEBTBAGFEEENABLED = true;
export const LOCAL_CHARGE = 6;
export const DRIVE_OFF = 5;

// Vanguard
export const VANGUARD_STANDIN = 'VANGUARD_STANDIN';

// Default value for Max Credit Items
export const MAX_CREDIT_ITEMS = 3;

export const FuelRewardCancelReasons = {
  error: 'Error',
  timeout: 'Timed Out',
  dispenserCanceled: 'Dispenser Canceled',
};

// Receipt Network Message
export const RECEIPT_NETWORK_MESSAGE = 'Network Message';

// Receipt Host Message
export const RECEIPT_HOST_MESSAGE = 'Host Receipt Message';

// 1 for Item, 2 for department , 3 card load, 4 fuel
export const ITEM_TYPE = {
  PLU: 1,
  DEPT: 2,
  CARD_LOAD: 3,
  FUEL: 4,
};
