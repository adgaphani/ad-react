module.exports = {
  parser: 'babel-eslint',
  env: {
    browser: true,
    es6: true,
  },
  extends: [
    'plugin:react/recommended', // Uses the recommended rules from @eslint-plugin-react
    'plugin:prettier/recommended', // Enables eslint-plugin-prettier and displays prettier errors as ESLint errors. Make sure this is always the last configuration in the extends array.
    'prettier/react', // disables react-specific linting rules that conflict with prettier
    'eslint:recommended',
    'airbnb',
    'plugin:jest/recommended',
    'plugin:import/errors',
    'prettier',
  ],
  globals: {
    Messages: true,
    Logger: true,
    IS_DEV: true,
    PumpStates: true,
    CHANNEL: true,
  },
  plugins: ['react', 'prettier', 'react-hooks'],
  rules: {
    'react/display-name': 'off',
    'arrow-body-style': 'error',
    'lines-between-class-members': 'error',
    'no-var': 'error',
    'prefer-const': 'error',
    'prefer-destructuring': 'error',
    'max-lines': [
      'off',
      { max: 500, skipBlankLines: true, skipComments: true },
    ],
    'import/order': 'error',
    'react/destructuring-assignment': 'error',
    'react/require-default-props': 'warn',
    'react/sort-comp': 'error',
    'react/no-unused-state': 'error',
    'react/no-unused-prop-types': 'error',
    'react/prop-types': 'off',
    'prettier/prettier': 'error',
    'import/prefer-default-export': 'off',
    'import/no-extraneous-dependencies': 'off',
    'react/jsx-filename-extension': 'off',
    'react/forbid-prop-types': 'off',
    'consistent-return': 'off',
    'no-shadow': 'off',
    'no-param-reassign': 'off',
    'no-unused-expressions': 'off',
    'global-require': 'off',
    'react/jsx-one-expression-per-line': 'off',
    'react/no-array-index-key': 'off',
    'camel-case': 'off',
    'import/no-cycle': 'off',
    'no-restricted-globals': 'off',
    'no-console': 'off',
    'prefer-promise-reject-errors': 'off',
    camelcase: 'off',
    'no-nested-ternary': 'off',
    'import/no-named-as-default': 'off',
  },
  settings: {
    react: {
      version: 'detect', // Tells eslint-plugin-react to automatically detect the version of React to use
    },
    'import/resolver': {
      alias: {
        map: [
          ['@icons', './src/Icons'],
          ['@fuelIcons', './src/Icons/fuelIcons'],
        ],
        extensions: ['.ts', '.js', '.jsx', '.json'],
      },
    },
  },
};
